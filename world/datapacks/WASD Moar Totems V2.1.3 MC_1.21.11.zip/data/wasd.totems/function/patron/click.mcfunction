#mc-build WASD content
execute if predicate wasd.totems:holding_item/click_totem1 run function wasd.totems:patron/click/defence
execute if predicate wasd.totems:holding_item/click_totem2 run function wasd.totems:patron/click/regeneration
execute if predicate wasd.totems:holding_item/click_totem3 run function wasd.totems:patron/click/experience
execute if predicate wasd.totems:holding_item/click_totem4 run function wasd.totems:patron/click/shielding
execute if predicate wasd.totems:holding_item/click_totem5 run function wasd.totems:patron/click/withering
#mc-build WASD content
function wasd.lib:util/uuid_to_scoreboard
execute at @e[type=item_display,tag=wasd.totem_entity,tag=wasd.withering] if score @e[type=item_display,tag=wasd.totem_entity,tag=wasd.withering,sort=nearest,limit=1] wasd.uuid1 = @s wasd.uuid1 if score @e[type=item_display,tag=wasd.totem_entity,tag=wasd.withering,sort=nearest,limit=1] wasd.uuid2 = @s wasd.uuid2 if score @e[type=item_display,tag=wasd.totem_entity,tag=wasd.withering,sort=nearest,limit=1] wasd.uuid3 = @s wasd.uuid3 if score @e[type=item_display,tag=wasd.totem_entity,tag=wasd.withering,sort=nearest,limit=1] wasd.uuid4 = @s wasd.uuid4 run tag @s add wasd.already_placed_totem
execute as @s[tag=!wasd.already_placed_totem] run function wasd.totems:patron/click/zzz/8
tag @s remove wasd.already_placed_totem
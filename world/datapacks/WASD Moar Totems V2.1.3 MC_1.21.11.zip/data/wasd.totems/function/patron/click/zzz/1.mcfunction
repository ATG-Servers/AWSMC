#mc-build WASD content
execute store result score @s wasd.uuid1 run data get entity @p UUID[0]
execute store result score @s wasd.uuid2 run data get entity @p UUID[1]
execute store result score @s wasd.uuid3 run data get entity @p UUID[2]
execute store result score @s wasd.uuid4 run data get entity @p UUID[3]
#mc-build WASD content
loot give @s loot wasd.totems:items/patron/defence
loot give @s loot wasd.totems:items/patron/regeneration
loot give @s loot wasd.totems:items/patron/experience
loot give @s loot wasd.totems:items/patron/shielding
loot give @s loot wasd.totems:items/patron/withering
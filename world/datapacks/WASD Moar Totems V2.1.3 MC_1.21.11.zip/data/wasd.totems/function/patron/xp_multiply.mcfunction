#mc-build WASD content
playsound entity.experience_orb.pickup player @a ~ ~ ~ 0.5 1.2
particle dust_color_transition{from_color:[0.000,0.592,0.012],scale:2,to_color:[0.400,1.000,0.000]} ~ ~ ~ 0.2 0.2 0.2 0 3 force
tag @s add wasd.totem_multiplied_xp
execute store result score @s wasd.temp run data get entity @e[type=minecraft:experience_orb,limit=1] Value 100
execute store result entity @s Value short 0.015 run scoreboard players get @s wasd.temp
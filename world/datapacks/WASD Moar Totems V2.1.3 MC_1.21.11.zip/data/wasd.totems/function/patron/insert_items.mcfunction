#mc-build WASD content
loot insert ~ ~ ~ loot wasd.totems:items/patron/defence
loot insert ~ ~ ~ loot wasd.totems:items/patron/regeneration
loot insert ~ ~ ~ loot wasd.totems:items/patron/experience
loot insert ~ ~ ~ loot wasd.totems:items/patron/shielding
loot insert ~ ~ ~ loot wasd.totems:items/patron/withering
#mc-build WASD content
rotate @s ~5 ~
particle dust_color_transition{from_color:[0.000,0.592,0.012],scale:2,to_color:[0.400,1.000,0.000]} ^ ^0.1 ^7
particle dust_color_transition{from_color:[0.000,0.592,0.012],scale:2,to_color:[0.400,1.000,0.000]} ^7 ^0.1 ^
particle dust_color_transition{from_color:[0.000,0.592,0.012],scale:2,to_color:[0.400,1.000,0.000]} ^-7 ^0.1 ^
particle dust_color_transition{from_color:[0.000,0.592,0.012],scale:2,to_color:[0.400,1.000,0.000]} ^ ^0.1 ^-7
execute positioned ^ ^ ^2 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-2 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^2 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-2 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^3 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-3 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^3 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-3 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^4 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-4 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^4 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-4 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^5 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-5 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^5 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-5 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^6 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-6 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^6 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-6 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^7 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^ ^ ^-7 as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^7 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
execute positioned ^-7 ^ ^ as @e[type=experience_orb,tag=!wasd.totem_multiplied_xp,distance=..2] at @s run function wasd.totems:patron/xp_multiply
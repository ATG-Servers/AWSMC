#mc-build WASD content
scoreboard players add @s wasd.timer 1
scoreboard players add @s wasd.temp 1
scoreboard players add @s wasd.temp2 1
execute as @e[type=#wasd.tags:fireballs,distance=..7,tag=!wasd.stopped] at @s run function wasd.totems:patron/entities/zzz/27
execute as @e[type=#wasd.tags:projectiles,distance=..7,tag=!wasd.stopped] at @s run function wasd.totems:patron/entities/zzz/28
execute as @s[scores={wasd.temp2=2}] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1f,0f],scale:[1.03f,1.03f,1.03f]}}
execute as @s[scores={wasd.temp2=20}] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.47f,0f],scale:[1.01f,1.01f,1.01f]}}
scoreboard players set @s[scores={wasd.temp2=40..}] wasd.temp2 1
execute as @s[scores={wasd.timer=200..}] run function wasd.totems:patron/entities/zzz/29
execute on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/30
execute as @s[scores={wasd.temp=5}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/31
execute as @s[scores={wasd.temp=10}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/32
execute as @s[scores={wasd.temp=15}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/33
execute as @s[scores={wasd.temp=20}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/34
execute as @s[scores={wasd.temp=25}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/35
execute as @s[scores={wasd.temp=30}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/36
execute as @s[scores={wasd.temp=35}] on passengers as @s[tag=wasd.shielding] at @s run function wasd.totems:patron/entities/zzz/37
scoreboard players reset @s[scores={wasd.temp=35..}] wasd.temp
#mc-build WASD content
rotate @s ~5 ~
particle dust_color_transition{from_color:[0.000,1.000,0.984],scale:2,to_color:[0.000,0.051,1.000]} ^ ^0.1 ^7
particle dust_color_transition{from_color:[0.000,1.000,0.984],scale:2,to_color:[0.000,0.051,1.000]} ^7 ^0.1 ^
particle dust_color_transition{from_color:[0.000,1.000,0.984],scale:2,to_color:[0.000,0.051,1.000]} ^-7 ^0.1 ^
particle dust_color_transition{from_color:[0.000,1.000,0.984],scale:2,to_color:[0.000,0.051,1.000]} ^ ^0.1 ^-7
execute positioned ^ ^ ^ run effect give @a[distance=..1] minecraft:resistance 2 2 true
execute positioned ^ ^ ^2 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-2 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^2 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-2 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^3 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-3 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^3 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-3 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^4 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-4 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^4 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-4 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^5 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-5 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^5 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-5 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^6 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-6 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^6 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-6 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^7 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^ ^ ^-7 run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^7 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
execute positioned ^-7 ^ ^ run effect give @a[distance=..2] minecraft:resistance 2 2 true
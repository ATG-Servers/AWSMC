#mc-build WASD content
rotate @s ~5 ~
particle dust_color_transition{from_color:[1.000,0.431,0.431],scale:2,to_color:[1.000,0.000,0.000]} ^ ^0.1 ^7
particle dust_color_transition{from_color:[1.000,0.431,0.431],scale:2,to_color:[1.000,0.000,0.000]} ^7 ^0.1 ^
particle dust_color_transition{from_color:[1.000,0.431,0.431],scale:2,to_color:[1.000,0.000,0.000]} ^-7 ^0.1 ^
particle dust_color_transition{from_color:[1.000,0.431,0.431],scale:2,to_color:[1.000,0.000,0.000]} ^ ^0.1 ^-7
execute as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^2 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-2 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^2 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-2 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^3 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-3 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^3 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-3 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^4 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-4 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^4 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-4 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^5 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-5 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^5 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-5 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^6 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-6 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^6 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-6 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^7 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^ ^ ^-7 as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^7 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
execute positioned ^-7 ^ ^ as @a[distance=..2] unless predicate wasd.lib:active_effects/regeneration run effect give @s minecraft:regeneration 2 2 true
#mc-build WASD content
tag @s add wasd.stopped
data merge entity @s {Motion:[0.0,-0.5,0.0]}
particle large_smoke ~ ~ ~ 0.1 0.1 0.1 0.05 5 force
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 1 1.5
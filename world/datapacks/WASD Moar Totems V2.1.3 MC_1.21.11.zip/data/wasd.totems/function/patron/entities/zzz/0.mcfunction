#mc-build WASD content
execute on passengers as @s[tag=wasd.defence] run kill @s
kill @s
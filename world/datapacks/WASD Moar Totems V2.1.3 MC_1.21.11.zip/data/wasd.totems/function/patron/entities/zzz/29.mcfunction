#mc-build WASD content
execute on passengers as @s[tag=wasd.shielding] run kill @s
kill @s
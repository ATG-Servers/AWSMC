#mc-build WASD content
execute on passengers as @s[tag=wasd.withering] run kill @s
kill @s
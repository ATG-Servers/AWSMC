#mc-build WASD content
rotate @s ~5 ~
particle dust_color_transition{from_color:[0.259,0.000,0.000],scale:3,to_color:[0.725,0.000,0.000]} ^ ^0.1 ^7
particle dust_color_transition{from_color:[0.259,0.000,0.000],scale:3,to_color:[0.725,0.000,0.000]} ^7 ^0.1 ^
particle dust_color_transition{from_color:[0.259,0.000,0.000],scale:3,to_color:[0.725,0.000,0.000]} ^-7 ^0.1 ^
particle dust_color_transition{from_color:[0.259,0.000,0.000],scale:3,to_color:[0.725,0.000,0.000]} ^ ^0.1 ^-7
execute as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^2 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-2 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^2 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-2 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-3 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^3 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-3 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^4 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-4 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^4 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-4 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^5 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-5 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^5 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-5 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^6 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-6 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^6 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-6 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^7 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^ ^ ^-7 as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^7 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute positioned ^-7 ^ ^ as @e[type=#wasd.tags:mobs_player,distance=..2] unless predicate wasd.lib:active_effects/wither run tag @s add wasd.should_wither_by_totem
execute as @e[type=#wasd.tags:mobs,distance=..10,tag=wasd.should_wither_by_totem] run function wasd.totems:patron/entities/zzz/40
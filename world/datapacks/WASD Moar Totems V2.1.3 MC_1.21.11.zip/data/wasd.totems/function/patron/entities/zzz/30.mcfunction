#mc-build WASD content
rotate @s ~5 ~
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^0.1 ^7
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^7 ^0.1 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^-7 ^0.1 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^0.1 ^-7
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^1.5 ^7
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^7 ^1.5 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^-7 ^1.5 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^1.5 ^-7
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^3 ^7
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^7 ^3 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^-7 ^3 ^
particle dust{color:[0.392, 0.392, 0.392], scale:3.0} ^ ^3 ^-7
#mc-build WASD content
tag @s remove wasd.should_wither_by_totem
effect give @s minecraft:wither 2 1 true
#mc-build WASD content
scoreboard players add @s wasd.timer 1
scoreboard players add @s wasd.temp 1
scoreboard players add @s wasd.temp2 1
execute as @s[scores={wasd.temp2=2}] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1f,0f],scale:[1.03f,1.03f,1.03f]}}
execute as @s[scores={wasd.temp2=20}] run data merge entity @s {start_interpolation:-1,interpolation_duration:20,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.47f,0f],scale:[1.01f,1.01f,1.01f]}}
scoreboard players set @s[scores={wasd.temp2=40..}] wasd.temp2 1
execute as @s[scores={wasd.timer=200..}] run function wasd.totems:patron/entities/zzz/9
execute on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/10
execute as @s[scores={wasd.temp=5}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/11
execute as @s[scores={wasd.temp=10}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/12
execute as @s[scores={wasd.temp=15}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/13
execute as @s[scores={wasd.temp=20}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/14
execute as @s[scores={wasd.temp=25}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/15
execute as @s[scores={wasd.temp=30}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/16
execute as @s[scores={wasd.temp=35}] on passengers as @s[tag=wasd.regeneration] at @s run function wasd.totems:patron/entities/zzz/17
scoreboard players reset @s[scores={wasd.temp=35..}] wasd.temp
#mc-build WASD content
tag @s add wasd.stopped
kill @s
particle large_smoke ~ ~ ~ 0.1 0.1 0.1 0.05 5 force
playsound block.lava.extinguish player @a ~ ~ ~ 1 1.5
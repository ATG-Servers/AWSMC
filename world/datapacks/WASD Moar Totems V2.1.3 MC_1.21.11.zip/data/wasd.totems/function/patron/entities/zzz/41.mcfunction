#mc-build WASD content
execute if score @p[tag=wasd.should_wither_by_totem] wasd.uuid1 = @s wasd.uuid1 if score @p[tag=wasd.should_wither_by_totem] wasd.uuid2 = @s wasd.uuid2 if score @p[tag=wasd.should_wither_by_totem] wasd.uuid3 = @s wasd.uuid3 if score @p[tag=wasd.should_wither_by_totem] wasd.uuid4 = @s wasd.uuid4 run tag @p[tag=wasd.should_wither_by_totem] remove wasd.should_wither_by_totem
effect give @s[tag=wasd.should_wither_by_totem] minecraft:wither 2 1 true
tag @s remove wasd.should_wither_by_totem
#mc-build WASD content
execute on passengers as @s[tag=wasd.experience] run kill @s
kill @s
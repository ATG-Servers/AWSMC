#mc-build WASD content
execute as @s[tag=wasd.defence] run function wasd.totems:patron/entities/defence
execute as @s[tag=wasd.regeneration] run function wasd.totems:patron/entities/regeneration
execute as @s[tag=wasd.experience] run function wasd.totems:patron/entities/experience
execute as @s[tag=wasd.shielding] run function wasd.totems:patron/entities/shielding
execute as @s[tag=wasd.withering] run function wasd.totems:patron/entities/withering
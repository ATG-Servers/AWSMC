#mc-build WASD content
advancement revoke @a only wasd.hammers:give_all_recipes
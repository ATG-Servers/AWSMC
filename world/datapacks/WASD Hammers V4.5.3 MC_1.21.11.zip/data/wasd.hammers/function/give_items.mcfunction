#mc-build WASD content
loot give @s loot wasd.hammers:1
loot give @s loot wasd.hammers:2
loot give @s loot wasd.hammers:3
loot give @s loot wasd.hammers:4
loot give @s loot wasd.hammers:5
loot give @s loot wasd.hammers:6
loot give @s loot wasd.hammers:7
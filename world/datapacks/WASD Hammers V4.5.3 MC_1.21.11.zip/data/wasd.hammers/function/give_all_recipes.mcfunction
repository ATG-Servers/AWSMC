#mc-build WASD content
recipe give @s wasd.hammers:1
recipe give @s wasd.hammers:2
recipe give @s wasd.hammers:3
recipe give @s wasd.hammers:4
recipe give @s wasd.hammers:5
recipe give @s wasd.hammers:6
recipe give @s wasd.hammers:7
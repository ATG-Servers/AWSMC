execute as @e[type=text_display,tag=mt.marker,predicate=!mt:no_vehicle] run kill @s

schedule function mt:treasure/clear_text_display 1200t replace
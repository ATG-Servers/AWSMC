execute if score @s mt.plot matches 8 run function mt:particles/legendary/deep_darkframes/f8
execute if score @s mt.plot matches 9 run function mt:particles/legendary/deep_darkframes/f9
execute if score @s mt.plot matches 10 run function mt:particles/legendary/deep_darkframes/f10
execute if score @s mt.plot matches 11 run function mt:particles/legendary/deep_darkframes/f11
execute if score @s mt.plot matches 12 run function mt:particles/legendary/deep_darkframes/f12
execute if score @s mt.plot matches 13 run function mt:particles/legendary/deep_darkframes/f13
execute if score @s mt.plot matches 14 run function mt:particles/legendary/deep_darkframes/f14
execute if score @s mt.plot matches 15 run function mt:particles/legendary/deep_darkframes/f15

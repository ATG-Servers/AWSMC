execute if score @s mt.plot matches 0 run function mt:particles/legendary/default_end/frames/f0
execute if score @s mt.plot matches 1 run function mt:particles/legendary/default_end/frames/f1
execute if score @s mt.plot matches 2 run function mt:particles/legendary/default_end/frames/f2
execute if score @s mt.plot matches 3 run function mt:particles/legendary/default_end/frames/f3
execute if score @s mt.plot matches 4 run function mt:particles/legendary/default_end/frames/f4
execute if score @s mt.plot matches 5 run function mt:particles/legendary/default_end/frames/f5
execute if score @s mt.plot matches 6 run function mt:particles/legendary/default_end/frames/f6
execute if score @s mt.plot matches 7 run function mt:particles/legendary/default_end/frames/f7

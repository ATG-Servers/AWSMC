#mc-build WASD content
execute if predicate wasd.crossbow:holding_item/custom_crossbow unless entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{levels:{"minecraft:multishot":1}}}}}] run function wasd.crossbow:determine_crossbow
execute if predicate wasd.crossbow:holding_item/custom_crossbow if entity @s[nbt={SelectedItem:{components:{"minecraft:enchantments":{levels:{"minecraft:multishot":1}}}}}] run function wasd.crossbow:determine_crossbow_multishot
scoreboard players reset @s wasd.shoot_cbow
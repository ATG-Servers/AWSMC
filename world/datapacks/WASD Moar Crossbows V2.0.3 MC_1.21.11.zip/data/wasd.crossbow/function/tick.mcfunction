#mc-build WASD content
#slime levitation
execute as @e[tag=wasd.slime_launched_crossbow] run effect clear @s minecraft:levitation
execute as @e[tag=wasd.slime_launched_crossbow] run tag @s remove wasd.slime_launched_crossbow
#arrow particles
execute as @e[type=arrow,tag=wasd.custom_crossbow_arrow] at @s run function wasd.crossbow:determine_arrow
execute as @a at @s run function wasd.crossbow:as_players
execute as @e[tag=wasd.crossbow_laser] at @s run function wasd.crossbow:arrows/laser_trace
#determine hit
execute unless score arrow_count w.xbow_setting = arrow_shot w.xbow_setting as @e[type=#wasd.tags:mobs_player] at @s if data entity @s active_effects as @s[nbt={active_effects:[{id:"minecraft:unluck"}]}] run function wasd.crossbow:arrow_hit
scoreboard players operation arrow_count w.xbow_setting = arrow_shot w.xbow_setting
scoreboard players set arrow_shot w.xbow_setting 0
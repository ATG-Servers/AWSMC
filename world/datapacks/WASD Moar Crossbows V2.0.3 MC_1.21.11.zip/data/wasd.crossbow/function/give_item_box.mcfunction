#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.crossbow:items/burst
loot insert ~ ~ ~ loot wasd.crossbow:items/dragon_breath
loot insert ~ ~ ~ loot wasd.crossbow:items/egg
loot insert ~ ~ ~ loot wasd.crossbow:items/laser
loot insert ~ ~ ~ loot wasd.crossbow:items/quickload
loot insert ~ ~ ~ loot wasd.crossbow:items/zooming
function wasd.crossbow:insert_items
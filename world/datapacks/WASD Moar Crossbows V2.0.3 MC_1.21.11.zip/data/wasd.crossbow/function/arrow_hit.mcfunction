#mc-build WASD content
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:50b}]}] run function wasd.crossbow:crossbows/dragon_breath
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:101b}]}] run function wasd.crossbow:crossbows/patron/ice
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:102b}]}] run function wasd.crossbow:crossbows/patron/lightning
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:103b}]}] run function wasd.crossbow:crossbows/patron/honey
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:104b}]}] run function wasd.crossbow:crossbows/patron/slime
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:105b}]}] run function wasd.crossbow:crossbows/patron/firework
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:106b}]}] run function wasd.crossbow:crossbows/patron/tnt
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:107b}]}] run function wasd.crossbow:crossbows/patron/critical
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:108b}]}] run function wasd.crossbow:crossbows/patron/rainbow
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:109b}]}] run function wasd.crossbow:crossbows/patron/quartz
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:110b}]}] run function wasd.crossbow:crossbows/patron/prismarine
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:111b}]}] run function wasd.crossbow:crossbows/patron/shulker
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:112b}]}] run function wasd.crossbow:crossbows/patron/chorus
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:115b}]}] run function wasd.crossbow:crossbows/patron/glowstone
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:117b}]}] run function wasd.crossbow:crossbows/patron/emerald
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:118b}]}] run function wasd.crossbow:crossbows/shared
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:119b}]}] run function wasd.crossbow:crossbows/shared
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:120b}]}] run function wasd.crossbow:crossbows/patron/random
execute as @s[nbt={active_effects:[{id:"minecraft:unluck",amplifier:121b}]}] run function wasd.crossbow:crossbows/patron/armor_piercing
scoreboard players reset @s wasd.shoot_bow
#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_crossbows wasd_data_packs 1
scoreboard objectives add wasd.shoot_cbow minecraft.used:minecraft.crossbow
scoreboard objectives add wasd.crossbow_type dummy
scoreboard objectives add wasd.burst_timer dummy
scoreboard objectives add w.xbow_setting dummy
scoreboard objectives add w.bows_settings dummy
function wasd.crossbow:config
schedule function wasd.crossbow:check_installed_packs 30t replace
#mc-build WASD content
execute as @s[scores={wasd.shoot_cbow=1..}] run function wasd.crossbow:zzz/1
execute as @s[tag=wasd.crossbow_burst] run function wasd.crossbow:player/burst
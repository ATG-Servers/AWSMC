#mc-build WASD content
scoreboard players add @s wasd.burst_timer 1
execute as @s[scores={ wasd.burst_timer=3}] run function wasd.crossbow:player/burst_shot
execute as @s[scores={wasd.burst_timer=6}] run function wasd.crossbow:player/burst_shot
execute as @s[scores={wasd.burst_timer=9}] run function wasd.crossbow:player/burst_shot
execute as @s[scores={wasd.burst_timer=12}] run function wasd.crossbow:player/burst_shot
execute as @s[scores={wasd.burst_timer=12..}] run tag @s remove wasd.crossbow_burst
execute as @s[scores={wasd.burst_timer=12..}] run scoreboard players reset @s wasd.burst_timer
#mc-build WASD content
summon arrow ~ ~1.6 ~ {life:1200,ShotFromCrossbow:1b,Tags:["wasd.burst","wasd.custom_crossbow_arrow"]}
execute positioned ~ ~1.6 ~ as @e[type=arrow,tag=wasd.burst,tag=wasd.custom_crossbow_arrow,limit=1,sort=nearest] positioned ^ ^ ^30 run function wasd.lib:math/apply_motion
playsound minecraft:item.crossbow.shoot player @a ~ ~ ~ 1 1
#mc-build WASD content
#Enable/Disable recipes. 1 = Enabled/True. 0= Disabled/False.
#Should arrows have particle trails?
scoreboard players set particles w.xbow_setting 1
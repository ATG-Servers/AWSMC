#mc-build WASD content
function wasd.crossbow:crossbows/shared
summon area_effect_cloud ~ ~ ~ {custom_particle:{type:"dragon_breath"},ReapplicationDelay:20,RadiusPerTick:-0.01f,RadiusOnUse:-0.25f,Radius:2.5f,Duration:150,DurationOnUse:15f,potion_contents:{custom_effects:[{id:"minecraft:instant_damage",amplifier:0,duration:1}]}}
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 1
#mc-build WASD content
execute if score particles w.xbow_setting matches 1 run particle minecraft:dragon_breath ~ ~ ~ 0.1 0.1 0.1 0.02 5 force
execute as @s[nbt={inGround:1b}] run summon area_effect_cloud ~ ~ ~ {custom_particle:{type:"dragon_breath"},ReapplicationDelay:20,RadiusPerTick:-0.01f,RadiusOnUse:-0.25f,Radius:2.5f,Duration:150,DurationOnUse:15f,potion_contents:{custom_effects:[{id:"minecraft:instant_damage",amplifier:0,duration:1}]}}
execute as @s[nbt={inGround:1b}] run playsound minecraft:entity.generic.explode player @a ~ ~ ~ 2 1
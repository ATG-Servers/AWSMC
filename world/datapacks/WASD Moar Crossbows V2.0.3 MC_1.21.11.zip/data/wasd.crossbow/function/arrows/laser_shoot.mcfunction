#mc-build WASD content
summon area_effect_cloud ~ ~ ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.crossbow_laser"]}
tp @e[tag=wasd.crossbow_laser,limit=1,sort=nearest] ~ ~1.6 ~ ~ ~
execute as @e[tag=wasd.crossbow_laser,limit=1,sort=nearest] at @s run function wasd.crossbow:arrows/laser
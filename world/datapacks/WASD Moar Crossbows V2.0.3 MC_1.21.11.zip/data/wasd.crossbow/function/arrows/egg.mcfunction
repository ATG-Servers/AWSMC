#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1}] run summon egg
execute as @s[scores={wasd.timer=5..}] run scoreboard players reset @s wasd.timer
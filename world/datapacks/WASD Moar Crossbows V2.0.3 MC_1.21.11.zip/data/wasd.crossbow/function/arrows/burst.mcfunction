#mc-build WASD content
execute if score particles w.xbow_setting matches 1 run particle dust{color:[0.435, 0.78, 0.451], scale:2.0} ~ ~ ~ 0.1 0.1 0.1 0.02 1 force
#mc-build WASD content
particle minecraft:dust{color:[1.0, 0.0, 0.0], scale:1.0} ~ ~ ~ 0 0 0 1 1 force
tp @s ~ ~ ~
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=300..}]
execute as @s[scores={wasd.timer=5..}] positioned ^ ^ ^0.2 positioned ~ ~1 ~ as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 4 minecraft:arrow
execute as @s[scores={wasd.timer=5..}] positioned ^ ^ ^0.2 positioned ~ ~ ~ as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 4 minecraft:arrow
execute as @s[scores={wasd.timer=5..}] positioned ^ ^ ^0.2 positioned ~ ~-1 ~ as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 4 minecraft:arrow
execute positioned ~ ~ ~ unless block ^ ^ ^0.7 #wasd.tags:nonsolid run setblock ~ ~ ~ fire keep
execute unless score @s wasd.timer matches 300.. positioned ^ ^ ^0.2 if block ^ ^ ^0.5 #wasd.tags:nonsolid positioned ~ ~1 ~ unless entity @e[type=#wasd.tags:mobs,distance=..1] positioned ~ ~-1 ~ unless entity @e[type=#wasd.tags:mobs,distance=..1] positioned ~ ~-1 ~ unless entity @e[type=#wasd.tags:mobs,distance=..1] positioned ~ ~1 ~ run function wasd.crossbow:arrows/laser
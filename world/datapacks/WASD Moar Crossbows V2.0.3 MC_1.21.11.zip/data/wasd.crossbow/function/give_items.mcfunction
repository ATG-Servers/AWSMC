#mc-build WASD content
loot give @s loot wasd.crossbow:items/burst
loot give @s loot wasd.crossbow:items/dragon_breath
loot give @s loot wasd.crossbow:items/egg
loot give @s loot wasd.crossbow:items/laser
loot give @s loot wasd.crossbow:items/quickload
loot give @s loot wasd.crossbow:items/zooming
function wasd.crossbow:give_items_patron
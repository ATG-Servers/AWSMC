#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_shovel wasd_data_packs 1
scoreboard objectives remove wasd.used_shovel
scoreboard objectives add wasd.used_shovel minecraft.used:minecraft.stone_shovel
scoreboard objectives add wasd.shovel_click minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add w.shovel_setting dummy
#enable crafter
scoreboard objectives add wasd.lib_setting dummy
scoreboard players set wasd.crafter wasd.lib_setting 1
schedule function wasd.shovel:outdated_lib 1t replace
function wasd.shovel:config
schedule function wasd.shovel:check_installed_packs 30t replace
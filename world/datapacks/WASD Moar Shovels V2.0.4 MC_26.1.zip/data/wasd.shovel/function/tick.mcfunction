#mc-build WASD content
execute as @a at @s run function wasd.shovel:as_players
execute as @e[tag=wasd.shovel_entity_tick] at @s run function wasd.shovel:as_entities
#mc-build WASD content
execute unless entity @a[advancements={wasd.installed:library=true}] run function wasd.shovel:zzz/0
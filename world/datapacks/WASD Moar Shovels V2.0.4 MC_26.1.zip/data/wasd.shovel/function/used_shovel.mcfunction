#mc-build WASD content
execute if predicate wasd.shovel:holding_item/shovel1 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:code/excavator
execute if predicate wasd.shovel:holding_item/shovel2 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:code/digger
execute if predicate wasd.shovel:holding_item/shovel3 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:code/magnetic
execute if predicate wasd.shovel:holding_item/shovel4 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:code/diamond_excavator
execute if predicate wasd.shovel:holding_item/shovel5 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:code/diamond_digger
execute if predicate wasd.shovel:holding_item/shovel6 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:patron/code/snow
#this is meant to be used on right-click making a path rather than mining
execute if predicate wasd.shovel:holding_item/shovel7 run function wasd.shovel:patron/code/path
execute if predicate wasd.shovel:holding_item/shovel8 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:patron/code/molten
execute if predicate wasd.shovel:holding_item/shovel9 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:patron/code/giant
execute if predicate wasd.shovel:holding_item/shovel10 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.shovel:patron/code/weedkiller
scoreboard players reset @s wasd.used_shovel
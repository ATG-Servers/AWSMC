#mc-build WASD content
execute if predicate wasd.shovel:holding_item/shovel11 run function wasd.shovel:patron/code/vacuum
#reset at the end so you can execute at the player that just clicked.
scoreboard players reset @s wasd.shovel_click
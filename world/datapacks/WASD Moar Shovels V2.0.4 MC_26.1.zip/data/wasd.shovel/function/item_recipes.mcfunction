#mc-build WASD content
recipe give @s wasd.shovel:items/digger
recipe give @s wasd.shovel:items/magnetic
recipe give @s wasd.shovel:items/excavator
recipe give @s wasd.shovel:items/diamond_excavator
recipe give @s wasd.shovel:items/diamond_digger
recipe give @s wasd.shovel:items/patron/vacuum
recipe give @s wasd.shovel:items/patron/weedkiller
recipe give @s wasd.shovel:items/patron/path
recipe give @s wasd.shovel:items/patron/snow
recipe give @s wasd.shovel:items/patron/giant_diamond
recipe give @s wasd.shovel:items/patron/molten
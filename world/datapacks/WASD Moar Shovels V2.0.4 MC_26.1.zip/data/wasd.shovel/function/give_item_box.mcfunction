#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.shovel:items/excavator
loot insert ~ ~ ~ loot wasd.shovel:items/digger
loot insert ~ ~ ~ loot wasd.shovel:items/magnetic
loot insert ~ ~ ~ loot wasd.shovel:items/diamond_excavator
loot insert ~ ~ ~ loot wasd.shovel:items/diamond_digger
function wasd.shovel:patron/insert_items
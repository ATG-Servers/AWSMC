#mc-build WASD content
function wasd.shovel:invalid_mine
execute unless entity @s[tag=wasd.invalid_mine_attempt] run function wasd.shovel:code/zzz/7
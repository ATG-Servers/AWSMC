#mc-build WASD content
data modify entity @s Rotation set from entity @p[scores={wasd.used_shovel=1..},predicate=wasd.shovel:holding_item/shovel1] Rotation
execute as @s[x_rotation=45..90] run tag @s add down
execute as @s[x_rotation=-90..-45] run tag @s add up
execute as @s[y_rotation=45..135] run tp @s ~ ~ ~ 90 ~
execute as @s[y_rotation=136..225] run tp @s ~ ~ ~ 180 ~
execute as @s[y_rotation=226..315] run tp @s ~ ~ ~ 270 ~
execute as @s[y_rotation=316..44] run tp @s ~ ~ ~ 0 ~
execute as @s[tag=!up,tag=!down] rotated as @s align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.shovel:code/zzz/1
execute as @s[tag=up] rotated 0 -90 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.shovel:code/zzz/2
execute as @s[tag=down] rotated 0 90 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.shovel:code/zzz/3
execute at @e[tag=wasd.mining_location] if block ~ ~ ~ #minecraft:mineable/shovel run function wasd.shovel:code/zzz/4
kill @e[tag=wasd.mining_location]
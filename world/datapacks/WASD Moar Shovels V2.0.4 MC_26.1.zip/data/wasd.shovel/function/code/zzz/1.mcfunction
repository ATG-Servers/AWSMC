#mc-build WASD content
summon minecraft:marker ^1 ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^1 ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^1 ^-1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^-1 ^ {Tags:["wasd.mining_location"]}
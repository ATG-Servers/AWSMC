#mc-build WASD content
summon minecraft:marker ^ ^ ^ {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^-1 ^ {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^ ^1 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^-1 ^1 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^ ^2 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^-1 ^2 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^ ^3 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^-1 ^3 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^ ^4 {Tags:["wasd.digging_location"]}
summon minecraft:marker ^ ^-1 ^4 {Tags:["wasd.digging_location"]}
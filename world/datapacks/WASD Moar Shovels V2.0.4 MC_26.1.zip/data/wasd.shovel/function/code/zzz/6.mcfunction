#mc-build WASD content
execute as @p[scores={wasd.used_shovel=1..},predicate=wasd.shovel:holding_item/shovel2] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air replace
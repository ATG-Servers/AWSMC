#mc-build WASD content
execute as @s[scores={wasd.used_shovel=1..}] run function wasd.shovel:used_shovel
execute as @s[scores={wasd.shovel_click=1..}] run function wasd.shovel:on_click
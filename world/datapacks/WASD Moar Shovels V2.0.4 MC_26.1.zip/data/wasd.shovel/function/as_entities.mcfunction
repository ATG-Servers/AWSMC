#mc-build WASD content
function wasd.shovel:patron/as_entities
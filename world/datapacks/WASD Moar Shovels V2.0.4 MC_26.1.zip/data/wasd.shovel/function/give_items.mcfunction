#mc-build WASD content
loot give @s loot wasd.shovel:items/excavator
loot give @s loot wasd.shovel:items/digger
loot give @s loot wasd.shovel:items/magnetic
loot give @s loot wasd.shovel:items/diamond_excavator
loot give @s loot wasd.shovel:items/diamond_digger
function wasd.shovel:patron/give_items
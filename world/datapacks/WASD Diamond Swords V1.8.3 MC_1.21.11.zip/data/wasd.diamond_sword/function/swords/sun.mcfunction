#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
execute store result score @s wasd.temp run time query daytime
execute as @s[scores={wasd.temp=0..12000}] run scoreboard players set @s wasd.temp 9
execute as @s[scores={wasd.temp=0..12000}] run playsound minecraft:block.beacon.activate player @a ~ ~ ~ 1 2
execute as @s[scores={wasd.temp=0..12000}] run execute positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run particle falling_dust{block_state:{Name:"minecraft:yellow_wool"}} ~ ~1 ~ 0.3 0.5 0.3 0 50
execute as @s[scores={wasd.temp=12001..24000}] run scoreboard players set @s wasd.temp 1
#use SBIM to put score onto held item
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute at @e[tag=wasd.box_location] store result block ~ ~ ~ Items[0].components."minecraft:attribute_modifiers"[0].amount double 1 run scoreboard players get @s wasd.temp
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
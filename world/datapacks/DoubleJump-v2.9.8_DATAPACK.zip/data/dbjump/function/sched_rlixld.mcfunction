scoreboard players set $oqjqjY XboQ26 0
execute if score $oqjqjY XboQ26 matches 0 unless score $hidden.m0 st.activate matches 1 run function dbjump:nxf/s900j
execute if score $oqjqjY XboQ26 matches 0 run function dbjump:nxf/lghl
scoreboard players set $oqjqjY XboQ26 0
scoreboard players set $speeder st.success 0
execute as @s if score $speeder st.success matches 0 if score $speeder st.activate matches 1 run function dbjump:menu/speeder_off
execute as @s if score $speeder st.success matches 0 unless score $speeder st.activate matches 1 run function dbjump:menu/speeder_on
scoreboard players set $speeder st.success 0
function dbjump:menu/main
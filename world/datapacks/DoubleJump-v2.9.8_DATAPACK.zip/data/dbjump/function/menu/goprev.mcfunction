execute if score $db.fs db.menu.page matches 2..2 run scoreboard players remove $db.fs db.menu.page 1
function dbjump:menu/main
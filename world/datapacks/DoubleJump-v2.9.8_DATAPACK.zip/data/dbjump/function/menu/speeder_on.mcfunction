tellraw @a "[MENU] Menu Activated"
scoreboard players set $speeder st.success 1
scoreboard players set $speeder st.activate 1
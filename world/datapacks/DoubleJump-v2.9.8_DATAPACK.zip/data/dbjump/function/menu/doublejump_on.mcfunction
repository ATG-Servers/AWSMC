tellraw @a "[MENU] Menu Activated"
scoreboard players set $doublejump st.success 1
scoreboard players set $doublejump st.activate 1
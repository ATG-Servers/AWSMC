tellraw @a "[MENU] Menu Deactivated"
scoreboard players set $doublejump st.success 1
scoreboard players set $doublejump st.activate 0
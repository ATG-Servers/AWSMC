execute unless score $dbj.bjump bonus_jump matches 3 run scoreboard players add $dbj.bjump bonus_jump 1
function dbjump:menu/main
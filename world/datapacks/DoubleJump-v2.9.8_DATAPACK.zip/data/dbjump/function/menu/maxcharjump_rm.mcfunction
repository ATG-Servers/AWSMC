execute unless score $dbj.bjump bonus_jump matches 0 run scoreboard players remove $dbj.bjump bonus_jump 1
function dbjump:menu/main
scoreboard players set $doublejump st.success 0
execute as @s if score $doublejump st.success matches 0 if score $doublejump st.activate matches 1 run function dbjump:menu/doublejump_off
execute as @s if score $doublejump st.success matches 0 unless score $doublejump st.activate matches 1 run function dbjump:menu/doublejump_on
scoreboard players set $doublejump st.success 0
function dbjump:menu/main
scoreboard objectives add dbjump.isrunning dummy
scoreboard objectives add islib dummy
scoreboard objectives add ismodded dummy
scoreboard players set Modded ismodded 0
scoreboard objectives add rl.debug dummy
scoreboard objectives add XboQ26 dummy
scoreboard objectives add VersionInfo dummy
scoreboard players add MinecraftVersion VersionInfo 0
function fokus:vd/cores/1.14
scoreboard objectives add dbj.sneak minecraft.custom:minecraft.sneak_time
scoreboard objectives add dbj.sneak_char minecraft.custom:minecraft.sneak_time
scoreboard objectives add dbj.jump minecraft.custom:minecraft.jump
scoreboard objectives add dbj.sprint minecraft.custom:minecraft.sprint_one_cm
scoreboard objectives add db.menu.page dummy
scoreboard objectives add st.success dummy
scoreboard objectives add st.activate dummy
scoreboard objectives add bonus_jump dummy
scoreboard players add $db.fl st.activate 0
execute if score $db.fl st.activate matches 0 run function dbjump:nxf/7cxawl0cv3
scoreboard players set $db.fs db.menu.page 1
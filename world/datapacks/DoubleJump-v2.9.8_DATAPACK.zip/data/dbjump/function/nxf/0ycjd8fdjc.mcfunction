scoreboard players set $fJpx XboQ26 0
execute if score $fJpx XboQ26 matches 0 run function dbjump:nxf/_ignored_ucjql
execute if score $fJpx XboQ26 matches 0 run function dbjump:nxf/_ignored_vz01ibcj
scoreboard players set $fJpx XboQ26 0
setblock ~ ~ ~ minecraft:barrier
scoreboard players set $1Fyd2 XboQ26 1
execute as @s[tag=candjump] run function dbjump:nxf/e8i5s
execute unless score $walljump st.activate matches 0 as @s[tag=!candjump,tag=djumped] run function dbjump:nxf/w6j6
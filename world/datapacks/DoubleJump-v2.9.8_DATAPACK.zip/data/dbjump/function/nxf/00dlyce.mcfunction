execute unless score $charjump st.activate matches 0 as @s[scores={dbj.sneak=1..}] run function dbjump:nxf/9zo6l
execute as @s[scores={dbj.sneak=0}] run scoreboard players set @s dbj.sneak_char 0
execute unless score $speeder st.activate matches 0 as @s[scores={dbj.sprint=1..}] run function dbjump:nxf/hs81xy
execute as @s[nbt={OnGround:0b},scores={dbj.sneak=1..}] unless score $doublejump st.activate matches 0 run function dbjump:nxf/4y1g
effect give @s slow_falling 1 0 true
execute if score MinecraftVersion VersionInfo matches 1..9 run function dbjump:nxf/zhfwi
execute if score MinecraftVersion VersionInfo matches 10..14 run function dbjump:nxf/se3dyipyb
execute if score MinecraftVersion VersionInfo matches 15.. run function dbjump:nxf/rl3r
tag @s add eff.slowf
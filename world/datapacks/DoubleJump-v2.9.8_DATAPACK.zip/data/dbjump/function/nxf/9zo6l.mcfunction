scoreboard players set $55n4bJho XboQ26 0
execute if score $55n4bJho XboQ26 matches 0 run function dbjump:nxf/2c7v
execute if score $55n4bJho XboQ26 matches 0 run function dbjump:nxf/mr34noxs18t
execute if score $55n4bJho XboQ26 matches 0 run function dbjump:nxf/y7g0
scoreboard players set $55n4bJho XboQ26 0
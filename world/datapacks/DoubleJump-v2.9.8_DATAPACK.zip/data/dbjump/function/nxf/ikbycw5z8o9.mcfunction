execute as @s[nbt={OnGround:1b}] run function dbjump:nxf/jbf579
execute as @s[tag=djumped_1,scores={dbj.jump=1..}] run function dbjump:nxf/5nae2xacl1
execute as @s[gamemode=survival] run function dbjump:nxf/00dlyce
execute as @s[tag=initdjump,nbt={OnGround:0b}] run function dbjump:nxf/gqj1z326gu
execute as @s[tag=eff.slowf] at @s if block ~ ~-1 ~ barrier run function dbjump:nxf/b6g8tph2
execute as @e[type=minecraft:area_effect_cloud,tag=djump] at @s run function dbjump:nxf/i7hh6zjt4p9
execute as @s[scores={dbj.sneak=1..}] run scoreboard players set @s dbj.sneak 0
execute as @s[tag=!djumped_1,scores={dbj.jump=1..}] run scoreboard players set @s dbj.jump 0
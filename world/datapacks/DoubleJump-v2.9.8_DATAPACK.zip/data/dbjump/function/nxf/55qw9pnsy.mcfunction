tag @s add djumped_1
scoreboard players set @s dbj.jump 0
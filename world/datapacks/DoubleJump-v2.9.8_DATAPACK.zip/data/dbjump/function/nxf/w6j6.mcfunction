scoreboard players set $DN5bgX7 XboQ26 0
execute if score $DN5bgX7 XboQ26 matches 0 run function dbjump:nxf/bt1vej8ppp
execute if score $DN5bgX7 XboQ26 matches 0 run function dbjump:nxf/rr3b
scoreboard players set $DN5bgX7 XboQ26 0
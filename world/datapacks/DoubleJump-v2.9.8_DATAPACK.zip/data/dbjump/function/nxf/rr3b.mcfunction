execute positioned ~ ~ ~ run function dbjump:nxf/2lber4
execute at @s[tag=initdjump] run scoreboard players set $DN5bgX7 XboQ26 1
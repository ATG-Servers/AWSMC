scoreboard players set $puV8 XboQ26 0
execute if score $puV8 XboQ26 matches 0 run function dbjump:nxf/rdnnw6
execute if score $puV8 XboQ26 matches 0 run function dbjump:nxf/w1665y7mz
execute if score $puV8 XboQ26 matches 0 run function dbjump:nxf/wg2wcnm
execute if score $puV8 XboQ26 matches 0 run function dbjump:nxf/ac43acdl
scoreboard players set $puV8 XboQ26 0
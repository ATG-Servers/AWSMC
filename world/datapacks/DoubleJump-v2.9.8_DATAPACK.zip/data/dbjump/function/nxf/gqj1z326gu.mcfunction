execute as @s at @s if block ~ ~-1 ~ air run function dbjump:nxf/ihtl95
tag @s remove initdjump
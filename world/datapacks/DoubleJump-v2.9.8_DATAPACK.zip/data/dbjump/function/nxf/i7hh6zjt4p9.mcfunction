scoreboard players set $1Fyd2 XboQ26 0
execute if score $1Fyd2 XboQ26 matches 0 run function dbjump:nxf/vmc8m6zf49b
execute if score $1Fyd2 XboQ26 matches 0 run function dbjump:nxf/582qnmfy
scoreboard players set $1Fyd2 XboQ26 0
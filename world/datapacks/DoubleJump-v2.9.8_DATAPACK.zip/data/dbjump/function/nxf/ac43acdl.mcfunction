execute unless block ~ ~1 ~-1 air run function dbjump:nxf/sc94kozbeq
execute at @s[tag=initdjump] run scoreboard players set $puV8 XboQ26 1
effect clear @s slow_falling
tag @s remove eff.slowf
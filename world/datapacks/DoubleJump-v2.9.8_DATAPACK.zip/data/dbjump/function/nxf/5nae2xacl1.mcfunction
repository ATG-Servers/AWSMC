scoreboard players set @s dbj.jump 0
tag @s add djumped
tag @s remove djumped_1
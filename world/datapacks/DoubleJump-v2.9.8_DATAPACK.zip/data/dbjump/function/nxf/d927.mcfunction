effect give @s minecraft:jump_boost 1 1 true
title @s actionbar ["",{"text":"Charged Jump","color":"green"}," : ",{"text":"I","color":"gold"}]
execute as @s run scoreboard players set $55n4bJho XboQ26 1
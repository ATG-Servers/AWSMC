execute as @s[nbt={Age:20}] if block ~ ~ ~ barrier run setblock ~ ~ ~ air
scoreboard players set $1Fyd2 XboQ26 1
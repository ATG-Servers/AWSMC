execute as @a[tag=cfg.allowjp] at @s run function dbjump:nxf/ikbycw5z8o9
scoreboard players set $oqjqjY XboQ26 1
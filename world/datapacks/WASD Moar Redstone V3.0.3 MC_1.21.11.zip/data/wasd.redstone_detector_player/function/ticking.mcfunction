#mc-build WASD content
function wasd.redstone_detector_player:zzz/2
execute if entity @a[distance=..7] run tag @s add wasd.powered
execute unless entity @a[distance=..7] run tag @s remove wasd.powered
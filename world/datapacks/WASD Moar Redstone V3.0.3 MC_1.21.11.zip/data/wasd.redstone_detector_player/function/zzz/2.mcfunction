#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ repeater run function wasd.redstone_detector_player:zzz/3
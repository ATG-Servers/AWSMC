#mc-build WASD content
execute as @s[tag=wasd.south] run setblock ~ ~ ~ repeater[delay=4,facing=south] replace
execute as @s[tag=wasd.west] run setblock ~ ~ ~ repeater[delay=4,facing=west] replace
execute as @s[tag=wasd.north] run setblock ~ ~ ~ repeater[delay=4,facing=north] replace
execute as @s[tag=wasd.east] run setblock ~ ~ ~ repeater[delay=4,facing=east] replace
execute if entity @p[predicate=wasd.lib:sneaking] run scoreboard players remove @s wasd.variables 20
execute as @s[scores={wasd.variables=1200..}] run scoreboard players reset @s wasd.variables
execute as @s[scores={wasd.variables=..0}] run scoreboard players set @s wasd.variables 1200
execute unless entity @p[predicate=wasd.lib:sneaking] run scoreboard players add @s wasd.variables 20
kill @e[tag=wasd.text_display,sort=nearest,limit=1,distance=..0.1]
execute store result storage minecraft:wasd.redstone_storage temp int 0.05 run scoreboard players get @s wasd.variables
function wasd.redstone_timer:summon_text with storage minecraft:wasd.redstone_storage
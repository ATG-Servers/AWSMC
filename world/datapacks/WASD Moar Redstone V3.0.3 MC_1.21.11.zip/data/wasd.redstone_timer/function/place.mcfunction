#mc-build WASD content
function wasd.redstone_timer:zzz/0
execute as @e[type=item_display,tag=wasd.redstone_device,tag=wasd.timer,sort=nearest,limit=1,distance=..0.0001] at @s if block ~ ~ ~ #wasd.tags:air run function wasd.redstone_timer:zzz/1
#mc-build WASD content
function wasd.redstone_timer:zzz/2
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1}] run tag @s add wasd.powered
execute as @s[scores={wasd.timer=2}] run tag @s remove wasd.powered
execute if score @s wasd.timer >= @s wasd.variables run scoreboard players reset @s wasd.timer
execute if block ~ ~ ~ repeater unless block ~ ~ ~ repeater[delay=4] run function wasd.redstone_timer:zzz/4
#mc-build WASD content
execute as @s[tag=wasd.south] run setblock ~ ~ ~ repeater[delay=1,facing=south]
execute as @s[tag=wasd.west] run setblock ~ ~ ~ repeater[delay=1,facing=west]
execute as @s[tag=wasd.north] run setblock ~ ~ ~ repeater[delay=1,facing=north]
execute as @s[tag=wasd.east] run setblock ~ ~ ~ repeater[delay=1,facing=east]
#mc-build WASD content
execute if block ~ ~ ~1 #wasd.tags:pistons[extended=true,facing=north] run fill ~ ~ ~-1 ~ ~ ~-1 air replace minecraft:moving_piston
execute if block ~ ~ ~-1 #wasd.tags:pistons[extended=true,facing=south] run fill ~ ~ ~1 ~ ~ ~1 air replace minecraft:moving_piston
execute if block ~-1 ~ ~ #wasd.tags:pistons[extended=true,facing=east] run fill ~1 ~ ~ ~1 ~ ~ air replace minecraft:moving_piston
execute if block ~1 ~ ~ #wasd.tags:pistons[extended=true,facing=west] run fill ~-1 ~ ~ ~-1 ~ ~ air replace minecraft:moving_piston
execute if block ~ ~-1 ~ #wasd.tags:pistons[extended=true,facing=up] run fill ~ ~1 ~ ~ ~1 ~ air replace minecraft:moving_piston
execute if block ~ ~1 ~ #wasd.tags:pistons[extended=true,facing=down] run fill ~ ~-1 ~ ~ ~-1 ~ air replace minecraft:moving_piston
loot spawn ~ ~0.5 ~ loot wasd.redstone:items/receiver
execute store result storage minecraft:wasd.redstone_storage channel int 1 run scoreboard players get @s wasd.channel
execute positioned ~ ~1 ~ as @n[type=item] run function wasd.redstone:shared/set_lore with storage minecraft:wasd.redstone_storage
execute positioned ~ ~1 ~ store result entity @n[type=item] Item.components."minecraft:entity_data".Item.components."minecraft:custom_data"."wasd.channel" int 1 run scoreboard players get @s wasd.channel
setblock ~ ~ ~ air
kill @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s,Item:{id:"minecraft:repeater"}}]
kill @s
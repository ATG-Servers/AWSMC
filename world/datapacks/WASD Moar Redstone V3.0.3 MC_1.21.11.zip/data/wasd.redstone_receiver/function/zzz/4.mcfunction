#mc-build WASD content
tag @s add wasd.valid
tag @s add wasd.is_wireless
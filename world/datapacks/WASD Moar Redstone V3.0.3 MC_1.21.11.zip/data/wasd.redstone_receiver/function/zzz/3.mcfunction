#mc-build WASD content
tag @s add wasd.validated
execute as @s[nbt={Item:{id:"minecraft:carrot_on_a_stick",components:{"minecraft:item_model":"wasd:redstone/handheld_transmitter"}}}] run function wasd.redstone_receiver:zzz/4
execute as @s[nbt={Item:{id:"minecraft:item_frame",components:{"minecraft:item_model":"wasd:redstone/transmitter"}}}] run tag @s add wasd.valid
execute as @s[nbt={Item:{id:"minecraft:item_frame",components:{"minecraft:item_model":"wasd:redstone/receiver"}}}] run tag @s add wasd.valid
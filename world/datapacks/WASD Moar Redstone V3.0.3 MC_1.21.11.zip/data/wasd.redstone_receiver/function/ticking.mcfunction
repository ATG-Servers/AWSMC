#mc-build WASD content
execute unless block ~ ~ ~ repeater run function wasd.redstone_receiver:zzz/2
execute if block ~ ~ ~ repeater as @e[type=item,tag=!wasd.validated,distance=..1] run function wasd.redstone_receiver:zzz/3
execute at @e[type=item,tag=!wasd.linked,tag=wasd.valid,distance=..1] run function wasd.redstone:shared/link
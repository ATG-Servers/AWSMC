#mc-build WASD content
particle dust{color:[0.69, 0.0, 0.0], scale:1.0} ~-0.3 ~0.6 ~-0.3 0 0 0 1 0 normal
execute as @s[scores={wasd.variables=1}] at @e[tag=wasd.receiver] if score @e[tag=wasd.receiver,sort=nearest,limit=1] wasd.channel = @s wasd.channel run tag @e[tag=wasd.receiver,sort=nearest,limit=1] add wasd.powered
execute as @s[scores={wasd.variables=0}] at @e[tag=wasd.receiver] if score @e[tag=wasd.receiver,sort=nearest,limit=1] wasd.channel = @s wasd.channel run tag @e[tag=wasd.receiver,sort=nearest,limit=1] remove wasd.powered
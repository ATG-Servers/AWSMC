#mc-build WASD content
execute store result score @s wasd.channel run data get entity @s Item.components."minecraft:custom_data"."wasd.channel"
execute if score @s wasd.channel matches 0 run scoreboard players add channel wasd.variables 1
execute if score @s wasd.channel matches 0 run scoreboard players operation @s wasd.channel = channel wasd.variables
function wasd.redstone_transmitter:zzz/0
scoreboard players operation @e[type=item_display,tag=wasd.redstone_device,tag=wasd.transmitter,sort=nearest,limit=1,distance=..0.0001] wasd.channel = @s wasd.channel
execute as @e[type=item_display,tag=wasd.redstone_device,tag=wasd.transmitter,sort=nearest,limit=1,distance=..0.0001] at @s if block ~ ~ ~ #wasd.tags:air run function wasd.redstone_transmitter:zzz/1
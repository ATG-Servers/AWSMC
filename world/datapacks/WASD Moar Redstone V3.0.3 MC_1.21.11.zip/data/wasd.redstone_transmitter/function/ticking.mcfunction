#mc-build WASD content
execute unless block ~ ~ ~ repeater run function wasd.redstone_transmitter:zzz/2
execute if block ~ ~ ~ repeater as @e[type=item,tag=!wasd.validated,distance=..1] run function wasd.redstone_transmitter:zzz/3
execute at @e[type=item,tag=!wasd.linked,tag=wasd.valid,distance=..1] run function wasd.redstone:shared/link
execute if block ~ ~ ~ minecraft:repeater[powered=false] run scoreboard players set @s wasd.variables 0
execute if block ~ ~ ~ minecraft:repeater[powered=true] run scoreboard players set @s wasd.variables 1
execute unless score @s wasd.temp = @s wasd.variables run function wasd.redstone_transmitter:zzz/5
scoreboard players operation @s wasd.temp = @s wasd.variables
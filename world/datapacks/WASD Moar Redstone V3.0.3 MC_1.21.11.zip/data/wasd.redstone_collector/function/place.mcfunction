#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ hopper replace
function wasd.redstone_collector:zzz/0
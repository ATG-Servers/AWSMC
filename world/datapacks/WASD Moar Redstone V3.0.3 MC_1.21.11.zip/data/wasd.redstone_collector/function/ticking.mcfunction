#mc-build WASD content
function wasd.redstone_collector:zzz/1
execute if score wasd.global_1 wasd.timer matches 1 at @e[type=item,distance=..7] run function wasd.redstone_collector:zzz/3
particle minecraft:portal ~ ~0.5 ~ 0.1 0 0.1 0.2 1
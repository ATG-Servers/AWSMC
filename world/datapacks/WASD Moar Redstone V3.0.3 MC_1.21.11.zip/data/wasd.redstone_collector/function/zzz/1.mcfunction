#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ hopper run function wasd.redstone_collector:zzz/2
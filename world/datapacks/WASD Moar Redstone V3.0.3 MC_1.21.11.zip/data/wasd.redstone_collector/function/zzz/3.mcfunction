#mc-build WASD content
particle dust{color:[0.651, 0.078, 0.478], scale:2.0} ~ ~ ~ 0.1 0.1 0.1 1 4 normal
playsound minecraft:entity.shulker.teleport block @a ~ ~ ~ 0.3 2
execute positioned as @s run tp @e[type=item,distance=..7,tag=!wasd.collector_teleported,sort=nearest,limit=1] ~ ~1 ~
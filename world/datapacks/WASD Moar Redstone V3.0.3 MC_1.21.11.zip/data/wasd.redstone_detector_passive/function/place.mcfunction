#mc-build WASD content
function wasd.redstone_detector_passive:zzz/0
execute as @e[type=item_display,tag=wasd.redstone_device,tag=wasd.passive_detector,sort=nearest,limit=1,distance=..0.0001] at @s if block ~ ~ ~ #wasd.tags:air run function wasd.redstone_detector_passive:zzz/1
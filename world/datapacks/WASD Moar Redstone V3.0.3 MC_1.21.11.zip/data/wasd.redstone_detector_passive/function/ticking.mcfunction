#mc-build WASD content
function wasd.redstone_detector_passive:zzz/2
execute if entity @e[distance=..7,type=#wasd.tags:passive_mobs] run tag @s add wasd.powered
execute unless entity @e[distance=..7,type=#wasd.tags:passive_mobs] run tag @s remove wasd.powered
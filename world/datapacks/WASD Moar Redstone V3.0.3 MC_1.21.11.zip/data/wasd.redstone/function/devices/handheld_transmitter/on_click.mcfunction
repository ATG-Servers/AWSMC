#mc-build WASD content
execute positioned ~ ~1.7 ~ run particle dust{color:[0.69, 0.0, 0.0], scale:1.0} ^ ^ ^1 0 0 0 1 0 normal
execute store result score @s wasd.channel run data get entity @s SelectedItem.components."minecraft:custom_data"."wasd.channel"
execute at @e[tag=wasd.receiver] if score @e[tag=wasd.receiver,sort=nearest,limit=1] wasd.channel = @s wasd.channel run function wasd.lib:power/repeater
#mc-build WASD content
recipe give @s wasd.redstone:receiver
recipe give @s wasd.redstone:transmitter
recipe give @s wasd.redstone:handheld_transmitter
recipe give @s wasd.redstone:player_detector
recipe give @s wasd.redstone:passive_detector
recipe give @s wasd.redstone:hostile_detector
recipe give @s wasd.redstone:collector
recipe give @s wasd.redstone:timer
#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_redstone wasd_data_packs 1
scoreboard objectives add wasd.channel dummy
scoreboard objectives add wasd.clean_item dummy
scoreboard objectives add w.red_settings dummy
function wasd.redstone:config
execute unless block 200000 -64 0 repeating_command_block run setblock 200000 -64 0 minecraft:repeating_command_block[conditional=false,facing=up]{Command:"execute as @e[tag=wasd.redstone_device,tag=wasd.powered] at @s run function wasd.lib:power/repeater",CustomName:'{"text":"@"}',LastExecution:1849680L,LastOutput:'{"extra":[{"translate":"commands.function.success.single","with":["32","wasd.lib:power/repeater"]}],"text":"[00:13:32] "}',SuccessCount:2,TrackOutput:1b,UpdateLastExecution:1b,auto:1b,conditionMet:1b,powered:0b}
gamerule command_block_output false
gamerule command_blocks_work true
schedule function wasd.redstone:check_installed_packs 30t replace
data merge storage wasd.redstone_storage {channel:0,temp:0}
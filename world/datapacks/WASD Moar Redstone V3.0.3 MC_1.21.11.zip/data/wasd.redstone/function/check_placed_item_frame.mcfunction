#mc-build WASD content
execute as @s[tag=wasd.receiver] run function wasd.redstone_receiver:place
execute as @s[tag=wasd.transmitter] run function wasd.redstone_transmitter:place
execute as @s[tag=wasd.player_detector] run function wasd.redstone_detector_player:place
execute as @s[tag=wasd.passive_detector] run function wasd.redstone_detector_passive:place
execute as @s[tag=wasd.hostile_detector] run function wasd.redstone_detector_hostile:place
execute as @s[tag=wasd.collector] run function wasd.redstone_collector:place
execute as @s[tag=wasd.timer] run function wasd.redstone_timer:place
#mc-build WASD content
setblock ~ ~ ~ minecraft:red_shulker_box
loot insert ~ ~ ~ loot wasd.redstone:items/receiver
loot insert ~ ~ ~ loot wasd.redstone:items/transmitter
loot insert ~ ~ ~ loot wasd.redstone:items/handheld_transmitter
loot insert ~ ~ ~ loot wasd.redstone:items/player_detector
loot insert ~ ~ ~ loot wasd.redstone:items/passive_detector
loot insert ~ ~ ~ loot wasd.redstone:items/hostile_detector
loot insert ~ ~ ~ loot wasd.redstone:items/collector
loot insert ~ ~ ~ loot wasd.redstone:items/timer
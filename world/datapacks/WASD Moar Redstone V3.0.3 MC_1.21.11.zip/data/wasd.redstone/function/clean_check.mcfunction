#mc-build WASD content
execute at @s if block ~ ~ ~ minecraft:water_cauldron unless block ~ ~ ~ minecraft:cauldron run function wasd.redstone:shared/clean
scoreboard players add @s wasd.clean_item 1
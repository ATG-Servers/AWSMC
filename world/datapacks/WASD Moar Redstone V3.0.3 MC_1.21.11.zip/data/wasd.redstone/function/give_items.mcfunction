#mc-build WASD content
loot give @s loot wasd.redstone:items/receiver
loot give @s loot wasd.redstone:items/transmitter
loot give @s loot wasd.redstone:items/handheld_transmitter
loot give @s loot wasd.redstone:items/player_detector
loot give @s loot wasd.redstone:items/passive_detector
loot give @s loot wasd.redstone:items/hostile_detector
loot give @s loot wasd.redstone:items/collector
loot give @s loot wasd.redstone:items/timer
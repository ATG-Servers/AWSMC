#mc-build WASD content
execute as @e[tag=wasd.redstone_device] at @s run function wasd.redstone:redstone_device
execute if score wasd.global_1 wasd.timer matches 1 as @e[type=item,tag=!wasd.cleaned] unless score @s wasd.clean_item matches 2.. run function wasd.redstone:clean_check
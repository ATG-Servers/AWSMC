#mc-build WASD content
execute as @s[tag=wasd.receiver] run function wasd.redstone_receiver:ticking
execute as @s[tag=wasd.transmitter] run function wasd.redstone_transmitter:ticking
execute as @s[tag=wasd.player_detector] run function wasd.redstone_detector_player:ticking
execute as @s[tag=wasd.passive_detector] run function wasd.redstone_detector_passive:ticking
execute as @s[tag=wasd.hostile_detector] run function wasd.redstone_detector_hostile:ticking
execute as @s[tag=wasd.collector] run function wasd.redstone_collector:ticking
execute as @s[tag=wasd.timer] run function wasd.redstone_timer:ticking
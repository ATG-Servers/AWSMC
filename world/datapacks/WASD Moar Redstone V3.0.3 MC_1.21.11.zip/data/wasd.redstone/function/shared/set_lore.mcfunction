#mc-build WASD content
$data merge entity @s {Item:{components:{"minecraft:lore":[[{"color":"gray","text":"Channel: ","italic":false},{"color":"dark_red","italic":false,"text":"$(channel)"}]]}}}
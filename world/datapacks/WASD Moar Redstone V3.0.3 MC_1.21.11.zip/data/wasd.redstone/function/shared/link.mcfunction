#mc-build WASD content
tag @n[type=item] add wasd.linked
execute store result entity @n[type=item,tag=!wasd.is_wireless,distance=..1] Item.components."minecraft:entity_data".Item.components."minecraft:custom_data"."wasd.channel" int 1 run scoreboard players get @s wasd.channel
execute store result entity @n[type=item,tag=wasd.is_wireless,distance=..1] Item.components."minecraft:custom_data"."wasd.channel" int 1 run scoreboard players get @s wasd.channel
execute store result storage minecraft:wasd.redstone_storage channel int 1 run scoreboard players get @s wasd.channel
execute as @n[type=item] run function wasd.redstone:shared/set_lore with storage minecraft:wasd.redstone_storage
particle dust{color:[1.0, 0.0, 0.0], scale:1.0} ~ ~ ~ 0 0 0 0 1
playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 7 1
#mc-build WASD content
execute store result entity @s Item.components."minecraft:custom_data"."wasd.channel" byte 1 run scoreboard players get 0 wasd.constants
execute store result entity @s Item.components."minecraft:entity_data".Item.components."minecraft:custom_data"."wasd.channel" byte 1 run scoreboard players get 0 wasd.constants
execute store result storage minecraft:wasd.redstone_storage channel int 1 run scoreboard players get @s wasd.channel
function wasd.redstone:shared/set_lore with storage minecraft:wasd.redstone_storage
execute align xyz run particle minecraft:splash ~0.5 ~0.5 ~0.5 0.2 0.2 0.2 0 50
execute align xyz run particle minecraft:bubble_pop ~0.5 ~0.7 ~0.5 0.2 0.2 0.2 0 10
execute as @e[distance=..1] at @s if block ~ ~ ~ minecraft:cauldron unless block ~ ~ ~ minecraft:cauldron run function wasd.lib:affects/damage/2_hearts
playsound minecraft:block.bubble_column.upwards_inside master @a ~ ~ ~ 10 1.5
execute if block ~ ~ ~ minecraft:water_cauldron[level=1] run setblock ~ ~ ~ minecraft:cauldron
execute if block ~ ~ ~ minecraft:water_cauldron[level=2] run setblock ~ ~ ~ minecraft:water_cauldron[level=1]
execute if block ~ ~ ~ minecraft:water_cauldron[level=3] run setblock ~ ~ ~ minecraft:water_cauldron[level=2]
tag @s add wasd.cleaned
#mc-build WASD content
particle poof ~ ~0.5 ~ 0.3 0.3 0.3 0 3
scoreboard players add @s wasd.break_time 1
execute as @s[scores={wasd.break_time=100..}] run function wasd.machine_oxidizer:zzz/8
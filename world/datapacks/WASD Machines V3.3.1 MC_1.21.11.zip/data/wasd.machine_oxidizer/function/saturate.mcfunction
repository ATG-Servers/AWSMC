#mc-build WASD content
execute if block ~ ~ ~ weathered_cut_copper_stairs run function wasd.machine_oxidizer:zzz/2
execute if block ~ ~ ~ exposed_cut_copper_stairs run function wasd.machine_oxidizer:zzz/3
execute if block ~ ~ ~ cut_copper_stairs run function wasd.machine_oxidizer:zzz/4
execute if block ~ ~ ~ weathered_cut_copper_slab run function wasd.machine_oxidizer:zzz/5
execute if block ~ ~ ~ exposed_cut_copper_slab run function wasd.machine_oxidizer:zzz/6
execute if block ~ ~ ~ cut_copper_slab run function wasd.machine_oxidizer:zzz/7
execute if block ~ ~ ~ weathered_cut_copper run setblock ~ ~ ~ oxidized_cut_copper replace
execute if block ~ ~ ~ exposed_cut_copper run setblock ~ ~ ~ weathered_cut_copper replace
execute if block ~ ~ ~ cut_copper run setblock ~ ~ ~ exposed_cut_copper replace
execute if block ~ ~ ~ weathered_copper run setblock ~ ~ ~ oxidized_copper replace
execute if block ~ ~ ~ exposed_copper run setblock ~ ~ ~ weathered_copper replace
execute if block ~ ~ ~ copper_block run setblock ~ ~ ~ exposed_copper replace
execute if block ~ ~ ~ weathered_copper_grate run setblock ~ ~ ~ oxidized_copper_grate replace
execute if block ~ ~ ~ exposed_copper_grate run setblock ~ ~ ~ weathered_copper_grate replace
execute if block ~ ~ ~ copper_grate run setblock ~ ~ ~ exposed_copper_grate replace
execute if block ~ ~ ~ weathered_chiseled_copper run setblock ~ ~ ~ oxidized_chiseled_copper replace
execute if block ~ ~ ~ exposed_chiseled_copper run setblock ~ ~ ~ weathered_chiseled_copper replace
execute if block ~ ~ ~ chiseled_copper run setblock ~ ~ ~ exposed_chiseled_copper replace
execute if block ~ ~ ~ weathered_copper_bulb run setblock ~ ~ ~ oxidized_copper_bulb replace
execute if block ~ ~ ~ exposed_copper_bulb run setblock ~ ~ ~ weathered_copper_bulb replace
execute if block ~ ~ ~ copper_bulb run setblock ~ ~ ~ exposed_copper_bulb replace
execute if block ~ ~ ~ weathered_copper_trapdoor run setblock ~ ~ ~ oxidized_copper_trapdoor replace
execute if block ~ ~ ~ exposed_copper_trapdoor run setblock ~ ~ ~ weathered_copper_trapdoor replace
execute if block ~ ~ ~ copper_trapdoor run setblock ~ ~ ~ exposed_copper_trapdoor replace
particle poof ~ ~0.5 ~ 0.2 0.2 0.2 0.1 30
playsound minecraft:block.copper.break block @a ~ ~ ~ 1 0
scoreboard players reset @s wasd.break_time
#mc-build WASD content
execute unless block ~ ~ ~ water_cauldron run function wasd.machine_oxidizer:zzz/1
execute positioned ~ ~1 ~ if block ~ ~ ~ #wasd.tags:oxidizable unless block ~ ~ ~ #wasd.tags:oxidizable[waterlogged=true] run function wasd.machine_oxidizer:active
execute positioned ~ ~1 ~ if block ~ ~ ~ #wasd.machine:oxidizable_coral run function wasd.machine_oxidizer:active_coral
tag @s[tag=!wasd.placed] add wasd.placed
execute unless block ~ ~1 ~ #wasd.tags:oxidizable unless block ~ ~1 ~ #wasd.machine:oxidizable_coral run scoreboard players reset @s wasd.break_time
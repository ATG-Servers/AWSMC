#mc-build WASD content
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=bottom,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=bottom,facing=north]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=bottom,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=bottom,facing=east]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=bottom,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=bottom,facing=south]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=bottom,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=bottom,facing=west]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=top,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=top,facing=north]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=top,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=top,facing=east]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=top,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=top,facing=south]
execute if block ~ ~ ~ weathered_cut_copper_stairs[half=top,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_stairs[half=top,facing=west]
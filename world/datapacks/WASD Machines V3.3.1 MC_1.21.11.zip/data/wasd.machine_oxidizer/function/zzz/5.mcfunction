#mc-build WASD content
execute if block ~ ~ ~ weathered_cut_copper_slab[type=bottom] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_slab[type=bottom]
execute if block ~ ~ ~ weathered_cut_copper_slab[type=top] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_slab[type=top]
execute if block ~ ~ ~ weathered_cut_copper_slab[type=double] store success score @s wasd.temp run setblock ~ ~ ~ oxidized_cut_copper_slab[type=double]
#mc-build WASD content
execute if block ~ ~ ~ cut_copper_slab[type=bottom] store success score @s wasd.temp run setblock ~ ~ ~ exposed_cut_copper_slab[type=bottom]
execute if block ~ ~ ~ cut_copper_slab[type=top] store success score @s wasd.temp run setblock ~ ~ ~ exposed_cut_copper_slab[type=top]
execute if block ~ ~ ~ cut_copper_slab[type=double] store success score @s wasd.temp run setblock ~ ~ ~ exposed_cut_copper_slab[type=double]
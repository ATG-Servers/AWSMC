#mc-build WASD content
setblock ~ ~ ~ sponge replace
particle poof ~ ~0.5 ~ 0.2 0.2 0.2 0.1 30
playsound minecraft:block.copper.break block @a ~ ~ ~ 1 0
scoreboard players reset @s wasd.break_time
#mc-build WASD content
execute if block ~ ~ ~ exposed_cut_copper_slab[type=bottom] store success score @s wasd.temp run setblock ~ ~ ~ weathered_cut_copper_slab[type=bottom]
execute if block ~ ~ ~ exposed_cut_copper_slab[type=top] store success score @s wasd.temp run setblock ~ ~ ~ weathered_cut_copper_slab[type=top]
execute if block ~ ~ ~ exposed_cut_copper_slab[type=double] store success score @s wasd.temp run setblock ~ ~ ~ weathered_cut_copper_slab[type=double]
#mc-build WASD content
setblock ~ ~ ~ minecraft:light_gray_shulker_box
loot insert ~ ~ ~ loot wasd.machine:machines/crusher
loot insert ~ ~ ~ loot wasd.machine:machines/washer
loot insert ~ ~ ~ loot wasd.machine:machines/saturator
loot insert ~ ~ ~ loot wasd.machine:machines/breaker
loot insert ~ ~ ~ loot wasd.machine:machines/placer
loot insert ~ ~ ~ loot wasd.machine:machines/chunk_loader
loot insert ~ ~ ~ loot wasd.machine:machines/composter
loot insert ~ ~ ~ loot wasd.machine:machines/sprinkler
loot insert ~ ~ ~ loot wasd.machine:machines/extruder
loot insert ~ ~ ~ loot wasd.machine:machines/compactor
loot insert ~ ~ ~ loot wasd.machine:machines/fan
loot insert ~ ~ ~ loot wasd.machine:machines/farmer
loot insert ~ ~ ~ loot wasd.machine:machines/pearl_thrower
loot insert ~ ~ ~ loot wasd.machine:machines/rotator
loot insert ~ ~ ~ loot wasd.machine:machines/stripper
loot insert ~ ~ ~ loot wasd.machine:machines/trash_can
loot insert ~ ~ ~ loot wasd.machine:machines/oxidizer
loot insert ~ ~ ~ loot wasd.machine:machines/bedrock_breaker
loot insert ~ ~ ~ loot wasd.machine:machines/sifter
loot insert ~ ~ ~ loot wasd.machine:machines/ore_extruder
loot insert ~ ~ ~ loot wasd.machine:machines/fluid_tank
loot insert ~ ~ ~ loot wasd.machine:machines/fluid_pipe
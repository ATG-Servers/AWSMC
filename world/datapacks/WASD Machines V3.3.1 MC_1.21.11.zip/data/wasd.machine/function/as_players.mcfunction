#mc-build WASD content
scoreboard players reset @a wasd.used_stand
scoreboard players reset @a wasd.mach_frame
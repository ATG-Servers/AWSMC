#mc-build WASD content
execute unless entity @a[advancements={wasd.installed:library=true}] run function wasd.machine:zzz/0
#mc-build WASD content
#configure specific machine settings
#crusher specific recipes (blocks that the crusher can crush). Ores crushed produce double ores. If it is crushable it will also be enabled in the washer... unless you disable ores.
scoreboard players set stone wasd.crusher 1
scoreboard players set cobblestone wasd.crusher 1
scoreboard players set gravel wasd.crusher 1
scoreboard players set dirt wasd.crusher 1
scoreboard players set polished wasd.crusher 1
scoreboard players set coal wasd.crusher 1
scoreboard players set iron wasd.crusher 1
scoreboard players set copper wasd.crusher 1
scoreboard players set gold wasd.crusher 1
scoreboard players set lapis wasd.crusher 1
scoreboard players set diamond wasd.crusher 1
scoreboard players set redstone wasd.crusher 1
scoreboard players set emerald wasd.crusher 1
scoreboard players set quartz wasd.crusher 1
scoreboard players set concrete wasd.crusher 1
#washer specific recipes (items it can wash). Coal = Gunpowder, Wheat = Seeds, Blaze Rod = More Blaze Powder
scoreboard players set ores wasd.washer 1
scoreboard players set coal wasd.washer 1
scoreboard players set wheat wasd.washer 1
scoreboard players set blaze_rod wasd.washer 1
#saturator specific recipes (Blocks it can saturate)
scoreboard players set sand wasd.saturator 1
scoreboard players set cobblestone wasd.saturator 1
scoreboard players set stone_bricks wasd.saturator 1
scoreboard players set snow_block wasd.saturator 1
scoreboard players set dirt wasd.saturator 1
scoreboard players set coarse_dirt wasd.saturator 1
scoreboard players set gravel wasd.saturator 1
#chunkloader: Range is the radius of chunks around it to load. (Min=1, Max=4). Amount is how many chunk loaders a specific player is allowed to place.
scoreboard players set range wasd.chunkloader 2
scoreboard players set amount wasd.chunkloader 5
#mc-build WASD content
execute as @s[tag=wasd.extruder_interaction] run function wasd.machine_extruder:clicked
execute as @s[tag=wasd.sifter_interaction] run function wasd.machine_sifter:right_clicked
execute as @s[tag=wasd.ore_extruder_interaction] run function wasd.machine_ore_extruder:right_clicked
execute as @s[tag=wasd.fluid_tank_interaction] run function wasd.machine_fluid_tank:right_clicked
execute as @s[tag=wasd.fluid_pipe_interaction] run function wasd.machine_fluid_pipe:right_clicked
#mc-build WASD content
execute as @s[tag=wasd.sifter_interaction] run function wasd.machine_sifter:left_clicked
execute as @s[tag=wasd.ore_extruder_interaction] run function wasd.machine_ore_extruder:left_clicked
execute as @s[tag=wasd.fluid_tank_interaction] run function wasd.machine_fluid_tank:left_clicked
execute as @s[tag=wasd.fluid_pipe_interaction] run function wasd.machine_fluid_pipe:left_clicked
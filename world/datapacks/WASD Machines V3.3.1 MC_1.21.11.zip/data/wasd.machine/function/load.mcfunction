#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_machines wasd_data_packs 1
scoreboard objectives add wasd.break_time dummy
scoreboard objectives add wasd.used_stand minecraft.used:minecraft.armor_stand
scoreboard objectives add wasd.mach_frame minecraft.used:minecraft.item_frame
scoreboard objectives add wasd.load_count minecraft.used:minecraft.item_frame
#liquids
scoreboard objectives add wasd.water_amount dummy
scoreboard objectives add wasd.lava_amount dummy
scoreboard objectives add wasd.fluid_amount dummy
#breaker
scoreboard objectives add wasd.tool_damage dummy
scoreboard objectives add wasd.check_slot dummy
scoreboard objectives add wasd.is_pickaxe dummy
scoreboard objectives add wasd.is_axe dummy
scoreboard objectives add wasd.is_shovel dummy
scoreboard objectives add wasd.is_hoe dummy
scoreboard objectives add wasd.slot_number dummy
scoreboard objectives add wasd.total_items dummy
scoreboard objectives add wasd.tool_wood dummy
scoreboard objectives add wasd.tool_stone dummy
scoreboard objectives add wasd.tool_gold dummy
scoreboard objectives add wasd.tool_iron dummy
scoreboard objectives add wasd.tool_dia dummy
scoreboard objectives add wasd.tool_nether dummy
scoreboard objectives add wasd.tool_copper dummy
scoreboard objectives add machine_settings dummy
#machine specific settings
scoreboard objectives add wasd.crusher dummy
scoreboard objectives add wasd.washer dummy
scoreboard objectives add wasd.saturator dummy
scoreboard objectives add wasd.sprinkler dummy
scoreboard objectives add wasd.farmer dummy
scoreboard objectives add wasd.lava_gen dummy
scoreboard objectives add wasd.dirt_comp dummy
scoreboard objectives add wasd.sifter dummy
scoreboard objectives add wasd.rotator dummy
scoreboard objectives add wasd.fan dummy
scoreboard objectives add wasd.turret dummy
scoreboard objectives add wasd.chunkloader dummy
function wasd.machine:config
schedule function wasd.machine:check_installed_packs 30t replace
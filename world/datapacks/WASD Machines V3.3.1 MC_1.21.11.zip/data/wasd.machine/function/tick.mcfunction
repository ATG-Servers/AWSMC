#mc-build WASD content
execute as @e[tag=wasd.machine_block] at @s run function wasd.machine:machines
#crafter
execute as @e[tag=wasd.machine_crafter] at @s run function wasd.machine_crafter:crafter
#as players
execute as @a at @s run function wasd.machine:as_players
execute as @e[tag=wasd.machine_entity] at @s run function wasd.machine:as_entities
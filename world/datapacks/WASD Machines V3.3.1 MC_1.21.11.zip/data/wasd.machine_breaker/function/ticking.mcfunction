#mc-build WASD content
function wasd.machine_breaker:zzz/0
execute as @s[tag=wasd.north] positioned ~ ~ ~-1 if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
execute as @s[tag=wasd.south] positioned ~ ~ ~1 if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
execute as @s[tag=wasd.east] positioned ~1 ~ ~ if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
execute as @s[tag=wasd.west] positioned ~-1 ~ ~ if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
execute as @s[tag=wasd.up] positioned ~ ~1 ~ if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
execute as @s[tag=wasd.down] positioned ~ ~-1 ~ if block ~ ~ ~ #wasd.tags:all_mineable unless block ~ ~ ~ moving_piston run function wasd.machine_breaker:tool
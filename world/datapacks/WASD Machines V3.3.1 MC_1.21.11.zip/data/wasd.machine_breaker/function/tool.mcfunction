#mc-build WASD content
function wasd.machine_breaker:zzz/2
function wasd.machine_breaker:zzz/3
function wasd.machine_breaker:zzz/4
function wasd.machine_breaker:zzz/5
#if we have a tool, determine the direction of the breaker
execute as @s[tag=wasd.has_pickaxe] run function wasd.machine_breaker:break
execute as @s[tag=wasd.has_axe] run function wasd.machine_breaker:break
execute as @s[tag=wasd.has_shovel] run function wasd.machine_breaker:break
execute as @s[tag=wasd.has_hoe] run function wasd.machine_breaker:break
#clean up tags
tag @s remove wasd.has_pickaxe
tag @s remove wasd.has_axe
tag @s remove wasd.has_shovel
tag @s remove wasd.has_hoe
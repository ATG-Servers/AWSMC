#mc-build WASD content
#determine which tool was/is used
execute as @s[tag=wasd.has_pickaxe] if block ~ ~ ~ #minecraft:mineable/pickaxe run tag @s add wasd.used_pick
execute as @s[tag=wasd.has_axe] if block ~ ~ ~ #minecraft:mineable/axe run tag @s add wasd.used_axe
execute as @s[tag=wasd.has_shovel] if block ~ ~ ~ #minecraft:mineable/shovel run tag @s add wasd.used_shovel
execute as @s[tag=wasd.has_hoe] if block ~ ~ ~ #minecraft:mineable/hoe run tag @s add wasd.used_hoe
tag @s[tag=wasd.used_pick] add wasd.used_valid_tool
tag @s[tag=wasd.used_axe] add wasd.used_valid_tool
tag @s[tag=wasd.used_shovel] add wasd.used_valid_tool
tag @s[tag=wasd.used_hoe] add wasd.used_valid_tool
#determine slot number
#slot number for pickaxes
execute at @s[tag=wasd.used_pick] run function wasd.machine_breaker:zzz/7
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/8
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/9
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/10
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/11
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/12
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/13
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/14
execute at @s[tag=wasd.used_pick] unless score @s wasd.is_pickaxe matches 1.. run function wasd.machine_breaker:zzz/15
#slot number for axes
execute at @s[tag=wasd.used_axe] run function wasd.machine_breaker:zzz/16
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/17
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/18
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/19
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/20
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/21
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/22
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/23
execute at @s[tag=wasd.used_axe] unless score @s wasd.is_axe matches 1.. run function wasd.machine_breaker:zzz/24
#slot number for shovel
execute at @s[tag=wasd.used_shovel] run function wasd.machine_breaker:zzz/25
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/26
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/27
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/28
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/29
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/30
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/31
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/32
execute at @s[tag=wasd.used_shovel] unless score @s wasd.is_shovel matches 1.. run function wasd.machine_breaker:zzz/33
#slot number for hoe
execute at @s[tag=wasd.used_hoe] run function wasd.machine_breaker:zzz/34
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/35
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/36
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/37
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/38
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/39
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/40
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/41
execute at @s[tag=wasd.used_hoe] unless score @s wasd.is_hoe matches 1.. run function wasd.machine_breaker:zzz/42
function wasd.machine_breaker:zzz/43
execute unless score @s wasd.temp matches 1.. run function wasd.machine_breaker:zzz/44
execute if score @s wasd.temp matches 1 if predicate wasd.lib:rng/0.5 run function wasd.machine_breaker:zzz/45
execute if score @s wasd.temp matches 2 if predicate wasd.lib:rng/0.33 run function wasd.machine_breaker:zzz/46
execute if score @s wasd.temp matches 3 if predicate wasd.lib:rng/0.25 run function wasd.machine_breaker:zzz/47
execute as @s[tag=wasd.used_valid_tool] run function wasd.machine_breaker:zzz/48
#break tool based on tool health
function wasd.machine_breaker:zzz/56
function wasd.machine_breaker:zzz/58
function wasd.machine_breaker:zzz/59
function wasd.machine_breaker:zzz/60
function wasd.machine_breaker:zzz/61
function wasd.machine_breaker:zzz/62
function wasd.machine_breaker:zzz/63
function wasd.machine_breaker:zzz/64
#reset everything
scoreboard players reset @s wasd.is_pickaxe
scoreboard players reset @s wasd.is_axe
scoreboard players reset @s wasd.is_shovel
scoreboard players reset @s wasd.is_hoe
tag @s remove wasd.used_pick
tag @s remove wasd.used_axe
tag @s remove wasd.used_shovel
tag @s remove wasd.used_hoe
scoreboard players reset @s wasd.tool_wood
scoreboard players reset @s wasd.tool_stone
scoreboard players reset @s wasd.tool_gold
scoreboard players reset @s wasd.tool_iron
scoreboard players reset @s wasd.tool_dia
scoreboard players reset @s wasd.tool_nether
scoreboard players reset @s wasd.tool_copper
scoreboard players reset @s wasd.check_slot
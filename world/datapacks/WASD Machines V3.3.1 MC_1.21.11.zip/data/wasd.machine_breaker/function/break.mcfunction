#mc-build WASD content
#damage the tool
function wasd.machine_breaker:damage
#break the block (if the breaker has the correct tool)
execute as @s[tag=wasd.used_valid_tool] run function wasd.machine_breaker:zzz/6
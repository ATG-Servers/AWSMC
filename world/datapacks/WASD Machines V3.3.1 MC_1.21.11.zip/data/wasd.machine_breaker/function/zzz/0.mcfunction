#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ dropper run function wasd.machine_breaker:zzz/1
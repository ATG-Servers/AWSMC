#mc-build WASD content
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:diamond_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:iron_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:golden_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:stone_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:wooden_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:netherite_axe"}]} run tag @s add wasd.has_axe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:copper_axe"}]} run tag @s add wasd.has_axe
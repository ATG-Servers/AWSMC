#mc-build WASD content
execute store result score @s wasd.tool_dia if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:diamond_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_gold if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:golden_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_iron if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:iron_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_stone if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:stone_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_wood if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:wooden_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_nether if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:netherite_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute store result score @s wasd.tool_copper if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b,id:"minecraft:copper_axe"}]} run scoreboard players add @s wasd.is_axe 1
execute unless score @s wasd.is_axe matches 1.. if block ~ ~ ~ minecraft:dropper{Items:[{Slot:3b}]} run scoreboard players add @s wasd.slot_number 1
execute unless score @s wasd.slot_number matches ..0 run scoreboard players add @s[scores={wasd.is_axe=1..}] wasd.slot_number 0
scoreboard players set @s[scores={wasd.is_axe=1..}] wasd.check_slot 3
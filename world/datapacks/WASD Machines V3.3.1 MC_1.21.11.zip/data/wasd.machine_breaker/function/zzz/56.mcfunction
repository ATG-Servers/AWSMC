#mc-build WASD content
execute at @s[scores={wasd.slot_number=0}] store result score @s wasd.temp run data get block ~ ~ ~ Items[0].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=1}] store result score @s wasd.temp run data get block ~ ~ ~ Items[1].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=2}] store result score @s wasd.temp run data get block ~ ~ ~ Items[2].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=3}] store result score @s wasd.temp run data get block ~ ~ ~ Items[3].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=4}] store result score @s wasd.temp run data get block ~ ~ ~ Items[4].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=5}] store result score @s wasd.temp run data get block ~ ~ ~ Items[5].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=6}] store result score @s wasd.temp run data get block ~ ~ ~ Items[6].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=7}] store result score @s wasd.temp run data get block ~ ~ ~ Items[7].components."minecraft:max_damage"
execute at @s[scores={wasd.slot_number=8}] store result score @s wasd.temp run data get block ~ ~ ~ Items[8].components."minecraft:max_damage"
execute if score @s wasd.tool_damage > @s wasd.temp unless score @s wasd.temp matches 0 run function wasd.machine_breaker:zzz/57
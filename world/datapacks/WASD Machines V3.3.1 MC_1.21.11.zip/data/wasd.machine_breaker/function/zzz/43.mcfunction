#mc-build WASD content
summon marker ~ ~ ~ {Tags:["wasd.breaker_data_storage"],data:{breaker:[]}}
execute as @s[scores={wasd.slot_number=0}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[0].tag.Enchantments
execute as @s[scores={wasd.slot_number=1}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[1].tag.Enchantments
execute as @s[scores={wasd.slot_number=2}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[2].tag.Enchantments
execute as @s[scores={wasd.slot_number=3}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[3].tag.Enchantments
execute as @s[scores={wasd.slot_number=4}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[4].tag.Enchantments
execute as @s[scores={wasd.slot_number=5}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[5].tag.Enchantments
execute as @s[scores={wasd.slot_number=6}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[6].tag.Enchantments
execute as @s[scores={wasd.slot_number=7}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[7].tag.Enchantments
execute as @s[scores={wasd.slot_number=8}] at @s run data modify entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest] data.breaker set from block ~ ~ ~ Items[8].tag.Enchantments
scoreboard players set @s wasd.temp 0
execute if entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest,nbt={data:{breaker:[{id:"minecraft:unbreaking",lvl:1s}]}}] run scoreboard players set @s wasd.temp 1
execute if entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest,nbt={data:{breaker:[{id:"minecraft:unbreaking",lvl:2s}]}}] run scoreboard players set @s wasd.temp 2
execute if entity @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest,nbt={data:{breaker:[{id:"minecraft:unbreaking",lvl:3s}]}}] run scoreboard players set @s wasd.temp 3
kill @e[tag=wasd.breaker_data_storage,limit=1,sort=nearest]
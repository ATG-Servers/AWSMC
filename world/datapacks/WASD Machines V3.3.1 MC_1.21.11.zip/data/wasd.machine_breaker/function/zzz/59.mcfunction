#mc-build WASD content
execute at @s[scores={wasd.check_slot=0,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.0 with air
execute at @s[scores={wasd.check_slot=1,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.1 with air
execute at @s[scores={wasd.check_slot=2,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.2 with air
execute at @s[scores={wasd.check_slot=3,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.3 with air
execute at @s[scores={wasd.check_slot=4,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.4 with air
execute at @s[scores={wasd.check_slot=5,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.5 with air
execute at @s[scores={wasd.check_slot=6,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.6 with air
execute at @s[scores={wasd.check_slot=7,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.7 with air
execute at @s[scores={wasd.check_slot=8,wasd.tool_stone=1..,wasd.tool_damage=132..}] run item replace block ~ ~ ~ container.8 with air
#mc-build WASD content
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:diamond_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:iron_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:golden_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:stone_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:wooden_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:netherite_hoe"}]} run tag @s add wasd.has_hoe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:copper_hoe"}]} run tag @s add wasd.has_hoe
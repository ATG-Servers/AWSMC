#mc-build WASD content
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:diamond_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:iron_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:golden_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:stone_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:wooden_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:netherite_shovel"}]} run tag @s add wasd.has_shovel
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:copper_shovel"}]} run tag @s add wasd.has_shovel
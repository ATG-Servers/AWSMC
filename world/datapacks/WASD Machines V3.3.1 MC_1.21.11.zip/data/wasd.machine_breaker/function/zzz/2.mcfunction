#mc-build WASD content
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:diamond_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:iron_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:golden_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:stone_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:wooden_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:netherite_pickaxe"}]} run tag @s add wasd.has_pickaxe
execute at @s if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:copper_pickaxe"}]} run tag @s add wasd.has_pickaxe
#mc-build WASD content
#use slot number to get Damage value of the used tool ()
execute at @s[scores={wasd.slot_number=0}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[0].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=1}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[1].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=2}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[2].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=3}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[3].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=4}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[4].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=5}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[5].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=6}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[6].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=7}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[7].components."minecraft:damage"
execute at @s[scores={wasd.slot_number=8}] store result score @s wasd.tool_damage run data get block ~ ~ ~ Items[8].components."minecraft:damage"
#increase damage value by 1
scoreboard players operation @s wasd.tool_damage += 1 wasd.constants
#store new damage value back into tool (increases damage by 1)
execute at @s[scores={wasd.slot_number=0}] store result block ~ ~ ~ Items[0].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=1}] store result block ~ ~ ~ Items[1].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=2}] store result block ~ ~ ~ Items[2].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=3}] store result block ~ ~ ~ Items[3].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=4}] store result block ~ ~ ~ Items[4].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=5}] store result block ~ ~ ~ Items[5].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=6}] store result block ~ ~ ~ Items[6].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=7}] store result block ~ ~ ~ Items[7].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
execute at @s[scores={wasd.slot_number=8}] store result block ~ ~ ~ Items[8].components."minecraft:damage" float 1 run scoreboard players get @s wasd.tool_damage
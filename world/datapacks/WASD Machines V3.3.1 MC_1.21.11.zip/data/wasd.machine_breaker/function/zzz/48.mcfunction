#mc-build WASD content
summon armor_stand ~ ~ ~ {NoGravity:1b,Silent:1b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,Tags:["wasd.breaker_tool"],equipment:{mainhand:{id:"minecraft:stone"}}}
function wasd.machine_breaker:zzz/49
execute as @e[tag=wasd.breaker_tool,sort=nearest,limit=1,distance=..0.1] run loot spawn ~ ~0.5 ~ mine ~ ~ ~ mainhand
kill @e[tag=wasd.breaker_tool,sort=nearest,limit=1,distance=..0.1]
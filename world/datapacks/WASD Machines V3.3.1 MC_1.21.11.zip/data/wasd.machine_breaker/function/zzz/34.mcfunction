#mc-build WASD content
execute store result score @s wasd.tool_dia if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:diamond_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_gold if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:golden_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_iron if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:iron_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_stone if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:stone_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_wood if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:wooden_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_nether if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:netherite_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute store result score @s wasd.tool_copper if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b,id:"minecraft:copper_hoe"}]} run scoreboard players add @s wasd.is_hoe 1
execute unless score @s wasd.is_hoe matches 1.. if block ~ ~ ~ minecraft:dropper{Items:[{Slot:0b}]} run scoreboard players add @s wasd.slot_number 1
execute unless score @s wasd.slot_number matches ..0 run scoreboard players add @s[scores={wasd.is_hoe=1..}] wasd.slot_number 0
scoreboard players set @s[scores={wasd.is_hoe=1..}] wasd.check_slot 0
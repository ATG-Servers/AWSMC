#mc-build WASD content
setblock ~ ~ ~ air replace
particle block{block_state:{Name:"minecraft:stone"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 50 normal
playsound block.stone.break block @a ~ ~ ~ 1 1
scoreboard players reset @s wasd.slot_number
tag @s remove wasd.used_valid_tool
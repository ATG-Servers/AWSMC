#mc-build WASD content
execute as @s[tag=wasd.north] run function wasd.machine_breaker:zzz/50
execute as @s[tag=wasd.south] run function wasd.machine_breaker:zzz/51
execute as @s[tag=wasd.east] run function wasd.machine_breaker:zzz/52
execute as @s[tag=wasd.west] run function wasd.machine_breaker:zzz/53
execute as @s[tag=wasd.up] run function wasd.machine_breaker:zzz/54
execute as @s[tag=wasd.down] run function wasd.machine_breaker:zzz/55
#mc-build WASD content
function wasd.machine_composter:zzz/1
execute if block ~ ~ ~ minecraft:composter[level=7] run function wasd.machine_composter:zzz/3
#mc-build WASD content
#<Block's tag/name> <model name> <Optional "face_me", "face_away">

summon item_display ~ ~ ~ {Tags:["wasd.machine","wasd.machine_block","wasd.composter"],brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.47f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:item_frame",count:1,components:{"minecraft:item_model":"wasd:machine/composter"}}}

#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ composter run function wasd.machine_composter:zzz/2
#mc-build WASD content
scoreboard players reset @s wasd.timer
setblock ~ ~ ~ composter[level=0]
particle composter ~ ~0.5 ~ 0.2 0.2 0.2 0.1 20
particle block{block_state:{Name:"minecraft:dirt"}} ~ ~0.5 ~ 0.2 0.2 0.2 0.1 20
playsound block.composter.empty block @a ~ ~ ~ 1 1
execute if block ~ ~-1 ~ hopper run summon item ~ ~-0.3 ~ {Item:{id:"minecraft:dirt",count:1}}
execute unless block ~ ~-1 ~ hopper run summon item ~-0.2 ~0.3 ~ {Motion:[0.05,0.3,0.0],Item:{id:"minecraft:dirt",count:1}}
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=20..}] run function wasd.machine_composter:zzz/4
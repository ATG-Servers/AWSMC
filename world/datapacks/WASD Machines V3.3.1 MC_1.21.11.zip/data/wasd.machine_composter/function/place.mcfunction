#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ composter replace
function wasd.machine_composter:zzz/0
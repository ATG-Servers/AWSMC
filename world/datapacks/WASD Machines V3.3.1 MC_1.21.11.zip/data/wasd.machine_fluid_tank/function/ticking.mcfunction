#mc-build WASD content
execute positioned ~ ~ ~ as @n[tag=wasd.fluid_tank_interaction,tag=wasd.new_water,distance=..0.001] run function wasd.machine_fluid_tank:zzz/3
execute positioned ~ ~ ~ as @n[tag=wasd.fluid_tank_interaction,tag=wasd.new_lava,distance=..0.001] run function wasd.machine_fluid_tank:zzz/5
execute as @n[type=item_display,tag=wasd.kill_me,tag=wasd.machine,distance=..0.01] run function wasd.machine_fluid_tank:zzz/7
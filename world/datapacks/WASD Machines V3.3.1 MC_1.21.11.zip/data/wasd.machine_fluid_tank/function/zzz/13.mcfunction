#mc-build WASD content
scoreboard players add @s wasd.water_amount 1000
function wasd.machine_fluid_tank:water_changed
execute as @p[tag=wasd.right_click,distance=..6,predicate=wasd.machine:holding_water,gamemode=!creative] run item replace entity @s weapon.mainhand with bucket
playsound minecraft:item.bucket.empty player @a ~ ~ ~ 0.5 1
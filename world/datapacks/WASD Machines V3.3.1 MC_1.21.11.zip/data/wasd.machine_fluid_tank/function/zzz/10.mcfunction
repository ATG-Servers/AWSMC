#mc-build WASD content
item modify entity @s weapon.mainhand wasd.lib:remove1
give @s[predicate=wasd.machine:holding_bucket] minecraft:water_bucket
item replace entity @s[predicate=!wasd.machine:holding_bucket] weapon.mainhand with water_bucket
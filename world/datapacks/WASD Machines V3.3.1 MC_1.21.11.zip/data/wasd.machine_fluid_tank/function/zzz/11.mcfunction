#mc-build WASD content
scoreboard players remove @s wasd.lava_amount 1000
function wasd.machine_fluid_tank:lava_changed
execute as @p[tag=wasd.right_click,distance=..6,predicate=wasd.machine:holding_bucket,gamemode=!creative] run function wasd.machine_fluid_tank:zzz/12
playsound minecraft:item.bucket.fill_lava player @a ~ ~ ~ 0.5 1
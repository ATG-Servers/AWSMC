#mc-build WASD content
execute if block ~ ~ ~ barrier run setblock ~ ~ ~ air
loot spawn ~ ~0.6 ~ loot wasd.machine:machines/fluid_tank
particle block{block_state:{Name:"minecraft:deepslate"}} ~ ~0.6 ~ 0.3 0.35 0.3 0.03 20 force
playsound minecraft:block.deepslate.break block @a ~ ~ ~ 1 1
kill @n[type=item_display,tag=wasd.fluid_tank,distance=..0.1]
kill @s
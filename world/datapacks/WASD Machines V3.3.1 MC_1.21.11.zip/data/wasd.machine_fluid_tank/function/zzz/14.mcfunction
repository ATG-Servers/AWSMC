#mc-build WASD content
scoreboard players add @s wasd.lava_amount 1000
function wasd.machine_fluid_tank:lava_changed
execute as @p[tag=wasd.right_click,distance=..6,predicate=wasd.machine:holding_lava,gamemode=!creative] run item replace entity @s weapon.mainhand with bucket
playsound minecraft:item.bucket.empty_lava player @a ~ ~ ~ 0.5 1
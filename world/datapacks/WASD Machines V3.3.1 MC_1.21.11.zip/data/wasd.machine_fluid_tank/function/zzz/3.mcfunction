#mc-build WASD content
execute as @s[tag=wasd.wait_one] run function wasd.machine_fluid_tank:zzz/4
tag @s[tag=wasd.new_water] add wasd.wait_one
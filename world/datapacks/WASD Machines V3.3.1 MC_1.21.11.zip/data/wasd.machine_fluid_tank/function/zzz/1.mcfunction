#mc-build WASD content
function wasd.machine_fluid_tank:zzz/2
summon interaction ~ ~ ~ {width:1.01f,height:1.01f,Tags:["wasd.machine","wasd.fluid_tank_interaction","wasd.interaction_entity"]}
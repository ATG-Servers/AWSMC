#mc-build WASD content
tag @s add wasd.fluid_removed
execute if score @s wasd.water_amount matches 1000.. run function wasd.machine_fluid_tank:zzz/9
execute if score @s wasd.lava_amount matches 1000.. run function wasd.machine_fluid_tank:zzz/11
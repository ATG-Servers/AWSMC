#mc-build WASD content
kill @n[tag=wasd.machine,tag=wasd.fake_water,distance=..0.001]
kill @n[tag=wasd.machine,tag=wasd.fake_lava,distance=..0.001]
function wasd.machine_fluid_tank:zzz/15
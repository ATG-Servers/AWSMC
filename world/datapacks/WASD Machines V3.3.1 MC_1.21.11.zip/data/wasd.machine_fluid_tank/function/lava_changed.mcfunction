#mc-build WASD content
scoreboard players operation @s wasd.temp = @s wasd.lava_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] transformation.translation[1] float 0.01 run scoreboard players operation @s wasd.temp /= 340 wasd.constants
scoreboard players operation @s wasd.temp = @s wasd.lava_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] transformation.scale[1] float 0.01 run scoreboard players operation @s wasd.temp /= 160 wasd.constants
data merge entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] {start_interpolation:0}
execute unless entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.05] run function wasd.machine_fluid_tank:summon_lava
execute if score @s wasd.lava_amount matches ..0 positioned ~ ~ ~ run tag @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] add wasd.kill_me
#mc-build WASD content
execute positioned ~ ~ ~ as @n[tag=wasd.ore_extruder_interaction,tag=wasd.new_water,distance=..0.001] run function wasd.machine_ore_extruder:zzz/3
execute positioned ~ ~ ~ as @n[tag=wasd.ore_extruder_interaction,tag=wasd.new_lava,distance=..0.001] run function wasd.machine_ore_extruder:zzz/5
execute if entity @a[distance=..128] positioned ~ ~ ~ if entity @n[tag=wasd.ore_extruder_interaction,distance=..0.001,scores={wasd.lava_amount=10..,wasd.water_amount=10..}] at @s unless entity @s[tag=wasd.actively_extruding] run function wasd.machine_ore_extruder:zzz/7
execute as @n[type=item_display,tag=wasd.kill_me,tag=wasd.machine,distance=..0.01] run function wasd.machine_ore_extruder:zzz/8
execute as @s[tag=wasd.actively_extruding] run function wasd.machine_ore_extruder:zzz/9
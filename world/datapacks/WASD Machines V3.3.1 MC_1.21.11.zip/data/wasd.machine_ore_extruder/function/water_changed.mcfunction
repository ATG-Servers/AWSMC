#mc-build WASD content
execute positioned ~ ~ ~ run function wasd.machine_ore_extruder:zzz/13
execute unless entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.05] run function wasd.machine_ore_extruder:summon_water
execute if score @s wasd.water_amount matches ..0 positioned ~ ~ ~ run tag @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.01] add wasd.kill_me
#mc-build WASD content
execute positioned ~ ~ ~ run function wasd.machine_ore_extruder:zzz/14
execute unless entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.05] run function wasd.machine_ore_extruder:summon_lava
execute if score @s wasd.lava_amount matches ..0 positioned ~ ~ ~ run tag @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] add wasd.kill_me
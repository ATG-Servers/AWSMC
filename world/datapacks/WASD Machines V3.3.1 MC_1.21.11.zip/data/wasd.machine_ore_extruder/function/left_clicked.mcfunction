#mc-build WASD content
execute positioned ~ ~ ~ run kill @n[tag=wasd.ore_extruder_visual,distance=..0.01]
execute positioned ~ ~ ~ run kill @n[tag=wasd.machine,tag=wasd.fake_water,distance=..0.001]
execute positioned ~ ~ ~ run kill @n[tag=wasd.machine,tag=wasd.fake_lava,distance=..0.001]
function wasd.machine_ore_extruder:zzz/17
#mc-build WASD content
playsound minecraft:block.anvil.land player @a ~ ~ ~ 0.25 0.5
particle smoke ~ ~0.5 ~ 0.3 0.3 0.3 0.05 25 normal
tag @s remove wasd.actively_extruding
scoreboard players reset @s wasd.timer
kill @n[tag=wasd.ore_extruder_visual,distance=..0.01]
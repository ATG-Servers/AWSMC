#mc-build WASD content
execute unless score @s wasd.water_amount matches 3001.. if entity @p[tag=wasd.right_click,distance=..6,predicate=wasd.machine:holding_water] run function wasd.machine_ore_extruder:zzz/15
execute unless score @s wasd.lava_amount matches 3001.. if entity @p[tag=wasd.right_click,distance=..6,predicate=wasd.machine:holding_lava] run function wasd.machine_ore_extruder:zzz/16
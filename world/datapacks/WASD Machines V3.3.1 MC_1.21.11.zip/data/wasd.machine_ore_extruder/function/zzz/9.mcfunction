#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=60..}] run function wasd.machine_ore_extruder:zzz/10
execute as @s[scores={wasd.timer=2}] as @n[tag=wasd.ore_extruder_visual,distance=..0.01] run data merge entity @s {interpolation_duration:80,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[1f,0.5f,0f],scale:[0.40f,0.40f,0.40f]}}
execute as @s[scores={wasd.timer=64}] as @n[tag=wasd.ore_extruder_visual,distance=..0.01] run data merge entity @s {interpolation_duration:16,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[1f,0.47f,0f],scale:[0.98f,0.98f,0.98f]}}
execute as @s[scores={wasd.timer=80..}] run function wasd.machine_ore_extruder:zzz/11
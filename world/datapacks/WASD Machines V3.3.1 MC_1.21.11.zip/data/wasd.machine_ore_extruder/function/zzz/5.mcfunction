#mc-build WASD content
execute as @s[tag=wasd.wait_one] run function wasd.machine_ore_extruder:zzz/6
tag @s[tag=wasd.new_lava] add wasd.wait_one
#mc-build WASD content
execute as @s[tag=wasd.south] if block ~ ~ ~1 #wasd.tags:air run function wasd.machine_ore_extruder:extrude
execute as @s[tag=wasd.west] if block ~-1 ~ ~ #wasd.tags:air run function wasd.machine_ore_extruder:extrude
execute as @s[tag=wasd.north] if block ~ ~ ~-1 #wasd.tags:air run function wasd.machine_ore_extruder:extrude
execute as @s[tag=wasd.east] if block ~1 ~ ~ #wasd.tags:air run function wasd.machine_ore_extruder:extrude
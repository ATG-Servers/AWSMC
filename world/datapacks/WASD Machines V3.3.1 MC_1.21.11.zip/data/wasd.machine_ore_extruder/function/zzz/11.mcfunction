#mc-build WASD content
#playsound block.fire.extinguish block @a ~ ~ ~ 0.5 1
scoreboard players reset @s wasd.timer
tag @s remove wasd.actively_extruding
kill @n[tag=wasd.ore_extruder_visual,distance=..0.01]
execute as @s[tag=wasd.south] positioned ~ ~ ~1 run function wasd.machine_ore_extruder:place_ore
execute as @s[tag=wasd.west] positioned ~-1 ~ ~ run function wasd.machine_ore_extruder:place_ore
execute as @s[tag=wasd.north] positioned ~ ~ ~-1 run function wasd.machine_ore_extruder:place_ore
execute as @s[tag=wasd.east] positioned ~1 ~ ~ run function wasd.machine_ore_extruder:place_ore
#mc-build WASD content
scoreboard players remove @n[type=interaction,tag=wasd.ore_extruder_interaction,distance=..0.01] wasd.water_amount 10
execute as @n[type=interaction,tag=wasd.ore_extruder_interaction,distance=..0.01] run function wasd.machine_ore_extruder:water_changed
scoreboard players remove @n[type=interaction,tag=wasd.ore_extruder_interaction,distance=..0.01] wasd.lava_amount 10
execute as @n[type=interaction,tag=wasd.ore_extruder_interaction,distance=..0.01] run function wasd.machine_ore_extruder:lava_changed
#mc-build WASD content
function wasd.machine_ore_extruder:zzz/2
summon interaction ~ ~ ~ {width:1.01f,height:1.01f,Tags:["wasd.machine","wasd.ore_extruder_interaction","wasd.interaction_entity"]}
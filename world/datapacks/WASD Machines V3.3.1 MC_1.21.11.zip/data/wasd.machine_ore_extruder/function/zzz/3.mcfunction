#mc-build WASD content
execute as @s[tag=wasd.wait_one] run function wasd.machine_ore_extruder:zzz/4
tag @s[tag=wasd.new_water] add wasd.wait_one
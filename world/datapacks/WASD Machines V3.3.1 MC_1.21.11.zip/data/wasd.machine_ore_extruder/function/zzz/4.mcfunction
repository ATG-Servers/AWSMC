#mc-build WASD content
tag @s remove wasd.wait_one
tag @s remove wasd.new_water
function wasd.machine_ore_extruder:water_changed
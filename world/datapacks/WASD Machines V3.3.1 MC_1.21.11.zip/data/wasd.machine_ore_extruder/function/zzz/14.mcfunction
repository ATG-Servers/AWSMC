#mc-build WASD content
scoreboard players operation @s wasd.temp = @s wasd.lava_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] transformation.translation[1] float 0.01 run scoreboard players operation @s wasd.temp /= 85 wasd.constants
scoreboard players operation @s wasd.temp = @s wasd.lava_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] transformation.scale[1] float 0.01 run scoreboard players operation @s wasd.temp /= 40 wasd.constants
data merge entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_lava,distance=..0.01] {start_interpolation:0}
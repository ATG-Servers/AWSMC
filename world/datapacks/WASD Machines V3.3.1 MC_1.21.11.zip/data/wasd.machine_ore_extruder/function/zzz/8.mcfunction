#mc-build WASD content
scoreboard players add @s wasd.variables 1
kill @s[scores={wasd.variables=10..}]
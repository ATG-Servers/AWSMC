#mc-build WASD content
execute as @s[tag=wasd.south] unless block ~ ~ ~1 #wasd.tags:air run function wasd.machine_ore_extruder:abort
execute as @s[tag=wasd.west] unless block ~-1 ~ ~ #wasd.tags:air run function wasd.machine_ore_extruder:abort
execute as @s[tag=wasd.north] unless block ~ ~ ~-1 #wasd.tags:air run function wasd.machine_ore_extruder:abort
execute as @s[tag=wasd.east] unless block ~1 ~ ~ #wasd.tags:air run function wasd.machine_ore_extruder:abort
#mc-build WASD content
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl"}]} run function wasd.machine_bedrock_breaker:zzz/4
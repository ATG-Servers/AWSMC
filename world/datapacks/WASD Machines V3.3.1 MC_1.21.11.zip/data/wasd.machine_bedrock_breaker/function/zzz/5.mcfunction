#mc-build WASD content
scoreboard players add @s wasd.temp3 1
execute as @s[scores={wasd.temp3=20..}] run function wasd.machine_bedrock_breaker:zzz/6
particle dragon_breath ~0.1 ~-0.5 ~ 0 -1 0 0.05 0 force
particle dragon_breath ~0.1 ~-0.5 ~0.1 0 -1 0 0.05 0 force
particle dragon_breath ~-0.1 ~-0.5 ~ 0 -1 0 0.05 0 force
particle dragon_breath ~-0.1 ~-0.5 ~0.1 0 -1 0 0.05 0 force
particle dragon_breath ~ ~-0.5 ~0.1 0 -1 0 0.05 0 force
particle dragon_breath ~ ~-0.5 ~-0.1 0 -1 0 0.05 0 force
particle dragon_breath ~0.1 ~-0.5 ~-0.1 0 -1 0 0.05 0 force
particle dragon_breath ~-0.1 ~-0.5 ~-0.1 0 -1 0 0.05 0 force
particle dragon_breath ~ ~-0.5 ~ 0 -1 0 0.05 0 force
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=200..}] run function wasd.machine_bedrock_breaker:zzz/7
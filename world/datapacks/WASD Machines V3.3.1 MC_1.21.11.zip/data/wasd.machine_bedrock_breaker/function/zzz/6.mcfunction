#mc-build WASD content
scoreboard players reset @s wasd.temp3
execute store result score @s wasd.temp4 run data get block ~ ~ ~ Items[0].count
execute store result block ~ ~ ~ Items[0].count int 1 run scoreboard players remove @s wasd.temp4 1
execute if score @s wasd.temp4 matches 0 run data remove block ~ ~ ~ Items[0]
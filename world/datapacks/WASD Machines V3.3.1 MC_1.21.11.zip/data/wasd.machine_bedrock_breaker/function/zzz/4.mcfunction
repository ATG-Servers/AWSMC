#mc-build WASD content
#make sure that ender pearls are the only item inside. Store total slots in use, then check every slot for pearls and see if those numbers are the same.
execute store result score @s wasd.temp run data get block ~ ~ ~ Items
scoreboard players reset @s wasd.temp2
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:0b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:1b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:2b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:3b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:4b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:5b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:6b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:7b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:8b}]} run scoreboard players add @s wasd.temp2 1
execute if block ~ ~ ~ minecraft:dropper{Items:[{id:"minecraft:ender_pearl",Slot:9b}]} run scoreboard players add @s wasd.temp2 1
execute if score @s wasd.temp = @s wasd.temp2 run function wasd.machine_bedrock_breaker:zzz/5
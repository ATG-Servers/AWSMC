#mc-build WASD content
scoreboard players reset @s wasd.timer
execute unless block ~ ~-2 ~ bedrock unless block ~ ~-3 ~ bedrock unless block ~ ~-4 ~ bedrock if block ~ ~-5 ~ bedrock run setblock ~ ~-5 ~ air replace
execute unless block ~ ~-2 ~ bedrock unless block ~ ~-3 ~ bedrock if block ~ ~-4 ~ bedrock run setblock ~ ~-4 ~ air replace
execute unless block ~ ~-2 ~ bedrock if block ~ ~-3 ~ bedrock run setblock ~ ~-3 ~ air replace
execute if block ~ ~-2 ~ bedrock run setblock ~ ~-2 ~ air replace
#mc-build WASD content
execute if block ~ ~1 ~ water run setblock ~ ~1 ~ air replace
execute if block ~ ~1 ~ lava run setblock ~ ~1 ~ air replace
#block to place. Done here in case of needing data
execute if block ~ ~1 ~ #wasd.tags:air run setblock ~ ~1 ~ dropper{CustomName:{"text":"Bedrock Breaker"}} keep
#
execute positioned ~ ~1 ~ run function wasd.machine_bedrock_breaker:zzz/0
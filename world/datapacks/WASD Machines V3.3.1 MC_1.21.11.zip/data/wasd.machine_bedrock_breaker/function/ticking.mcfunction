#mc-build WASD content
function wasd.machine_bedrock_breaker:zzz/1
tag @s remove wasd.bedrock_below
execute if block ~ ~-2 ~ bedrock run tag @s add wasd.bedrock_below
execute if block ~ ~-3 ~ bedrock run tag @s add wasd.bedrock_below
execute if block ~ ~-4 ~ bedrock run tag @s add wasd.bedrock_below
execute if block ~ ~-5 ~ bedrock run tag @s add wasd.bedrock_below
execute unless block ~ ~-1 ~ #wasd.machine:bedrock_breaker run tag @s remove wasd.bedrock_below
execute unless block ~ ~-2 ~ #wasd.machine:bedrock_breaker run tag @s remove wasd.bedrock_below
execute unless block ~ ~-3 ~ #wasd.machine:bedrock_breaker unless block ~ ~-2 ~ bedrock run tag @s remove wasd.bedrock_below
execute unless block ~ ~-4 ~ #wasd.machine:bedrock_breaker unless block ~ ~-2 ~ bedrock unless block ~ ~-3 ~ bedrock run tag @s remove wasd.bedrock_below
execute unless block ~ ~-5 ~ #wasd.machine:bedrock_breaker unless block ~ ~-2 ~ bedrock unless block ~ ~-3 ~ bedrock unless block ~ ~-4 ~ bedrock run tag @s remove wasd.bedrock_below
execute as @s[tag=wasd.bedrock_below] run function wasd.machine_bedrock_breaker:zzz/3
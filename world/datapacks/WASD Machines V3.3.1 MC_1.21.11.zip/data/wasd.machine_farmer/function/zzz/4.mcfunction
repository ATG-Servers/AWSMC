#mc-build WASD content
scoreboard players reset @s wasd.timer
execute as @s[tag=wasd.south] positioned ~ ~ ~-4 run function wasd.lib:detection/horizontal/fixed/7x7
execute as @s[tag=wasd.west] positioned ~4 ~ ~ run function wasd.lib:detection/horizontal/fixed/7x7
execute as @s[tag=wasd.north] positioned ~ ~ ~4 run function wasd.lib:detection/horizontal/fixed/7x7
execute as @s[tag=wasd.east] positioned ~-4 ~ ~ run function wasd.lib:detection/horizontal/fixed/7x7
execute as @e[tag=wasd.location] at @s run function wasd.machine_farmer:zzz/5
#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ glass run function wasd.machine_farmer:zzz/2
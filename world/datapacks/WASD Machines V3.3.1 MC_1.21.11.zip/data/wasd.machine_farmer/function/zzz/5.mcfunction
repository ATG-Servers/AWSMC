#mc-build WASD content
scoreboard players reset @s wasd.temp
execute store success score @s wasd.temp if block ~ ~ ~ wheat[age=7] run loot spawn ~ ~ ~ mine ~ ~ ~
execute if block ~ ~ ~ wheat[age=7] run setblock ~ ~ ~ wheat[age=0]
execute store success score @s wasd.temp if block ~ ~ ~ carrots[age=7] run loot spawn ~ ~ ~ mine ~ ~ ~
execute if block ~ ~ ~ carrots[age=7] run setblock ~ ~ ~ carrots[age=0]
execute store success score @s wasd.temp if block ~ ~ ~ potatoes[age=7] run loot spawn ~ ~ ~ mine ~ ~ ~
execute if block ~ ~ ~ potatoes[age=7] run setblock ~ ~ ~ potatoes[age=0]
execute store success score @s wasd.temp if block ~ ~ ~ beetroots[age=3] run loot spawn ~ ~ ~ mine ~ ~ ~
execute if block ~ ~ ~ beetroots[age=3] run setblock ~ ~ ~ beetroots[age=0]
execute store success score @s wasd.temp if block ~ ~ ~ sweet_berry_bush[age=3] run loot spawn ~ ~ ~ mine ~ ~ ~
execute if block ~ ~ ~ sweet_berry_bush[age=3] run setblock ~ ~ ~ sweet_berry_bush[age=1]
execute if block ~ ~ ~ pumpkin run setblock ~ ~ ~ air destroy
execute if block ~ ~ ~ melon run setblock ~ ~ ~ air destroy
execute if block ~ ~ ~ sugar_cane run setblock ~ ~ ~ air destroy
execute if block ~ ~ ~ cactus run setblock ~ ~ ~ air destroy
execute as @s[scores={wasd.temp=1..}] run playsound minecraft:block.crop.break block @a ~ ~ ~ 0.5 1
execute as @s[scores={wasd.temp=1..}] run particle falling_dust{block_state:{Name:"minecraft:green_concrete"}} ~ ~ ~ 0.2 0.2 0.2 0 5 normal
kill @s
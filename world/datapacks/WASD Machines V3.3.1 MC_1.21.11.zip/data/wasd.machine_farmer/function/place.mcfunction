#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
#block to place. Done here in case of needing data
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ glass replace
#
function wasd.machine_farmer:zzz/0
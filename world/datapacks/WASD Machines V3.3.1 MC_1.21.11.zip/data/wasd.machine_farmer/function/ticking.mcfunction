#mc-build WASD content
function wasd.machine_farmer:zzz/1
execute if entity @a[distance=..128] run function wasd.machine_farmer:zzz/3
execute as @s[scores={wasd.timer=200..}] run function wasd.machine_farmer:zzz/4
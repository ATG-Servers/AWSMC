#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ dispenser run function wasd.machine_pearl_thrower:zzz/3
#mc-build WASD content
execute if data entity @s Item.components run data merge entity @s {NoGravity:1b}
execute if data entity @s Item.components."minecraft:custom_data"."wasd_pearl" run function wasd.pearl:determine_pearl
tag @s add wasd.updated
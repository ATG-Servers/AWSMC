#mc-build WASD content
execute as @s[tag=wasd.south] run setblock ~ ~ ~ dispenser[facing=south]{CustomName:{"text":"Pearl Thrower"}} keep
execute as @s[tag=wasd.west] run setblock ~ ~ ~ dispenser[facing=west]{CustomName:{"text":"Pearl Thrower"}} keep
execute as @s[tag=wasd.north] run setblock ~ ~ ~ dispenser[facing=north]{CustomName:{"text":"Pearl Thrower"}} keep
execute as @s[tag=wasd.east] run setblock ~ ~ ~ dispenser[facing=east]{CustomName:{"text":"Pearl Thrower"}} keep
execute as @a run function wasd.lib:util/store_uuid
scoreboard players operation @s wasd.uuid1 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid1
scoreboard players operation @s wasd.uuid2 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid2
scoreboard players operation @s wasd.uuid3 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid3
scoreboard players operation @s wasd.uuid4 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid4
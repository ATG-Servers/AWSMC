#mc-build WASD content
data modify entity @e[type=ender_pearl,tag=wasd.mach_shot_pearl,tag=!wasd.updated,sort=nearest,limit=1] Item set from entity @s Item
execute as @e[type=minecraft:ender_pearl,sort=nearest,limit=1,tag=wasd.mach_shot_pearl,tag=!wasd.updated,tag=!wasd.custom_pearl,tag=!global.ignore] at @s run function wasd.machine_pearl_thrower:zzz/6
kill @s
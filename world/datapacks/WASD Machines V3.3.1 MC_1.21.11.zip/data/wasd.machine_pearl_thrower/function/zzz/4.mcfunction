#mc-build WASD content
execute if entity @e[type=item,sort=nearest,limit=1,distance=..3,nbt={Age:1s,OnGround:0b,Item:{id:"minecraft:ender_pearl"}}] run tag @s add wasd.shot_pearl
execute as @s[tag=wasd.shot_pearl,tag=wasd.south] run summon ender_pearl ~ ~0.5 ~1 {Tags:["wasd.mach_shot_pearl"],Owner:[I;0,1,0,1],Motion:[0.0,0.1,1.0],Item:{id:"minecraft:ender_pearl",count:1}}
execute as @s[tag=wasd.shot_pearl,tag=wasd.west] run summon ender_pearl ~-1 ~0.5 ~ {Tags:["wasd.mach_shot_pearl"],Owner:[I;0,1,0,1],Motion:[-1.0,0.1,0.0],Item:{id:"minecraft:ender_pearl",count:1}}
execute as @s[tag=wasd.shot_pearl,tag=wasd.north] run summon ender_pearl ~ ~0.5 ~-1 {Tags:["wasd.mach_shot_pearl"],Owner:[I;0,1,0,1],Motion:[0.0,0.1,-1.0],Item:{id:"minecraft:ender_pearl",count:1}}
execute as @s[tag=wasd.shot_pearl,tag=wasd.east] run summon ender_pearl ~1 ~0.5 ~ {Tags:["wasd.mach_shot_pearl"],Owner:[I;0,1,0,1],Motion:[1.0,0.1,0.0],Item:{id:"minecraft:ender_pearl",count:1}}
execute store result entity @e[tag=wasd.mach_shot_pearl,sort=nearest,limit=1,tag=!wasd.updated] Owner[0] int 1 run scoreboard players get @s wasd.uuid1
execute store result entity @e[tag=wasd.mach_shot_pearl,sort=nearest,limit=1,tag=!wasd.updated] Owner[1] int 1 run scoreboard players get @s wasd.uuid2
execute store result entity @e[tag=wasd.mach_shot_pearl,sort=nearest,limit=1,tag=!wasd.updated] Owner[2] int 1 run scoreboard players get @s wasd.uuid3
execute store result entity @e[tag=wasd.mach_shot_pearl,sort=nearest,limit=1,tag=!wasd.updated] Owner[3] int 1 run scoreboard players get @s wasd.uuid4
execute as @e[type=item,sort=nearest,limit=1,distance=..3,nbt={Age:1s,OnGround:0b}] run function wasd.machine_pearl_thrower:zzz/5
tag @s remove wasd.shot_pearl
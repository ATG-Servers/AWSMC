#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=5}] run function wasd.machine_pearl_thrower:zzz/4
execute as @s[scores={wasd.timer=6..}] if block ~ ~ ~ minecraft:dispenser[triggered=true] run tag @s add wasd.still_powered
execute as @s[scores={wasd.timer=6..}] run tag @s remove wasd.placer_triggered
execute as @s[scores={wasd.timer=6..}] run scoreboard players reset @s wasd.timer
#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
function wasd.machine_pearl_thrower:zzz/0
execute if block ~ ~ ~ #wasd.tags:air as @e[type=item_display,tag=wasd.machine,tag=wasd.pearl_thrower,sort=nearest,limit=1,distance=..0.001] run function wasd.machine_pearl_thrower:zzz/1
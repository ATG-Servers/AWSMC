#mc-build WASD content
function wasd.machine_pearl_thrower:zzz/2
execute as @s[tag=!wasd.placer_triggered,tag=!wasd.still_powered] if block ~ ~ ~ minecraft:dispenser[triggered=true] run tag @s add wasd.placer_triggered
execute as @s[tag=wasd.placer_triggered] run function wasd.machine_pearl_thrower:triggered
execute if block ~ ~ ~ minecraft:dispenser[triggered=false] run tag @s remove wasd.still_powered
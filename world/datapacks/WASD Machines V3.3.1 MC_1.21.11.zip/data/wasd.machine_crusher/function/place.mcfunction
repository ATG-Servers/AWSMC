#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
#block to place. Done here in case of needing data
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ redstone_lamp replace
function wasd.machine_crusher:zzz/0
summon item_display ~ ~ ~ {Tags:["wasd.machine","wasd.crusher_head"],brightness:{sky:15,block:15},interpolation_duration:20,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1.48f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:item_frame",count:1,components:{"minecraft:item_model":"wasd:machine/crusher"}}}
#mc-build WASD content
#breaking sounds and particles
playsound minecraft:block.stone.break block @a ~ ~ ~ 1 0.0
execute if block ~ ~ ~ stone run particle minecraft:block{block_state:{Name:"minecraft:stone"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ cobblestone run particle minecraft:block{block_state:{Name:"minecraft:cobblestone"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ gravel run particle minecraft:block{block_state:{Name:"minecraft:gravel"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ white_concrete run particle minecraft:block{block_state:{Name:"minecraft:white_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ orange_concrete run particle minecraft:block{block_state:{Name:"minecraft:orange_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ magenta_concrete run particle minecraft:block{block_state:{Name:"minecraft:magenta_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ light_blue_concrete run particle minecraft:block{block_state:{Name:"minecraft:light_blue_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ yellow_concrete run particle minecraft:block{block_state:{Name:"minecraft:yellow_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ lime_concrete run particle minecraft:block{block_state:{Name:"minecraft:lime_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ pink_concrete run particle minecraft:block{block_state:{Name:"minecraft:pink_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ gray_concrete run particle minecraft:block{block_state:{Name:"minecraft:gray_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ light_gray_concrete run particle minecraft:block{block_state:{Name:"minecraft:light_gray_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ cyan_concrete run particle minecraft:block{block_state:{Name:"minecraft:cyan_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ purple_concrete run particle minecraft:block{block_state:{Name:"minecraft:purple_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ blue_concrete run particle minecraft:block{block_state:{Name:"minecraft:blue_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ brown_concrete run particle minecraft:block{block_state:{Name:"minecraft:brown_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ green_concrete run particle minecraft:block{block_state:{Name:"minecraft:green_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ red_concrete run particle minecraft:block{block_state:{Name:"minecraft:red_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ black_concrete run particle minecraft:block{block_state:{Name:"minecraft:black_concrete"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ stone_bricks run particle minecraft:block{block_state:{Name:"minecraft:stone_bricks"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ polished_granite run particle minecraft:block{block_state:{Name:"minecraft:polished_granite"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ polished_diorite run particle minecraft:block{block_state:{Name:"minecraft:polished_diorite"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ polished_andesite run particle minecraft:block{block_state:{Name:"minecraft:polished_andesite"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ coal_ore run particle minecraft:block{block_state:{Name:"minecraft:coal_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_coal_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_coal_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ iron_ore run particle minecraft:block{block_state:{Name:"minecraft:iron_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_iron_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_iron_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ copper_ore run particle minecraft:block{block_state:{Name:"minecraft:copper_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_copper_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_copper_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ gold_ore run particle minecraft:block{block_state:{Name:"minecraft:gold_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_gold_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_gold_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ lapis_ore run particle minecraft:block{block_state:{Name:"minecraft:lapis_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_lapis_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_lapis_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ diamond_ore run particle minecraft:block{block_state:{Name:"minecraft:diamond_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_diamond_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_diamond_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ redstone_ore run particle minecraft:block{block_state:{Name:"minecraft:redstone_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_redstone_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_redstone_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ emerald_ore run particle minecraft:block{block_state:{Name:"minecraft:emerald_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ deepslate_emerald_ore run particle minecraft:block{block_state:{Name:"minecraft:deepslate_emerald_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
execute if block ~ ~ ~ nether_quartz_ore run particle minecraft:block{block_state:{Name:"minecraft:nether_quartz_ore"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 5
scoreboard players add @s wasd.break_time 1
execute as @s[scores={wasd.break_time=100..}] run function wasd.machine_crusher:crush
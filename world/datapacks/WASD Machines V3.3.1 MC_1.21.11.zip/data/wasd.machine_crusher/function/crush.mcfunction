#mc-build WASD content
execute if block ~ ~ ~ gravel run setblock ~ ~ ~ sand replace
execute if block ~ ~ ~ cobblestone run setblock ~ ~ ~ gravel replace
execute if block ~ ~ ~ stone run setblock ~ ~ ~ cobblestone replace
execute if block ~ ~ ~ white_concrete run setblock ~ ~ ~ white_concrete_powder replace
execute if block ~ ~ ~ orange_concrete run setblock ~ ~ ~ orange_concrete_powder replace
execute if block ~ ~ ~ magenta_concrete run setblock ~ ~ ~ magenta_concrete_powder replace
execute if block ~ ~ ~ light_blue_concrete run setblock ~ ~ ~ light_blue_concrete_powder replace
execute if block ~ ~ ~ yellow_concrete run setblock ~ ~ ~ yellow_concrete_powder replace
execute if block ~ ~ ~ lime_concrete run setblock ~ ~ ~ lime_concrete_powder replace
execute if block ~ ~ ~ pink_concrete run setblock ~ ~ ~ pink_concrete_powder replace
execute if block ~ ~ ~ gray_concrete run setblock ~ ~ ~ gray_concrete_powder replace
execute if block ~ ~ ~ light_gray_concrete run setblock ~ ~ ~ light_gray_concrete_powder replace
execute if block ~ ~ ~ cyan_concrete run setblock ~ ~ ~ cyan_concrete_powder replace
execute if block ~ ~ ~ purple_concrete run setblock ~ ~ ~ purple_concrete_powder replace
execute if block ~ ~ ~ blue_concrete run setblock ~ ~ ~ blue_concrete_powder replace
execute if block ~ ~ ~ brown_concrete run setblock ~ ~ ~ brown_concrete_powder replace
execute if block ~ ~ ~ green_concrete run setblock ~ ~ ~ green_concrete_powder replace
execute if block ~ ~ ~ red_concrete run setblock ~ ~ ~ red_concrete_powder replace
execute if block ~ ~ ~ black_concrete run setblock ~ ~ ~ black_concrete_powder replace
execute if block ~ ~ ~ stone_bricks run setblock ~ ~ ~ cracked_stone_bricks replace
execute if block ~ ~ ~ polished_granite run setblock ~ ~ ~ granite replace
execute if block ~ ~ ~ polished_diorite run setblock ~ ~ ~ diorite replace
execute if block ~ ~ ~ polished_andesite run setblock ~ ~ ~ andesite replace
execute if block ~ ~ ~ coal_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/coal
execute if block ~ ~ ~ deepslate_coal_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/coal
execute if block ~ ~ ~ iron_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/iron
execute if block ~ ~ ~ deepslate_iron_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/iron
execute if block ~ ~ ~ copper_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/copper
execute if block ~ ~ ~ deepslate_copper_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/copper
execute if block ~ ~ ~ gold_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/gold
execute if block ~ ~ ~ deepslate_gold_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/gold
execute if block ~ ~ ~ lapis_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/lapis
execute if block ~ ~ ~ deepslate_lapis_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/lapis
execute if block ~ ~ ~ diamond_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/diamond
execute if block ~ ~ ~ deepslate_diamond_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/diamond
execute if block ~ ~ ~ redstone_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/redstone
execute if block ~ ~ ~ deepslate_redstone_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/redstone
execute if block ~ ~ ~ emerald_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/emerald
execute if block ~ ~ ~ deepslate_emerald_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/emerald
execute if block ~ ~ ~ nether_quartz_ore run loot spawn ~ ~ ~ loot wasd.machine:ores/quartz
execute if block ~ ~ ~ #wasd.tags:ores run setblock ~ ~ ~ air replace
particle minecraft:smoke ~ ~0.5 ~ 0.2 0.2 0.2 0.1 30
playsound minecraft:entity.iron_golem.damage block @a ~ ~ ~ 1 0.8
scoreboard players reset @s wasd.break_time
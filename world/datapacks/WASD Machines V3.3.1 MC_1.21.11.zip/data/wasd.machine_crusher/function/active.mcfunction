#mc-build WASD content
#cause crusher to spin
execute as @e[tag=wasd.crusher_head,sort=nearest,limit=1] run function wasd.machine_crusher:zzz/2
#crusher sounds and particles
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1}] run playsound minecraft:block.smoker.smoke block @a ~ ~ ~ 0.5 0
execute as @s[scores={wasd.timer=10..}] run scoreboard players reset @s wasd.timer
particle minecraft:mycelium ~ ~1.2 ~ 0.2 0.1 0.2 1 1
execute positioned ~ ~1 ~ if block ~ ~ ~ #wasd.machine:crushable run function wasd.machine_crusher:zzz/3
execute unless block ~ ~1 ~ #wasd.machine:crushable run scoreboard players reset @s wasd.break_time
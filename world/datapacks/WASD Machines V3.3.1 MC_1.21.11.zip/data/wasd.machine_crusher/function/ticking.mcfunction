#mc-build WASD content
execute unless block ~ ~ ~ redstone_lamp run function wasd.machine_crusher:zzz/1
execute if block ~ ~ ~ minecraft:redstone_lamp[lit=true] run function wasd.machine_crusher:active
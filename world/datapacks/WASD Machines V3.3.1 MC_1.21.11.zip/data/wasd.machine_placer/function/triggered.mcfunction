#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=5}] run function wasd.machine_placer:do_dropper_check
execute as @s[scores={wasd.timer=5..}] if block ~ ~ ~ minecraft:dropper[triggered=true] run tag @s add wasd.still_powered
execute as @s[scores={wasd.timer=5..}] run tag @s remove wasd.placer_triggered
execute as @s[scores={wasd.timer=5..}] run scoreboard players reset @s wasd.timer
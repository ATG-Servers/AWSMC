#mc-build WASD content
execute as @s[tag=wasd.south] run setblock ~ ~ ~ dropper[facing=south]{CustomName:{"text":"Block Placer"}} replace
execute as @s[tag=wasd.west] run setblock ~ ~ ~ dropper[facing=west]{CustomName:{"text":"Block Placer"}} replace
execute as @s[tag=wasd.north] run setblock ~ ~ ~ dropper[facing=north]{CustomName:{"text":"Block Placer"}} replace
execute as @s[tag=wasd.east] run setblock ~ ~ ~ dropper[facing=east]{CustomName:{"text":"Block Placer"}} replace
execute as @s[tag=wasd.up] run setblock ~ ~ ~ dropper[facing=up]{CustomName:{"text":"Block Placer"}} replace
execute as @s[tag=wasd.down] run setblock ~ ~ ~ dropper[facing=down]{CustomName:{"text":"Block Placer"}} replace
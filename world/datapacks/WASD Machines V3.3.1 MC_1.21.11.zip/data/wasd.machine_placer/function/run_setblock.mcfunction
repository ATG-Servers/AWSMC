#mc-build WASD content
$setblock ~ ~ ~ $(id)
kill @s
#mc-build WASD content
tag @s add wasd.powered
execute as @n[type=item,distance=..3,nbt={Age:1s,OnGround:0b}] at @s align xyz positioned ~0.5 ~ ~0.5 if block ~ ~ ~ #minecraft:replaceable run function wasd.machine_placer:item_to_block with entity @s Item
#mc-build WASD content
function wasd.machine_placer:zzz/1
execute as @s[tag=!wasd.placer_triggered,tag=!wasd.still_powered] if block ~ ~ ~ minecraft:dropper[triggered=true] run tag @s add wasd.placer_triggered
execute as @s[tag=wasd.placer_triggered] run function wasd.machine_placer:triggered
execute if block ~ ~ ~ minecraft:dropper[triggered=false] run tag @s remove wasd.still_powered
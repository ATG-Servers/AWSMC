#mc-build WASD content
$summon block_display ~ ~ ~ {block_state:{Name:"$(id)"},Tags:["wasd.valid_block_check"]}
execute unless entity @n[tag=wasd.valid_block_check,nbt={block_state:{Name:"minecraft:air"}}] run function wasd.machine_placer:run_setblock with entity @s Item
kill @n[tag=wasd.valid_block_check]
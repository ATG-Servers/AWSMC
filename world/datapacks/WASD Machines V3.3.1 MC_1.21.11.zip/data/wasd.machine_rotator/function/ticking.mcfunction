#mc-build WASD content
function wasd.machine_rotator:zzz/1
execute as @s[tag=!wasd.rotator_triggered,tag=!wasd.still_powered] if block ~ ~ ~ minecraft:redstone_lamp[lit=true] run tag @s add wasd.rotator_triggered
execute as @s[tag=wasd.rotator_triggered] run function wasd.machine_rotator:zzz/3
execute if block ~ ~ ~ minecraft:redstone_lamp[lit=false] run tag @s remove wasd.still_powered
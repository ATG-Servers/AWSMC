#mc-build WASD content
scoreboard players reset @s wasd.temp
#all logs/wood/stripped
function wasd.machine_rotator:zzz/4
function wasd.machine_rotator:zzz/6
function wasd.machine_rotator:zzz/8
function wasd.machine_rotator:zzz/10
function wasd.machine_rotator:zzz/12
function wasd.machine_rotator:zzz/14
function wasd.machine_rotator:zzz/16
function wasd.machine_rotator:zzz/18
function wasd.machine_rotator:zzz/20
function wasd.machine_rotator:zzz/22
function wasd.machine_rotator:zzz/24
function wasd.machine_rotator:zzz/26
function wasd.machine_rotator:zzz/28
function wasd.machine_rotator:zzz/30
function wasd.machine_rotator:zzz/32
function wasd.machine_rotator:zzz/34
function wasd.machine_rotator:zzz/36
function wasd.machine_rotator:zzz/38
function wasd.machine_rotator:zzz/40
function wasd.machine_rotator:zzz/42
function wasd.machine_rotator:zzz/44
function wasd.machine_rotator:zzz/46
function wasd.machine_rotator:zzz/48
function wasd.machine_rotator:zzz/50
function wasd.machine_rotator:zzz/52
function wasd.machine_rotator:zzz/54
function wasd.machine_rotator:zzz/56
function wasd.machine_rotator:zzz/58
function wasd.machine_rotator:zzz/60
function wasd.machine_rotator:zzz/62
function wasd.machine_rotator:zzz/64
function wasd.machine_rotator:zzz/66
#every other xyz block.
function wasd.machine_rotator:zzz/68
function wasd.machine_rotator:zzz/70
function wasd.machine_rotator:zzz/72
function wasd.machine_rotator:zzz/74
function wasd.machine_rotator:zzz/76
function wasd.machine_rotator:zzz/78
#blocks that have north/south/east/west rotations (terracotta)
execute if block ~ ~ ~ white_glazed_terracotta run function wasd.machine_rotator:zzz/80
execute if block ~ ~ ~ orange_glazed_terracotta run function wasd.machine_rotator:zzz/82
execute if block ~ ~ ~ magenta_glazed_terracotta run function wasd.machine_rotator:zzz/84
execute if block ~ ~ ~ light_blue_glazed_terracotta run function wasd.machine_rotator:zzz/86
execute if block ~ ~ ~ yellow_glazed_terracotta run function wasd.machine_rotator:zzz/88
execute if block ~ ~ ~ lime_glazed_terracotta run function wasd.machine_rotator:zzz/90
execute if block ~ ~ ~ pink_glazed_terracotta run function wasd.machine_rotator:zzz/92
execute if block ~ ~ ~ gray_glazed_terracotta run function wasd.machine_rotator:zzz/94
execute if block ~ ~ ~ light_gray_glazed_terracotta run function wasd.machine_rotator:zzz/96
execute if block ~ ~ ~ cyan_glazed_terracotta run function wasd.machine_rotator:zzz/98
execute if block ~ ~ ~ purple_glazed_terracotta run function wasd.machine_rotator:zzz/100
execute if block ~ ~ ~ blue_glazed_terracotta run function wasd.machine_rotator:zzz/102
execute if block ~ ~ ~ brown_glazed_terracotta run function wasd.machine_rotator:zzz/104
execute if block ~ ~ ~ green_glazed_terracotta run function wasd.machine_rotator:zzz/106
execute if block ~ ~ ~ red_glazed_terracotta run function wasd.machine_rotator:zzz/108
execute if block ~ ~ ~ black_glazed_terracotta run function wasd.machine_rotator:zzz/110
#blocks that have north/south/east/west rotations (all others)
execute if block ~ ~ ~ carved_pumpkin run function wasd.machine_rotator:zzz/112
execute if block ~ ~ ~ jack_o_lantern run function wasd.machine_rotator:zzz/114
execute if block ~ ~ ~ stonecutter run function wasd.machine_rotator:zzz/116
execute if block ~ ~ ~ loom run function wasd.machine_rotator:zzz/118
execute if block ~ ~ ~ anvil run function wasd.machine_rotator:zzz/120
execute if block ~ ~ ~ chipped_anvil run function wasd.machine_rotator:zzz/122
execute if block ~ ~ ~ damaged_anvil run function wasd.machine_rotator:zzz/124
execute if block ~ ~ ~ ender_chest run function wasd.machine_rotator:zzz/126
#blocks with nbt that needs to be stored (4 directions)
execute if block ~ ~ ~ chest run function wasd.machine_rotator:zzz/128
execute if block ~ ~ ~ furnace run function wasd.machine_rotator:zzz/130
execute if block ~ ~ ~ trapped_chest run function wasd.machine_rotator:zzz/132
execute if block ~ ~ ~ smoker run function wasd.machine_rotator:zzz/134
execute if block ~ ~ ~ blast_furnace run function wasd.machine_rotator:zzz/136
execute if block ~ ~ ~ soul_campfire run function wasd.machine_rotator:zzz/138
execute if block ~ ~ ~ campfire run function wasd.machine_rotator:zzz/140
execute if block ~ ~ ~ lectern run function wasd.machine_rotator:zzz/142
#blocks with nbt that needs to be stored (6 directions)
execute if block ~ ~ ~ dispenser run function wasd.machine_rotator:zzz/144
execute if block ~ ~ ~ dropper run function wasd.machine_rotator:zzz/146
execute if block ~ ~ ~ barrel run function wasd.machine_rotator:zzz/148
execute if block ~ ~ ~ shulker_box run function wasd.machine_rotator:zzz/150
execute if block ~ ~ ~ black_shulker_box run function wasd.machine_rotator:zzz/152
execute if block ~ ~ ~ blue_shulker_box run function wasd.machine_rotator:zzz/154
execute if block ~ ~ ~ brown_shulker_box run function wasd.machine_rotator:zzz/156
execute if block ~ ~ ~ cyan_shulker_box run function wasd.machine_rotator:zzz/158
execute if block ~ ~ ~ gray_shulker_box run function wasd.machine_rotator:zzz/160
execute if block ~ ~ ~ green_shulker_box run function wasd.machine_rotator:zzz/162
execute if block ~ ~ ~ light_blue_shulker_box run function wasd.machine_rotator:zzz/164
execute if block ~ ~ ~ light_gray_shulker_box run function wasd.machine_rotator:zzz/166
execute if block ~ ~ ~ lime_shulker_box run function wasd.machine_rotator:zzz/168
execute if block ~ ~ ~ magenta_shulker_box run function wasd.machine_rotator:zzz/170
execute if block ~ ~ ~ orange_shulker_box run function wasd.machine_rotator:zzz/172
execute if block ~ ~ ~ pink_shulker_box run function wasd.machine_rotator:zzz/174
execute if block ~ ~ ~ purple_shulker_box run function wasd.machine_rotator:zzz/176
execute if block ~ ~ ~ red_shulker_box run function wasd.machine_rotator:zzz/178
execute if block ~ ~ ~ white_shulker_box run function wasd.machine_rotator:zzz/180
execute if block ~ ~ ~ yellow_shulker_box run function wasd.machine_rotator:zzz/182
execute if block ~ ~ ~ hopper run function wasd.machine_rotator:zzz/184
#redstone
execute if block ~ ~ ~ repeater run function wasd.machine_rotator:zzz/186
execute if block ~ ~ ~ comparator run function wasd.machine_rotator:zzz/187
#pistons
function wasd.machine_rotator:zzz/188
function wasd.machine_rotator:zzz/190
#6 directional
execute if block ~ ~ ~ end_rod run function wasd.machine_rotator:zzz/192
execute if block ~ ~ ~ observer run function wasd.machine_rotator:zzz/194
execute if block ~ ~ ~ lightning_rod run function wasd.machine_rotator:zzz/196
#trapdoors
function wasd.machine_rotator:zzz/198
function wasd.machine_rotator:zzz/200
function wasd.machine_rotator:zzz/202
function wasd.machine_rotator:zzz/204
function wasd.machine_rotator:zzz/206
function wasd.machine_rotator:zzz/208
function wasd.machine_rotator:zzz/210
function wasd.machine_rotator:zzz/212
function wasd.machine_rotator:zzz/214
#fence gates
function wasd.machine_rotator:zzz/216
function wasd.machine_rotator:zzz/218
function wasd.machine_rotator:zzz/220
function wasd.machine_rotator:zzz/222
function wasd.machine_rotator:zzz/224
function wasd.machine_rotator:zzz/226
function wasd.machine_rotator:zzz/228
function wasd.machine_rotator:zzz/230
#stairs
function wasd.machine_rotator:zzz/232
function wasd.machine_rotator:zzz/234
function wasd.machine_rotator:zzz/236
function wasd.machine_rotator:zzz/238
function wasd.machine_rotator:zzz/240
function wasd.machine_rotator:zzz/242
function wasd.machine_rotator:zzz/244
function wasd.machine_rotator:zzz/246
function wasd.machine_rotator:zzz/248
function wasd.machine_rotator:zzz/250
function wasd.machine_rotator:zzz/252
function wasd.machine_rotator:zzz/254
function wasd.machine_rotator:zzz/256
function wasd.machine_rotator:zzz/258
function wasd.machine_rotator:zzz/260
function wasd.machine_rotator:zzz/262
function wasd.machine_rotator:zzz/264
function wasd.machine_rotator:zzz/266
function wasd.machine_rotator:zzz/268
function wasd.machine_rotator:zzz/270
function wasd.machine_rotator:zzz/272
function wasd.machine_rotator:zzz/274
function wasd.machine_rotator:zzz/276
function wasd.machine_rotator:zzz/278
function wasd.machine_rotator:zzz/280
function wasd.machine_rotator:zzz/282
function wasd.machine_rotator:zzz/284
function wasd.machine_rotator:zzz/286
function wasd.machine_rotator:zzz/288
function wasd.machine_rotator:zzz/290
function wasd.machine_rotator:zzz/292
function wasd.machine_rotator:zzz/294
function wasd.machine_rotator:zzz/296
function wasd.machine_rotator:zzz/298
function wasd.machine_rotator:zzz/300
function wasd.machine_rotator:zzz/302
function wasd.machine_rotator:zzz/304
function wasd.machine_rotator:zzz/306
function wasd.machine_rotator:zzz/308
function wasd.machine_rotator:zzz/310
function wasd.machine_rotator:zzz/312
function wasd.machine_rotator:zzz/314
function wasd.machine_rotator:zzz/316
function wasd.machine_rotator:zzz/318
function wasd.machine_rotator:zzz/320
function wasd.machine_rotator:zzz/322
function wasd.machine_rotator:zzz/324
function wasd.machine_rotator:zzz/326
#rails
function wasd.machine_rotator:zzz/328
function wasd.machine_rotator:zzz/330
function wasd.machine_rotator:zzz/332
execute if block ~ ~ ~ rail run function wasd.machine_rotator:zzz/334
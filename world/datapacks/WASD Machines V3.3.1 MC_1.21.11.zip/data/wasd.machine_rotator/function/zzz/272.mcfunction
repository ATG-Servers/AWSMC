#mc-build WASD content
execute if block ~ ~ ~ smooth_red_sandstone_stairs run function wasd.machine_rotator:zzz/273
#mc-build WASD content
data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ hopper[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ hopper[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ hopper[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ hopper[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ hopper[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ hopper[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ hopper[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ hopper[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ hopper[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ hopper[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items
kill @s
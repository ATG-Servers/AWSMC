#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dropper[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ dropper[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
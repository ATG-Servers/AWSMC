#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ carved_pumpkin[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ carved_pumpkin[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ carved_pumpkin[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ carved_pumpkin[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ carved_pumpkin[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ carved_pumpkin[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ carved_pumpkin[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ carved_pumpkin[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/113
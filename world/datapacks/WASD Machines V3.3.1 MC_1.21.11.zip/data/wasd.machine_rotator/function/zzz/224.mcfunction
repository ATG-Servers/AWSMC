#mc-build WASD content
execute if block ~ ~ ~ oak_fence_gate run function wasd.machine_rotator:zzz/225
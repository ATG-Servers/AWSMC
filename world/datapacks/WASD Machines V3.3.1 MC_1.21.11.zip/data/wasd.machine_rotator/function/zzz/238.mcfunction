#mc-build WASD content
execute if block ~ ~ ~ jungle_stairs run function wasd.machine_rotator:zzz/239
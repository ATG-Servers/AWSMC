#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=false,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=false,facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=false,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=false,facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=false,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=false,facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=false,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=false,facing=north]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=true,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=true,facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=true,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=true,facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=true,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=true,facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_fence_gate[open=true,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ jungle_fence_gate[open=true,facing=north]
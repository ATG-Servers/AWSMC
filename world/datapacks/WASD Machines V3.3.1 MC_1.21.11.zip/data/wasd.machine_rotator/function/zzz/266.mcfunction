#mc-build WASD content
execute if block ~ ~ ~ prismarine_stairs run function wasd.machine_rotator:zzz/267
#mc-build WASD content
#<Block's tag> <Base Block ie stone> 
execute unless block ~ ~ ~ redstone_lamp run function wasd.machine_rotator:zzz/2
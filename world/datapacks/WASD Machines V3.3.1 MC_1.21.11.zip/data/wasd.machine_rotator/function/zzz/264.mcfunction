#mc-build WASD content
execute if block ~ ~ ~ prismarine_brick_stairs run function wasd.machine_rotator:zzz/265
#mc-build WASD content
execute if block ~ ~ ~ oak_trapdoor run function wasd.machine_rotator:zzz/207
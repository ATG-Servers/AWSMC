#mc-build WASD content
execute if block ~ ~ ~ dark_oak_trapdoor run function wasd.machine_rotator:zzz/203
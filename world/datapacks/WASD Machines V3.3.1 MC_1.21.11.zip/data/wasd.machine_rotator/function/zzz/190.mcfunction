#mc-build WASD content
execute if block ~ ~ ~ sticky_piston run function wasd.machine_rotator:zzz/191
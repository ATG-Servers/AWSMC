#mc-build WASD content
execute if block ~ ~ ~ crimson_stairs run function wasd.machine_rotator:zzz/245
#mc-build WASD content
execute if block ~ ~ ~ jungle_trapdoor run function wasd.machine_rotator:zzz/205
#mc-build WASD content
execute if block ~ ~ ~ acacia_stairs run function wasd.machine_rotator:zzz/241
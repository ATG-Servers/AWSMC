#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ smoker[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ smoker[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ smoker[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ smoker[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ smoker[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ smoker[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ smoker[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ smoker[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
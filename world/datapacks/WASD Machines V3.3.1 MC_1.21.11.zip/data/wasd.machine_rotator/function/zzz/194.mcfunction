#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ observer[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ observer[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/195
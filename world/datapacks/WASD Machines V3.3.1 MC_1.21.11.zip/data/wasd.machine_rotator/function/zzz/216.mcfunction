#mc-build WASD content
execute if block ~ ~ ~ acacia_fence_gate run function wasd.machine_rotator:zzz/217
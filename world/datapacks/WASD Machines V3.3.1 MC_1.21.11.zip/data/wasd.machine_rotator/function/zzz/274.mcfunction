#mc-build WASD content
execute if block ~ ~ ~ mossy_stone_brick_stairs run function wasd.machine_rotator:zzz/275
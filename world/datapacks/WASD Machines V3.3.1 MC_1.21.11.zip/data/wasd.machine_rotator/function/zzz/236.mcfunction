#mc-build WASD content
execute if block ~ ~ ~ birch_stairs run function wasd.machine_rotator:zzz/237
#mc-build WASD content
execute if block ~ ~ ~ polished_diorite_stairs run function wasd.machine_rotator:zzz/277
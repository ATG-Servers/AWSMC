#mc-build WASD content
execute if block ~ ~ ~ acacia_log run function wasd.machine_rotator:zzz/15
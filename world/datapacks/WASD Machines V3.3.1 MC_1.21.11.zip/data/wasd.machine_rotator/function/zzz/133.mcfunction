#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ trapped_chest[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ trapped_chest[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ trapped_chest[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ trapped_chest[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ trapped_chest[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ trapped_chest[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ trapped_chest[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ trapped_chest[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
#mc-build WASD content
execute if block ~ ~ ~ jungle_log run function wasd.machine_rotator:zzz/11
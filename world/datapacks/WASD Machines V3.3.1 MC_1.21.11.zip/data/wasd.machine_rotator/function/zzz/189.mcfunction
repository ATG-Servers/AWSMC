#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=up] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ piston[extended=false,facing=down] store success score @s wasd.temp run setblock ~ ~ ~ piston[facing=north]
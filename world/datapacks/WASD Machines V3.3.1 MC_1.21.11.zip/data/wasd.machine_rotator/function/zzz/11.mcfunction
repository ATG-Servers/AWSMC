#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_log[axis=x] store success score @s wasd.temp run setblock ~ ~ ~ jungle_log[axis=y]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_log[axis=y] store success score @s wasd.temp run setblock ~ ~ ~ jungle_log[axis=z]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_log[axis=z] store success score @s wasd.temp run setblock ~ ~ ~ jungle_log[axis=x]
#mc-build WASD content
data modify entity @s data.Items set from block ~ ~ ~ Book
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=true,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=true,facing=east]{Book:{id:"minecraft:writable_book",Count:1b}}
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=true,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=true,facing=south]{Book:{id:"minecraft:writable_book",Count:1b}}
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=true,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=true,facing=west]{Book:{id:"minecraft:writable_book",Count:1b}}
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=true,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=true,facing=north]{Book:{id:"minecraft:writable_book",Count:1b}}
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=false,facing=north] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=false,facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=false,facing=east] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=false,facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=false,facing=south] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=false,facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ lectern[has_book=false,facing=west] store success score @s wasd.temp run setblock ~ ~ ~ lectern[has_book=false,facing=north]
data modify block ~ ~ ~ Book set from entity @s data.Items
kill @s
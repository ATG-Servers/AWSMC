#mc-build WASD content
execute if block ~ ~ ~ crimson_trapdoor run function wasd.machine_rotator:zzz/211
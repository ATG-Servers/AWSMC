#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_wood[axis=x] store success score @s wasd.temp run setblock ~ ~ ~ jungle_wood[axis=y]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_wood[axis=y] store success score @s wasd.temp run setblock ~ ~ ~ jungle_wood[axis=z]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jungle_wood[axis=z] store success score @s wasd.temp run setblock ~ ~ ~ jungle_wood[axis=x]
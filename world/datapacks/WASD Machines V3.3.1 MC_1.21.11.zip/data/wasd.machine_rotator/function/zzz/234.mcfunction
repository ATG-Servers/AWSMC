#mc-build WASD content
execute if block ~ ~ ~ spruce_stairs run function wasd.machine_rotator:zzz/235
#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ soul_campfire[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ soul_campfire[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ soul_campfire[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ soul_campfire[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ soul_campfire[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ soul_campfire[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ soul_campfire[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ soul_campfire[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
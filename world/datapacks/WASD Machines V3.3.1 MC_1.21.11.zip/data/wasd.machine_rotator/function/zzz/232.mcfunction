#mc-build WASD content
execute if block ~ ~ ~ oak_stairs run function wasd.machine_rotator:zzz/233
#mc-build WASD content
execute if block ~ ~ ~ dark_prismarine_stairs run function wasd.machine_rotator:zzz/269
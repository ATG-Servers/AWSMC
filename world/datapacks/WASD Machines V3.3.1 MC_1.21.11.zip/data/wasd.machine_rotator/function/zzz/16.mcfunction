#mc-build WASD content
execute if block ~ ~ ~ warped_stem run function wasd.machine_rotator:zzz/17
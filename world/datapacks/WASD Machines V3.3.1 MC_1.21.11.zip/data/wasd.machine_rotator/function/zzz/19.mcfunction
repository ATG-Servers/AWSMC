#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ crimson_stem[axis=x] store success score @s wasd.temp run setblock ~ ~ ~ crimson_stem[axis=y]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ crimson_stem[axis=y] store success score @s wasd.temp run setblock ~ ~ ~ crimson_stem[axis=z]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ crimson_stem[axis=z] store success score @s wasd.temp run setblock ~ ~ ~ crimson_stem[axis=x]
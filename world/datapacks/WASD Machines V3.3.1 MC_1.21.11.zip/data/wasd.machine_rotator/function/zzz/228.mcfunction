#mc-build WASD content
execute if block ~ ~ ~ crimson_fence_gate run function wasd.machine_rotator:zzz/229
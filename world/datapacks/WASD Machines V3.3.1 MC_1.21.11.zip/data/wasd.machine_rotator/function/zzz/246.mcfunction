#mc-build WASD content
execute if block ~ ~ ~ warped_stairs run function wasd.machine_rotator:zzz/247
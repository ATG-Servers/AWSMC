#mc-build WASD content
execute if block ~ ~ ~ purpur_stairs run function wasd.machine_rotator:zzz/259
#mc-build WASD content
execute if block ~ ~ ~ spruce_wood run function wasd.machine_rotator:zzz/25
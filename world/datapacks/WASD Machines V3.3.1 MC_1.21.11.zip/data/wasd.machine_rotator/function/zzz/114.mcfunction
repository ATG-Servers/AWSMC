#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jack_o_lantern[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ jack_o_lantern[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jack_o_lantern[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ jack_o_lantern[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jack_o_lantern[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ jack_o_lantern[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ jack_o_lantern[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ jack_o_lantern[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/115
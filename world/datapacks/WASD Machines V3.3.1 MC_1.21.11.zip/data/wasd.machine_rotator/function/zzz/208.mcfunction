#mc-build WASD content
execute if block ~ ~ ~ spruce_trapdoor run function wasd.machine_rotator:zzz/209
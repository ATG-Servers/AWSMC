#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dispenser[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ dispenser[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
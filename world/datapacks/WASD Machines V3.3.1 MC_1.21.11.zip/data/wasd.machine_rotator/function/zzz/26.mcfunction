#mc-build WASD content
execute if block ~ ~ ~ jungle_wood run function wasd.machine_rotator:zzz/27
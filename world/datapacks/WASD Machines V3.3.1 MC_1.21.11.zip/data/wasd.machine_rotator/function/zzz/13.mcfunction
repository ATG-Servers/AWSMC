#mc-build WASD content
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dark_oak_log[axis=x] store success score @s wasd.temp run setblock ~ ~ ~ dark_oak_log[axis=y]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dark_oak_log[axis=y] store success score @s wasd.temp run setblock ~ ~ ~ dark_oak_log[axis=z]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ dark_oak_log[axis=z] store success score @s wasd.temp run setblock ~ ~ ~ dark_oak_log[axis=x]
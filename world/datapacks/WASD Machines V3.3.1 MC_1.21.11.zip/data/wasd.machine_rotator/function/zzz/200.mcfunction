#mc-build WASD content
execute if block ~ ~ ~ birch_trapdoor run function wasd.machine_rotator:zzz/201
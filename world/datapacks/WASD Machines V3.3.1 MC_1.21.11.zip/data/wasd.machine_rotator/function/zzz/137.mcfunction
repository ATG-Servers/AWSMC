#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ blast_furnace[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ blast_furnace[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ blast_furnace[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ blast_furnace[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ blast_furnace[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ blast_furnace[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ blast_furnace[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ blast_furnace[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
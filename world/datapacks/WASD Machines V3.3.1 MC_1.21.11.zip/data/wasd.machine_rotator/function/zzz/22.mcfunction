#mc-build WASD content
execute if block ~ ~ ~ birch_wood run function wasd.machine_rotator:zzz/23
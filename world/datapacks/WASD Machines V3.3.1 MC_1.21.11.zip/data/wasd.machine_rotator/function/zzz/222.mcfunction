#mc-build WASD content
execute if block ~ ~ ~ jungle_fence_gate run function wasd.machine_rotator:zzz/223
#mc-build WASD content
execute if block ~ ~ ~ dark_oak_log run function wasd.machine_rotator:zzz/13
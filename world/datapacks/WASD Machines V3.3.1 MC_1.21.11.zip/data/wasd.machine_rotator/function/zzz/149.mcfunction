#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ barrel[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ barrel[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
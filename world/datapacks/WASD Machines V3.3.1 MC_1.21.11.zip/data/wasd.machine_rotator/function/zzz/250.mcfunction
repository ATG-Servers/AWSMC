#mc-build WASD content
execute if block ~ ~ ~ sandstone_stairs run function wasd.machine_rotator:zzz/251
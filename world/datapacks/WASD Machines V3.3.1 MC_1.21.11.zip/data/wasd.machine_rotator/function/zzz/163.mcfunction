#mc-build WASD content

data modify entity @s data.Items set from block ~ ~ ~ Items
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ green_shulker_box[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ green_shulker_box[facing=north]
data modify block ~ ~ ~ Items set from entity @s data.Items

kill @s
#mc-build WASD content
execute if block ~ ~ ~ dark_oak_fence_gate run function wasd.machine_rotator:zzz/221
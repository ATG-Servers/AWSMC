#mc-build WASD content
execute if block ~ ~ ~ quartz_stairs run function wasd.machine_rotator:zzz/261
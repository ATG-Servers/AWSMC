#mc-build WASD content
execute if block ~ ~ ~ oak_wood run function wasd.machine_rotator:zzz/21
#mc-build WASD content
execute if block ~ ~ ~ brick_stairs run function wasd.machine_rotator:zzz/257
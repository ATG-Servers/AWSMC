#mc-build WASD content
execute if block ~ ~ ~ warped_fence_gate run function wasd.machine_rotator:zzz/231
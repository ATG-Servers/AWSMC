#mc-build WASD content
execute if block ~ ~ ~ stone_brick_stairs run function wasd.machine_rotator:zzz/255
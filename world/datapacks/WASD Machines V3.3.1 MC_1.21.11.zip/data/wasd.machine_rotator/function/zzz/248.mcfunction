#mc-build WASD content
execute if block ~ ~ ~ cobblestone_stairs run function wasd.machine_rotator:zzz/249
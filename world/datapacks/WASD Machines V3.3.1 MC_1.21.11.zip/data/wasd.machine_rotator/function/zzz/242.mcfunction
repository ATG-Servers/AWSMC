#mc-build WASD content
execute if block ~ ~ ~ dark_oak_stairs run function wasd.machine_rotator:zzz/243
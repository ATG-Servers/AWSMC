#mc-build WASD content
execute if block ~ ~ ~ acacia_trapdoor run function wasd.machine_rotator:zzz/199
#mc-build WASD content
execute if block ~ ~ ~ spruce_fence_gate run function wasd.machine_rotator:zzz/227
#mc-build WASD content
execute if block ~ ~ ~ crimson_stem run function wasd.machine_rotator:zzz/19
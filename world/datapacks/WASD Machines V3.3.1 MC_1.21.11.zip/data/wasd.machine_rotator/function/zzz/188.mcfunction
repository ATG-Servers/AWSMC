#mc-build WASD content
execute if block ~ ~ ~ piston run function wasd.machine_rotator:zzz/189
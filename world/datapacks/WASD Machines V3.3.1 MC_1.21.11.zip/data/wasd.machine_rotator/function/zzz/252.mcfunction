#mc-build WASD content
execute if block ~ ~ ~ nether_brick_stairs run function wasd.machine_rotator:zzz/253
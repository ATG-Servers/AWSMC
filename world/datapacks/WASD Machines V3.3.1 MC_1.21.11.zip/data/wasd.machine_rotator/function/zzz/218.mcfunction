#mc-build WASD content
execute if block ~ ~ ~ birch_fence_gate run function wasd.machine_rotator:zzz/219
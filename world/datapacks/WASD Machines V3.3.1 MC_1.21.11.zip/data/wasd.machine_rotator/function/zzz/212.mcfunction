#mc-build WASD content
execute if block ~ ~ ~ warped_trapdoor run function wasd.machine_rotator:zzz/213
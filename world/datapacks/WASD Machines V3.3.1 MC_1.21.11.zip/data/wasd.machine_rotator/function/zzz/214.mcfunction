#mc-build WASD content
execute if block ~ ~ ~ iron_trapdoor run function wasd.machine_rotator:zzz/215
#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=up]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=up] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=down]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ end_rod[facing=down] store success score @s wasd.temp run setblock ~ ~ ~ end_rod[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/193
#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ stonecutter[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ stonecutter[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ stonecutter[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ stonecutter[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ stonecutter[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ stonecutter[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ stonecutter[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ stonecutter[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/117
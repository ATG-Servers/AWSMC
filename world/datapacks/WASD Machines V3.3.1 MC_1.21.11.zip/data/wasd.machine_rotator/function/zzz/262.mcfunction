#mc-build WASD content
execute if block ~ ~ ~ red_sandstone_stairs run function wasd.machine_rotator:zzz/263
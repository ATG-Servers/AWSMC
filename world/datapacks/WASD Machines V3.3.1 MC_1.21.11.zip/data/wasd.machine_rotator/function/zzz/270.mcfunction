#mc-build WASD content
execute if block ~ ~ ~ polished_granite_stairs run function wasd.machine_rotator:zzz/271
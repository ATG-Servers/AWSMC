#mc-build WASD content
execute if block ~ ~ ~ mossy_cobblestone_stairs run function wasd.machine_rotator:zzz/279
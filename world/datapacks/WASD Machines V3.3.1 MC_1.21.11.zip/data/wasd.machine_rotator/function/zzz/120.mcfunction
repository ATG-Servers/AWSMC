#mc-build WASD content

execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ anvil[facing=north] store success score @s wasd.temp run setblock ~ ~ ~ anvil[facing=east]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ anvil[facing=east] store success score @s wasd.temp run setblock ~ ~ ~ anvil[facing=south]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ anvil[facing=south] store success score @s wasd.temp run setblock ~ ~ ~ anvil[facing=west]
execute unless score @s wasd.temp matches 1.. if block ~ ~ ~ anvil[facing=west] store success score @s wasd.temp run setblock ~ ~ ~ anvil[facing=north]

summon marker ~ ~ ~ {Tags:["wasd.blockdata_to_copy"],data:{Items:[]}}
execute as @e[tag=wasd.blockdata_to_copy,sort=nearest,limit=1] run function wasd.machine_rotator:zzz/121
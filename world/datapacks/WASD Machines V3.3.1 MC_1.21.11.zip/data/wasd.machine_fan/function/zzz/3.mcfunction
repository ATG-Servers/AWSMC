#mc-build WASD content
execute as @s[tag=wasd.south] if block ~ ~ ~1 #wasd.tags:nonsolid run scoreboard players add @s wasd.timer 1
execute as @s[tag=wasd.west] if block ~-1 ~ ~ #wasd.tags:nonsolid run scoreboard players add @s wasd.timer 1
execute as @s[tag=wasd.north] if block ~ ~ ~-1 #wasd.tags:nonsolid run scoreboard players add @s wasd.timer 1
execute as @s[tag=wasd.east] if block ~1 ~ ~ #wasd.tags:nonsolid run scoreboard players add @s wasd.timer 1
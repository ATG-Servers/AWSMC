#mc-build WASD content
particle minecraft:poof ~ ~ ~ 1 0 0 1.5 0 normal
execute positioned ~2 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~3 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~5 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~7 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~9 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~11 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
execute positioned ~13 ~ ~ as @e[type=#wasd.tags:mobs,distance=..2] run function wasd.machine_fan:motion_4
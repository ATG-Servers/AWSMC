#mc-build WASD content
scoreboard players reset @s wasd.timer
execute as @s[tag=wasd.south] positioned ~ ~0.5 ~0.5 run function wasd.machine_fan:zzz/5
execute as @s[tag=wasd.west] positioned ~-0.5 ~0.5 ~ run function wasd.machine_fan:zzz/6
execute as @s[tag=wasd.north] positioned ~ ~0.5 ~-0.5 run function wasd.machine_fan:zzz/7
execute as @s[tag=wasd.east] positioned ~0.5 ~0.5 ~ run function wasd.machine_fan:zzz/8
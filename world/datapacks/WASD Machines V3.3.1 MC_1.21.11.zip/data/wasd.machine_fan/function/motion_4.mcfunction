#mc-build WASD content
data modify entity @s Motion[0] set value 1.0
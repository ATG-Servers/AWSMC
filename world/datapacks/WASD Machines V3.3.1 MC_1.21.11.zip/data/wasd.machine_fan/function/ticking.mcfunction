#mc-build WASD content
function wasd.machine_fan:zzz/1
execute if entity @a[distance=..128] run function wasd.machine_fan:zzz/3
execute as @s[scores={wasd.timer=3..}] run function wasd.machine_fan:zzz/4
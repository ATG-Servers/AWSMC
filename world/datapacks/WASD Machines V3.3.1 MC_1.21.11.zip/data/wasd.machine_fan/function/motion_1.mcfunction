#mc-build WASD content
data modify entity @s Motion[2] set value 1.0
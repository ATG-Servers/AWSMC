#mc-build WASD content
execute at @s run function wasd.machine_fluid_pipe:zzz/25
#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ barrier replace
execute unless block ~ ~ ~ barrier run function wasd.machine_fluid_pipe:zzz/0
execute if block ~ ~ ~ barrier align y run function wasd.machine_fluid_pipe:zzz/1
execute align y run tp @n[type=item_display,tag=wasd.fluid_pipe] ~ ~ ~
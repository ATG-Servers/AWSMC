#mc-build WASD content
#pull from fluid tank
execute if entity @n[type=item_display,tag=wasd.machine,tag=wasd.stored_liquid,distance=..0.01] run function wasd.machine_fluid_pipe:zzz/10
#pull from other pipes
execute if entity @n[tag=!wasd.skip,type=item_display,tag=wasd.machine,tag=wasd.fluid_pipe,distance=..0.01,scores={wasd.water_amount=250..}] unless entity @s[scores={wasd.lava_amount=1..}] run function wasd.machine_fluid_pipe:zzz/13
execute if entity @n[tag=!wasd.skip,type=item_display,tag=wasd.machine,tag=wasd.fluid_pipe,distance=..0.01,scores={wasd.lava_amount=250..}] unless entity @s[scores={wasd.water_amount=1..}] run function wasd.machine_fluid_pipe:zzz/14
#pull from cauldrons and water source
execute if block ~ ~ ~ lava_cauldron unless entity @s[scores={wasd.fluid_amount=1..}] run function wasd.machine_fluid_pipe:zzz/15
execute if block ~ ~ ~ lava[level=0] unless entity @s[scores={wasd.fluid_amount=1..}] run function wasd.machine_fluid_pipe:zzz/16
execute if block ~ ~ ~ water_cauldron[level=3] unless entity @s[scores={wasd.fluid_amount=1..}] run function wasd.machine_fluid_pipe:zzz/17
execute if block ~ ~ ~ water[level=0] unless entity @s[scores={wasd.water_amount=751..}] unless entity @s[scores={wasd.lava_amount=1..}] run function wasd.machine_fluid_pipe:zzz/18
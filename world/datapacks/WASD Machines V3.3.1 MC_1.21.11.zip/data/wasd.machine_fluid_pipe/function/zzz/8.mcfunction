#mc-build WASD content
tag @s remove wasd.wait_one
tag @s remove wasd.new_lava
function wasd.machine_fluid_pipe:lava_changed
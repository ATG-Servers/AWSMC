#mc-build WASD content
tag @s add wasd.east
data merge entity @s {Rotation:[-90F,0F]}
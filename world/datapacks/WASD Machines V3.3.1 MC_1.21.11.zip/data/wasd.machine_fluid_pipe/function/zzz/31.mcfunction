#mc-build WASD content
execute as @s[tag=wasd.south] run scoreboard players set @s wasd.rotation 1
execute as @s[tag=wasd.west] run scoreboard players set @s wasd.rotation 2
execute as @s[tag=wasd.north] run scoreboard players set @s wasd.rotation 3
execute as @s[tag=wasd.east] run scoreboard players set @s wasd.rotation 4
tag @s remove wasd.south
tag @s remove wasd.west
tag @s remove wasd.north
tag @s remove wasd.east
scoreboard players add @s wasd.rotation 1
execute as @s[scores={wasd.rotation=2}] run function wasd.machine_fluid_pipe:zzz/32
execute as @s[scores={wasd.rotation=3}] run function wasd.machine_fluid_pipe:zzz/33
execute as @s[scores={wasd.rotation=4}] run function wasd.machine_fluid_pipe:zzz/34
scoreboard players set @s[scores={wasd.rotation=5}] wasd.rotation 1
execute as @s[scores={wasd.rotation=1}] run function wasd.machine_fluid_pipe:zzz/35
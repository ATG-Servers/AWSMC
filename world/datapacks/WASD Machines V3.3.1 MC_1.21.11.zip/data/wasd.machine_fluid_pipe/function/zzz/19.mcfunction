#mc-build WASD content
scoreboard players add @n[type=interaction,tag=wasd.fluid_tank_interaction,distance=..0.01] wasd.water_amount 250
execute as @n[type=interaction,tag=wasd.fluid_tank_interaction,distance=..0.01] run function wasd.machine_fluid_tank:water_changed
scoreboard players remove @s wasd.fluid_amount 250
scoreboard players remove @s wasd.water_amount 250
function wasd.machine_fluid_pipe:water_changed
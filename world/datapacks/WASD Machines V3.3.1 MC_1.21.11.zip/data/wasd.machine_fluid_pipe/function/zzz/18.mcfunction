#mc-build WASD content
scoreboard players add @s wasd.fluid_amount 250
scoreboard players add @s wasd.water_amount 250
function wasd.machine_fluid_pipe:water_changed
#mc-build WASD content
setblock ~ ~ ~ cauldron
scoreboard players add @s wasd.fluid_amount 1000
scoreboard players add @s wasd.water_amount 1000
function wasd.machine_fluid_pipe:water_changed
#mc-build WASD content
tag @s add wasd.south
data merge entity @s {Rotation:[0F,0F]}
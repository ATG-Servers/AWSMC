#mc-build WASD content
scoreboard players operation @s wasd.temp = @s wasd.water_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.01] transformation.translation[1] float 0.01 run scoreboard players operation @s wasd.temp /= 21 wasd.constants
scoreboard players operation @s wasd.temp = @s wasd.water_amount
execute store result entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.01] transformation.scale[1] float 0.01 run scoreboard players operation @s wasd.temp /= 10 wasd.constants
data merge entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.01] {start_interpolation:0}
execute positioned ~ ~ ~ unless entity @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.05] run function wasd.machine_fluid_pipe:summon_water
execute if score @s wasd.water_amount matches ..0 run tag @n[type=item_display,tag=wasd.machine,tag=wasd.fake_water,distance=..0.01] add wasd.kill_me
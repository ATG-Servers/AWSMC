#mc-build WASD content
setblock ~ ~ ~ air
scoreboard players add @s wasd.fluid_amount 1000
scoreboard players add @s wasd.lava_amount 1000
function wasd.machine_fluid_pipe:lava_changed
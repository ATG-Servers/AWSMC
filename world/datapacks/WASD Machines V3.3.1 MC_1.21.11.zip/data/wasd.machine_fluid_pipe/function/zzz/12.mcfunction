#mc-build WASD content
scoreboard players remove @n[type=interaction,tag=wasd.fluid_tank_interaction,distance=..0.01] wasd.lava_amount 250
execute as @n[type=interaction,tag=wasd.fluid_tank_interaction,distance=..0.01] run function wasd.machine_fluid_tank:lava_changed
scoreboard players add @s wasd.fluid_amount 250
scoreboard players add @s wasd.lava_amount 250
function wasd.machine_fluid_pipe:lava_changed
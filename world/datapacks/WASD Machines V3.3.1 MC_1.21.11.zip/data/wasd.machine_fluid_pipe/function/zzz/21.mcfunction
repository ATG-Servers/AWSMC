#mc-build WASD content
scoreboard players add @n[type=item_display,tag=wasd.fluid_pipe,distance=..0.01] wasd.fluid_amount 250
scoreboard players add @n[type=item_display,tag=wasd.fluid_pipe,distance=..0.01] wasd.water_amount 250
execute as @n[type=item_display,tag=wasd.fluid_pipe,distance=..0.01] positioned ~ ~ ~ run function wasd.machine_fluid_pipe:water_changed
scoreboard players remove @s wasd.fluid_amount 250
scoreboard players remove @s wasd.water_amount 250
function wasd.machine_fluid_pipe:water_changed
#mc-build WASD content
tag @s remove wasd.down
tag @s add wasd.normal
data merge entity @s {transformation:[1.0100f,0.0000f,0.0000f,0.0000f,0.0000f,1.0100f,0.0000f,0.4700f,0.0000f,0.0000f,1.0100f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f]}
#mc-build WASD content
tag @s add wasd.north
data merge entity @s {Rotation:[180F,0F]}
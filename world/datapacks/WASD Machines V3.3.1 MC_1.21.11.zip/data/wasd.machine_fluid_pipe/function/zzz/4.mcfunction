#mc-build WASD content
execute as @s[tag=wasd.south] positioned ~ ~ ~1 run function wasd.machine_fluid_pipe:push
execute as @s[tag=wasd.north] positioned ~ ~ ~-1 run function wasd.machine_fluid_pipe:push
execute as @s[tag=wasd.east] positioned ~1 ~ ~ run function wasd.machine_fluid_pipe:push
execute as @s[tag=wasd.west] positioned ~-1 ~ ~ run function wasd.machine_fluid_pipe:push
execute as @s[tag=wasd.up] positioned ~ ~1 ~ run function wasd.machine_fluid_pipe:push
execute as @s[tag=wasd.down] positioned ~ ~-1 ~ run function wasd.machine_fluid_pipe:push
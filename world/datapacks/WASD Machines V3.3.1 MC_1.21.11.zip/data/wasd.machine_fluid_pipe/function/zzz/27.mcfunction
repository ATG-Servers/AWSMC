#mc-build WASD content
execute as @s[tag=wasd.down] run function wasd.machine_fluid_pipe:zzz/28
execute as @s[tag=wasd.up] run function wasd.machine_fluid_pipe:zzz/29
execute unless entity @s[tag=wasd.normal] unless entity @s[tag=wasd.up] unless entity @s[tag=wasd.down] run function wasd.machine_fluid_pipe:zzz/30
tag @s remove wasd.normal
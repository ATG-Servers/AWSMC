#mc-build WASD content
function wasd.machine_fluid_pipe:zzz/2
summon interaction ~ ~ ~ {width:1.01f,height:1.01f,Tags:["wasd.machine","wasd.fluid_pipe_interaction","wasd.interaction_entity"]}
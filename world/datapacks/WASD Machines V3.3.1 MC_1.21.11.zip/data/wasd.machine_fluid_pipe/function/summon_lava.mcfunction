#mc-build WASD content
tag @s add wasd.skip
tag @s add wasd.new_lava
summon item_display ~ ~ ~ {interpolation_duration:10,start_interpolation:0,Rotation:[90F,0F],Tags:["wasd.machine","wasd.fake_lava","wasd.stored_liquid"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.0f,0.0f],scale:[1.0f,0.0f,1.0f]},item:{id:"minecraft:item_frame",count:1,components:{"minecraft:item_model":"wasd:objects/fake_lava"}}}
#mc-build WASD content
execute if score wasd.global_0.5 wasd.timer matches 1 unless score @s wasd.fluid_amount matches 1000.. unless entity @s[tag=wasd.skip] run function wasd.machine_fluid_pipe:zzz/3
execute if score wasd.global_0.5 wasd.timer matches 6 if score @s wasd.fluid_amount matches 1.. unless entity @s[tag=wasd.skip] run function wasd.machine_fluid_pipe:zzz/4
execute if score wasd.global_0.5 wasd.timer matches 9 if entity @s[tag=wasd.skip] run tag @s[tag=wasd.skip] remove wasd.skip
execute as @s[tag=wasd.new_water] run function wasd.machine_fluid_pipe:zzz/5
execute as @s[tag=wasd.new_lava] run function wasd.machine_fluid_pipe:zzz/7
execute as @n[type=item_display,tag=wasd.kill_me,tag=wasd.machine,distance=..0.01] run function wasd.machine_fluid_pipe:zzz/9
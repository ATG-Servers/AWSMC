#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
#block to place. Done here in case of needing data
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ polished_blackstone_slab replace
#
function wasd.machine_chunk_loader:zzz/0
summon item_display ~ ~ ~ {Tags:["wasd.machine","wasd.chunk_loader_star"],brightness:{sky:15,block:15},interpolation_duration:20,start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1.48f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:machine/chunk_loader_star"}}}
execute as @e[type=item_display,tag=wasd.chunk_loader,sort=nearest,limit=1,distance=..0.001] run function wasd.machine_chunk_loader:zzz/1
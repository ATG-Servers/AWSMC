#mc-build WASD content
tag @s add wasd.active
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 2 0.5
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 2 0.5
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 2 0.5
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 2 0.5
playsound minecraft:block.beacon.activate player @a ~ ~ ~ 2 0.5
particle minecraft:flash{color:[0.761, 0.961, 1.000,1.00]}
particle dust{color:[0.761, 0.961, 1.000], scale:4.0} ~ ~4 ~ 0 2 0 1 100 normal
execute if score range wasd.chunkloader matches 1 run forceload add ~ ~ ~ ~
execute if score range wasd.chunkloader matches 2 run forceload add ~16 ~16 ~-16 ~-16
execute if score range wasd.chunkloader matches 3 run forceload add ~32 ~32 ~-32 ~-32
execute if score range wasd.chunkloader matches 4 run forceload add ~48 ~48 ~-48 ~-48
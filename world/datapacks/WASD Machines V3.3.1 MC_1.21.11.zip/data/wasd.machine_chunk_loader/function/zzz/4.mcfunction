#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1}] run data merge entity @s {interpolation_duration:20,start_interpolation:0,transformation:[-1.0100f,0.0000f,0.0000f,0.0000f,0.0000f,1.0100f,0.0000f,1.4800f,-0.0000f,0.0000f,-1.0100f,0.0000f,0.0000f,0.0000f,0.0000f,1.0000f]}
execute as @s[scores={wasd.timer=21}] run data merge entity @s {interpolation_duration:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1.48f,0f],scale:[1.01f,1.01f,1.01f]}}
execute as @s[scores={wasd.timer=21..}] run scoreboard players reset @s wasd.timer
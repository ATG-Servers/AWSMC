#mc-build WASD content
execute as @a run function wasd.lib:util/store_uuid
tag @p[scores={wasd.placed_item_frame=1..}] add wasd.load_placer
scoreboard players operation @s wasd.uuid1 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid1
scoreboard players operation @s wasd.uuid2 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid2
scoreboard players operation @s wasd.uuid3 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid3
scoreboard players operation @s wasd.uuid4 = @p[scores={wasd.placed_item_frame=1..}] wasd.uuid4
scoreboard players reset @p[scores={wasd.placed_item_frame=1..}] wasd.load_count
execute at @e[tag=wasd.chunk_loader] if score @e[tag=wasd.chunk_loader,sort=nearest,limit=1] wasd.uuid1 = @s wasd.uuid1 if score @e[tag=wasd.chunk_loader,sort=nearest,limit=1] wasd.uuid2 = @s wasd.uuid2 if score @e[tag=wasd.chunk_loader,sort=nearest,limit=1] wasd.uuid3 = @s wasd.uuid3 if score @e[tag=wasd.chunk_loader,sort=nearest,limit=1] wasd.uuid4 = @s wasd.uuid4 at @s run scoreboard players add @p[scores={wasd.placed_item_frame=1..}] wasd.load_count 1
scoreboard players operation @p[scores={wasd.placed_item_frame=1..}] wasd.load_count -= 1 wasd.constants
execute unless score amount wasd.chunkloader < @p[scores={wasd.placed_item_frame=1..}] wasd.load_count run function wasd.machine_chunk_loader:activate
tag @p[scores={wasd.placed_item_frame=1..}] remove wasd.load_placer
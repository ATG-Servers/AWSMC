#mc-build WASD content
particle minecraft:end_rod ~0.5 ~0.9 ~
particle minecraft:end_rod ~-0.5 ~0.9 ~
particle minecraft:end_rod ~ ~0.9 ~0.5
particle minecraft:end_rod ~ ~0.9 ~-0.5
particle minecraft:portal ~ ~ ~ 0.05 0.05 0.05 0.3 2
particle minecraft:falling_dust{block_state:{Name:"minecraft:purple_wool"}}
#cause star to spin
execute as @e[tag=wasd.chunk_loader_star,sort=nearest,limit=1] run function wasd.machine_chunk_loader:zzz/4
#mc-build WASD content
execute if block ~ ~ ~1 #wasd.tags:pistons[extended=true,facing=north] run fill ~ ~ ~-1 ~ ~ ~-1 air replace minecraft:moving_piston
execute if block ~ ~ ~-1 #wasd.tags:pistons[extended=true,facing=south] run fill ~ ~ ~1 ~ ~ ~1 air replace minecraft:moving_piston
execute if block ~-1 ~ ~ #wasd.tags:pistons[extended=true,facing=east] run fill ~1 ~ ~ ~1 ~ ~ air replace minecraft:moving_piston
execute if block ~1 ~ ~ #wasd.tags:pistons[extended=true,facing=west] run fill ~-1 ~ ~ ~-1 ~ ~ air replace minecraft:moving_piston
execute if block ~ ~-1 ~ #wasd.tags:pistons[extended=true,facing=up] run fill ~ ~1 ~ ~ ~1 ~ air replace minecraft:moving_piston
execute if block ~ ~1 ~ #wasd.tags:pistons[extended=true,facing=down] run fill ~ ~-1 ~ ~ ~-1 ~ air replace minecraft:moving_piston
loot spawn ~ ~0.5 ~ loot wasd.machine:machines/chunk_loader
kill @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s,Item:{id:"minecraft:polished_blackstone_slab"}}]
kill @e[type=item_display,tag=wasd.chunk_loader_star,sort=nearest,limit=1,distance=..0.001]
kill @s
execute if score range wasd.chunkloader matches 1 run forceload remove ~ ~ ~ ~
execute if score range wasd.chunkloader matches 2 run forceload remove ~16 ~16 ~-16 ~-16
execute if score range wasd.chunkloader matches 3 run forceload remove ~32 ~32 ~-32 ~-32
execute if score range wasd.chunkloader matches 4 run forceload remove ~48 ~48 ~-48 ~-48
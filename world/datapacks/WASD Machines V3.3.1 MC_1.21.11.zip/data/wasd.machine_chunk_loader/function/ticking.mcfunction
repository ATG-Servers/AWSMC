#mc-build WASD content
execute unless block ~ ~ ~ polished_blackstone_slab run function wasd.machine_chunk_loader:zzz/2
execute as @s[tag=wasd.active] if entity @p[distance=..32] run function wasd.machine_chunk_loader:zzz/3
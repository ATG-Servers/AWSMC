#mc-build WASD content
execute if entity @p[tag=wasd.right_click,predicate=wasd.lib:sneaking] run scoreboard players remove @s wasd.temp 1
execute if entity @p[tag=wasd.right_click,predicate=!wasd.lib:sneaking] run scoreboard players add @s wasd.temp 1
execute as @s[scores={wasd.temp=..-1}] run scoreboard players set @s wasd.temp 8
execute as @s[scores={wasd.temp=1}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370124f
execute as @s[scores={wasd.temp=2}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370122f
execute as @s[scores={wasd.temp=3}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370121f
execute as @s[scores={wasd.temp=4}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370125f
execute as @s[scores={wasd.temp=5}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370120f
execute as @s[scores={wasd.temp=6}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370123f
execute as @s[scores={wasd.temp=7}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370119f
execute as @s[scores={wasd.temp=8}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370155f
execute as @s[scores={wasd.temp=9}] run scoreboard players set @s wasd.temp 0
execute as @s[scores={wasd.temp=0}] run data modify entity @s item.components."minecraft:custom_model_data".floats[0] set value 6370118f
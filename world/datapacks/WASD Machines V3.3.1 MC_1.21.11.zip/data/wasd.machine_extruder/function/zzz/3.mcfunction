#mc-build WASD content
execute as @s[tag=wasd.south] if block ~ ~ ~1 #wasd.tags:air positioned ~ ~ ~-1 if block ~ ~ ~ cobblestone run function wasd.machine_extruder:eat_cobblestone
execute as @s[tag=wasd.west] if block ~-1 ~ ~ #wasd.tags:air positioned ~1 ~ ~ if block ~ ~ ~ cobblestone run function wasd.machine_extruder:eat_cobblestone
execute as @s[tag=wasd.north] if block ~ ~ ~-1 #wasd.tags:air positioned ~ ~ ~1 if block ~ ~ ~ cobblestone run function wasd.machine_extruder:eat_cobblestone
execute as @s[tag=wasd.east] if block ~1 ~ ~ #wasd.tags:air positioned ~-1 ~ ~ if block ~ ~ ~ cobblestone run function wasd.machine_extruder:eat_cobblestone
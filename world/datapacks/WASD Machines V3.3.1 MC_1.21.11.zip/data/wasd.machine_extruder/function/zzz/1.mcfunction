#mc-build WASD content
scoreboard players set @s wasd.temp 0
data merge entity @s {item:{components:{"minecraft:custom_model_data":{floats:[6370118]}}}}
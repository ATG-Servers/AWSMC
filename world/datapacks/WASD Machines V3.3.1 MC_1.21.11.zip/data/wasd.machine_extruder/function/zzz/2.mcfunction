#mc-build WASD content
execute if block ~ ~ ~1 #wasd.tags:pistons[extended=true,facing=north] run fill ~ ~ ~-1 ~ ~ ~-1 air replace minecraft:moving_piston
execute if block ~ ~ ~-1 #wasd.tags:pistons[extended=true,facing=south] run fill ~ ~ ~1 ~ ~ ~1 air replace minecraft:moving_piston
execute if block ~-1 ~ ~ #wasd.tags:pistons[extended=true,facing=east] run fill ~1 ~ ~ ~1 ~ ~ air replace minecraft:moving_piston
execute if block ~1 ~ ~ #wasd.tags:pistons[extended=true,facing=west] run fill ~-1 ~ ~ ~-1 ~ ~ air replace minecraft:moving_piston
execute if block ~ ~-1 ~ #wasd.tags:pistons[extended=true,facing=up] run fill ~ ~1 ~ ~ ~1 ~ air replace minecraft:moving_piston
execute if block ~ ~1 ~ #wasd.tags:pistons[extended=true,facing=down] run fill ~ ~-1 ~ ~ ~-1 ~ air replace minecraft:moving_piston
loot spawn ~ ~0.5 ~ loot wasd.machine:machines/extruder
kill @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s,Item:{id:"minecraft:glass"}}]
kill @e[type=interaction,tag=wasd.extruder_interaction,sort=nearest,limit=1,distance=..0.001]
kill @e[type=item_display,tag=wasd.extruder_visual,sort=nearest,limit=1,distance=..0.001]
kill @e[type=item_display,tag=wasd.extruder_visual2,sort=nearest,limit=1,distance=..0.001]
kill @s
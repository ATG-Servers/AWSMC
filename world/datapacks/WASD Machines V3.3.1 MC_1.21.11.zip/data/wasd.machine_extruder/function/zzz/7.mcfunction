#mc-build WASD content
playsound block.fire.extinguish block @a ~ ~ ~ 0.5 1
scoreboard players reset @s wasd.timer
tag @s remove wasd.ate_cobblestone
kill @e[tag=wasd.extruder_visual2,sort=nearest,limit=1,distance=..0.001]
execute as @s[tag=wasd.south] positioned ~ ~ ~1 run function wasd.machine_extruder:set_new_stone
execute as @s[tag=wasd.west] positioned ~-1 ~ ~ run function wasd.machine_extruder:set_new_stone
execute as @s[tag=wasd.north] positioned ~ ~ ~-1 run function wasd.machine_extruder:set_new_stone
execute as @s[tag=wasd.east] positioned ~1 ~ ~ run function wasd.machine_extruder:set_new_stone
#mc-build WASD content
particle flame ~ ~0.5 ~ 0.085 0.085 0.085 0 3 normal
particle dust_color_transition{from_color:[0.831, 0.22, 0.067],scale:1,to_color:[0.98, 0.592, 0.09]} ~ ~0.5 ~ 0.12 0.12 0.12 0 2
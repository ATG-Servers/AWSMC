#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=2}] run function wasd.machine_extruder:zzz/5
execute as @s[scores={wasd.timer=5..75}] run function wasd.machine_extruder:zzz/6
execute as @s[scores={wasd.timer=40}] run kill @e[type=minecraft:item_display,tag=wasd.extruder_visual,sort=nearest,limit=1,distance=..0.001]
execute as @s[scores={wasd.timer=80..}] run function wasd.machine_extruder:zzz/7
#mc-build WASD content
execute as @s[scores={wasd.temp=0}] run setblock ~ ~ ~ andesite keep
execute as @s[scores={wasd.temp=1}] run setblock ~ ~ ~ granite keep
execute as @s[scores={wasd.temp=2}] run setblock ~ ~ ~ diorite keep
execute as @s[scores={wasd.temp=3}] run setblock ~ ~ ~ cobbled_deepslate keep
execute as @s[scores={wasd.temp=4}] run setblock ~ ~ ~ tuff keep
execute as @s[scores={wasd.temp=5}] run setblock ~ ~ ~ calcite keep
execute as @s[scores={wasd.temp=6}] run setblock ~ ~ ~ dripstone_block keep
execute as @s[scores={wasd.temp=7}] run setblock ~ ~ ~ blackstone keep
execute as @s[scores={wasd.temp=8}] run setblock ~ ~ ~ basalt keep
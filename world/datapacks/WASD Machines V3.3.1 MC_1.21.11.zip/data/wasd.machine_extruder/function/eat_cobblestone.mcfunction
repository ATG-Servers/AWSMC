#mc-build WASD content
tag @s add wasd.ate_cobblestone
setblock ~ ~ ~ air replace
playsound block.stone.break block @a ~ ~ ~ 0.5 1
particle block{block_state:{Name:"minecraft:cobblestone"}} ~ ~0.5 ~ 0.2 0.2 0.2 0 10 normal
execute at @s run function wasd.machine_extruder:zzz/9
#mc-build WASD content
execute if block ~ ~ ~ water run setblock ~ ~ ~ air replace
execute if block ~ ~ ~ lava run setblock ~ ~ ~ air replace
#block to place. Done here in case of needing data
execute if block ~ ~ ~ #wasd.tags:air run setblock ~ ~ ~ glass replace
#
function wasd.machine_extruder:zzz/0
summon interaction ~ ~ ~ {width:0.5f,height:1.1f,Tags:["wasd.machine","wasd.extruder_interaction","wasd.interaction_entity"]}
execute as @n[type=minecraft:item_display,tag=wasd.extruder,distance=..0.001] run function wasd.machine_extruder:zzz/1
#mc-build WASD content
execute as @e[type=minecraft:item_display,tag=wasd.extruder,sort=nearest,limit=1,distance=..0.001] run function wasd.machine_extruder:zzz/8
#mc-build WASD content
execute unless block ~ ~ ~ glass run function wasd.machine_extruder:zzz/2
execute if entity @a[distance=..128] unless entity @s[tag=wasd.ate_cobblestone] run function wasd.machine_extruder:zzz/3
execute as @s[tag=wasd.ate_cobblestone] run function wasd.machine_extruder:zzz/4
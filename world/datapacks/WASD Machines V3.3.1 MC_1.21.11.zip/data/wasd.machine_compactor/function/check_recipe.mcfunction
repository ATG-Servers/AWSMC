#mc-build WASD content
execute store result score @s wasd.timer run data get block ~ ~-1 ~ Items
execute unless score @s wasd.timer matches 2.. run function wasd.machine_compactor:zzz/3
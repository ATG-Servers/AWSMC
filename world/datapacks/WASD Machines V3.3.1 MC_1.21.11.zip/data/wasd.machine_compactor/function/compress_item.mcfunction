#mc-build WASD content
execute store result score @s wasd.temp3 run data get block ~ ~ ~ Items[0].count
execute as @s[scores={wasd.temp2=1..999}] store result block ~ ~ ~ Items.[0].count byte 1 run scoreboard players operation @s wasd.temp3 -= 4 wasd.constants
execute as @s[scores={wasd.temp2=1000..}] store result block ~ ~ ~ Items.[0].count byte 1 run scoreboard players operation @s wasd.temp3 -= 9 wasd.constants
execute as @s[scores={wasd.temp3=0}] run data remove block ~ ~ ~ Items[0]
playsound block.piston.extend block @a ~ ~ ~ 0.5 0.5
execute as @s[tag=wasd.north] run summon minecraft:item ~ ~0.3 ~-0.7 {Tags:["wasd.compressed_item"],Motion:[0.0,0.1,-0.15],Item:{id:"minecraft:stone",count:1}}
execute as @s[tag=wasd.south] run summon minecraft:item ~ ~0.3 ~0.7 {Tags:["wasd.compressed_item"],Motion:[0.0,0.1,0.15],Item:{id:"minecraft:stone",count:1}}
execute as @s[tag=wasd.east] run summon minecraft:item ~0.7 ~0.3 ~ {Tags:["wasd.compressed_item"],Motion:[0.15,0.1,0.0],Item:{id:"minecraft:stone",count:1}}
execute as @s[tag=wasd.west] run summon minecraft:item ~-0.7 ~0.3 ~ {Tags:["wasd.compressed_item"],Motion:[-0.15,0.1,0.0],Item:{id:"minecraft:stone",count:1}}
execute as @s[scores={wasd.temp2=1}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:nether_bricks"}}
execute as @s[scores={wasd.temp2=2}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:quartz_block",count:1}}
execute as @s[scores={wasd.temp2=3}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:quartz_pillar",count:4}}
execute as @s[scores={wasd.temp2=4}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:honey_block"}}
execute as @s[scores={wasd.temp2=5}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_deepslate",count:4}}
execute as @s[scores={wasd.temp2=6}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_granite",count:4}}
execute as @s[scores={wasd.temp2=7}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_andesite",count:4}}
execute as @s[scores={wasd.temp2=8}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:magma_block"}}
execute as @s[scores={wasd.temp2=9}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:end_stone_bricks",count:4}}
execute as @s[scores={wasd.temp2=10}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:purpur_block",count:4}}
execute as @s[scores={wasd.temp2=11}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:acacia_wood",count:3}}
execute as @s[scores={wasd.temp2=12}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:dark_oak_wood",count:3}}
execute as @s[scores={wasd.temp2=13}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:oak_wood",count:3}}
execute as @s[scores={wasd.temp2=14}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:birch_wood",count:3}}
execute as @s[scores={wasd.temp2=15}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:jungle_wood",count:3}}
execute as @s[scores={wasd.temp2=16}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:spruce_wood",count:3}}
execute as @s[scores={wasd.temp2=17}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:warped_hyphae",count:3}}
execute as @s[scores={wasd.temp2=18}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:crimson_hyphae",count:3}}
execute as @s[scores={wasd.temp2=19}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_blackstone_bricks",count:4}}
execute as @s[scores={wasd.temp2=20}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_blackstone",count:4}}
execute as @s[scores={wasd.temp2=21}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:bricks",count:4}}
execute as @s[scores={wasd.temp2=22}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:snow_block"}}
execute as @s[scores={wasd.temp2=23}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:clay"}}
execute as @s[scores={wasd.temp2=24}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:glowstone"}}
execute as @s[scores={wasd.temp2=25}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:sandstone"}}
execute as @s[scores={wasd.temp2=26}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:red_sandstone"}}
execute as @s[scores={wasd.temp2=27}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:stone_bricks",count:4}}
execute as @s[scores={wasd.temp2=28}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:amethyst_block"}}
execute as @s[scores={wasd.temp2=29}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:white_wool"}}
execute as @s[scores={wasd.temp2=30}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:dripstone_block"}}
execute as @s[scores={wasd.temp2=31}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_diorite",count:4}}
execute as @s[scores={wasd.temp2=32}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:deepslate_tiles",count:4}}
execute as @s[scores={wasd.temp2=33}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:deepslate_bricks",count:4}}
execute as @s[scores={wasd.temp2=34}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:cut_copper",count:4}}
execute as @s[scores={wasd.temp2=35}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:exposed_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=36}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:weathered_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=37}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:oxidized_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=38}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:waxed_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=39}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:waxed_exposed_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=40}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:waxed_weathered_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=41}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:waxed_oxidized_cut_copper",count:4}}
execute as @s[scores={wasd.temp2=42}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:mangrove_wood",count:3}}
execute as @s[scores={wasd.temp2=43}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:cherry_wood",count:3}}
execute as @s[scores={wasd.temp2=44}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:polished_tuff",count:4}}
execute as @s[scores={wasd.temp2=45}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:tuff_bricks",count:4}}
execute as @s[scores={wasd.temp2=1000}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:hay_block"}}
execute as @s[scores={wasd.temp2=1001}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:packed_ice"}}
execute as @s[scores={wasd.temp2=1002}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:bone_block"}}
execute as @s[scores={wasd.temp2=1003}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:nether_wart_block"}}
execute as @s[scores={wasd.temp2=1004}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:dried_kelp_block"}}
execute as @s[scores={wasd.temp2=1005}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:emerald_block"}}
execute as @s[scores={wasd.temp2=1006}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:coal_block"}}
execute as @s[scores={wasd.temp2=1007}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:netherite_block"}}
execute as @s[scores={wasd.temp2=1008}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:gold_block"}}
execute as @s[scores={wasd.temp2=1009}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:lapis_block"}}
execute as @s[scores={wasd.temp2=1010}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:melon"}}
execute as @s[scores={wasd.temp2=1011}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:iron_block"}}
execute as @s[scores={wasd.temp2=1012}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:blue_ice"}}
execute as @s[scores={wasd.temp2=1013}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:copper_block"}}
execute as @s[scores={wasd.temp2=1014}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:raw_gold_block"}}
execute as @s[scores={wasd.temp2=1015}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:raw_copper_block"}}
execute as @s[scores={wasd.temp2=1016}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:raw_iron_block"}}
execute as @s[scores={wasd.temp2=1017}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:diamond_block"}}
execute as @s[scores={wasd.temp2=1018}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:slime_block"}}
execute as @s[scores={wasd.temp2=1019}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:redstone_block"}}
execute as @s[scores={wasd.temp2=1020}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:iron_ingot"}}
execute as @s[scores={wasd.temp2=1021}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:gold_ingot"}}
execute as @s[scores={wasd.temp2=1022}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:bamboo_block"}}
execute as @s[scores={wasd.temp2=1023}] run data merge entity @e[tag=wasd.compressed_item,type=item,sort=nearest,limit=1] {Tags:["converted"],Item:{id:"minecraft:cobbled_deepslate"}}
scoreboard players reset @s wasd.temp2
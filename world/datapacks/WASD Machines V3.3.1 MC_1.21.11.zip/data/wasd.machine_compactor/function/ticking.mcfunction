#mc-build WASD content
function wasd.machine_compactor:zzz/1
scoreboard players operation @s wasd.temp = @s wasd.variables
execute store result score @s wasd.variables run data get block ~ ~ ~ Items[0].count
execute unless score @s wasd.temp = @s wasd.variables run function wasd.machine_compactor:check_recipe
execute as @s[scores={wasd.temp2=1..}] run function wasd.machine_compactor:compress_item
#mc-build WASD content
recipe give @s wasd.hoe:big
recipe give @s wasd.hoe:farmers
recipe give @s wasd.hoe:fortune
recipe give @s wasd.hoe:replanting
recipe give @s wasd.hoe:side
recipe give @s wasd.hoe:leaf
recipe give @s wasd.hoe:patron/giant_replanting
recipe give @s wasd.hoe:patron/dyeing
recipe give @s wasd.hoe:patron/tally
recipe give @s wasd.hoe:patron/tobacchoe
recipe give @s wasd.hoe:patron/lucky
recipe give @s wasd.hoe:patron/potat_hoe
recipe give @s wasd.hoe:patron/hoe_hoe_hoe
recipe give @s wasd.hoe:patron/composting
recipe give @s wasd.hoe:patron/ida_hoe
recipe give @s wasd.hoe:patron/backhoe
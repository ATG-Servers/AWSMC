#mc-build WASD content
execute as @s[type=item,tag=wasd.present] run function wasd.hoe:patron/hoes/present
execute as @s[tag=wasd.ida_hoe_entity] run function wasd.hoe:patron/hoes/ida_hoe_entity
execute as @s[tag=wasd.ida_hoe_projectile] run function wasd.hoe:patron/hoes/ida_hoe_projectile
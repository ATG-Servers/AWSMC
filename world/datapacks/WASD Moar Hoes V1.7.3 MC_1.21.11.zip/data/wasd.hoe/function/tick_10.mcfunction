#mc-build WASD content
execute as @a at @s if predicate wasd.hoe:holding_item/hoe12 run function wasd.hoe:hoes/farmers
#mc-build WASD content
execute as @a at @s run function wasd.hoe:as_players
execute as @e[tag=wasd.hoe_entity_tick] at @s run function wasd.hoe:as_entities
execute if score wasd.global_10 wasd.timer matches 1 run function wasd.hoe:tick_10
#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.hoe:items/big
loot insert ~ ~ ~ loot wasd.hoe:items/farmers
loot insert ~ ~ ~ loot wasd.hoe:items/fortune
loot insert ~ ~ ~ loot wasd.hoe:items/replanting
loot insert ~ ~ ~ loot wasd.hoe:items/side
loot insert ~ ~ ~ loot wasd.hoe:items/leaf
function wasd.hoe:patron/insert_items
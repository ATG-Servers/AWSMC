#mc-build WASD content
scoreboard players add @s wasd.farm_timer_hoe 1
execute as @s[scores={wasd.farm_timer_hoe=2..}] run function wasd.hoe:hoes/zzz/8
#mc-build WASD content
function wasd.lib:util/looking_at_block
execute as @e[tag=wasd.block_location] at @s run function wasd.hoe:hoes/zzz/6
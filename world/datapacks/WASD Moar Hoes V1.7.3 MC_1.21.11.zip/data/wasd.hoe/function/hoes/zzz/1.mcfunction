#mc-build WASD content
execute if block ~ ~ ~ carrots run function wasd.hoe:hoes/zzz/2
execute if block ~ ~ ~ potatoes run function wasd.hoe:hoes/zzz/3
execute if block ~ ~ ~ wheat run function wasd.hoe:hoes/zzz/4
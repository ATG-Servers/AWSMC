#mc-build WASD content
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ #wasd.hoe:crops[age=7] run function wasd.hoe:hoes/zzz/1
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ beetroots[age=3] run function wasd.hoe:hoes/zzz/5
kill @s
#mc-build WASD content
playsound block.crop.break player @a ~ ~ ~ 1 1
particle block{block_state:{Name:"minecraft:beetroots",Properties:{age:"3"}}} ~ ~ ~ 0.25 0.25 0.25 0.05 50 force
loot spawn ~ ~ ~ mine ~ ~ ~
setblock ~ ~ ~ beetroots[age=0]
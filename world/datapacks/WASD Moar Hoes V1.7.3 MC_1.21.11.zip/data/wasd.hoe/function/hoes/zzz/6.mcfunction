#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:can_become_farmland run function wasd.lib:detection/cube/5x5
execute as @e[type=marker,tag=wasd.location] at @s run function wasd.hoe:hoes/zzz/7
#mc-build WASD content
playsound block.crop.break player @a ~ ~ ~ 1 1
particle block{block_state:{Name:"minecraft:potatoes",Properties:{age:"7"}}} ~ ~ ~ 0.25 0.25 0.25 0.05 50 force
loot spawn ~ ~ ~ mine ~ ~ ~
setblock ~ ~ ~ potatoes[age=0]
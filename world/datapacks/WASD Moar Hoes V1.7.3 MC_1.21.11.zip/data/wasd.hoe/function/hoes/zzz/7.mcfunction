#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:can_become_farmland if block ~ ~1 ~ #wasd.tags:air run setblock ~ ~ ~ farmland replace
execute if block ~ ~ ~ coarse_dirt run setblock ~ ~ ~ dirt replace
kill @s
#mc-build WASD content
function wasd.hoe:looking_at_crop
execute as @e[tag=wasd.crop_location] at @s run function wasd.hoe:hoes/zzz/0
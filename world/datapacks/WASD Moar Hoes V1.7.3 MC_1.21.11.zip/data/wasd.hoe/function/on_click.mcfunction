#mc-build WASD content
execute if predicate wasd.hoe:holding_item/hoe1 run function wasd.hoe:hoes/replanting
execute if predicate wasd.hoe:holding_item/hoe2 run function wasd.hoe:patron/hoes/giant_replanting
execute if predicate wasd.hoe:holding_item/hoe3 run function wasd.hoe:patron/hoes/dyeing
execute if predicate wasd.hoe:holding_item/hoe4 run function wasd.hoe:patron/hoes/tally
execute unless score @s wasd.hoe_cooldown matches 1.. if predicate wasd.hoe:holding_item/hoe5 run function wasd.hoe:patron/hoes/tobacchoe
#reset at the end so you can execute at the player that just clicked.
scoreboard players reset @s wasd.hoe_click
#mc-build WASD content
loot give @s loot wasd.hoe:items/big
loot give @s loot wasd.hoe:items/farmers
loot give @s loot wasd.hoe:items/fortune
loot give @s loot wasd.hoe:items/replanting
loot give @s loot wasd.hoe:items/side
loot give @s loot wasd.hoe:items/leaf
function wasd.hoe:patron/give_items
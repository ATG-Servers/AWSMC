#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_hoe wasd_data_packs 1
scoreboard objectives remove wasd.used_hoe
scoreboard objectives add wasd.used_hoe minecraft.used:minecraft.stone_hoe
scoreboard objectives add wasd.hoe_click minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add wasd.farm_timer_hoe dummy
scoreboard objectives add wasd.tally_hoe dummy
scoreboard objectives add wasd.hoe_cooldown dummy
scoreboard objectives add wasd.hoe_setting dummy
function wasd.hoe:config
schedule function wasd.hoe:check_installed_packs 30t replace
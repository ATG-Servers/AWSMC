#mc-build WASD content
execute if predicate wasd.hoe:holding_item/hoe6 run function wasd.hoe:hoes/big
execute if predicate wasd.hoe:holding_item/hoe8 positioned ^ ^ ^3 as @e[type=item,distance=..5,nbt={OnGround:0b,Age:0s}] at @s run function wasd.hoe:patron/hoes/lucky
execute if predicate wasd.hoe:holding_item/hoe9 positioned ^ ^ ^3 as @e[type=item,distance=..5,nbt={OnGround:0b,Age:0s}] at @s run function wasd.hoe:patron/hoes/potat_hoe
execute if predicate wasd.hoe:holding_item/hoe11 positioned ^ ^ ^3 as @e[type=item,distance=..5,nbt={OnGround:0b,Age:0s}] at @s run function wasd.hoe:patron/hoes/hoe_hoe_hoe
execute if predicate wasd.hoe:holding_item/hoe13 positioned ^ ^ ^3 as @e[type=item,distance=..5,nbt={OnGround:0b,Age:0s}] at @s run function wasd.hoe:patron/hoes/composting
execute if predicate wasd.hoe:holding_item/hoe14 run function wasd.hoe:patron/hoes/ida_hoe
execute if predicate wasd.hoe:holding_item/hoe15 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.hoe:patron/hoes/backhoe
scoreboard players reset @s wasd.used_hoe
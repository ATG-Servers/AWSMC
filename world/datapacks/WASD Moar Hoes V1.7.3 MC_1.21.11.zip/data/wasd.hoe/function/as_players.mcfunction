#mc-build WASD content
execute as @s[scores={wasd.used_hoe=1..}] run function wasd.hoe:used_hoe
execute as @s[scores={wasd.hoe_click=1..}] run function wasd.hoe:on_click
scoreboard players remove @s[scores={wasd.hoe_cooldown=1..}] wasd.hoe_cooldown 1
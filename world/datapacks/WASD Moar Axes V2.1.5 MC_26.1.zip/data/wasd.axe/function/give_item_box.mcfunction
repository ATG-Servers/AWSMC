#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.axe:items/fire
loot insert ~ ~ ~ loot wasd.axe:items/giant
loot insert ~ ~ ~ loot wasd.axe:items/replanting
loot insert ~ ~ ~ loot wasd.axe:items/water
loot insert ~ ~ ~ loot wasd.axe:items/enchanted
loot insert ~ ~ ~ loot wasd.axe:items/blaze_rod
loot insert ~ ~ ~ loot wasd.axe:items/berserker
loot insert ~ ~ ~ loot wasd.axe:items/magnetic
function wasd.axe:patron/insert_items
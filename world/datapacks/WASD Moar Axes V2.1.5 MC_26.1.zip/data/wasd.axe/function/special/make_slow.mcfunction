#mc-build WASD content
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute as @e[tag=wasd.box_location] at @s store result block ~ ~ ~ Items[0].components."minecraft:tool".rules[0].speed short 1 run scoreboard players operation @s wasd.temp = 8 wasd.constants
execute as @e[tag=wasd.box_location] at @s store result block ~ ~ ~ Items[0].components."minecraft:custom_data".wasd_fast byte 1 run scoreboard players operation @s wasd.temp = 0 wasd.constants
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
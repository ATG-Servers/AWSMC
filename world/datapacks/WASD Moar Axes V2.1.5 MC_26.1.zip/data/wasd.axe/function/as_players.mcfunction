#mc-build WASD content
execute as @s[scores={wasd.attack_axe=1..}] if predicate wasd.axe:holding_item/custom_axe run function wasd.axe:determine_attack
execute as @s[scores={wasd.used_axe=1..}] run function wasd.axe:used_axe
execute as @s[scores={wasd.axe_click=1..}] run function wasd.axe:click
execute if score wasd.global_1 wasd.timer matches 1 if predicate wasd.axe:holding_item/axe4 run function wasd.axe:special/water
scoreboard players remove @s[scores={wasd.axe_click_cooldown=1..}] wasd.axe_click_cooldown 1
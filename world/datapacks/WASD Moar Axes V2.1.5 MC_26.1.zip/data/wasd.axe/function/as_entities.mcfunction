#mc-build WASD content
function wasd.axe:patron/as_entities
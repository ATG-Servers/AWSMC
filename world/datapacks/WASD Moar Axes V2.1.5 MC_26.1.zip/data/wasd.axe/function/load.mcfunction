#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_axes wasd_data_packs 1
scoreboard objectives remove wasd.used_axe
scoreboard objectives add wasd.used_axe minecraft.used:minecraft.stone_axe
scoreboard objectives add wasd.axe_click minecraft.used:minecraft.warped_fungus_on_a_stick
scoreboard objectives add wasd.axe_click_cooldown dummy
scoreboard objectives add wasd.attack_axe minecraft.custom:minecraft.damage_dealt
scoreboard objectives add w.axe_settings dummy
function wasd.axe:config
schedule function wasd.bonsai:check_installed_packs 30t replace
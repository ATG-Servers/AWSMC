#mc-build WASD content
particle flame ~ ~ ~ 0 0 0 0.1 20
particle smoke ~ ~ ~ 0 0 0 0.1 10
playsound minecraft:entity.blaze.shoot block @a ~ ~ ~ 0.1 0.8
scoreboard players reset @s wasd.temp
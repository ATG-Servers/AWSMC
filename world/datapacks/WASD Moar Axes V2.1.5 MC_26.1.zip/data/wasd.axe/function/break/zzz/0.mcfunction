#mc-build WASD content
particle composter ~ ~ ~ 0.3 0.3 0.3 0 50 force
playsound block.azalea_leaves.break player @a ~ ~ ~ 1 1
playsound block.azalea_leaves.break player @a ~ ~ ~ 1 1
playsound block.azalea_leaves.break player @a ~ ~ ~ 1 1
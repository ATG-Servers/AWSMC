#mc-build WASD content
setblock ~ ~ ~ fire keep
playsound minecraft:item.firecharge.use player @a ~ ~ ~ 1 1
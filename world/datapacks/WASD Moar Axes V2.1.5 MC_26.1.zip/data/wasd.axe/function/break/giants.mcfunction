#mc-build WASD content
function wasd.axe:invalid_mine
execute unless entity @s[tag=wasd.invalid_mine_attempt] run fill ~1 ~1 ~1 ~-1 ~-1 ~-1 air replace #wasd.tags:better_axe_mineable destroy
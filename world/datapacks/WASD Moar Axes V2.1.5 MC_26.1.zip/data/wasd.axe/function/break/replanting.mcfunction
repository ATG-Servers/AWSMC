#mc-build WASD content
execute as @s[nbt={Item:{id:"minecraft:oak_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:oak_sapling keep
execute as @s[nbt={Item:{id:"minecraft:birch_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:birch_sapling keep
execute as @s[nbt={Item:{id:"minecraft:spruce_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:spruce_sapling keep
execute as @s[nbt={Item:{id:"minecraft:dark_oak_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:dark_oak_sapling keep
execute as @s[nbt={Item:{id:"minecraft:acacia_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:acacia_sapling keep
execute as @s[nbt={Item:{id:"minecraft:jungle_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:jungle_sapling keep
execute as @s[nbt={Item:{id:"minecraft:mangrove_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:mangrove_propagule keep
execute as @s[nbt={Item:{id:"minecraft:cherry_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:cherry_sapling keep
execute as @s[nbt={Item:{id:"minecraft:pale_oak_log"}}] if block ~ ~-1 ~ #wasd.tags:plant_soil store success score @s wasd.temp run setblock ~ ~ ~ minecraft:pale_oak_sapling keep
execute as @s[scores={wasd.temp=1}] align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.axe:break/zzz/0
#mc-build WASD content
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:oak_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:birch_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:spruce_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:dark_oak_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:acacia_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:jungle_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_oak_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_birch_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_spruce_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_dark_oak_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_acacia_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute store result score @s wasd.temp as @s[nbt={Item:{id:"minecraft:stripped_jungle_log"}}] run data merge entity @s {Item:{id:"minecraft:charcoal"}}
execute as @s[scores={wasd.temp=1..}] run function wasd.axe:break/zzz/2
#mc-build WASD content
damage @p[tag=wasd.attacker] 6 minecraft:player_attack by @s
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 0.1 0.2
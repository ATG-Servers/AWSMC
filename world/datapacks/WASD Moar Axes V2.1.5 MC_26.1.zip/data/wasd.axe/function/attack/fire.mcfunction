#mc-build WASD content
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 1.5
data merge entity @s {Fire:200s}
execute as @s[type=minecraft:player] run setblock ~ ~ ~ fire keep
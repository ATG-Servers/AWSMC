#mc-build WASD content
loot give @s loot wasd.axe:items/patron/ender
loot give @s loot wasd.axe:items/patron/inverted
loot give @s loot wasd.axe:items/patron/throwing
loot give @s loot wasd.axe:items/patron/instant
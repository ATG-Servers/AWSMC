#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_mangrove_wood"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_mangrove_wood[axis=x] run setblock ~ ~ ~ mangrove_wood[axis=x] replace
execute if block ~ ~ ~ stripped_mangrove_wood[axis=y] run setblock ~ ~ ~ mangrove_wood[axis=y] replace
execute if block ~ ~ ~ stripped_mangrove_wood[axis=z] run setblock ~ ~ ~ mangrove_wood[axis=z] replace
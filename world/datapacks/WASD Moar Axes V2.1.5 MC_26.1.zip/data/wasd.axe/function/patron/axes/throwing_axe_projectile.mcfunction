#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=2}] run data merge entity @s {teleport_duration:1}
execute as @s[scores={wasd.timer=100..}] run scoreboard players set @s wasd.temp 6
execute unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.temp 6
tp @s ^ ^ ^0.5 ~ ~1.5
execute as @s[scores={wasd.timer=5..}] run function wasd.axe:patron/axes/zzz/5
execute as @s[scores={wasd.temp=1..}] run function wasd.axe:patron/axes/throwing_hit
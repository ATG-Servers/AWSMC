#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:stripped_logs align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.axe:patron/axes/zzz/13
kill @s
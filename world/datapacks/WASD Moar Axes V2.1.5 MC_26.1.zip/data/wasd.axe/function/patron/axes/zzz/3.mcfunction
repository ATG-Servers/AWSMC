#mc-build WASD content
tp @s ~ ~ ~ ~1 ~
execute rotated ~20 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~40 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~60 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~80 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~100 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~120 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~140 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~160 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~180 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~200 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~220 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~240 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~260 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~280 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~300 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~320 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~340 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
execute rotated ~360 ~ run particle portal ~ ~ ~ ^ ^-10000000 ^-100000000 0.00000001 0 force
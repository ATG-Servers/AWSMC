#mc-build WASD content
execute if entity @a[distance=..32] run function wasd.axe:patron/axes/zzz/3
execute unless entity @a[distance=..128] run kill @s
execute unless block ~ ~-1 ~ #wasd.tags:stripped_logs run kill @s
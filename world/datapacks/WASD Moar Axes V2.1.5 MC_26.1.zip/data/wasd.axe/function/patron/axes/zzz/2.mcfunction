#mc-build WASD content
execute at @e[tag=wasd.ender_axe_location,type=marker] if score @e[tag=wasd.ender_axe_location,type=marker,sort=nearest,limit=1] wasd.uuid1 = @s wasd.uuid1 if score @e[tag=wasd.ender_axe_location,type=marker,sort=nearest,limit=1] wasd.uuid2 = @s wasd.uuid2 if score @e[tag=wasd.ender_axe_location,type=marker,sort=nearest,limit=1] wasd.uuid3 = @s wasd.uuid3 if score @e[tag=wasd.ender_axe_location,type=marker,sort=nearest,limit=1] wasd.uuid4 = @s wasd.uuid4 run kill @e[tag=wasd.ender_axe_location,type=marker,sort=nearest,limit=1]
execute if block ~ ~ ~ #wasd.tags:stripped_logs positioned ~ ~1 ~ align xyz positioned ~0.5 ~ ~0.5 run summon marker ~ ~ ~ {Tags:["wasd.axe_ticking_entity","wasd.ender_axe_location"]}
scoreboard players operation @e[tag=wasd.ender_axe_location,sort=nearest,limit=1] wasd.uuid1 = @s wasd.uuid1
scoreboard players operation @e[tag=wasd.ender_axe_location,sort=nearest,limit=1] wasd.uuid2 = @s wasd.uuid2
scoreboard players operation @e[tag=wasd.ender_axe_location,sort=nearest,limit=1] wasd.uuid3 = @s wasd.uuid3
scoreboard players operation @e[tag=wasd.ender_axe_location,sort=nearest,limit=1] wasd.uuid4 = @s wasd.uuid4
kill @e[tag=wasd.block_location,sort=nearest,limit=1]
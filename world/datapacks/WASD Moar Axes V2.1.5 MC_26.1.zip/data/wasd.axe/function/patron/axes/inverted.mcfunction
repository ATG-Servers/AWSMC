#mc-build WASD content
function wasd.lib:util/looking_at_block
execute as @e[tag=wasd.block_location,sort=nearest,limit=1] at @s run function wasd.axe:patron/axes/zzz/12
#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_acacia_log"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_acacia_log[axis=x] run setblock ~ ~ ~ acacia_log[axis=x] replace
execute if block ~ ~ ~ stripped_acacia_log[axis=y] run setblock ~ ~ ~ acacia_log[axis=y] replace
execute if block ~ ~ ~ stripped_acacia_log[axis=z] run setblock ~ ~ ~ acacia_log[axis=z] replace
#mc-build WASD content
function wasd.lib:util/looking_at_block
function wasd.lib:util/uuid_to_scoreboard
execute at @e[tag=wasd.block_location,sort=nearest,limit=1] run function wasd.axe:patron/axes/zzz/2
#mc-build WASD content
tag @s add wasd.mined_with_ender_axe
scoreboard players operation @e[type=item,sort=nearest,limit=1] wasd.uuid1 = @s wasd.uuid1
scoreboard players operation @e[type=item,sort=nearest,limit=1] wasd.uuid2 = @s wasd.uuid2
scoreboard players operation @e[type=item,sort=nearest,limit=1] wasd.uuid3 = @s wasd.uuid3
scoreboard players operation @e[type=item,sort=nearest,limit=1] wasd.uuid4 = @s wasd.uuid4
#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_cherry_wood"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_cherry_wood[axis=x] run setblock ~ ~ ~ cherry_wood[axis=x] replace
execute if block ~ ~ ~ stripped_cherry_wood[axis=y] run setblock ~ ~ ~ cherry_wood[axis=y] replace
execute if block ~ ~ ~ stripped_cherry_wood[axis=z] run setblock ~ ~ ~ cherry_wood[axis=z] replace
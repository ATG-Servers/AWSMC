#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_oak_log"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_oak_log[axis=x] run setblock ~ ~ ~ oak_log[axis=x] replace
execute if block ~ ~ ~ stripped_oak_log[axis=y] run setblock ~ ~ ~ oak_log[axis=y] replace
execute if block ~ ~ ~ stripped_oak_log[axis=z] run setblock ~ ~ ~ oak_log[axis=z] replace
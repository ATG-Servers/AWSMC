#mc-build WASD content
particle poof ~ ~0.2 ~ 0.1 0.1 0.1 0.2 5 force
playsound minecraft:block.copper.break player @a ~ ~ ~ 1 1
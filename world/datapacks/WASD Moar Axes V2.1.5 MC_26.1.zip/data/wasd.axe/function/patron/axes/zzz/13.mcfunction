#mc-build WASD content
playsound item.axe.strip player @a ~ ~ ~ 1 1.6
execute if block ~ ~ ~ stripped_oak_log run function wasd.axe:patron/axes/zzz/14
execute if block ~ ~ ~ stripped_birch_log run function wasd.axe:patron/axes/zzz/15
execute if block ~ ~ ~ stripped_spruce_log run function wasd.axe:patron/axes/zzz/16
execute if block ~ ~ ~ stripped_jungle_log run function wasd.axe:patron/axes/zzz/17
execute if block ~ ~ ~ stripped_dark_oak_log run function wasd.axe:patron/axes/zzz/18
execute if block ~ ~ ~ stripped_warped_stem run function wasd.axe:patron/axes/zzz/19
execute if block ~ ~ ~ stripped_crimson_stem run function wasd.axe:patron/axes/zzz/20
execute if block ~ ~ ~ stripped_acacia_log run function wasd.axe:patron/axes/zzz/21
execute if block ~ ~ ~ stripped_oak_wood run function wasd.axe:patron/axes/zzz/22
execute if block ~ ~ ~ stripped_birch_wood run function wasd.axe:patron/axes/zzz/23
execute if block ~ ~ ~ stripped_spruce_wood run function wasd.axe:patron/axes/zzz/24
execute if block ~ ~ ~ stripped_jungle_wood run function wasd.axe:patron/axes/zzz/25
execute if block ~ ~ ~ stripped_dark_oak_wood run function wasd.axe:patron/axes/zzz/26
execute if block ~ ~ ~ stripped_acacia_wood run function wasd.axe:patron/axes/zzz/27
execute if block ~ ~ ~ stripped_warped_hyphae run function wasd.axe:patron/axes/zzz/28
execute if block ~ ~ ~ stripped_crimson_hyphae run function wasd.axe:patron/axes/zzz/29
execute if block ~ ~ ~ stripped_mangrove_log run function wasd.axe:patron/axes/zzz/30
execute if block ~ ~ ~ stripped_mangrove_wood run function wasd.axe:patron/axes/zzz/31
execute if block ~ ~ ~ stripped_cherry_log run function wasd.axe:patron/axes/zzz/32
execute if block ~ ~ ~ stripped_cherry_wood run function wasd.axe:patron/axes/zzz/33
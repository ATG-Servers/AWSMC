#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_warped_hyphae"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_warped_hyphae[axis=x] run setblock ~ ~ ~ warped_hyphae[axis=x] replace
execute if block ~ ~ ~ stripped_warped_hyphae[axis=y] run setblock ~ ~ ~ warped_hyphae[axis=y] replace
execute if block ~ ~ ~ stripped_warped_hyphae[axis=z] run setblock ~ ~ ~ warped_hyphae[axis=z] replace
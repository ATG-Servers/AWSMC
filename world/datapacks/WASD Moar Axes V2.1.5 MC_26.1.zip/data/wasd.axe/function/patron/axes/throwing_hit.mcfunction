#mc-build WASD content
execute unless block ~ ~ ~ #minecraft:logs run function wasd.axe:patron/axes/zzz/9
execute if block ~ ~ ~ #minecraft:mineable/axe run function wasd.axe:patron/axes/zzz/10
execute if block ~ ~ ~ #minecraft:leaves run function wasd.axe:patron/axes/zzz/11
kill @s
#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_crimson_hyphae"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_crimson_hyphae[axis=x] run setblock ~ ~ ~ crimson_hyphae[axis=x] replace
execute if block ~ ~ ~ stripped_crimson_hyphae[axis=y] run setblock ~ ~ ~ crimson_hyphae[axis=y] replace
execute if block ~ ~ ~ stripped_crimson_hyphae[axis=z] run setblock ~ ~ ~ crimson_hyphae[axis=z] replace
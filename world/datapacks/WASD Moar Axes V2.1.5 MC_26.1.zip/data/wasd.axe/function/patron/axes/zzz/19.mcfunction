#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_warped_stem"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_warped_stem[axis=x] run setblock ~ ~ ~ warped_stem[axis=x] replace
execute if block ~ ~ ~ stripped_warped_stem[axis=y] run setblock ~ ~ ~ warped_stem[axis=y] replace
execute if block ~ ~ ~ stripped_warped_stem[axis=z] run setblock ~ ~ ~ warped_stem[axis=z] replace
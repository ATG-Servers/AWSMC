#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_crimson_stem"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_crimson_stem[axis=x] run setblock ~ ~ ~ crimson_stem[axis=x] replace
execute if block ~ ~ ~ stripped_crimson_stem[axis=y] run setblock ~ ~ ~ crimson_stem[axis=y] replace
execute if block ~ ~ ~ stripped_crimson_stem[axis=z] run setblock ~ ~ ~ crimson_stem[axis=z] replace
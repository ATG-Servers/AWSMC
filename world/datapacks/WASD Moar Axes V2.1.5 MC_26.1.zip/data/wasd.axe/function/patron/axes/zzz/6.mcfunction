#mc-build WASD content
tag @s add wasd.already_hit
damage @s 6 minecraft:player_attack by @e[tag=wasd.throwing_axe,limit=1,sort=nearest]
playsound minecraft:block.copper.break player @a ~ ~ ~ 1 1
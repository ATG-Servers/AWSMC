#mc-build WASD content
execute at @s run particle dragon_breath ~ ~0.2 ~ 0 0 0 0.03 10 force
execute at @s run playsound entity.enderman.teleport player @a ~ ~ ~ 0.1 1
tp @s ~ ~ ~
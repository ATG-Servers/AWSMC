#mc-build WASD content
particle block{block_state:{Name:"minecraft:stripped_spruce_wood"}} ~ ~0.5 ~ 0.3 0.3 0.3 0 20 normal
execute if block ~ ~ ~ stripped_spruce_wood[axis=x] run setblock ~ ~ ~ spruce_wood[axis=x] replace
execute if block ~ ~ ~ stripped_spruce_wood[axis=y] run setblock ~ ~ ~ spruce_wood[axis=y] replace
execute if block ~ ~ ~ stripped_spruce_wood[axis=z] run setblock ~ ~ ~ spruce_wood[axis=z] replace
#mc-build WASD content
scoreboard players add @s wasd.axe_click_cooldown 10
playsound entity.snowball.throw player @a ~ ~ ~ 0.1 0
execute anchored eyes positioned ^-0.4 ^ ^-0.5 run function wasd.axe:patron/axes/zzz/4
execute unless entity @s[gamemode=creative] run function wasd.lib:items/damage/mainhand/1
function wasd.lib:items/damage/break/tools/warped_fungus
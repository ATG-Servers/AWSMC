#mc-build WASD content
execute as @s[tag=wasd.ender_axe_location] run function wasd.axe:patron/axes/ender_axe_location
execute as @s[tag=wasd.throwing_axe] run function wasd.axe:patron/axes/throwing_axe_projectile
#aoe_armor_stand_projectile throwing_axe wasd.axe:patron/entities/ 0.7 1 100 1 4 3 <particle minecraft:dust 1 1 1 1 ^ ^ ^-1 0 0 0 0 1 force> <function wasd.axe:patron/axes/throwing_hit>
#mc-build WASD content
execute if predicate wasd.axe:holding_item/axe7 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,distance=..7,nbt={Age:0s}] at @s run function wasd.axe:patron/axes/ender_mine
execute as @s[tag=!wasd.mined_with_ender_axe] if predicate wasd.axe:holding_item/axe7 run function wasd.axe:patron/axes/ender_strip
tag @s[tag=wasd.mined_with_ender_axe] remove wasd.mined_with_ender_axe
#execute if predicate wasd.axe:holding_item/axe11 run function wasd.axe:patron/axes/lumber
#mc-build WASD content
loot insert ~ ~ ~ loot wasd.axe:items/patron/ender
loot insert ~ ~ ~ loot wasd.axe:items/patron/inverted
loot insert ~ ~ ~ loot wasd.axe:items/patron/throwing
loot insert ~ ~ ~ loot wasd.axe:items/patron/instant
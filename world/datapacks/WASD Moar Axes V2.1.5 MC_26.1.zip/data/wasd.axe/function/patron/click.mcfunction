#mc-build WASD content
execute if predicate wasd.axe:holding_item/axe12 run function wasd.axe:patron/axes/throwing
execute if predicate wasd.axe:holding_item/axe13 run function wasd.axe:patron/axes/inverted
#mc-build WASD content
recipe give @s wasd.axe:fire
recipe give @s wasd.axe:giant
recipe give @s wasd.axe:replanting
recipe give @s wasd.axe:water
recipe give @s wasd.axe:enchanted
recipe give @s wasd.axe:blaze_rod
recipe give @s wasd.axe:berserker
recipe give @s wasd.axe:magnetic
recipe give @s wasd.axe:patron/ender
recipe give @s wasd.axe:patron/inverted
recipe give @s wasd.axe:patron/throwing
recipe give @s wasd.axe:patron/instant
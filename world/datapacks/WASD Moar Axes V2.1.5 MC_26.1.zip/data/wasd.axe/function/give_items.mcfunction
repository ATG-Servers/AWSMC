#mc-build WASD content
loot give @s loot wasd.axe:items/fire
loot give @s loot wasd.axe:items/giant
loot give @s loot wasd.axe:items/replanting
loot give @s loot wasd.axe:items/water
loot give @s loot wasd.axe:items/enchanted
loot give @s loot wasd.axe:items/blaze_rod
loot give @s loot wasd.axe:items/berserker
loot give @s loot wasd.axe:items/magnetic
function wasd.axe:patron/give_items
#mc-build WASD content
execute unless score @s wasd.axe_click_cooldown matches 1.. run function wasd.axe:zzz/1
scoreboard players reset @s wasd.axe_click
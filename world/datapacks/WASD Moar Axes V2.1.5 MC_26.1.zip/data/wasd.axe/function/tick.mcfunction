#mc-build WASD content
execute as @a at @s run function wasd.axe:as_players
execute as @e[tag=wasd.axe_ticking_entity] at @s run function wasd.axe:as_entities
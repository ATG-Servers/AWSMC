#mc-build WASD content
tag @s add wasd.attacker
execute if predicate wasd.axe:holding_item/axe1 positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.axe:attack/fire
execute if predicate wasd.axe:holding_item/axe10 positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.axe:attack/berserker
scoreboard players reset @s wasd.attack_axe
function wasd.axe:patron/determine_attack
tag @s remove wasd.attacker
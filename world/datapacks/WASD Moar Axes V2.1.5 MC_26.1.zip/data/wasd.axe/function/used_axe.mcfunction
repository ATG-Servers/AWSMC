#mc-build WASD content
execute if predicate wasd.axe:holding_item/axe1 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/fire
execute if predicate wasd.axe:holding_item/axe2 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/giants
execute if predicate wasd.axe:holding_item/axe3 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/replanting
execute if predicate wasd.axe:holding_item/axe5 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/enchanted_book
execute if predicate wasd.axe:holding_item/axe6 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/blaze_rod
execute if predicate wasd.axe:holding_item/axe11 positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.axe:break/magnetic
function wasd.axe:patron/used_axe
scoreboard players reset @s wasd.used_axe
#mc-build WASD content
setblock ~ ~ ~ air
kill @s
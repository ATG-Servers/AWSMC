#mc-build WASD content
tag @s add wasd.shot_builder_bow
function wasd.bows:bows/master_builder
tag @s remove wasd.shot_builder_bow
tag @s remove wasd.invalid_ammo_bb
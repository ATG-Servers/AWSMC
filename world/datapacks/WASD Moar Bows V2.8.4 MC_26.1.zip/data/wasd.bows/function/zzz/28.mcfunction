#mc-build WASD content
tp @s ^ ^ ^0.5 ~0 ~0.5
summon marker ~ ~ ~ {Tags:["wasd.arrow_entity","wasd.bridge_bow_block"]}
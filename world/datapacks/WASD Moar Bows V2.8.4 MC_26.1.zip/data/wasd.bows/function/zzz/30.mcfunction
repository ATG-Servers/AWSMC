#mc-build WASD content
setblock ~ ~ ~ green_stained_glass
playsound minecraft:block.decorated_pot.place player @a ~ ~ ~ 0.3 1.5
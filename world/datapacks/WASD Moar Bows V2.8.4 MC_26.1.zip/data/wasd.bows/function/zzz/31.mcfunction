#mc-build WASD content
playsound minecraft:block.decorated_pot.break player @a ~ ~ ~ 0.3 1
kill @s
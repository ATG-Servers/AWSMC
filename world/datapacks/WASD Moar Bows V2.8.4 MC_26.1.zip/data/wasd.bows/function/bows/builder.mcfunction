#mc-build WASD content
execute as @n[type=minecraft:arrow,tag=!wasd.custom_arrow,tag=!wasd.custom_crossbow_arrow,nbt=!{ShotFromCrossbow:0b,inGround:1b,pickup:0b}] run function wasd.bows:bows/zzz/0
summon block_display ~ -64 ~ {block_state:{Name:"minecraft:air"},Tags:["wasd.build_bow_block"]}
execute positioned ~ -64 ~ run data modify entity @n[type=block_display,tag=wasd.build_bow_block,tag=!wasd.modified] block_state.Name set from entity @s equipment.offhand.id
execute positioned ~ -64 ~ as @n[type=block_display,tag=wasd.build_bow_block,tag=!wasd.modified] run function wasd.bows:bows/zzz/1
execute as @s[tag=!wasd.invalid_ammo_bb,gamemode=!creative] run item modify entity @s weapon.offhand wasd.lib:remove1
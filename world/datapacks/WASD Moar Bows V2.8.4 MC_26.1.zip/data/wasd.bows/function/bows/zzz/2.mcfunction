#mc-build WASD content
scoreboard players operation @s wasd.uuid1 = @n[type=arrow,tag=wasd.builder] wasd.uuid1
scoreboard players operation @s wasd.uuid2 = @n[type=arrow,tag=wasd.builder] wasd.uuid2
scoreboard players operation @s wasd.uuid3 = @n[type=arrow,tag=wasd.builder] wasd.uuid3
scoreboard players operation @s wasd.uuid4 = @n[type=arrow,tag=wasd.builder] wasd.uuid4
#mc-build WASD content
tag @s add wasd.modified
execute at @p[tag=wasd.shot_builder_bow] at @n[type=arrow,tag=wasd.builder] run function wasd.bows:bows/zzz/6
execute as @s[nbt={block_state:{Name:"minecraft:air"}}] run function wasd.bows:bows/zzz/7
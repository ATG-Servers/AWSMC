#mc-build WASD content
playsound minecraft:block.stone.place player @a ~ ~ ~ 1 1
$setblock ~ ~ ~ $(Name)
kill @s
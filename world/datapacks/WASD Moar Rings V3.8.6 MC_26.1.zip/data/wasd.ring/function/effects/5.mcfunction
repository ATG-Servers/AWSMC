effect give @s minecraft:resistance 1 1 true
effect give @s minecraft:weakness 1 0 true
execute if score drain ring_settings matches 1 run scoreboard players remove @s wasd.magic_meter 2
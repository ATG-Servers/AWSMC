

#stun then unstun entity for 3.0 seconds
scoreboard players add @s generic_stunned 1
execute if score @s generic_stunned matches 1 run attribute @s[type=player] minecraft:jump_strength modifier add wasd.no_jump -1000 add_value
execute if score @s generic_stunned matches 1 run attribute @s[type=player] minecraft:knockback_resistance modifier add wasd.no_knockback 1000 add_value
execute if score @s generic_stunned matches 1.. run data merge entity @s {NoAI:1b}
execute if score @s generic_stunned matches 60.. run data merge entity @s {NoAI:0b}

#stun player
effect give @s[type=minecraft:player] minecraft:slowness 1 255 true
execute if score @s generic_stunned matches 60.. run effect clear @s[type=minecraft:player] minecraft:slowness

#reset scores and tags
execute if score @s generic_stunned matches 60.. run attribute @s[type=player] minecraft:jump_strength modifier remove wasd.no_jump
execute if score @s generic_stunned matches 60.. run attribute @s[type=player] minecraft:knockback_resistance modifier remove wasd.no_knockback
execute if score @s generic_stunned matches 60.. run tag @s remove wasd.generic_stunned
execute if score @s generic_stunned matches 60.. run tag @s remove wasd.lib_entity_tick
execute if score @s generic_stunned matches 60.. run scoreboard players reset @s generic_stunned



#display particles
particle minecraft:crit ~ ~1.8 ~ 0.3 0.3 0.3 0.3 1 force
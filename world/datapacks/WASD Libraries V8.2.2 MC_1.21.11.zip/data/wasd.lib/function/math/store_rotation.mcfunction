execute store result storage minecraft:wasd.lib_storage x_rotation float 1 run data get entity @s Rotation[0]
execute store result storage minecraft:wasd.lib_storage y_rotation float 1 run data get entity @s Rotation[1]

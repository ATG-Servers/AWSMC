#mc-build WASD content
particle minecraft:smoke ~-0.5 ~ ~ 0 0.3 0.3 0 1 normal
scoreboard players reset @s wasd.temp
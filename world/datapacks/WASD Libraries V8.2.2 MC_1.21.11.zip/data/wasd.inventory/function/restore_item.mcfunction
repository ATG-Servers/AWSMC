#mc-build WASD content
$item replace entity @s container.$(Slot) with $(id) $(count)
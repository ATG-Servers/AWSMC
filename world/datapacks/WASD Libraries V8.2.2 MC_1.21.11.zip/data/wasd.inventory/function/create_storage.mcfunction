#mc-build WASD content
$data merge storage minecraft:$(uuid) {Inventory:[]}
$data modify storage minecraft:$(uuid) Inventory set from entity @s Inventory
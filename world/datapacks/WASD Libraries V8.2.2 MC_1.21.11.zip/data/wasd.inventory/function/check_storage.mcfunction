#mc-build WASD content
$function wasd.inventory:restore_item with storage minecraft:$(uuid) Inventory[0]
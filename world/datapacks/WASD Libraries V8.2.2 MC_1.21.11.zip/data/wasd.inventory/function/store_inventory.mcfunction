#mc-build WASD content
data modify storage minecraft:wasd.lib_storage uuid set from entity @s UUID[0]
function wasd.inventory:create_storage with storage minecraft:wasd.lib_storage
#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.helmet:items/helm_of_the_deep
loot insert ~ ~ ~ loot wasd.helmet:items/mining
loot insert ~ ~ ~ loot wasd.helmet:items/knowledge
loot insert ~ ~ ~ loot wasd.helmet:items/librarian
loot insert ~ ~ ~ loot wasd.helmet:items/tranquility
loot insert ~ ~ ~ loot wasd.helmet:items/lucky
loot insert ~ ~ ~ loot wasd.helmet:items/farming
loot insert ~ ~ ~ loot wasd.helmet:items/attractive
loot insert ~ ~ ~ loot wasd.helmet:items/curing
loot insert ~ ~ ~ loot wasd.helmet:items/magnetic
function wasd.helmet:patron/insert_items
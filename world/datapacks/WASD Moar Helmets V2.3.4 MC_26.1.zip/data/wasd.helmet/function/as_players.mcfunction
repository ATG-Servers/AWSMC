#mc-build WASD content
execute as @s[tag=wasd.inventory_changed] run function wasd.helmet:determine_helmet
execute if score wasd.global_1 wasd.timer matches 1 as @s[scores={wasd.helmet_type=1..}] run function wasd.helmet:effects
execute as @s[scores={wasd.helmet_type=1..}] run function wasd.helmet:effects_fast_tick
execute as @s[scores={wasd.helmet_click=1..}] run function wasd.helmet:on_click
scoreboard players reset @s[scores={wasd.helmet_jump=1..}] wasd.helmet_jump
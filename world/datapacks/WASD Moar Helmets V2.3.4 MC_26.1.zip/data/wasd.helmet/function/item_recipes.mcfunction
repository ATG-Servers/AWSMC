#mc-build WASD content
recipe give @s wasd.helmet:items/helm_of_the_deep
recipe give @s wasd.helmet:items/mining
recipe give @s wasd.helmet:items/knowledge
recipe give @s wasd.helmet:items/librarian
recipe give @s wasd.helmet:items/tranquility
recipe give @s wasd.helmet:items/lucky
recipe give @s wasd.helmet:items/farming
recipe give @s wasd.helmet:items/attractive
recipe give @s wasd.helmet:items/curing
recipe give @s wasd.helmet:items/magnetic
recipe give @s wasd.helmet:items/patron/ramming
recipe give @s wasd.helmet:items/patron/pickaxe
recipe give @s wasd.helmet:items/patron/crossbow
recipe give @s wasd.helmet:items/patron/potato
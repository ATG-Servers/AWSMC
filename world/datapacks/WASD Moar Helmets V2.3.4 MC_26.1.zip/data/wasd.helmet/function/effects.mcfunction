#mc-build WASD content
execute as @s[scores={wasd.helmet_type=1}] run effect give @s minecraft:conduit_power 2 0 true
execute as @s[scores={wasd.helmet_type=2}] run function wasd.helmet:code/mining
execute as @s[scores={wasd.helmet_type=3}] as @e[type=#wasd.tags:mobs_player,distance=0.01..15] run effect give @s minecraft:glowing 2 0 true
execute as @s[scores={wasd.helmet_type=4}] run function wasd.helmet:code/xp
execute as @s[scores={wasd.helmet_type=5}] run effect give @s minecraft:levitation 2 1 true
execute as @s[scores={wasd.helmet_type=6}] run effect give @s minecraft:luck 2 1 true
execute as @s[scores={wasd.helmet_type=7}] run function wasd.helmet:code/farmer
execute as @s[scores={wasd.helmet_type=8}] run effect give @s minecraft:glowing 2 0 true
execute as @s[scores={wasd.helmet_type=9}] run function wasd.helmet:code/curing
execute as @s[scores={wasd.helmet_type=10}] run function wasd.helmet:code/magnetic
function wasd.helmet:patron/effects
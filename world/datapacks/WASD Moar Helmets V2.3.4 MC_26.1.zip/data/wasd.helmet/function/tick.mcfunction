#mc-build WASD content
execute as @a at @s run function wasd.helmet:as_players
#crafting
execute if score recipes w.helm_settings matches 1 as @e[tag=wasd.custom_crafter,tag=wasd.crafter.has_items,tag=wasd.crafter_change] at @s run function wasd.helmet:recipes
#mc-build WASD content
scoreboard players set @s wasd.helmet_type 0
execute if predicate wasd.helmet:custom_helmet store result score @s wasd.helmet_type run data get entity @s equipment.head.components."minecraft:custom_data"."wasd.custom_helmet"
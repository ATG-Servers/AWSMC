#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_helmets wasd_data_packs 1
scoreboard players set camp_datapack wasd_data_packs 1
scoreboard objectives add wasd.xp_gain dummy
scoreboard objectives add wasd.farm_timer dummy
scoreboard objectives add wasd.cure_timer dummy
scoreboard objectives add wasd.potato_timer dummy
scoreboard objectives add wasd.crossbow_helmet_timer dummy
scoreboard objectives add wasd.helmet_type dummy
scoreboard objectives add wasd.helmet_jump minecraft.custom:minecraft.jump
scoreboard objectives add Food food
scoreboard objectives add w.helm_settings dummy
function wasd.helmet:config
schedule function wasd.helmet:check_installed_packs 30t replace
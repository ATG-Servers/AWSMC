#mc-build WASD content
function wasd.helmet:patron/effects_fast_tick
#mc-build WASD content
loot give @s loot wasd.helmet:items/helm_of_the_deep
loot give @s loot wasd.helmet:items/mining
loot give @s loot wasd.helmet:items/knowledge
loot give @s loot wasd.helmet:items/librarian
loot give @s loot wasd.helmet:items/tranquility
loot give @s loot wasd.helmet:items/lucky
loot give @s loot wasd.helmet:items/farming
loot give @s loot wasd.helmet:items/attractive
loot give @s loot wasd.helmet:items/curing
loot give @s loot wasd.helmet:items/magnetic
function wasd.helmet:patron/give_items
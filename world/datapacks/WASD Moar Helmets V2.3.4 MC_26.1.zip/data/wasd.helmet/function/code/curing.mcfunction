#mc-build WASD content
execute if data entity @s active_effects run tag @s add wasd.active_effects
execute as @s[tag=wasd.active_effects] run function wasd.helmet:code/zzz/2
#mc-build WASD content
effect give @s minecraft:night_vision 15 0 true
execute anchored eyes positioned ^ ^0.8 ^ run particle flame ~ ~ ~ 0.01 0.01 0.01 0.001 1 normal
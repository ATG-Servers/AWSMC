#mc-build WASD content
execute positioned ~ ~0.5 ~ run function wasd.lib:crops/grow/5x5
execute positioned ~ ~0.5 ~ run function wasd.lib:crops/grow/5x5
scoreboard players reset @s wasd.farm_timer
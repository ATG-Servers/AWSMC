#mc-build WASD content
tag @s add wasd.magnet_teleported
data merge entity @s {PickupDelay:0}
#mc-build WASD content
particle dust{color:[1.000, 0.000, 0.000], scale:2.0} ~ ~0.35 ~ 0.1 0.1 0.1 1 3 normal
particle dust{color:[0.129, 0.247, 1.000], scale:2.0} ~ ~0.35 ~ 0.1 0.1 0.1 1 3 normal
#mc-build WASD content
summon minecraft:experience_orb ~ ~ ~ {Value:5}
scoreboard players reset @s wasd.xp_gain
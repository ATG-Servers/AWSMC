#mc-build WASD content
effect clear @s
playsound minecraft:entity.generic.drink player @a ~ ~ ~ 1 0.9
particle falling_dust{block_state:{Name:"minecraft:white_concrete"}} ~ ~1.3 ~ 0.2 0.1 0.2 0 50
tag @s remove wasd.active_effects
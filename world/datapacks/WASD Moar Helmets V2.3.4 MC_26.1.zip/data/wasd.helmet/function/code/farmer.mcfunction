#mc-build WASD content
scoreboard players add @s wasd.farm_timer 1
execute as @s[scores={wasd.farm_timer=10..}] run function wasd.helmet:code/zzz/1
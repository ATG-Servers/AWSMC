#mc-build WASD content
scoreboard players add @s wasd.xp_gain 1
execute as @s[scores={wasd.xp_gain=60..}] run function wasd.helmet:code/zzz/0
#mc-build WASD content
execute as @e[type=item,distance=..10,tag=!wasd.magnet_teleported] at @s run function wasd.helmet:code/zzz/3
tp @e[type=item,distance=..10,tag=!wasd.magnet_teleported] @s
execute as @e[type=item,distance=..10,tag=!wasd.magnet_teleported] at @s run function wasd.helmet:code/zzz/4
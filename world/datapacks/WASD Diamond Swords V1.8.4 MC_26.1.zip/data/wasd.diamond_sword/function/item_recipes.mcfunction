#mc-build WASD content
recipe give @s wasd.diamond_sword:items/xp
recipe give @s wasd.diamond_sword:items/rainbow
recipe give @s wasd.diamond_sword:items/darkness
recipe give @s wasd.diamond_sword:items/light
recipe give @s wasd.diamond_sword:items/vampire
recipe give @s wasd.diamond_sword:items/demon
recipe give @s wasd.diamond_sword:items/angel
recipe give @s wasd.diamond_sword:items/moon
recipe give @s wasd.diamond_sword:items/sun
recipe give @s wasd.diamond_sword:items/invisible
recipe give @s wasd.diamond_sword:items/xp_star
recipe give @s wasd.diamond_sword:items/enhanced_diamond
recipe give @s wasd.diamond_sword:items/ender_diamond
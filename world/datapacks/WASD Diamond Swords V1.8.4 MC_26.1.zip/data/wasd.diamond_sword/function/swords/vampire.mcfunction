#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
tag @s add wasd.bleeding
scoreboard players add @s wasd.bleeding 120
playsound minecraft:entity.phantom.bite player @a ~ ~ ~ 1 0.5
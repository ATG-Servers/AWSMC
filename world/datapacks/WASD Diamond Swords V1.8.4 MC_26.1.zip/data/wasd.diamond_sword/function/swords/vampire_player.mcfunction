#mc-build WASD content
effect give @s regeneration 3 1 true
execute if predicate light_level:12-15 run damage @s 6 minecraft:in_fire
execute if predicate light_level:12-15 run setblock ~ ~ ~ fire keep
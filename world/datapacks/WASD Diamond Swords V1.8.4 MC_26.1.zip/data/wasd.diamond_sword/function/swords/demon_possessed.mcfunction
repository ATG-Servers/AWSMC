#mc-build WASD content
execute at @e[type=vindicator,tag=wasd.demon_mob] if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid1 = @s wasd.uuid1 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid2 = @s wasd.uuid2 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid3 = @s wasd.uuid3 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid4 = @s wasd.uuid4 run spectate @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] @s
gamemode spectator @s
scoreboard players add @s wasd.demon_timer 1
execute as @s[scores={wasd.demon_timer=200..}] run function wasd.diamond_sword:swords/demon_reset
particle smoke ~ ~0.5 ~ 0.2 0.3 0.2 0.01 20
particle falling_dust{block_state:{Name:"minecraft:black_wool"}} ~ ~ ~ 0.3 0.1 0.3 0.05 10
particle falling_dust{block_state:{Name:"minecraft:red_wool"}} ~ ~ ~ 0.3 0.1 0.3 0.05 10
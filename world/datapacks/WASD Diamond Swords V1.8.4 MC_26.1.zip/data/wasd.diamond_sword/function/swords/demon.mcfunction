#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 1 0.5
execute store result score @s wasd.rng run random value 1..15
execute as @s[scores={wasd.rng=1}] run function wasd.diamond_sword:swords/demon_math
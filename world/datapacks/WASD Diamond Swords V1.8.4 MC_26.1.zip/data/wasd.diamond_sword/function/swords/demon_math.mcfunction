#mc-build WASD content
tag @s add wasd.is_demon_possessed
summon vindicator ~ ~ ~ {Johnny:1b,Tags:["wasd.demon_mob"],CustomName:{"text":"Demon","color":"dark_red","italic":false},equipment:{mainhand:{id:"minecraft:netherite_axe",count:1}},drop_chances:{mainhand:0.000},active_effects:[{id:"minecraft:instant_health",amplifier:255,duration:1000000,show_particles:0b},{id:"minecraft:resistance",amplifier:255,duration:1000000,show_particles:0b}]}
function wasd.lib:util/store_uuid
scoreboard players operation @e[type=vindicator,tag=wasd.demon_mob] wasd.uuid1 = @s wasd.uuid1
scoreboard players operation @e[type=vindicator,tag=wasd.demon_mob] wasd.uuid2 = @s wasd.uuid2
scoreboard players operation @e[type=vindicator,tag=wasd.demon_mob] wasd.uuid3 = @s wasd.uuid3
scoreboard players operation @e[type=vindicator,tag=wasd.demon_mob] wasd.uuid4 = @s wasd.uuid4
tag @s[gamemode=survival] add wasd.in_survival
tag @s[gamemode=creative] add wasd.in_creative
tag @s[gamemode=adventure] add wasd.in_adventure
#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
playsound minecraft:entity.squid.squirt player @a ~ ~ ~ 1 0
#calculate sword damage
function wasd.lib:util/get_light_level
scoreboard players set @s wasd.temp 11
scoreboard players operation @s wasd.temp -= @s wasd.light_level
execute if score @s wasd.temp matches ..0 run scoreboard players set @s wasd.temp 1
#use SBIM to put score onto held item
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute at @e[tag=wasd.box_location] store result block ~ ~ ~ Items[0].components."minecraft:attribute_modifiers"[0].amount double 1 run scoreboard players get @s wasd.temp
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
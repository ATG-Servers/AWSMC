#mc-build WASD content
execute store result score @s wasd.temp run xp query @s levels
execute if score @s wasd.temp matches 1.. run xp add @s -15 points
execute if score @s wasd.temp matches 1.. as @p[scores={wasd.use_sword=1..,wasd.sword_type=46}] run xp add @s 15 points
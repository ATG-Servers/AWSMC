#mc-build WASD content
playsound minecraft:entity.phantom.swoop player @a ~ ~ ~ 1 0
execute positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run particle falling_dust{block_state:{Name:"minecraft:light_blue_terracotta"}} ~ ~1 ~ 0.3 0.5 0.3 0 50
scoreboard players set @s wasd.temp 9
#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
execute store result score @s wasd.temp run time query day
execute as @s[scores={wasd.temp=0..12000}] run scoreboard players set @s wasd.temp 1
execute as @s[scores={wasd.temp=12001..24000}] run function wasd.diamond_sword:swords/zzz/0
#use SBIM to put score onto held item
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute at @e[tag=wasd.box_location] store result block ~ ~ ~ Items[0].components."minecraft:attribute_modifiers"[0].amount double 1 run scoreboard players get @s wasd.temp
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
tag @s add wasd.gave_dye
function wasd.lib:affects/drop_rainbow_dye
#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
execute as @s[type=#wasd.tags:mobs] run summon minecraft:experience_orb ~ ~1 ~ {Value:5}
tag @s[type=#wasd.tags:mobs] add wasd.dropped_xp
particle dust{color:[0.906, 1.0, 0.741], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.506, 0.902, 0.388], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.769, 0.902, 0.396], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.42, 0.902, 0.298], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
particle dust{color:[0.937, 1.0, 0.361], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
playsound minecraft:entity.player.levelup player @a ~ ~ ~ 1 2
execute as @s[type=minecraft:player] run function wasd.diamond_sword:swords/zzz/1
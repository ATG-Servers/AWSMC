#mc-build WASD content
scoreboard players set @s click_cooldown 60
tag @s add wasd.ender_teleporting
summon minecraft:area_effect_cloud ~ ~1.6 ~ {Tags:["wasd.ender_sword_teleport"],Duration:1,custom_particle:{type:"block",block_state:"minecraft:air"}}
tp @e[type=minecraft:area_effect_cloud,tag=wasd.ender_sword_teleport,sort=nearest,limit=1] ~ ~1.6 ~ ~ ~
execute as @e[type=minecraft:area_effect_cloud,tag=wasd.ender_sword_teleport,sort=nearest,limit=1] at @s run function wasd.diamond_sword:swords/click_event/ender_diamond_raytrace
playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 2 1.3
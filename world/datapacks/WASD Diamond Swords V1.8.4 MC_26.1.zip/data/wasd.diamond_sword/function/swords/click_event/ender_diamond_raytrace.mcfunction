#mc-build WASD content
particle minecraft:portal ~ ~ ~ 0.1 0.1 0.1 0 5
tp @s ~ ~ ~
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=75..}]
execute unless score @s wasd.timer matches 75.. positioned ^ ^ ^0.2 if block ^ ^ ^0.5 #wasd.tags:nonsolid run function wasd.diamond_sword:swords/click_event/ender_diamond_raytrace
execute as @p[tag=wasd.ender_teleporting] run tp @s ~ ~ ~
execute as @p[tag=wasd.ender_teleporting] run tag @s remove wasd.ender_teleporting
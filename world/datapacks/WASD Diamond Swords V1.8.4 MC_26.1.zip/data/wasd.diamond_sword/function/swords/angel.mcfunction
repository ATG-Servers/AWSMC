#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
playsound minecraft:entity.allay.hurt player @a ~ ~ ~ 1 1.2
execute as @e[type=#wasd.tags:mobs_player,distance=..3] run effect give @s instant_health 1 0 true
particle heart ~ ~0.3 ~ 0.5 0 0.5 1 20 force
particle dust_color_transition{from_color:[1.000,0.431,0.431],scale:2,to_color:[1.000,0.000,0.000]} ~ ~0.2 ~ 1.5 0 1.5 1 50 force
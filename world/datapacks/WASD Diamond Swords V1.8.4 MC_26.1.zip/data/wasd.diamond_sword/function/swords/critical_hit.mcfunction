#mc-build WASD content
function wasd.lib:affects/damage/4_hearts
playsound minecraft:entity.player.attack.crit player @a ~ ~ ~ 10 0.5
particle minecraft:composter ~ ~1 ~ 0.3 0.5 0.3 1 50
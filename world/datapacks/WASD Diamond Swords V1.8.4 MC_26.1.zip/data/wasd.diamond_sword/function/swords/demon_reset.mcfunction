#mc-build WASD content
gamemode survival @s[tag=wasd.in_survival]
gamemode creative @s[tag=wasd.in_creative]
gamemode adventure @s[tag=wasd.in_adventure]
tag @s[gamemode=survival] remove wasd.in_survival
tag @s[gamemode=creative] remove wasd.in_creative
tag @s[gamemode=adventure] remove wasd.in_adventure
execute at @e[type=vindicator,tag=wasd.demon_mob] if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid1 = @s wasd.uuid1 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid2 = @s wasd.uuid2 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid3 = @s wasd.uuid3 if score @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] wasd.uuid4 = @s wasd.uuid4 run tp @e[type=vindicator,tag=wasd.demon_mob,limit=1,sort=nearest] ~ -1000 ~
tag @s remove wasd.is_demon_possessed
scoreboard players reset @s wasd.demon_timer
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 1 1
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 1 1.5
playsound minecraft:entity.evoker.prepare_attack player @a ~ ~ ~ 1 2
effect give @s blindness 3 0 true
particle squid_ink ~ ~1 ~ 0.1 0.1 0.1 0.1 100
particle explosion ~ ~1 ~ 0.1 0.1 0.1 0.1 3
particle flash{color:[0.000,0.000,0.000,1.00]} ~ ~1 ~ 0.1 0.1 0.1 0.1 1
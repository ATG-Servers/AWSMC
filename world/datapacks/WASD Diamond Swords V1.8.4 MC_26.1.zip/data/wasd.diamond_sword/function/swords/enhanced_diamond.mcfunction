#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
particle falling_dust{block_state:{Name:"minecraft:diamond_block"}} ~ ~1 ~ 0.3 0.5 0.3 1 50
playsound minecraft:block.note_block.chime player @a ~ ~ ~ 1 2
damage @s 3 minecraft:magic
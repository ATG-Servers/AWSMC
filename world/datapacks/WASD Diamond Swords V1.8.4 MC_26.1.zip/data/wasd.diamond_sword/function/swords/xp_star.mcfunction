#mc-build WASD content
function wasd.diamond_sword:swords/stop_sounds
execute as @s[type=#wasd.tags:mobs] run summon minecraft:experience_orb ~ ~1 ~ {Value:15}
tag @s[type=#wasd.tags:mobs] add wasd.dropped_xp
particle dust{color:[0.812, 1.0, 0.482], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 2 3 normal
particle dust{color:[0.29, 0.973, 0.082], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 2 3 normal
particle dust{color:[0.808, 1.0, 0.275], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 2 3 normal
particle dust{color:[0.235, 1.0, 0.043], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
particle dust{color:[0.89, 0.988, 0.0], scale:2.0} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
playsound minecraft:entity.player.levelup player @a ~ ~ ~ 1 2
execute as @s[type=minecraft:player] run function wasd.diamond_sword:swords/zzz/2
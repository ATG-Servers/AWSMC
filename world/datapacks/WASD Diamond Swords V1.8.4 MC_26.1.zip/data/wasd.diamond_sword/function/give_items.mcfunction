#mc-build WASD content
loot give @s loot wasd.diamond_sword:xp
loot give @s loot wasd.diamond_sword:rainbow
loot give @s loot wasd.diamond_sword:darkness
loot give @s loot wasd.diamond_sword:light
loot give @s loot wasd.diamond_sword:vampire
loot give @s loot wasd.diamond_sword:demon
loot give @s loot wasd.diamond_sword:angel
loot give @s loot wasd.diamond_sword:moon
loot give @s loot wasd.diamond_sword:sun
loot give @s loot wasd.diamond_sword:invisible
loot give @s loot wasd.diamond_sword:xp_star
loot give @s loot wasd.diamond_sword:enhanced_diamond
loot give @s loot wasd.diamond_sword:ender_diamond
#mc-build WASD content
execute as @a at @s run function wasd.diamond_sword:as_players
#mc-build WASD content
tag @s add wasd.attacker
#28-31
execute as @s[scores={wasd.sword_type=35}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s},tag=!wasd.dropped_xp] at @s run function wasd.diamond_sword:swords/xp
execute as @s[scores={wasd.sword_type=36}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs,distance=..10,nbt={HurtTime:10s},tag=!wasd.gave_dye] at @s run function wasd.diamond_sword:swords/rainbow
execute as @s[scores={wasd.sword_type=42}] run function wasd.diamond_sword:swords/darkness
execute as @s[scores={wasd.sword_type=43}] run function wasd.diamond_sword:swords/light
execute as @s[scores={wasd.sword_type=44}] run function wasd.diamond_sword:swords/vampire_player
execute as @s[scores={wasd.sword_type=44}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.diamond_sword:swords/vampire
#45-46
execute as @s[scores={wasd.sword_type=46}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s},tag=!wasd.dropped_xp] at @s run function wasd.diamond_sword:swords/xp_star
#52+
execute as @s[scores={wasd.sword_type=61}] run function wasd.diamond_sword:swords/demon
execute as @s[scores={wasd.sword_type=62}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.diamond_sword:swords/angel
execute as @s[scores={wasd.sword_type=63}] run function wasd.diamond_sword:swords/moon
execute as @s[scores={wasd.sword_type=64}] run function wasd.diamond_sword:swords/sun
execute as @s[scores={wasd.sword_type=110}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s},tag=!wasd.dropped_xp] at @s run function wasd.diamond_sword:swords/enhanced_diamond
tag @s remove wasd.attacker
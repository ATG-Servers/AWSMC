#mc-build WASD content
execute as @s[scores={wasd.use_d_sword=1..}] if data entity @s SelectedItem.components."minecraft:custom_data"."wasd.sword_type" run function wasd.diamond_sword:determine_sword
scoreboard players reset @s wasd.use_d_sword
execute as @s[tag=wasd.is_demon_possessed] run function wasd.diamond_sword:swords/demon_possessed
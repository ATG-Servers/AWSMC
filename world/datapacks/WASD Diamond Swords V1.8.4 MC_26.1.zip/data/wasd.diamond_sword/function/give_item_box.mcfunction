#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.diamond_sword:xp
loot insert ~ ~ ~ loot wasd.diamond_sword:rainbow
loot insert ~ ~ ~ loot wasd.diamond_sword:darkness
loot insert ~ ~ ~ loot wasd.diamond_sword:light
loot insert ~ ~ ~ loot wasd.diamond_sword:vampire
loot insert ~ ~ ~ loot wasd.diamond_sword:demon
loot insert ~ ~ ~ loot wasd.diamond_sword:angel
loot insert ~ ~ ~ loot wasd.diamond_sword:moon
loot insert ~ ~ ~ loot wasd.diamond_sword:sun
loot insert ~ ~ ~ loot wasd.diamond_sword:invisible
loot insert ~ ~ ~ loot wasd.diamond_sword:xp_star
loot insert ~ ~ ~ loot wasd.diamond_sword:enhanced_diamond
loot insert ~ ~ ~ loot wasd.diamond_sword:ender_diamond
#mc-build WASD content
summon armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["wasd.predicate_check"],equipment:{chest:{id:"minecraft:debug_stick",count:1}}}
tag @s add wasd.checking_validity
data modify entity @n[type=armor_stand,tag=wasd.predicate_check] equipment.chest set from entity @s Item
execute as @n[type=armor_stand,tag=wasd.predicate_check] run function wasd.pick:zzz/2
tag @s remove wasd.checking_validity
#possibly add coral and coral fans
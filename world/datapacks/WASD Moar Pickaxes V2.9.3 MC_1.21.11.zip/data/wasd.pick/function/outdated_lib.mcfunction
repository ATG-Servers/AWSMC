#mc-build WASD content
execute unless score version wasd.lib_setting matches 66.. run function wasd.pick:zzz/1
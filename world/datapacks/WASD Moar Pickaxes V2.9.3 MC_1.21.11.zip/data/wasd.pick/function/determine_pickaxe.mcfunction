#mc-build WASD content
execute as @s[scores={wasd.pick_type=1}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/tnt
execute as @s[scores={wasd.pick_type=2}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:patron/code/cow
execute as @s[scores={wasd.pick_type=3}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/log
execute as @s[scores={wasd.pick_type=4}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/snow
execute as @s[scores={wasd.pick_type=5}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/firework
execute as @s[scores={wasd.pick_type=7}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/magnetic
execute as @s[scores={wasd.pick_type=10}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/strip
execute as @s[scores={wasd.pick_type=11}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/tunnel
execute as @s[scores={wasd.pick_type=12}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/torch
execute as @s[scores={wasd.pick_type=13}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:patron/code/bookshelf
execute as @s[scores={wasd.pick_type=14}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:patron/code/cake
execute as @s[scores={wasd.pick_type=15}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:patron/code/creeper
execute as @s[scores={wasd.pick_type=16}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/smelter
execute as @s[scores={wasd.pick_type=17}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/diamond_strip
execute as @s[scores={wasd.pick_type=18}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/diamond_tunnel
execute as @s[scores={wasd.pick_type=19}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/xp
execute as @s[scores={wasd.pick_type=20}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.pick:code/rainbow
execute as @s[scores={wasd.pick_type=21}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/momentum
execute as @s[scores={wasd.pick_type=22}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/obsidian
execute as @s[scores={wasd.pick_type=23}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/giant_diamond
execute as @s[scores={wasd.pick_type=25}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/ice
execute as @s[scores={wasd.pick_type=26}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/lucky
execute as @s[scores={wasd.pick_type=29}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/wither
execute as @s[scores={wasd.pick_type=30}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:code/dragon
execute as @s[scores={wasd.pick_type=31}] positioned ^ ^ ^3 as @e[type=item,sort=nearest,limit=1,nbt={OnGround:0b,Age:0s}] at @s run function wasd.pick:patron/code/fortunate
scoreboard players reset @s wasd.used_pick
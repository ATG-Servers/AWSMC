#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_picks wasd_data_packs 1
scoreboard players set camp_datapack wasd_data_packs 1
scoreboard objectives remove wasd.used_pick
scoreboard objectives remove wasd.used_pick
scoreboard objectives add wasd.used_pick minecraft.used:minecraft.stone_pickaxe
scoreboard objectives add wasd.momentum dummy
scoreboard objectives add w.pick_setting dummy
scoreboard objectives add wasd.pick_type dummy
scoreboard objectives add w.pick_sneaking minecraft.custom:minecraft.sneak_time
schedule function wasd.pick:outdated_lib 1t replace
function wasd.pick:config
schedule function wasd.pick:check_installed_packs 30t replace
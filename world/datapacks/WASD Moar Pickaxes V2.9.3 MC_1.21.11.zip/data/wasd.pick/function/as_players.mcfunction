#mc-build WASD content
execute as @s[scores={wasd.used_pick=1..}] run function wasd.pick:determine_pickaxe
execute as @s[tag=wasd.hotbar_slot_changed] store result score @s wasd.pick_type run data get entity @s SelectedItem.components."minecraft:custom_data"."wasd.custom_pick"
execute as @s[scores={wasd.pick_type=1..}] run function wasd.pick:holding_pickaxe
scoreboard players reset @s[scores={w.pick_sneaking=1..}] w.pick_sneaking
#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.pick:items/control
loot insert ~ ~ ~ loot wasd.pick:items/diamond_strip
loot insert ~ ~ ~ loot wasd.pick:items/diamond_tunnel
loot insert ~ ~ ~ loot wasd.pick:items/dragon
loot insert ~ ~ ~ loot wasd.pick:items/efficient
loot insert ~ ~ ~ loot wasd.pick:items/firework
loot insert ~ ~ ~ loot wasd.pick:items/giant_diamond
loot insert ~ ~ ~ loot wasd.pick:items/ice
loot insert ~ ~ ~ loot wasd.pick:items/log
loot insert ~ ~ ~ loot wasd.pick:items/lucky
loot insert ~ ~ ~ loot wasd.pick:items/magnetic
loot insert ~ ~ ~ loot wasd.pick:items/momentum
loot insert ~ ~ ~ loot wasd.pick:items/pillow
loot insert ~ ~ ~ loot wasd.pick:items/rainbow
loot insert ~ ~ ~ loot wasd.pick:items/molten
loot insert ~ ~ ~ loot wasd.pick:items/snow
loot insert ~ ~ ~ loot wasd.pick:items/strip
loot insert ~ ~ ~ loot wasd.pick:items/tnt
loot insert ~ ~ ~ loot wasd.pick:items/torch
loot insert ~ ~ ~ loot wasd.pick:items/torch2
loot insert ~ ~ ~ loot wasd.pick:items/tunnel
loot insert ~ ~ ~ loot wasd.pick:items/wither
loot insert ~ ~ ~ loot wasd.pick:items/xp
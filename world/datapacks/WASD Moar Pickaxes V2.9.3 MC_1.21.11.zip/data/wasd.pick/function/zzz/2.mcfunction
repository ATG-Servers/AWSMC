#mc-build WASD content
execute if predicate wasd.pick:invalid_mine run tag @e[type=item,tag=wasd.checking_validity,sort=nearest,limit=1] add wasd.invalid_mine_attempt
kill @s
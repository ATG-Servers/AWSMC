#mc-build WASD content
execute as @a at @s run function wasd.pick:as_players
#mc-build WASD content
function wasd.pick:invalid_mine
execute unless entity @s[tag=wasd.invalid_mine_attempt] run function wasd.pick:code/zzz/0
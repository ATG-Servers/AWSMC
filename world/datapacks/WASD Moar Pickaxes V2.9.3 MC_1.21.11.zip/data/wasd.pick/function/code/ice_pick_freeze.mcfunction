#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:liquids[level=0] run particle snowflake ~0.5 ~0.5 ~0.5 0.3 0.3 0.3 0.01 30 force
execute if block ~ ~ ~ lava[level=0] run setblock ~ ~ ~ obsidian
execute if block ~ ~ ~ water[level=0] run setblock ~ ~ ~ ice
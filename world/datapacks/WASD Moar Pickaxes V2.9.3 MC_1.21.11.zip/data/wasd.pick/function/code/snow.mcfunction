#mc-build WASD content
particle snowflake ~0.5 ~0.5 ~0.5 0.2 0.2 0.2 0.05 10 force
playsound minecraft:block.snow.break player @a ~ ~ ~ 0.2 1
#mc-build WASD content
function wasd.abilities:firework_explosion
#mc-build WASD content
execute store result score @s wasd.rng run random value 1..2
execute as @s[scores={wasd.rng=1}] align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.pick:code/zzz/39
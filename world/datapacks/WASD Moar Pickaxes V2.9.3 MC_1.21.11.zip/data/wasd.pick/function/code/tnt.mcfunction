#mc-build WASD content
function wasd.lib:affects/tnt_explode
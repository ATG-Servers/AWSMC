#mc-build WASD content
execute positioned ~ ~-0.5 ~ run function wasd.lib:affects/drop_rainbow_dye
#mc-build WASD content
setblock ~ ~ ~ torch
execute align xyz positioned ~0.5 ~0.5 ~0.5 run particle flame ~ ~ ~ 0 0 0 0.05 10 force
playsound item.firecharge.use player @a ~ ~ ~ 1 0.5
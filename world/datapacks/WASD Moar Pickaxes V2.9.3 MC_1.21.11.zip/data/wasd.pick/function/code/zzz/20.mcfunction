#mc-build WASD content
function wasd.lib:detection/cube/3x3
execute at @e[tag=wasd.location] if block ~ ~ ~ #minecraft:mineable/pickaxe run function wasd.pick:code/zzz/21
kill @e[tag=wasd.location]
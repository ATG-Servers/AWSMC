#mc-build WASD content
function wasd.lib:detection/cube/5x5
execute as @e[tag=wasd.location,type=marker] at @s run function wasd.pick:code/zzz/29
kill @e[tag=wasd.location,type=marker]
function wasd.pick:code/kill_weak_stone
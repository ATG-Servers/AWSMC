#mc-build WASD content
summon experience_orb ~ ~ ~ {Value:1}
particle dust{color:[0.906, 1.000, 0.741], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 1 1 normal
particle dust{color:[0.506, 0.902, 0.388], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 1 1 normal
particle dust{color:[0.769, 0.902, 0.396], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 1 1 normal
particle dust{color:[0.420, 0.902, 0.298], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 1 1 normal
particle dust{color:[0.937, 1.000, 0.361], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 1 1 normal
playsound minecraft:entity.player.levelup player @a ~ ~ ~ 0.2 2
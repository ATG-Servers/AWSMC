#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:weak_stone run summon marker ~ ~ ~ {Tags:["wasd.withered_block","wasd.lib_entity_tick"]}
execute if block ~ ~ ~ #wasd.tags:ores run function wasd.pick:code/zzz/30
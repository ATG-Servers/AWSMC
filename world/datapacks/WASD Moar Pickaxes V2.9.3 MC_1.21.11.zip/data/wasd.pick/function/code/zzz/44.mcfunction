#mc-build WASD content
execute store result score @s wasd.rng run random value 1..45
scoreboard players add @s wasd.rng 2
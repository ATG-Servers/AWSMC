#mc-build WASD content
particle dust{color:[0.439, 0.0, 0.0], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 0 10 force
playsound minecraft:block.note_block.bass player @a ~ ~ ~ 1 1
loot spawn ~ ~ ~ loot wasd.pick:lucky/bad
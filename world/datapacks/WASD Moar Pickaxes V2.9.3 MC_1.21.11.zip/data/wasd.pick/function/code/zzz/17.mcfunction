#mc-build WASD content
execute as @p[scores={wasd.pick_type=11,wasd.used_pick=1..}] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air replace
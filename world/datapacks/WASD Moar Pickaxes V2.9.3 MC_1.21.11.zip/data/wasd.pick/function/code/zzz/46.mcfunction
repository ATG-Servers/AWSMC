#mc-build WASD content
particle dust{color:[0.235, 1.0, 0.0], scale:3.0} ~ ~ ~ 0.2 0.2 0.2 0 10 force
playsound block.note_block.bit player @a ~ ~ ~ 1 1
loot spawn ~ ~ ~ loot wasd.pick:lucky/good
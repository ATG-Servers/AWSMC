#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:weak_stone run summon marker ~ ~ ~ {Tags:["wasd.dragoned_block","wasd.lib_entity_tick"]}
#mc-build WASD content
execute if predicate wasd.pick:weak_stone run kill @e[type=item,tag=wasd.checking_validity,sort=nearest,limit=1]
kill @s
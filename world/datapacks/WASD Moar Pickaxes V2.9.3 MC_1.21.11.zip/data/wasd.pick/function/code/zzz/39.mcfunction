#mc-build WASD content
scoreboard players reset @s wasd.rng
#worst
execute as @s[nbt={Item:{id:"minecraft:coal"}}] run function wasd.pick:code/zzz/40
execute as @s[nbt={Item:{id:"minecraft:quartz"}}] run function wasd.pick:code/zzz/41
execute as @s[nbt={Item:{id:"minecraft:gold_nugget"}}] run function wasd.pick:code/zzz/42
execute as @s[nbt={Item:{id:"minecraft:raw_copper"}}] run function wasd.pick:code/zzz/43
execute as @s[nbt={Item:{id:"minecraft:raw_iron"}}] run function wasd.pick:code/zzz/44
#better
execute as @s[nbt={Item:{id:"minecraft:lapis_lazuli"}}] store result score @s wasd.rng run random value 1..9
execute as @s[nbt={Item:{id:"minecraft:raw_gold"}}] store result score @s wasd.rng run random value 1..7
execute as @s[nbt={Item:{id:"minecraft:diamond"}}] store result score @s wasd.rng run random value 1..4
#best
execute as @s[nbt={Item:{id:"minecraft:emerald"}}] store result score @s wasd.rng run random value 1..2
#best
execute as @s[scores={wasd.rng=1}] run function wasd.pick:code/zzz/45
#good
execute as @s[scores={wasd.rng=2}] run function wasd.pick:code/zzz/46
#okay
execute as @s[scores={wasd.rng=3..8}] run function wasd.pick:code/zzz/47
#bad
execute as @s[scores={wasd.rng=9..}] run function wasd.pick:code/zzz/48
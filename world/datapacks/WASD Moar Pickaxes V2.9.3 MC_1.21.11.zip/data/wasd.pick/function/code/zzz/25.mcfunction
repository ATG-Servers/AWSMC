#mc-build WASD content
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute at @e[tag=wasd.box_location] run data modify block ~ ~ ~ Items[0].components."minecraft:item_model" set value "wasd:pick/control"
execute at @e[tag=wasd.box_location] run data modify block ~ ~ ~ Items[0].components."minecraft:tool".rules[1].speed set value 9.0
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
#mc-build WASD content
execute store result score @s wasd.rng run random value 1..10
execute as @s[scores={wasd.rng=1}] run summon marker ~ ~ ~ {Tags:["wasd.withered_block","wasd.lib_entity_tick"]}
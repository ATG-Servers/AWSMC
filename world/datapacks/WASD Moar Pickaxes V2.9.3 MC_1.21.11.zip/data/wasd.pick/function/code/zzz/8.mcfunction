#mc-build WASD content
scoreboard players reset @s wasd.momentum
effect clear @s minecraft:mining_fatigue
tag @s add wasd.momentum_mined
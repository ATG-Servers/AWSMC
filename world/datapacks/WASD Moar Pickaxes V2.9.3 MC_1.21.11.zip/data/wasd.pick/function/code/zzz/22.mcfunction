#mc-build WASD content
execute if entity @s[nbt={SelectedItem:{components:{"minecraft:item_model":"wasd:pick/control"}}}] run function wasd.pick:code/zzz/23
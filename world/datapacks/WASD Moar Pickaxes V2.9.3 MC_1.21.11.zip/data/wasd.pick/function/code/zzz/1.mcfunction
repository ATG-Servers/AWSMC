#mc-build WASD content
summon minecraft:marker ^ ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^1 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^1 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^2 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^2 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^3 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^3 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^4 {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^4 {Tags:["wasd.mining_location"]}
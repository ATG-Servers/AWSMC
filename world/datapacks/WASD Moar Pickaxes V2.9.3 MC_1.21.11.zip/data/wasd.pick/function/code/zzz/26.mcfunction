#mc-build WASD content
execute if predicate light_level:0 if block ~ ~ ~ #wasd.tags:air unless block ~ ~-1 ~ #wasd.tags:nonsolid run function wasd.pick:code/zzz/27
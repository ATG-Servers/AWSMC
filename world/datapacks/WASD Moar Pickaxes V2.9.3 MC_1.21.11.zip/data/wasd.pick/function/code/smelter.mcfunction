#mc-build WASD content
particle flame ~ ~ ~ 0 0 0 0.1 20
particle smoke ~ ~ ~ 0 0 0 0.1 10
playsound minecraft:entity.blaze.shoot block @a ~ ~ ~ 0.1 0.8
data merge entity @s[nbt={Item:{id: "minecraft:stone"}}] {Item:{id:"minecraft:smooth_stone"}}
data merge entity @s[nbt={Item:{id: "minecraft:cobblestone"}}] {Item:{id:"minecraft:stone"}}
data merge entity @s[nbt={Item:{id: "minecraft:deepslate_iron_ore"}}] {Item:{id:"minecraft:iron_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:iron_ore"}}] {Item:{id:"minecraft:iron_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:raw_iron"}}] {Item:{id:"minecraft:iron_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:deepslate_gold_ore"}}] {Item:{id:"minecraft:gold_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:gold_ore"}}] {Item:{id:"minecraft:gold_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:raw_gold"}}] {Item:{id:"minecraft:gold_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:deepslate_copper_ore"}}] {Item:{id:"minecraft:copper_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:copper_ore"}}] {Item:{id:"minecraft:copper_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:raw_copper"}}] {Item:{id:"minecraft:copper_ingot"}}
data merge entity @s[nbt={Item:{id: "minecraft:sand"}}] {Item:{id:"minecraft:glass"}}
data merge entity @s[nbt={Item:{id: "minecraft:netherrack"}}] {Item:{id:"minecraft:nether_brick"}}
data merge entity @s[nbt={Item:{id: "minecraft:ancient_debris"}}] {Item:{id:"minecraft:netherite_scrap"}}
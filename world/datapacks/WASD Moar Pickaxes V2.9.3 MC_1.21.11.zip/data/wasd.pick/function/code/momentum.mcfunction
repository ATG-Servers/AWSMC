#mc-build WASD content
function wasd.pick:invalid_mine
execute unless entity @s[tag=wasd.invalid_mine_attempt] as @p[scores={wasd.pick_type=21,wasd.used_pick=1..}] run function wasd.pick:code/zzz/8
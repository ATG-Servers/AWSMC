#mc-build WASD content
execute align xyz run particle snowflake ~0.5 ~0.5 ~0.5 0.2 0.2 0.2 0.05 15 force
playsound minecraft:block.snow.break player @a ~ ~ ~ 0.5 1
execute positioned ~1 ~ ~ run function wasd.pick:code/ice_pick_freeze
execute positioned ~-1 ~ ~ run function wasd.pick:code/ice_pick_freeze
execute positioned ~ ~1 ~ run function wasd.pick:code/ice_pick_freeze
execute positioned ~ ~-1 ~ run function wasd.pick:code/ice_pick_freeze
execute positioned ~ ~ ~1 run function wasd.pick:code/ice_pick_freeze
execute positioned ~ ~ ~-1 run function wasd.pick:code/ice_pick_freeze
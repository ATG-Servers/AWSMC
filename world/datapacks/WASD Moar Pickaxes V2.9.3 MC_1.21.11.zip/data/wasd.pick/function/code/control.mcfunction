#mc-build WASD content
execute if predicate wasd.lib:sneaking run function wasd.pick:code/zzz/22
execute unless predicate wasd.lib:sneaking run function wasd.pick:code/zzz/24
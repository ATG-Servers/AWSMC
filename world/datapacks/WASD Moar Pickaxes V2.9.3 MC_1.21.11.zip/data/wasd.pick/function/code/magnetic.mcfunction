#mc-build WASD content
tp @s @p[scores={wasd.pick_type=7,wasd.used_pick=1..}]
data merge entity @s {PickupDelay:0}
particle dust{color:[1.000, 0.000, 0.000], scale:2.0} ~ ~ ~ 0.1 0.1 0.1 1 3 normal
particle dust{color:[0.129, 0.247, 1.000], scale:2.0} ~ ~ ~ 0.1 0.1 0.1 1 3 normal
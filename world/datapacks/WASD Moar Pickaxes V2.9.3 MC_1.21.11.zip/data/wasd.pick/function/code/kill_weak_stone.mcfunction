#mc-build WASD content
summon armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,Tags:["wasd.predicate_check"],ArmorItems:[{},{},{id:"minecraft:debug_stick",Count:1b},{}]}
tag @s add wasd.checking_validity
data modify entity @e[type=armor_stand,tag=wasd.predicate_check,sort=nearest,limit=1] ArmorItems[2] set from entity @s Item
execute as @e[type=armor_stand,tag=wasd.predicate_check,sort=nearest,limit=1] run function wasd.pick:code/zzz/33
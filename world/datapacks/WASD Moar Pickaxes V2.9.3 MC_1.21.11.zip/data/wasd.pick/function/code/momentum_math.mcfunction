#mc-build WASD content
effect give @s[tag=!wasd.momentum_mined] minecraft:mining_fatigue 1 2 true
execute as @s[tag=wasd.momentum_mined] run scoreboard players add @s wasd.momentum 1
tag @s[scores={wasd.momentum=20..}] remove wasd.momentum_mined
scoreboard players reset @s[scores={wasd.momentum=20..}] wasd.momentum
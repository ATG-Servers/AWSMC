#mc-build WASD content
loot give @s loot wasd.pick:items/control
loot give @s loot wasd.pick:items/diamond_strip
loot give @s loot wasd.pick:items/diamond_tunnel
loot give @s loot wasd.pick:items/dragon
loot give @s loot wasd.pick:items/efficient
#loot give @s loot wasd.pick:items/end_crystal
loot give @s loot wasd.pick:items/firework
loot give @s loot wasd.pick:items/giant_diamond
loot give @s loot wasd.pick:items/ice
loot give @s loot wasd.pick:items/log
loot give @s loot wasd.pick:items/lucky
loot give @s loot wasd.pick:items/magnetic
loot give @s loot wasd.pick:items/momentum
#loot give @s loot wasd.pick:items/obsidian
loot give @s loot wasd.pick:items/pillow
loot give @s loot wasd.pick:items/rainbow
#loot give @s loot wasd.pick:items/redstone
loot give @s loot wasd.pick:items/molten
loot give @s loot wasd.pick:items/snow
loot give @s loot wasd.pick:items/strip
loot give @s loot wasd.pick:items/tnt
loot give @s loot wasd.pick:items/torch
loot give @s loot wasd.pick:items/torch2
loot give @s loot wasd.pick:items/tunnel
loot give @s loot wasd.pick:items/wither
loot give @s loot wasd.pick:items/xp
function wasd.pick:patron/give_items
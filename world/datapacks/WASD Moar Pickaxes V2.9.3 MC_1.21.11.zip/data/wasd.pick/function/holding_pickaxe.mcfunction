#mc-build WASD content
execute as @s[scores={wasd.pick_type=21}] run function wasd.pick:code/momentum_math
execute as @s[scores={wasd.pick_type=27}] run function wasd.pick:code/control
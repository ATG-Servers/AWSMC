#mc-build WASD content
#configure spear settings
#
#
#Dripstone Spear
#Amount of pointed dripstone projectiles to shoot on left click (default 5)
scoreboard players set dripstone_shoot_amount wasd.spears_settings 5
#How many ticks should go by before shooting the next projectile (default 5 ticks)
scoreboard players set dripstone_shoot_interval wasd.spears_settings 5
#
#Amount of Falling Dripstone to launching into the air on ram attack (default 20)
scoreboard players set falling_dripstone_to_launch wasd.spears_settings 20
#
#Spearmint
#Distance the Spearmint Spear projectiles should travel, in 0.8 block increments (default 30)
scoreboard players set spearmint_distance wasd.spears_settings 30
#
#Spear Blossom
#How many gameticks between placing an exploding blossom while ramming (default 10 ticks)
scoreboard players set blossom_interval wasd.spears_settings 10
#Exploding Blossom delay before detonating (default 60 ticks)
scoreboard players set blossom_delay wasd.spears_settings 60
#
#Prismarine
#How long you need to ram for before the spikes appear around you (default 20 ticks)
scoreboard players set prismarine_spikes_delay wasd.spears_settings 20
#Prismarine Spike max travel distance, in half blocks (default 17 ticks)
scoreboard players set prismarine_spikes_max_distance wasd.spears_settings 17
#Prismarine Spike minimum travel distance, in half blocks before it can deal damage. Delayed to avoid self damage (default 5)
scoreboard players set prismarine_spikes_min_distance wasd.spears_settings 5
#
#Rainbow Projectile max travel distance, in half blocks (default 100)
scoreboard players set prismarine_rainbow_max_distance wasd.spears_settings 100
#Rainbow Projectile minimum travel distance, in half blocks before it can deal damage. Delayed to avoid self damage (default 5)
scoreboard players set prismarine_rainbow_min_distance wasd.spears_settings 5
#
#TNT
#How many gameticks between spawning TNT while ramming (default 30 ticks)
scoreboard players set tnt_interval wasd.spears_settings 30
#
#Goat Spear
#Delay before spawning charging mobs (default 60 ticks)
scoreboard players set goat_delay wasd.spears_settings 60
#How far the spawned mobs should charge for, in full blocks minus 20 (default 100 ticks)
scoreboard players set goat_charge_distance wasd.spears_settings 100
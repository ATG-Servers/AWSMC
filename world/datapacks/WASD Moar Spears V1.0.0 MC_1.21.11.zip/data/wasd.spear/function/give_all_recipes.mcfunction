#mc-build WASD content
recipe give @s wasd.spear:blossom
recipe give @s wasd.spear:disaspear
recipe give @s wasd.spear:drill
recipe give @s wasd.spear:dripstone
recipe give @s wasd.spear:fishing
recipe give @s wasd.spear:goat
recipe give @s wasd.spear:grabbing
recipe give @s wasd.spear:lance
recipe give @s wasd.spear:magma
recipe give @s wasd.spear:piston
recipe give @s wasd.spear:prismarine
recipe give @s wasd.spear:slime
recipe give @s wasd.spear:spearmint
recipe give @s wasd.spear:tire
recipe give @s wasd.spear:tnt
recipe give @s wasd.spear:wind
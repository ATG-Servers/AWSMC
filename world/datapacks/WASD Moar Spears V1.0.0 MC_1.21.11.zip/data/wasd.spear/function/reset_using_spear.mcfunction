#mc-build WASD content
tag @a remove wasd.using_spear
#mc-build WASD content
loot give @s loot wasd.spear:blossom
loot give @s loot wasd.spear:disaspear
loot give @s loot wasd.spear:drill
loot give @s loot wasd.spear:dripstone
loot give @s loot wasd.spear:fishing
loot give @s loot wasd.spear:goat
loot give @s loot wasd.spear:grabbing
loot give @s loot wasd.spear:lance
loot give @s loot wasd.spear:magma
loot give @s loot wasd.spear:piston
loot give @s loot wasd.spear:prismarine
loot give @s loot wasd.spear:slime
loot give @s loot wasd.spear:spearmint
loot give @s loot wasd.spear:tire
loot give @s loot wasd.spear:tnt
loot give @s loot wasd.spear:wind
#mc-build WASD content
tp @s ^ ^ ^0.8 ~ ~0.35
scoreboard players add @s wasd.timer 1
execute if score @s wasd.timer >= spearmint_distance wasd.spears_settings run tag @s add wasd.hit
particle dust_color_transition{from_color:[0.051,1.000,0.145],to_color:[0.000,0.651,0.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.hit
execute as @s[scores={wasd.timer=5..}] run function wasd.spear:entities/zzz/25
execute as @s[tag=wasd.hit] run function wasd.spear:entities/zzz/26
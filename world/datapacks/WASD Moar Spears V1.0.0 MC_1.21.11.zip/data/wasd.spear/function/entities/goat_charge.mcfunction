#mc-build WASD content
scoreboard players add @s wasd.timer 1
#teleport the dude to the right location (in case they got stuck)
execute as @s[scores={wasd.timer=10}] unless block ~ ~ ~ #wasd.tags:nonsolid run tp @s ~ ~2 ~
execute as @s[scores={wasd.timer=20}] run function wasd.spear:entities/zzz/17
execute rotated ~ 0 as @s[scores={wasd.timer=20..},tag=!wasd.hit_wall] run function wasd.spear:entities/zzz/18
execute if score @s wasd.timer > goat_charge_distance wasd.spears_settings run kill @s
execute as @s[tag=wasd.hit_wall] anchored eyes positioned ^ ^0.01 ^ run particle crit ~ ~ ~ 0.3 0.2 0.3 0 2 normal
execute as @s[tag=wasd.hit_wall] if block ~ ~-1 ~ #wasd.tags:nonsolid run kill @s
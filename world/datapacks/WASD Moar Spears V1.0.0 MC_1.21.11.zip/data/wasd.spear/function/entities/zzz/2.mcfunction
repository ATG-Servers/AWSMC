#mc-build WASD content
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.5 1
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.5 1.3
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.5 1.6
playsound minecraft:block.amethyst_block.place player @a ~ ~ ~ 0.5 1
playsound minecraft:block.amethyst_block.resonate player @a ~ ~ ~ 0.5 1
playsound minecraft:block.amethyst_block.resonate player @a ~ ~ ~ 0.5 0.5
execute store result score @s wasd.rng run random value 1..7
execute as @s[scores={wasd.rng=1}] run function wasd.spear:entities/zzz/3
execute as @s[scores={wasd.rng=2}] run function wasd.spear:entities/zzz/4
execute as @s[scores={wasd.rng=3}] run function wasd.spear:entities/zzz/5
execute as @s[scores={wasd.rng=4}] run function wasd.spear:entities/zzz/6
execute as @s[scores={wasd.rng=5}] run function wasd.spear:entities/zzz/7
execute as @s[scores={wasd.rng=6}] run function wasd.spear:entities/zzz/8
execute as @s[scores={wasd.rng=7}] run function wasd.spear:entities/zzz/9
execute positioned ~ ~1 ~ as @e[type=#wasd.tags:mobs_player,distance=..2] run damage @s 9 minecraft:on_fire
execute positioned ~ ~1 ~ as @e[type=#wasd.tags:mobs_player,distance=..3] run damage @s 6 minecraft:on_fire
execute positioned ~ ~1 ~ as @e[type=#wasd.tags:mobs_player,distance=..4] run damage @s 3 minecraft:on_fire
kill @s
#mc-build WASD content
execute store result score @s wasd.x_angle run data get entity @s Rotation[0]
execute store result score @s wasd.rng run random value -8..8
execute store result entity @s Rotation[0] float 1 run scoreboard players operation @s wasd.x_angle += @s wasd.rng
execute store result score @s wasd.y_angle run data get entity @s Rotation[1]
execute store result score @s wasd.rng run random value -4..4
execute store result entity @s Rotation[1] float 1 run scoreboard players operation @s wasd.y_angle += @s wasd.rng
tag @s add wasd.given_rotation
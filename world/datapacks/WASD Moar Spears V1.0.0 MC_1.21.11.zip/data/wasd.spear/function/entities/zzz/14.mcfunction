#mc-build WASD content
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 0.5 1
playsound minecraft:block.amethyst_block.place player @a ~ ~ ~ 0.5 1
playsound enchant.thorns.hit player @a ~ ~ ~ 0.5 0.8
particle falling_dust{block_state:{Name:"minecraft:prismarine_bricks"}} ~ ~ ~ 0.2 0.2 0.2 0 20 force
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 5 minecraft:cactus
execute as @e[type=#wasd.tags:mobs_player,distance=..2] run damage @s 2 minecraft:cactus
kill @s
#mc-build WASD content
particle flash{color:[1.000,0.467,0.000,1.00]} ~ ~ ~ 0.2 0.2 0.2 0 10 force
particle falling_dust{block_state:{Name:"minecraft:orange_wool"}} ~ ~ ~ 0.2 0.2 0.2 0 100 force
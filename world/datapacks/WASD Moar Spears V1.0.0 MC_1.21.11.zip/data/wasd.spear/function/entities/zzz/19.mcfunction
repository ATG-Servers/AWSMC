#mc-build WASD content
particle minecraft:gust ~ ~0.2 ~ 0 0 0 0 1 normal
particle spore_blossom_air ~ ~0.2 ~ 0.1 0.1 0.1 0.2 200 normal
particle dust_plume ~ ~0.2 ~ 0.1 0.1 0.1 0.1 50 normal
particle dust_pillar{block_state:"minecraft:pink_concrete"} ~ ~0.2 ~ 0.1 0.1 0.1 0.1 50 normal
execute as @e[type=#wasd.tags:mobs_player,distance=..2] run function wasd.spear:entities/zzz/20
kill @s
#mc-build WASD content
playsound minecraft:block.pointed_dripstone.break player @a ~ ~ ~ 0.5 1
playsound minecraft:block.pointed_dripstone.place player @a ~ ~ ~ 0.5 1
particle dust_pillar{block_state:"minecraft:dripstone_block"} ~ ~ ~ 0.1 0.1 0.1 0.1 20 normal
particle block{block_state:"minecraft:dripstone_block"} ~ ~ ~ 0.1 0.1 0.1 0.05 20 normal
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 5 minecraft:falling_stalactite at ^ ^ ^-5
execute as @e[type=#wasd.tags:mobs_player,distance=..2] run damage @s 2 minecraft:falling_stalactite at ^ ^ ^-5
kill @s
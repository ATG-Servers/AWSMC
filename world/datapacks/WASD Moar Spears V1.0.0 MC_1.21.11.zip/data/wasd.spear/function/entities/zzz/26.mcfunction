#mc-build WASD content
playsound minecraft:item.spear.hit player @a ~ ~ ~ 0.5 1
playsound minecraft:item.spear.hit player @a ~ ~ ~ 0.5 1
particle sneeze ~ ~ ~ 0.1 0.1 0.1 0.1 10 normal
particle block{block_state:"minecraft:lime_wool"} ~ ~ ~ 0.1 0.1 0.1 0.05 20 normal
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 10 minecraft:generic at ^ ^ ^-5
execute as @e[type=#wasd.tags:mobs_player,distance=..2] run damage @s 7 minecraft:generic at ^ ^ ^-5
kill @s
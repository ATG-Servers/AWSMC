#mc-build WASD content
execute if score @s wasd.timer >= prismarine_spikes_max_distance wasd.spears_settings run tag @s add wasd.hit
tp @s ^ ^ ^0.5
execute positioned ^ ^1.1 ^1.5 run function wasd.spear:entities/zzz/12
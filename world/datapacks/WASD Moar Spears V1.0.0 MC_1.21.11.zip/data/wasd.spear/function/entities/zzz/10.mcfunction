#mc-build WASD content
tag @s add wasd.launched
scoreboard players reset @p wasd.using_prismarine_spear
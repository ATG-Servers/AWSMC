#mc-build WASD content
scoreboard players add @s wasd.temp 1
execute as @s[scores={wasd.temp=1..3}] run particle dust_color_transition{from_color:[1.000,0.000,0.000],to_color:[1.000,0.467,0.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=4..6}] run particle dust_color_transition{from_color:[1.000,0.467,0.000],to_color:[1.000,0.867,0.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=7..9}] run particle dust_color_transition{from_color:[1.000,0.867,0.000],to_color:[0.169,1.000,0.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=10..12}] run particle dust_color_transition{from_color:[0.169,1.000,0.000],to_color:[0.000,0.969,1.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=13..15}] run particle dust_color_transition{from_color:[0.000,0.969,1.000],to_color:[0.000,0.165,1.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=16..18}] run particle dust_color_transition{from_color:[0.000,0.165,1.000],to_color:[0.565,0.000,1.000],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.hit
execute if score @s wasd.timer >= prismarine_spikes_min_distance wasd.spears_settings run function wasd.spear:entities/zzz/13
execute as @s[tag=wasd.hit] run function wasd.spear:entities/zzz/14
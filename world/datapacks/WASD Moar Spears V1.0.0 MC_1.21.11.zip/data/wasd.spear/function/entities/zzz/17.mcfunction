#mc-build WASD content
data merge entity @s {NoAI:1b}
execute store result entity @s Rotation[0] float 1 run scoreboard players get @s wasd.x_angle
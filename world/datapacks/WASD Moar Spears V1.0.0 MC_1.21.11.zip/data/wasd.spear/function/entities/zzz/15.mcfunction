#mc-build WASD content
particle block{block_state:dirt} ~ ~ ~ 0.3 0 0.3 0 3 normal
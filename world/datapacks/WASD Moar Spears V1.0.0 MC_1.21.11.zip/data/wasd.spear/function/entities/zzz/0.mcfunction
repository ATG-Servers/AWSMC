#mc-build WASD content
particle dust_color_transition{from_color:[0.565,0.000,1.000],to_color:[1.000,0.000,0.831],scale:2.5} ~ ~ ~ 0 0 0 0 0 force
execute as @s[scores={wasd.temp=21..}] run scoreboard players reset @s wasd.temp
#mc-build WASD content
particle poof ~ ~ ~ 0.3 0.1 0.3 0.1 20 normal
kill @s
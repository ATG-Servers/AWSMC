#mc-build WASD content
damage @s 1 player_attack by @n[tag=wasd.blossom_location]
effect give @s wither 15 1 false
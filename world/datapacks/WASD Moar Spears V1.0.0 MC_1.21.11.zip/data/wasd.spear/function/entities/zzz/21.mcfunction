#mc-build WASD content
scoreboard players add @s wasd.temp 1
scoreboard players reset @s wasd.timer
function wasd.spear:entities/summon_dripstone_projectile
execute if score @s wasd.temp >= dripstone_shoot_amount wasd.spears_settings run kill @s
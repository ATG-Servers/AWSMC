#mc-build WASD content
execute positioned ^ ^ ^1 if block ~ ~-1 ~ #wasd.tags:nonsolid if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid run tag @s add wasd.hit_wall
execute positioned ^ ^ ^1 unless block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~1 ~ #wasd.tags:nonsolid run tag @s add wasd.hit_wall
execute as @s[tag=!wasd.hit_wall] positioned ^ ^ ^0.5 if block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~-1 ~ #wasd.tags:nonsolid run tp @s ^ ^ ^
execute as @s[tag=!wasd.hit_wall] positioned ^ ^ ^0.5 if block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~-1 ~ #wasd.tags:nonsolid run tp @s ^ ^-1 ^
execute as @s[tag=!wasd.hit_wall] positioned ^ ^ ^0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run tp @s ^ ^1 ^
execute positioned ^ ^ ^2 as @e[distance=..1.5,type=#wasd.tags:mobs_player] run damage @s 6 player_attack by @n[tag=wasd.goat_charge_entity]
execute positioned ^ ^ ^3 as @e[distance=..1.5,type=#wasd.tags:mobs_player] run damage @s 9 player_attack by @n[tag=wasd.goat_charge_entity]
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=60..}] run function wasd.spear:entities/zzz/27
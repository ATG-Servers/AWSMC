#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute if score @s wasd.timer >= blossom_delay wasd.spears_settings run function wasd.spear:entities/zzz/19
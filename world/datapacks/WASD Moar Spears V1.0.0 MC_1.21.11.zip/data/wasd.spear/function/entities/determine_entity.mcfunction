#mc-build WASD content
execute as @s[tag=wasd.prismarine_projectile] run function wasd.spear:entities/prismarine
execute as @s[tag=wasd.prismarine_thorn] run function wasd.spear:entities/prismarine_thorn
execute as @s[tag=wasd.goat_spawn_location] run function wasd.spear:entities/goat_spawn
execute as @s[tag=wasd.goat_charge_entity] run function wasd.spear:entities/goat_charge
execute as @s[tag=wasd.blossom_location] run function wasd.spear:entities/blossom_location
execute as @s[tag=wasd.dripstone_spawn_location] run function wasd.spear:entities/dripstone_spawn_location
execute as @s[tag=wasd.dripstone_projectile] run function wasd.spear:entities/dripstone_projectile
execute as @s[tag=wasd.grabbed_by_spear] run function wasd.spear:spears/held_entity
execute as @s[tag=wasd.currently_holding_entity] run function wasd.spear:spears/holding_entity
execute as @s[tag=wasd.spearmint_projectile] run function wasd.spear:entities/spearmint_projectile
execute as @s[tag=wasd.spear_tire] run function wasd.spear:entities/spear_tire
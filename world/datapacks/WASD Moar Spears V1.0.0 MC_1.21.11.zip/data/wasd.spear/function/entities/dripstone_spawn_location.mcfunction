#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute if score @s wasd.timer >= dripstone_shoot_interval wasd.spears_settings run function wasd.spear:entities/zzz/21
#mc-build WASD content
tp @s ^ ^ ^1 ~ ~0.2
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=60..}] run tag @s add wasd.hit
particle dust_color_transition{from_color:[0.451,0.329,0.314],to_color:[0.627,0.553,0.443],scale:1.5} ~ ~ ~ 0 0 0 0 0 force
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.hit
execute as @s[scores={wasd.timer=5..}] run function wasd.spear:entities/zzz/23
execute as @s[tag=wasd.hit] run function wasd.spear:entities/zzz/24
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=2}] run function wasd.spear:entities/zzz/10
execute as @s[tag=wasd.launched] run function wasd.spear:entities/zzz/11
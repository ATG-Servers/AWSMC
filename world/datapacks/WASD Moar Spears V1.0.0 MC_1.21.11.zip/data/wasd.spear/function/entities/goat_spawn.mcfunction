#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.move_down
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.move_up
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1..5},tag=wasd.move_down,tag=!wasd.found_location] run tp @s ~ ~-1 ~
execute as @s[scores={wasd.timer=1..5},tag=wasd.move_up,tag=!wasd.found_location] run tp @s ~ ~1 ~
execute unless block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~1 ~ #wasd.tags:nonsolid if block ~ ~2 ~ #wasd.tags:nonsolid run tag @s add wasd.found_location
execute as @s[tag=wasd.found_location,scores={wasd.timer=5..}] run function wasd.spear:entities/zzz/15
kill @s[tag=!wasd.found_location,scores={wasd.timer=5..}]
execute if score @s wasd.timer = goat_delay wasd.spears_settings run function wasd.spear:entities/zzz/16
execute if score @s wasd.timer > goat_delay wasd.spears_settings run kill @s
#mc-build WASD content
scoreboard objectives add wasd.spears_settings dummy
scoreboard objectives add wasd.using_tnt_spear dummy
scoreboard objectives add wasd.using_prismarine_spear dummy
scoreboard objectives add wasd.grabber_id dummy
scoreboard objectives add wasd.blossom_timer dummy
#blossom
#disaspear
#drill
#dripstone
#fishing
#goat
#grabbing
#lance
#magma
#piston
#prismarine
#slime
#spearmint
#tire
#tnt
#wind
say loaded
function wasd.spear:config
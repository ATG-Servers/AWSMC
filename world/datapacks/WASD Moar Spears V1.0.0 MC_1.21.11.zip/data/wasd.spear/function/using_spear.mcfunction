#mc-build WASD content
advancement revoke @s only wasd.spear:using_spear
tag @s add wasd.using_spear
execute if predicate wasd.spear:holding_disaspear run effect give @s invisibility 1 0 true
execute if predicate wasd.spear:holding_drill if predicate wasd.lib:sprinting run function wasd.spear:spears/drill_ram
execute if predicate wasd.spear:holding_tnt run function wasd.spear:spears/tnt_ram
execute if predicate wasd.spear:holding_prismarine run function wasd.spear:spears/prismarine_ram
execute if predicate wasd.spear:holding_blossom if predicate wasd.lib:sprinting run function wasd.spear:spears/blossom_ram
execute if predicate wasd.spear:holding_lance run function wasd.spear:spears/using_lance
execute if predicate wasd.spear:holding_tire run function wasd.spear:spears/using_tire
schedule function wasd.spear:reset_using_spear 1t replace
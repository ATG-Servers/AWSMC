#mc-build WASD content
execute as @s[x_rotation=45..90] run tag @s add wasd.up_down
execute as @s[x_rotation=-90..-45] run tag @s add wasd.up_down
execute as @s[y_rotation=45..135] run tag @s add wasd.east_west
execute as @s[y_rotation=136..225] run tag @s add wasd.north_south
execute as @s[y_rotation=226..315] run tag @s add wasd.east_west
execute as @s[y_rotation=316..44] run tag @s add wasd.north_south
execute as @s[tag=!wasd.up_down,tag=wasd.north_south] rotated 0 0 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.spear:spears/zzz/1
execute as @s[tag=!wasd.up_down,tag=wasd.east_west] rotated 90 0 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.spear:spears/zzz/2
execute as @s[tag=wasd.up_down] rotated 0 -90 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.spear:spears/zzz/3
execute at @e[tag=wasd.mining_location,limit=5,sort=random] if block ~ ~ ~ #wasd.tags:weak_stone run setblock ~ ~ ~ air destroy
kill @e[tag=wasd.mining_location]
tag @s remove wasd.up_down
tag @s remove wasd.north_south
tag @s remove wasd.east_west
effect give @s slowness 1 0 false
#mc-build WASD content
tag @s remove wasd.spear_riding_mount
execute on vehicle if entity @s[type=#wasd.tags:mounts] on passengers run function wasd.spear:spears/zzz/16
execute as @s[tag=!wasd.spear_riding_mount] if predicate wasd.spear:strong_lance run item modify entity @s weapon.mainhand wasd.spear:make_spear_weak
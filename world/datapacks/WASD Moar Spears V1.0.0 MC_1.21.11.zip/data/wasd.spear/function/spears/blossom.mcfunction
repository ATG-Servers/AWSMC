#mc-build WASD content
particle minecraft:gust ~ ~0.2 ~ 0 0 0 0 1 normal
particle spore_blossom_air ~ ~1 ~ 0.1 0.5 0.1 0.1 100 normal
particle dust_plume ~ ~0.2 ~ 0.1 0.1 0.1 0.05 20 normal
particle dust_pillar{block_state:"minecraft:pink_concrete"} ~ ~0.2 ~ 0.1 0.1 0.1 0.05 20 normal
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run effect give @s wither 12 0 false
#mc-build WASD content
particle minecraft:sneeze ~ ~ ~ 0.1 0.5 0.1 0.1 30 normal
execute unless entity @s[tag=wasd.using_spear] run playsound minecraft:block.slime_block.break player @a ~ ~ ~ 1 1
execute if entity @s[tag=wasd.using_spear] run playsound minecraft:block.slime_block.break player @a ~ ~ ~ 1 0.5
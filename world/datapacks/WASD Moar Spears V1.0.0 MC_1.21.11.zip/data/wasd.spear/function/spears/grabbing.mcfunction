#mc-build WASD content
#determine if it should be picked up. If it is already picked up it shouldn't be again :P
execute as @s[type=!player] run function wasd.spear:spears/zzz/9
#mc-build WASD content
effect clear @e[tag=wasd.pistoned_bounced] levitation
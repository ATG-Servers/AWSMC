#mc-build WASD content
$summon fireball ~ ~ ~ {Owner:[I;0,0,0,0],Motion:[$(motion_0),$(motion_1),$(motion_2)]}
data modify entity @n[type=fireball,distance=..0.01] Owner set from entity @s UUID
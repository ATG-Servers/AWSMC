#mc-build WASD content
tag @s add wasd.grabbed_by_spear
tag @s add wasd.lib_entity_tick
tag @s add wasd.spear_entity
tag @s add wasd.ability
tag @s add wasd.just_picked_up
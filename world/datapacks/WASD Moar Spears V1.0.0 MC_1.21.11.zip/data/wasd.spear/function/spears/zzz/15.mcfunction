#mc-build WASD content
tag @s remove wasd.lib_entity_tick
tag @s remove wasd.spear_entity
tag @s remove wasd.ability
tag @s remove wasd.currently_holding_entity
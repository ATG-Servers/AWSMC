#mc-build WASD content
execute unless block ~0.3 ~ ~ #wasd.tags:nonsolid run tag @s add wasd.release
execute unless block ~-0.3 ~ ~ #wasd.tags:nonsolid run tag @s add wasd.release
execute unless block ~ ~ ~0.3 #wasd.tags:nonsolid run tag @s add wasd.release
execute unless block ~ ~ ~-0.3 #wasd.tags:nonsolid run tag @s add wasd.release
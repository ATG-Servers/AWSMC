#mc-build WASD content
tag @s add wasd.new_grabber
execute store result score @s wasd.grabber_id run data get entity @s UUID[0]
scoreboard players operation @n[type=#wasd.tags:mobs,tag=wasd.grabbed_by_spear,distance=..0.01] wasd.grabber_id = @s wasd.grabber_id
tag @s add wasd.lib_entity_tick
tag @s add wasd.spear_entity
tag @s add wasd.ability
tag @s add wasd.currently_holding_entity
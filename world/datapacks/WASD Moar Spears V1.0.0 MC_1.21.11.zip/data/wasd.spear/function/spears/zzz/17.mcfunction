#mc-build WASD content
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 1.5
particle small_flame ~ ~1 ~ 0.1 0.1 0.1 0.1 50 normal
particle flame ~ ~1 ~ 0.1 0.1 0.1 0.05 50 normal
#mc-build WASD content
tag @s remove wasd.lib_entity_tick
tag @s remove wasd.spear_entity
tag @s remove wasd.ability
tag @s remove wasd.grabbed_by_spear
scoreboard players reset @s wasd.grabber_id
execute at @a[tag=wasd.currently_holding_entity,distance=..10,tag=!wasd.new_grabber] if score @p[tag=wasd.currently_holding_entity,distance=..0.01] wasd.grabber_id = @s wasd.grabber_id as @p[tag=wasd.currently_holding_entity,distance=..0.01] run function wasd.spear:spears/zzz/15
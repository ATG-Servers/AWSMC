#mc-build WASD content
execute as @s[tag=!wasd.grabbed_by_spear] run function wasd.spear:spears/zzz/10
execute on attacker run function wasd.spear:spears/zzz/11
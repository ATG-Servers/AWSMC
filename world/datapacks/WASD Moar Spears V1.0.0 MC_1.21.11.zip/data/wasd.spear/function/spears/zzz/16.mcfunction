#mc-build WASD content
execute if predicate wasd.spear:weak_lance run item modify entity @s weapon.mainhand wasd.spear:make_spear_strong
tag @s add wasd.spear_riding_mount
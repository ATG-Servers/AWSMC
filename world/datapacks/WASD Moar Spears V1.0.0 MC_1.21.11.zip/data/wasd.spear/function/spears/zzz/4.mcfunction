#mc-build WASD content
execute if block ^0.3 ^ ^0.5 #wasd.tags:weak_stone run setblock ^0.3 ^ ^0.5 air destroy
execute if block ^-0.3 ^ ^0.5 #wasd.tags:weak_stone run setblock ^-0.3 ^ ^0.5 air destroy
execute if block ^0.3 ^ ^1 #wasd.tags:weak_stone run setblock ^0.3 ^ ^1 air destroy
execute if block ^-0.3 ^ ^1 #wasd.tags:weak_stone run setblock ^-0.3 ^ ^1 air destroy
execute if block ^0.3 ^ ^1.5 #wasd.tags:weak_stone run setblock ^0.3 ^ ^1.5 air destroy
execute if block ^-0.3 ^ ^1.5 #wasd.tags:weak_stone run setblock ^-0.3 ^ ^1.5 air destroy
execute if block ^0.3 ^1 ^0.5 #wasd.tags:weak_stone run setblock ^0.3 ^1 ^0.5 air destroy
execute if block ^-0.3 ^1 ^0.5 #wasd.tags:weak_stone run setblock ^-0.3 ^1 ^0.5 air destroy
execute if block ^0.3 ^1 ^1 #wasd.tags:weak_stone run setblock ^0.3 ^1 ^1 air destroy
execute if block ^-0.3 ^1 ^1 #wasd.tags:weak_stone run setblock ^-0.3 ^1 ^1 air destroy
execute if block ^0.3 ^1 ^1.5 #wasd.tags:weak_stone run setblock ^0.3 ^1 ^1.5 air destroy
execute if block ^-0.3 ^1 ^1.5 #wasd.tags:weak_stone run setblock ^-0.3 ^1 ^1.5 air destroy
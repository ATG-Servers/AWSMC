#mc-build WASD content
summon tnt ~ ~ ~ {fuse:60,explosion_power:1.5}
scoreboard players reset @s wasd.using_tnt_spear
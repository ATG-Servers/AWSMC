#mc-build WASD content
particle dust_pillar{block_state:"minecraft:dripstone_block"} ~ ~ ~ 0.1 0.1 0.1 0.1 50 normal
particle block{block_state:"minecraft:dripstone_block"} ~ ~ ~ 0.1 0.1 0.1 0.05 50 normal
summon marker ~ ~ ~ {Tags:["wasd.spear_entity","wasd.lib_entity_tick","wasd.ability","wasd.dripstone_spawn_location"]}
data modify entity @n[tag=wasd.dripstone_spawn_location,distance=..0.01] Rotation set from entity @s Rotation
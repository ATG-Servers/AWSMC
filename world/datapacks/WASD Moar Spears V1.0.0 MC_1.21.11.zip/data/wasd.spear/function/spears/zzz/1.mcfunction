#mc-build WASD content
summon minecraft:marker ^1 ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^1 ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^1 ^-1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^ ^-1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^1 ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^ ^ {Tags:["wasd.mining_location"]}
summon minecraft:marker ^-1 ^-1 ^ {Tags:["wasd.mining_location"]}
execute as @e[tag=wasd.mining_location] at @s unless block ~ ~ ~ #wasd.tags:weak_stone run kill @s
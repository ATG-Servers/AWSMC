#mc-build WASD content
execute at @p[tag=wasd.prismarine_spear_user] run tp @s ~ ~ ~
scoreboard players reset @s wasd.timer
#mc-build WASD content
tag @s add wasd.pistoned_bounced
effect give @s levitation 1 110 true
particle cloud ~ ~ ~ 0.3 0.1 0.3 0.1 20 normal
schedule function wasd.spear:spears/piston_bounce_reset 2t replace
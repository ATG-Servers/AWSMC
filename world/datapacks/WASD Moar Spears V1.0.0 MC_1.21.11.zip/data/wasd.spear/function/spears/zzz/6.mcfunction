#mc-build WASD content
tag @s add wasd.given_motion
execute store result score @s wasd.rng run random value -200..200
execute store result entity @s Motion[0] float 0.001 run scoreboard players get @s wasd.rng
execute store result score @s wasd.rng run random value -200..200
execute store result entity @s Motion[2] float 0.001 run scoreboard players get @s wasd.rng
execute store result score @s wasd.motion_posy run data get entity @s Motion[1] 1000
execute store result score @s wasd.rng run random value -50..50
execute store result entity @s Motion[1] float 0.001 run scoreboard players operation @s wasd.motion_posy += @s wasd.rng
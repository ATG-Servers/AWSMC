#mc-build WASD content
particle dust_color_transition{from_color:[0.251,0.925,1.000],to_color:[0.278,0.686,1.000],scale:1} ~ ~ ~ 0.3 0.3 0.3 0 20 normal
particle trial_spawner_detection_ominous ~ ~ ~ 0.1 0.1 0.1 0.05 20 normal
summon marker ~ ~ ~ {Tags:["wasd.spear_entity","wasd.lib_entity_tick","wasd.ability","wasd.prismarine_projectile"]}
data modify entity @n[tag=wasd.prismarine_projectile,distance=..0.01] Rotation set from entity @s Rotation
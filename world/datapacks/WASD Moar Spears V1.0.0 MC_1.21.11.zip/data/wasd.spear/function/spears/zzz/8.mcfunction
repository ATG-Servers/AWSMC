#mc-build WASD content
execute store result score @s wasd.rng run random value 1..4
execute as @s[scores={wasd.rng=1..}] run loot spawn ~ ~ ~ kill @s
execute as @s[scores={wasd.rng=2..}] run loot spawn ~ ~ ~ kill @s
execute as @s[scores={wasd.rng=3..}] run loot spawn ~ ~ ~ kill @s
execute as @s[scores={wasd.rng=4..}] run loot spawn ~ ~ ~ kill @s
kill @s
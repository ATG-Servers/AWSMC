#mc-build WASD content
execute as @s[tag=!wasd.just_picked_up] run function wasd.spear:spears/zzz/14
tag @s remove wasd.just_picked_up
tag @s remove wasd.release
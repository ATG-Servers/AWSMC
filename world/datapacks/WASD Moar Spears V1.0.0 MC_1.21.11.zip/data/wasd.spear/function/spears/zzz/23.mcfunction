#mc-build WASD content
tag @s add wasd.hit_by_wind_ram
summon wind_charge ~ ~0.1 ~ {acceleration_power:1d,Motion:[0.0,-1.0,0.0]}
#mc-build WASD content
tag @s remove wasd.using_tire_spear
execute if predicate wasd.spear:strong_tire run item modify entity @s weapon.mainhand wasd.spear:make_tire_weak
execute if predicate wasd.spear:strong_tire_offhand run item modify entity @s weapon.offhand wasd.spear:make_tire_weak
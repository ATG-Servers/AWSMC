#mc-build WASD content
particle minecraft:gust_emitter_small ~ ~ ~ 0 0 0 0 1 normal
playsound minecraft:entity.breeze.idle_air player @a ~ ~ ~ 1 1
playsound minecraft:entity.breeze.idle_air player @a ~ ~ ~ 1 1
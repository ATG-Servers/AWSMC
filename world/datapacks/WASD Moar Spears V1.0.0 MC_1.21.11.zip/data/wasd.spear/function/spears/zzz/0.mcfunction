#mc-build WASD content
summon marker ~ ~ ~ {CustomName:"Deadly Spores",Tags:["wasd.spear_entity","wasd.lib_entity_tick","wasd.ability","wasd.blossom_location"]}
particle spore_blossom_air ~ ~ ~ 0.1 0.1 0.1 0.01 15 normal
particle dust{color:[0.965,0.451,1.000],scale:1} ~0.2 ~ ~ 0 0 0 0 0 normal
particle dust{color:[0.965,0.451,1.000],scale:1} ~-0.2 ~ ~ 0 0 0 0 0 normal
particle dust{color:[0.965,0.451,1.000],scale:1} ~ ~ ~0.2 0 0 0 0 0 normal
particle dust{color:[0.965,0.451,1.000],scale:1} ~ ~ ~-0.2 0 0 0 0 0 normal
particle dust{color:[1.000,0.804,0.161],scale:1} ~ ~ ~ 0 0 0 0 0 normal
scoreboard players reset @s wasd.blossom_timer
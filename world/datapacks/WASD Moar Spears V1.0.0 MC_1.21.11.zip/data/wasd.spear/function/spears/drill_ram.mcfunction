#mc-build WASD content
execute align y rotated ~ 0 run function wasd.spear:spears/zzz/4
execute if score wasd.global_1 wasd.timer matches 1 run function wasd.spear:spears/zzz/5
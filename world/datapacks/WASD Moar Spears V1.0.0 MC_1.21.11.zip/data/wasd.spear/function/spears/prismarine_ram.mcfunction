#mc-build WASD content
scoreboard players add @s wasd.using_prismarine_spear 1
tag @s add wasd.prismarine_spear_user
execute as @s[tag=!wasd.already_summoned_prismarine] if score @s wasd.using_prismarine_spear >= prismarine_spikes_delay wasd.spears_settings run function wasd.spear:spears/summon_prismarine
tag @s remove wasd.already_summoned_prismarine
execute at @e[tag=wasd.prismarine_thorn,distance=..3,tag=!wasd.launched] if score @n[tag=wasd.prismarine_thorn,distance=..0.01] wasd.uuid1 = @s wasd.uuid1 if score @n[tag=wasd.prismarine_thorn,distance=..0.01] wasd.uuid2 = @s wasd.uuid2 if score @n[tag=wasd.prismarine_thorn,distance=..0.01] wasd.uuid3 = @s wasd.uuid3 if score @n[tag=wasd.prismarine_thorn,distance=..0.01] wasd.uuid4 = @s wasd.uuid4 as @e[tag=wasd.prismarine_thorn,distance=..0.01,limit=8] run function wasd.spear:spears/zzz/19
execute if entity @n[tag=wasd.prismarine_thorn,distance=..0.01] run tag @s add wasd.already_summoned_prismarine
tag @s remove wasd.prismarine_spear_user
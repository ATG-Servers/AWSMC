#mc-build WASD content
advancement revoke @s only wasd.spear:eat_spearmint
function wasd.spear:spears/summon_spears
playsound entity.player.burp player @a ~ ~ ~ 1 1
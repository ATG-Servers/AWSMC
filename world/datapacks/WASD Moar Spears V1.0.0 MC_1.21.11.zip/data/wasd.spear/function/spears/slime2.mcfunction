#mc-build WASD content
particle minecraft:sneeze ~ ~ ~ 0.1 0.5 0.1 0.1 30 normal
playsound minecraft:block.slime_block.break player @a ~ ~ ~ 1 1
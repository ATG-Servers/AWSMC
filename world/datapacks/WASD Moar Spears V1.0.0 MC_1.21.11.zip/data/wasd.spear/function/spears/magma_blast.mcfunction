#mc-build WASD content
playsound item.firecharge.use player @a ~ ~ ~ 1 0.8
execute anchored eyes run particle flame ^-0.5 ^-0.2 ^0.5 0.1 0.1 0.1 0.05 20 normal
execute anchored eyes run particle small_flame ^-0.5 ^-0.2 ^0.5 0.1 0.1 0.1 0.1 20 normal
execute positioned ^ ^ ^10 run function wasd.lib:math/store_motion
execute anchored eyes positioned ^-0.5 ^-0.2 ^0.5 run function wasd.spear:spears/magma_shoot_fireball with storage minecraft:wasd.lib_storage
#mc-build WASD content
tag @s add wasd.hit_by_wind
execute on attacker if entity @s[tag=wasd.using_spear] as @n[tag=wasd.hit_by_wind,distance=..0.01] run function wasd.spear:spears/zzz/23
execute as @s[tag=!wasd.hit_by_wind_ram] run function wasd.spear:spears/zzz/24
tag @s remove wasd.hit_by_wind
tag @s remove wasd.hit_by_wind_ram
#mc-build WASD content
effect give @s invisibility 5 0 true
particle minecraft:smoke ~ ~1 ~ 0.2 0.2 0.2 0.05 100 normal
particle minecraft:small_gust ~ ~1 ~ 0.2 0.2 0.2 0.05 100 normal
particle minecraft:poof ~ ~1 ~ 0.2 0.2 0.2 0.05 20 normal
playsound minecraft:entity.breeze.inhale player @a ~ ~ ~ 1 1.5
#mc-build WASD content
execute if entity @s[nbt={HurtTime:10s}] run tag @s add wasd.release
execute anchored eyes positioned ^ ^ ^0.01 run function wasd.spear:spears/zzz/12
execute as @s[tag=wasd.release] run function wasd.spear:spears/zzz/13
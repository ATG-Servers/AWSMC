#mc-build WASD content
execute on attacker if entity @s[tag=wasd.using_spear] as @n run function wasd.spear:spears/zzz/17
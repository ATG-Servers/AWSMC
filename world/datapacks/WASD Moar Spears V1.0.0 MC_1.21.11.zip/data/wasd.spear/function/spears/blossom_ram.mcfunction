#mc-build WASD content
scoreboard players add @s wasd.blossom_timer 1
execute if score @s wasd.blossom_timer >= blossom_interval wasd.spears_settings run function wasd.spear:spears/zzz/0
#mc-build WASD content
execute on attacker unless entity @s[tag=wasd.using_spear] run summon tnt ~ ~ ~ {fuse:0,explosion_power:0.5}
execute on attacker if entity @s[tag=wasd.using_spear] run summon tnt ~ ~ ~ {fuse:0,explosion_power:0.5}
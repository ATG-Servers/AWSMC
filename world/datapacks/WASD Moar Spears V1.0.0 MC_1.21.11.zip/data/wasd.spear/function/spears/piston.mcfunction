#mc-build WASD content
playsound block.piston.extend player @a ~ ~ ~ 1 1
playsound block.piston.extend player @a ~ ~ ~ 1 1
playsound block.piston.extend player @a ~ ~ ~ 1 1
execute on attacker if entity @s[tag=wasd.using_spear] as @n run function wasd.spear:spears/zzz/18
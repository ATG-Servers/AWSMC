#mc-build WASD content
scoreboard players add @s wasd.using_tnt_spear 1
particle smoke ~ ~0.1 ~ 0.3 0.05 0.3 0.05 2 normal
execute if score @s wasd.using_tnt_spear >= tnt_interval wasd.spears_settings run function wasd.spear:spears/zzz/22
#mc-build WASD content
tag @s add wasd.using_tire_spear
execute if predicate wasd.spear:weak_tire run item modify entity @s weapon.mainhand wasd.spear:make_tire_strong
execute if predicate wasd.spear:weak_tire_offhand run item modify entity @s weapon.offhand wasd.spear:make_tire_strong
schedule function wasd.spear:spears/reset_tire_spear 1t append
#mc-build WASD content
execute store result score @s wasd.rng run random value 0..7
execute as @s[scores={wasd.rng=0}] run playsound item.goat_horn.sound.0 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=1}] run playsound item.goat_horn.sound.1 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=2}] run playsound item.goat_horn.sound.2 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=3}] run playsound item.goat_horn.sound.3 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=4}] run playsound item.goat_horn.sound.4 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=5}] run playsound item.goat_horn.sound.5 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=6}] run playsound item.goat_horn.sound.6 player @a ~ ~ ~ 3 1
execute as @s[scores={wasd.rng=7}] run playsound item.goat_horn.sound.7 player @a ~ ~ ~ 3 1
function wasd.lib:math/store_rotation
function wasd.spear:spears/spawn_goat_location with storage minecraft:wasd.lib_storage
execute store result score @s wasd.rng run random value 1..6
execute as @s[scores={wasd.rng=1}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_skeleton
execute as @s[scores={wasd.rng=2}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_parched
execute as @s[scores={wasd.rng=3}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_stray
execute as @s[scores={wasd.rng=4}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_bogged
execute as @s[scores={wasd.rng=5}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_husk
execute as @s[scores={wasd.rng=6}] as @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] run tag @s add wasd.spawn_zombie
tag @e[tag=!wasd.goat_spear_selected,tag=wasd.goat_spawn_location,distance=..4,limit=3] add wasd.goat_spear_selected
#mc-build WASD content
execute as @a[tag=wasd.using_tire_spear] run function wasd.spear:spears/zzz/21
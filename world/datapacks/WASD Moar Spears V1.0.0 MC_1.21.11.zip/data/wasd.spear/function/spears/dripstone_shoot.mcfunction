#mc-build WASD content
playsound minecraft:block.pointed_dripstone.break player @a ~ ~ ~ 1 1
playsound minecraft:block.pointed_dripstone.fall player @a ~ ~ ~ 1 0.5
playsound minecraft:block.pointed_dripstone.land player @a ~ ~ ~ 1 0.5
execute anchored eyes positioned ^-0.5 ^-0.2 ^0.5 run function wasd.spear:spears/zzz/7
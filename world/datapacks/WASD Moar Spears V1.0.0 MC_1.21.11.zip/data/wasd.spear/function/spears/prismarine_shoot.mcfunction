#mc-build WASD content
playsound minecraft:block.beacon.power_select player @a ~ ~ ~ 1 2
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 1 0.2
playsound minecraft:block.amethyst_block.break player @a ~ ~ ~ 1 0.2
execute anchored eyes positioned ^-0.5 ^-0.2 ^0.5 run function wasd.spear:spears/zzz/20
#mc-build WASD content
playsound entity.goat.ram_impact player @a ~ ~ ~ 1 1
playsound entity.goat.ram_impact player @a ~ ~ ~ 1 1
playsound entity.goat.ram_impact player @a ~ ~ ~ 1 1
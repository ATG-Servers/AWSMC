#mc-build WASD content
scoreboard players add @s wasd.temp 1
summon falling_block ~ ~ ~ {Tags:["wasd.falling_dripstone"],Motion:[0.0,1.0,0.0],BlockState:{Name:"minecraft:pointed_dripstone",Properties:{vertical_direction:"down"}},Time:1,DropItem:0b,HurtEntities:1b,FallHurtAmount:1f}
execute as @n[tag=wasd.falling_dripstone,distance=..0.01,tag=!wasd.given_motion] run function wasd.spear:spears/zzz/6
execute unless score @s wasd.temp >= falling_dripstone_to_launch wasd.spears_settings run function wasd.spear:spears/throw_dripstone
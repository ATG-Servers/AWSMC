#mc-build WASD content
playsound minecraft:block.pointed_dripstone.break player @a ~ ~ ~ 1 1
playsound minecraft:block.pointed_dripstone.fall player @a ~ ~ ~ 1 0.5
playsound minecraft:block.pointed_dripstone.land player @a ~ ~ ~ 1 0.5
particle dust_pillar{block_state:"minecraft:dripstone_block"} ~ ~ ~ 1 0.1 1 0.1 300 normal
particle block{block_state:"minecraft:dripstone_block"} ~ ~ ~ 0.3 0.5 0.3 0.05 50 normal
scoreboard players reset @s wasd.temp
function wasd.spear:spears/throw_dripstone
#mc-build WASD content
execute on attacker run tag @s add wasd.used_fishing_spear
execute if entity @s[type=#minecraft:aquatic,type=!elder_guardian] run function wasd.spear:spears/zzz/8
execute as @s[type=elder_guardian] run damage @s 15 spear by @p[tag=wasd.used_fishing_spear]
execute facing entity @p[tag=wasd.used_fishing_spear] feet positioned ^ ^5 ^10 run function wasd.lib:math/apply_motion
execute on attacker run tag @s remove wasd.used_fishing_spear
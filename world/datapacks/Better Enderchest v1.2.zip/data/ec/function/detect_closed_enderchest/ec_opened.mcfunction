scoreboard players set @s ec_open 1

kill @e[type=marker,tag=check_movement]

# execute store result score @s ec_x_snap run data get entity @s Pos[0]
# execute store result score @s ec_y_snap run data get entity @s Pos[1]
# execute store result score @s ec_z_snap run data get entity @s Pos[2]
execute store result storage auction get_money int 1 run scoreboard players get @s ec_chest_id
function ec:ec_function/auction/get_money with storage auction

execute at @s unless entity @e[type=marker,tag=check_movement,distance=..1] run summon marker ~ ~ ~ {Tags:[check_movement]}

function ec:detect_closed_enderchest/check_movement

scoreboard players set @s ec_check_enderchest 0
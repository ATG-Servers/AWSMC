execute as @e[type=marker,tag=check_movement] at @s unless entity @a[scores={ec_open=1},distance=..4] run scoreboard players set @s ec_open 2
# execute as @e[type=marker,tag=check_movement] at @s unless entity @a[scores={ec_open=1},distance=..4] run say away
execute as @e[type=marker,tag=check_movement] at @s if score @s ec_open matches 2 run scoreboard players set @e[scores={ec_open=1},distance=..10] ec_open 0
execute as @e[type=marker,tag=check_movement] at @s if score @s ec_open matches 2 run kill @s

# execute as @e[type=marker,tag=check_movement] at @s if entity @a[scores={ec_open=1},distance=..4] run say still there
execute as @e[type=marker,tag=check_movement] at @s if entity @a[scores={ec_open=1},distance=..4] run schedule function ec:detect_closed_enderchest/check_movement 5t
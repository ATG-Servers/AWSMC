# # # # # v1.1
scoreboard objectives add ec_auction_prize dummy
scoreboard objectives add ec_auction_count dummy
scoreboard objectives add ec_misc dummy
scoreboard objectives add ec_auction_get_item dummy
scoreboard objectives add ec_auction_page dummy
scoreboard objectives add ec_auction_buy_rate dummy
scoreboard objectives add ec_auction_player dummy
scoreboard objectives add ec_auction_stored_money dummy
scoreboard objectives add ec_check_quit custom:leave_game
scoreboard objectives add ec_shop_price dummy
scoreboard objectives add ec_open dummy
scoreboard objectives add kr_ec_cross dummy

# # # # # v1.2
scoreboard objectives add ec_chest_page dummy
scoreboard objectives add ec_chest_page_max dummy
scoreboard objectives add ec_chest_next_page_prize dummy
scoreboard objectives add ec_shulker_load_page dummy
scoreboard objectives add ec_has_died deathCount

execute unless score @s ec_chest_next_page_prize matches 1.. run scoreboard players operation @s ec_chest_next_page_prize += start_price_chest ec_shop_price
function ec:reset/prices

function ec:ec_function/back_to_main_page
execute as @a store result storage playername current int 1 run scoreboard players get current ec_chest_id
execute as @a run function ec:store_player_name with storage playername
execute as @a run scoreboard players operation @s ec_chest_id = current ec_chest_id

tellraw @s {"text": "Better Enderchest updated to version 1.1!","color": "dark_purple"}
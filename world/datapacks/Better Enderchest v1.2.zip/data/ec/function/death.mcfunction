execute as @a[scores={ec_death=1..}] run function ec:level/mortal/add_mortal_xp


execute as @a[scores={ec_death=1..}] run scoreboard players remove @s ec_mining_speed 1
execute as @a[scores={ec_death=1..}] run function ec:level/mining/mining_attribut

execute as @a[scores={ec_death=1..}] run scoreboard players remove @s ec_max_fallen_blocks 1
execute as @a[scores={ec_death=1..}] run function ec:level/acrobatics/acrobatics_attribut

execute as @a[scores={ec_death=1..}] run scoreboard players remove @s ec_attack_speed 1
execute as @a[scores={ec_death=1..}] run function ec:level/combat/combat_attribut

execute as @a[scores={ec_death=1..}] run scoreboard players remove @s ec_fishing_bonus 1
execute as @a[scores={ec_death=1..}] run function ec:level/fishing/fishing_attribut

execute as @a[scores={ec_death=1..}] run scoreboard players remove @s ec_mortal_bonus 1
execute as @a[scores={ec_death=1..}] run function ec:level/mortal/mortal_attribut

execute as @a[scores={ec_death=1..},tag=effect_vision] run effect give @s night_vision infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_luck] run effect give @s luck infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_conduit] run effect give @s conduit_power infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_saturation] run effect give @s saturation infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_leaping] run effect give @s jump_boost infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_speed] run effect give @s speed infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_haste] run effect give @s haste infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_fire] run effect give @s fire_resistance infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_resistance] run effect give @s resistance infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_strength] run effect give @s strength infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_health] run effect give @s health_boost infinite 0 true
execute as @a[scores={ec_death=1..},tag=effect_regeneration] run effect give @s regeneration infinite 0 true

execute as @a[scores={ec_death=1..}] run scoreboard players operation death ec_money = @s ec_money
execute as @a[scores={ec_death=1..}] run scoreboard players operation death ec_money /= Iron ec_sell_values
execute as @a[scores={ec_death=1..}] run scoreboard players operation death ec_money *= 9 ec_money
execute as @a[scores={ec_death=1..}] run scoreboard players operation @s ec_money -= death ec_money
execute as @a[scores={ec_death=1..}] run tellraw @a ["",{"selector":"@s"}," died and lost ",{"score":{"name":"death","objective":"ec_money"},"color":"yellow"},{"text":"€","color":"yellow"}]
execute as @a[scores={ec_death=1..}] run tellraw @s "Prevent this by depositing your money in the bank!"
execute as @a[scores={ec_death=1..}] unless score grave ec_layout matches 1 run tellraw @s "The graveyard menu is enabled in your world. You can get back your lost items there for a small fee. ;)"

execute as @a[scores={ec_death=1..}] unless score grave ec_layout matches 1 store result storage graveyard current_player int 1 run scoreboard players get @s ec_chest_id
execute as @a[scores={ec_death=1..}] unless score grave ec_layout matches 1 run function ec:ec_function/graveyard/save_items with storage graveyard
execute as @a[scores={ec_death=1..}] unless score grave ec_layout matches 1 run clear @s

execute as @a[scores={ec_death=1..}] run effect give @s blindness 3 0 true
execute as @a[scores={ec_death=1..}] run effect give @s slowness 3 100 true
execute as @a[scores={ec_death=1..}] run title @s title {text:"You died!",color:red}
execute as @a[scores={ec_death=1..}] unless score grave ec_layout matches 1 unless entity @s[tag=no_enderchest] run title @s subtitle {text:"Get back your items in the Graveyard Menu",color:white}

execute as @a[scores={ec_death=1..}] run scoreboard players set @s ec_has_died 1

execute as @a[scores={ec_death=1..}] run scoreboard players set @s ec_death 0
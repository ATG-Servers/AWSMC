clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Actionbar: Money"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Money"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Actionbar: Money"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Money"} }}}]

execute at @s run playsound ui.button.click master @s ~ ~ ~


scoreboard players set @s ec_actionbar 1

execute as @s run function ec:ec_menus/bank_page
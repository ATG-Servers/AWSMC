# opens the bank
scoreboard players set @s ec_menu 6

clear @s diamond[custom_name= {"italic":false,"text":"Bank"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bank"} }}}]
execute at @s run playsound minecraft:ui.button.click master @s ~ ~ ~
execute as @s run function ec:ec_menus/bank_page
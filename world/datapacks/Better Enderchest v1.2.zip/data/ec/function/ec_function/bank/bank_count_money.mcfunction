clear @s diamond[item_name= "count" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:item_name": "count" }}}]

execute as @s run function ec:ec_menus/bank_page
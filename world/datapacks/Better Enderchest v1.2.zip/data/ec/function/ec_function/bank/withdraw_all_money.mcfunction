clear @s copper_ingot[custom_name= {"italic":false,"text":"Withdraw all Money"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:copper_ingot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Withdraw all Money"} }}}]
execute at @s if score @s ec_bank matches 1.. run playsound minecraft:block.composter.fill master @s ~ ~ ~
execute at @s unless score @s ec_bank matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~
scoreboard players operation @s ec_money += @s ec_bank
scoreboard players set @s ec_bank 0

function ec:ec_menus/bank_page
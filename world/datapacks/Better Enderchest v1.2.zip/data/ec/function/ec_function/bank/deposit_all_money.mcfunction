# adds all your money to the bank
clear @s netherite_ingot[custom_name= {"italic":false,"text":"Deposit all Money"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Deposit all Money"} }}}]
execute at @s if score @s ec_money matches 1.. run playsound minecraft:block.composter.empty master @s ~ ~ ~
execute at @s unless score @s ec_money matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~
scoreboard players operation @s ec_bank += @s ec_money
scoreboard players set @s ec_money 0

function ec:ec_menus/bank_page
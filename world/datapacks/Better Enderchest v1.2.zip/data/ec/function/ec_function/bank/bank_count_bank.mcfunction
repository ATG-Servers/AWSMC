
clear @s gold_ingot[item_name= "count" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gold_ingot",count:1,components:{"minecraft:item_name": "count" }}}]


execute as @s run function ec:ec_menus/bank_page
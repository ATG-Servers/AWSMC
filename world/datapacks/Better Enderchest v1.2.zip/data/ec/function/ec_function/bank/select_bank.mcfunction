clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Actionbar: Bank"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Bank"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Actionbar: Bank"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Bank"} }}}]

execute at @s run playsound ui.button.click master @s ~ ~ ~


scoreboard players set @s ec_actionbar 2

execute as @s run function ec:ec_menus/bank_page
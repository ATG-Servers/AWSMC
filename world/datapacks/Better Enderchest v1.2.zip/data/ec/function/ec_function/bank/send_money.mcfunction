clear @s redstone[custom_name= {"italic":false,"text":"Send Money [Left Click]"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:redstone",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Send Money [Left Click]"} }}}]
execute at @s if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper"}]}] run playsound ui.button.click master @s ~ ~ ~
execute at @s if score @s ec_send_money matches 1.. run playsound ui.button.click master @s ~ ~ ~
execute at @s unless entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper"}]}] run playsound entity.villager.no master @s ~ ~ ~
execute at @s unless score @s ec_send_money matches 1.. run playsound entity.villager.no master @s ~ ~ ~
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "1" }}]}] run scoreboard players operation mailbox_1 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "1" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "2" }}]}] run scoreboard players operation mailbox_2 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "2" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "3" }}]}] run scoreboard players operation mailbox_3 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "3" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "4" }}]}] run scoreboard players operation mailbox_4 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "4" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "5" }}]}] run scoreboard players operation mailbox_5 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "5" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "6" }}]}] run scoreboard players operation mailbox_6 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "6" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "7" }}]}] run scoreboard players operation mailbox_7 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "7" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "8" }}]}] run scoreboard players operation mailbox_8 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "8" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "9" }}]}] run scoreboard players operation mailbox_9 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "9" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "10" }}]}] run scoreboard players operation mailbox_10 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "10" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "11" }}]}] run scoreboard players operation mailbox_11 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "11" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "12" }}]}] run scoreboard players operation mailbox_12 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "12" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "13" }}]}] run scoreboard players operation mailbox_13 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "13" }}]}] run scoreboard players set @s ec_send_money 0
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "14" }}]}] run scoreboard players operation mailbox_14 ec_mail_money += @s ec_send_money
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "14" }}]}] run scoreboard players set @s ec_send_money 0
execute unless entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper"}]}] run tellraw @s {"text": "Click again with address!","color": "red"}

execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "1" }}]}] run advancement grant @a[scores={ec_mailbox=1},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "2" }}]}] run advancement grant @a[scores={ec_mailbox=2},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "3" }}]}] run advancement grant @a[scores={ec_mailbox=3},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "4" }}]}] run advancement grant @a[scores={ec_mailbox=4},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "5" }}]}] run advancement grant @a[scores={ec_mailbox=5},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "6" }}]}] run advancement grant @a[scores={ec_mailbox=6},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "7" }}]}] run advancement grant @a[scores={ec_mailbox=7},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "8" }}]}] run advancement grant @a[scores={ec_mailbox=8},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "9" }}]}] run advancement grant @a[scores={ec_mailbox=9},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "10" }}]}] run advancement grant @a[scores={ec_mailbox=10},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "11" }}]}] run advancement grant @a[scores={ec_mailbox=11},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "12" }}]}] run advancement grant @a[scores={ec_mailbox=12},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "13" }}]}] run advancement grant @a[scores={ec_mailbox=13},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper",components:{"minecraft:item_name": "14" }}]}] run advancement grant @a[scores={ec_mailbox=14},tag=!no_mail_announcement] only ec:announce_mail
execute if entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:paper"}]}] run schedule function ec:ec_function/post/clear_announcement 5t replace

item replace entity @s player.cursor from entity @s enderchest.22

execute as @s run function ec:ec_menus/bank_page
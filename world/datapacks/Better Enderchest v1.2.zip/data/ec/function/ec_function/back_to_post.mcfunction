execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b, Tags:[restore_item]}

item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.11
item replace entity @n[tag=restore_item,type=chest_minecart] container.1 from entity @s enderchest.12
item replace entity @n[tag=restore_item,type=chest_minecart] container.2 from entity @s enderchest.13
item replace entity @n[tag=restore_item,type=chest_minecart] container.3 from entity @s enderchest.14
item replace entity @n[tag=restore_item,type=chest_minecart] container.4 from entity @s enderchest.15

execute at @s run playsound ui.button.click master @s ~ ~ ~

kill @n[tag=restore_item,type=chest_minecart]

clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]

execute if score @s ec_menu matches 8 run data remove storage mailboxes mailbox_1
execute if score @s ec_menu matches 9 run data remove storage mailboxes mailbox_2
execute if score @s ec_menu matches 10 run data remove storage mailboxes mailbox_3
execute if score @s ec_menu matches 11 run data remove storage mailboxes mailbox_4
execute if score @s ec_menu matches 12 run data remove storage mailboxes mailbox_5
execute if score @s ec_menu matches 13 run data remove storage mailboxes mailbox_6
execute if score @s ec_menu matches 14 run data remove storage mailboxes mailbox_7
execute if score @s ec_menu matches 15 run data remove storage mailboxes mailbox_8
execute if score @s ec_menu matches 16 run data remove storage mailboxes mailbox_9
execute if score @s ec_menu matches 17 run data remove storage mailboxes mailbox_10
execute if score @s ec_menu matches 18 run data remove storage mailboxes mailbox_11
execute if score @s ec_menu matches 19 run data remove storage mailboxes mailbox_12
execute if score @s ec_menu matches 20 run data remove storage mailboxes mailbox_13
execute if score @s ec_menu matches 21 run data remove storage mailboxes mailbox_14

scoreboard players set @s ec_menu 7
execute as @s run function ec:ec_menus/post_page
scoreboard players set @s ec_menu 40

item replace entity @s enderchest.17 from entity @s player.cursor
item replace entity @s player.cursor with air
kill @e[type=item,nbt={Item:{id:"minecraft:shulker_box"}}]
clear @s shulker_box[custom_data={better_ec:true}]

tag @a remove shulkerplayer
schedule clear ec:ec_function/shulker/transfer_items_5t
function ec:ec_function/shulker/safe_changes
function ec:ec_menus/shulker_page
execute if items entity @s enderchest.17 #shulker_boxes run scoreboard players set @s ec_menu 39
clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Place Shulker Here"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place Shulker Here"} }}}]
execute unless items entity @s enderchest.17 #shulker_boxes run item replace entity @s player.cursor from entity @s enderchest.17

execute unless items entity @s enderchest.17 #shulker_boxes run function ec:ec_menus/shulker_page

execute if items entity @s enderchest.17 #shulker_boxes run function ec:ec_function/shulker/transfer_items
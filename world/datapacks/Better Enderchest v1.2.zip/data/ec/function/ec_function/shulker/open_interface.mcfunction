scoreboard players set @s ec_menu 38
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s lime_shulker_box[custom_name= {"italic":false,"text":"Shulker Box Loader"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_shulker_box",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Shulker Box Loader"} }}}]

function ec:ec_menus/shulker_page
$execute at @s run data modify entity @n[type=chest_minecart,tag=shulker_load] Items set from storage enderchest ec.$(current_player).$(current_page)
execute at @s run item replace entity @s enderchest.0 from entity @n[type=chest_minecart,tag=shulker_load] container.0
execute at @s run item replace entity @s enderchest.1 from entity @n[type=chest_minecart,tag=shulker_load] container.1
execute at @s run item replace entity @s enderchest.2 from entity @n[type=chest_minecart,tag=shulker_load] container.2
execute at @s run item replace entity @s enderchest.3 from entity @n[type=chest_minecart,tag=shulker_load] container.3
execute at @s run item replace entity @s enderchest.4 from entity @n[type=chest_minecart,tag=shulker_load] container.4
execute at @s run item replace entity @s enderchest.5 from entity @n[type=chest_minecart,tag=shulker_load] container.5
execute at @s run item replace entity @s enderchest.6 from entity @n[type=chest_minecart,tag=shulker_load] container.6
execute at @s run item replace entity @s enderchest.7 from entity @n[type=chest_minecart,tag=shulker_load] container.7
execute at @s run item replace entity @s enderchest.9 from entity @n[type=chest_minecart,tag=shulker_load] container.9
execute at @s run item replace entity @s enderchest.10 from entity @n[type=chest_minecart,tag=shulker_load] container.10
execute at @s run item replace entity @s enderchest.11 from entity @n[type=chest_minecart,tag=shulker_load] container.11
execute at @s run item replace entity @s enderchest.12 from entity @n[type=chest_minecart,tag=shulker_load] container.12
execute at @s run item replace entity @s enderchest.13 from entity @n[type=chest_minecart,tag=shulker_load] container.13
execute at @s run item replace entity @s enderchest.14 from entity @n[type=chest_minecart,tag=shulker_load] container.14
execute at @s run item replace entity @s enderchest.15 from entity @n[type=chest_minecart,tag=shulker_load] container.15
execute at @s run item replace entity @s enderchest.16 from entity @n[type=chest_minecart,tag=shulker_load] container.16
execute at @s run item replace entity @s enderchest.18 from entity @n[type=chest_minecart,tag=shulker_load] container.18
execute at @s run item replace entity @s enderchest.19 from entity @n[type=chest_minecart,tag=shulker_load] container.19
execute at @s run item replace entity @s enderchest.20 from entity @n[type=chest_minecart,tag=shulker_load] container.20
execute at @s run item replace entity @s enderchest.21 from entity @n[type=chest_minecart,tag=shulker_load] container.21
execute at @s run item replace entity @s enderchest.22 from entity @n[type=chest_minecart,tag=shulker_load] container.22
execute at @s run item replace entity @s enderchest.23 from entity @n[type=chest_minecart,tag=shulker_load] container.23
execute at @s run item replace entity @s enderchest.24 from entity @n[type=chest_minecart,tag=shulker_load] container.24
execute at @s run item replace entity @s enderchest.25 from entity @n[type=chest_minecart,tag=shulker_load] container.25

execute at @s run data merge entity @n[type=chest_minecart,tag=shulker_load] {Items:[{}]}
execute at @s run kill @n[type=chest_minecart,tag=shulker_load]
data remove storage shulker current_page
data remove storage shulker current_player
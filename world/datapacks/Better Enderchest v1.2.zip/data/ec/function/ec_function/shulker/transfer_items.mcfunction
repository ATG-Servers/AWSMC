tag @s add shulkerplayer
forceload add 0 0 0 0

execute at @s run setblock ~ 300 ~ dispenser
execute at @s run data modify block ~ 300 ~ Items[{Slot:4b}].id set from entity @s EnderItems[{Slot:17b}].id
execute at @s run data modify block ~ 300 ~ Items[{Slot:4b}].components set from entity @s EnderItems[{Slot:17b}].components
execute at @s run setblock ~ 299 ~ redstone_block
execute as @s at @s run schedule function ec:ec_function/shulker/transfer_items_5t 5t append
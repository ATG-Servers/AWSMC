execute unless data entity @n[type=chest_minecart,tag=shulker] Items[{}] run item replace entity @p[tag=shulkerplayer] enderchest.8 with ender_chest[custom_name= {"italic":false,"text":"Load Enderchest Page"} ,custom_data={"better_ec":1b}]

execute unless data entity @n[type=chest_minecart,tag=shulker] Items[{}] run tag @p[tag=shulkerplayer] add empty_shulker

item replace entity @p[tag=shulkerplayer] enderchest.0 from entity @n[type=chest_minecart,tag=shulker] container.0
item replace entity @p[tag=shulkerplayer] enderchest.1 from entity @n[type=chest_minecart,tag=shulker] container.1
item replace entity @p[tag=shulkerplayer] enderchest.2 from entity @n[type=chest_minecart,tag=shulker] container.2
item replace entity @p[tag=shulkerplayer] enderchest.3 from entity @n[type=chest_minecart,tag=shulker] container.3
item replace entity @p[tag=shulkerplayer] enderchest.4 from entity @n[type=chest_minecart,tag=shulker] container.4
item replace entity @p[tag=shulkerplayer] enderchest.5 from entity @n[type=chest_minecart,tag=shulker] container.5
item replace entity @p[tag=shulkerplayer] enderchest.6 from entity @n[type=chest_minecart,tag=shulker] container.6
item replace entity @p[tag=shulkerplayer] enderchest.7 from entity @n[type=chest_minecart,tag=shulker] container.7
# item replace entity @p[tag=shulkerplayer] enderchest.8 from entity @n[type=chest_minecart,tag=shulker] container.8
item replace entity @p[tag=shulkerplayer] enderchest.9 from entity @n[type=chest_minecart,tag=shulker] container.9
item replace entity @p[tag=shulkerplayer] enderchest.10 from entity @n[type=chest_minecart,tag=shulker] container.10
item replace entity @p[tag=shulkerplayer] enderchest.11 from entity @n[type=chest_minecart,tag=shulker] container.11
item replace entity @p[tag=shulkerplayer] enderchest.12 from entity @n[type=chest_minecart,tag=shulker] container.12
item replace entity @p[tag=shulkerplayer] enderchest.13 from entity @n[type=chest_minecart,tag=shulker] container.13
item replace entity @p[tag=shulkerplayer] enderchest.14 from entity @n[type=chest_minecart,tag=shulker] container.14
item replace entity @p[tag=shulkerplayer] enderchest.15 from entity @n[type=chest_minecart,tag=shulker] container.15
item replace entity @p[tag=shulkerplayer] enderchest.16 from entity @n[type=chest_minecart,tag=shulker] container.16
item replace entity @p[tag=shulkerplayer] enderchest.18 from entity @n[type=chest_minecart,tag=shulker] container.18
item replace entity @p[tag=shulkerplayer] enderchest.19 from entity @n[type=chest_minecart,tag=shulker] container.19
item replace entity @p[tag=shulkerplayer] enderchest.20 from entity @n[type=chest_minecart,tag=shulker] container.20
item replace entity @p[tag=shulkerplayer] enderchest.21 from entity @n[type=chest_minecart,tag=shulker] container.21
item replace entity @p[tag=shulkerplayer] enderchest.22 from entity @n[type=chest_minecart,tag=shulker] container.22
item replace entity @p[tag=shulkerplayer] enderchest.23 from entity @n[type=chest_minecart,tag=shulker] container.23
item replace entity @p[tag=shulkerplayer] enderchest.24 from entity @n[type=chest_minecart,tag=shulker] container.24
item replace entity @p[tag=shulkerplayer] enderchest.25 from entity @n[type=chest_minecart,tag=shulker] container.25
execute at @p[tag=shulkerplayer] run summon chest_minecart ~ ~1 ~ {NoGravity:1b,Tags:["restore_item"]}

item modify entity @p[tag=shulkerplayer] enderchest.17 {function:"set_components",components:{container:[]}}

execute at @p[tag=shulkerplayer] run item replace entity @n[type=chest_minecart,tag=restore_item] container.0 from entity @n[type=chest_minecart,tag=shulker] container.17
execute at @p[tag=shulkerplayer] run item replace entity @n[type=chest_minecart,tag=restore_item] container.1 from entity @n[type=chest_minecart,tag=shulker] container.26
tag @a remove shulkerplayer
data merge entity @n[type=chest_minecart,tag=shulker] {Items:[{}]}
kill @n[tag=shulker,type=chest_minecart]
kill @n[tag=restore_item,type=chest_minecart]
$data remove storage enderchest ec.$(current_player).$(current_page)
data remove storage shulker current_page
data remove storage shulker current_player
execute at @p[tag=shulkerplayer] run summon chest_minecart ~ ~3 ~ {NoGravity:1b,Tags:["shulker"]}
execute at @p[tag=shulkerplayer] run data modify entity @n[tag=shulker] Items set from block ~ 300 ~-1 Items
execute at @p[tag=shulkerplayer] run setblock ~ 300 ~ air
execute at @p[tag=shulkerplayer] run setblock ~ 299 ~ air
execute at @p[tag=shulkerplayer] run setblock ~ 300 ~-1 air
execute at @p[tag=shulkerplayer] run playsound block.shulker_box.open master @p[tag=shulkerplayer] ~ ~ ~

# say hi

schedule function ec:ec_function/shulker/import_items 1t replace


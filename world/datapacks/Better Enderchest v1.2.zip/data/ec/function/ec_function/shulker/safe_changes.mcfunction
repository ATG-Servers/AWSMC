tag @s add shulkerplayer
forceload add 0 0 0 0
execute at @p[tag=shulkerplayer] run summon chest_minecart ~ ~3 ~ {NoGravity:1b,Tags:["shulker"]}
data modify entity @n[tag=shulker,type=chest_minecart] Items set from entity @s EnderItems
# data modify entity @n[type=chest_minecart,tag=shulker] Items[{Slot:17b}].id set value  air  
# data modify entity @n[type=chest_minecart,tag=shulker] Items[{Slot:26b}].id set value  air
item replace entity @n[type=chest_minecart,tag=shulker] container.8 with air
item replace entity @n[type=chest_minecart,tag=shulker] container.17 with air
item replace entity @n[type=chest_minecart,tag=shulker] container.26 with air
summon marker ~ 300 ~ {Tags:["shulker"]}

setblock ~ 300 ~ shulker_box
data modify block ~ 300 ~ Items set from entity @n[type=chest_minecart,tag=shulker] Items
setblock ~ 300 ~ air destroy

execute as @n[tag=shulker,type=marker] at @s run data modify entity @n[type=chest_minecart,tag=shulker] Items[{Slot:0b}].id set from entity @n[type=item,nbt={Item:{id:"minecraft:shulker_box"}}] Item.id
execute as @n[tag=shulker,type=marker] at @s run data modify entity @n[type=chest_minecart,tag=shulker] Items[{Slot:0b}].components set from entity @n[type=item,nbt={Item:{id:"minecraft:shulker_box"}}] Item.components
execute as @n[tag=shulker,type=marker] at @s run kill @n[type=item,nbt={Item:{id:"minecraft:shulker_box"}}]
kill @e[type=marker,tag=shulker]

data modify entity @n[type=chest_minecart,tag=shulker,limit=1] Items[{Slot:0b}].id set from entity @s EnderItems[{Slot:17b}].id 
item replace entity @s enderchest.17 from entity @n[type=chest_minecart,tag=shulker] container.0
data merge entity @n[tag=shulker,type=chest_minecart] {Items:[{}]}
kill @n[tag=shulker,type=chest_minecart]
item replace entity @s player.cursor from entity @s enderchest.17
item replace entity @s enderchest.17 with air


execute if score @s ec_shulker_load_page matches 1..50 store result storage shulker current_page int 1 run scoreboard players get @s ec_shulker_load_page
execute if score @s ec_shulker_load_page matches 1..50 store result storage shulker current_player int 1 run scoreboard players get @s ec_chest_id
execute if score @s ec_shulker_load_page matches 1..50 run function ec:ec_function/shulker/remove_enderchest with storage shulker

tag @s remove empty_shulker
scoreboard players reset @s ec_shulker_load_page
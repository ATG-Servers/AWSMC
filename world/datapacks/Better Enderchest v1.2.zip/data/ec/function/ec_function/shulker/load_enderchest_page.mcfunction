clear @s ender_chest[custom_name= {"italic":false,"text":"Load Enderchest Page"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Load Enderchest Page"} }}}]

execute unless score @s ec_shulker_load_page matches ..99 at @s run summon chest_minecart ~ ~2 ~ {Tags:[shulker_restore],NoGravity:1b}
execute unless score @s ec_shulker_load_page matches ..99 at @s run data modify entity @n[type=chest_minecart,tag=shulker_restore] Items set from entity @s EnderItems
execute unless score @s ec_shulker_load_page matches ..99 at @s run item replace entity @n[type=chest_minecart,tag=shulker_restore] container.8 with air
execute unless score @s ec_shulker_load_page matches ..99 at @s run item replace entity @n[type=chest_minecart,tag=shulker_restore] container.17 with air
execute unless score @s ec_shulker_load_page matches ..99 at @s run item replace entity @n[type=chest_minecart,tag=shulker_restore] container.26 with air
execute unless score @s ec_shulker_load_page matches ..99 at @s run kill @n[type=chest_minecart,tag=shulker_restore]

execute if score @s ec_shulker_load_page matches 100 run scoreboard players set @s ec_shulker_load_page 0
execute unless score @s ec_shulker_load_page matches -1.. run scoreboard players set @s ec_shulker_load_page 100
scoreboard players add @s ec_shulker_load_page 1
execute if score @s ec_shulker_load_page > @s ec_chest_page_max run scoreboard players set @s ec_shulker_load_page 100


execute at @s run summon chest_minecart ~ ~2 ~ {Tags:[shulker_load],NoGravity:1b}

execute store result storage shulker current_page int 1 run scoreboard players get @s ec_shulker_load_page
execute store result storage shulker current_player int 1 run scoreboard players get @s ec_chest_id
function ec:ec_function/shulker/import_page with storage shulker



item replace entity @s enderchest.8 with ender_chest[custom_name= {"italic":false,"text":"Load Enderchest Page"} ,custom_data={"better_ec":1b}]
execute unless score @s ec_shulker_load_page matches 100 run item modify entity @s enderchest.8 {function:"set_lore",mode:"replace_all",entity:this,lore:[[{text:"Page: ",italic:false,color:"gray"},{score:{name:"@s",objective:"ec_shulker_load_page"},color:gray,italic:false}]]}
execute if score @s ec_shulker_load_page matches 100 run item modify entity @s enderchest.8 {function:"set_lore",mode:"replace_all",entity:this,lore:[[{text:"No page selected!",italic:false,color:"red"}]]}
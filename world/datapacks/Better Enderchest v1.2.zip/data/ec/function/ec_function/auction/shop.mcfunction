clear @s emerald[custom_name= {"italic":false,"text":"Shop"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Shop"} }}}]
execute at @s run playsound ui.button.click master @s
scoreboard players set @s ec_menu 1000
scoreboard players set @s ec_auction_page 0


function ec:ec_menus/auction/shop_page
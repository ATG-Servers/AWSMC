execute at @s run playsound ui.button.click master @s ~ ~ ~

execute if entity @s[nbt={Inventory:[{Slot:0b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run scoreboard players set @s ec_menu 1000
execute if entity @s[nbt={Inventory:[{Slot:0b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.0 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:1b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 1.. run scoreboard players set @s ec_menu 1001
execute if entity @s[nbt={Inventory:[{Slot:1b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.1 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:2b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 2.. run scoreboard players set @s ec_menu 1002
execute if entity @s[nbt={Inventory:[{Slot:2b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.2 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:3b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 3.. run scoreboard players set @s ec_menu 1003
execute if entity @s[nbt={Inventory:[{Slot:3b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.3 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:4b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 4.. run scoreboard players set @s ec_menu 1004
execute if entity @s[nbt={Inventory:[{Slot:4b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.4 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:5b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 5.. run scoreboard players set @s ec_menu 1005
execute if entity @s[nbt={Inventory:[{Slot:5b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.5 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:6b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 6.. run scoreboard players set @s ec_menu 1006
execute if entity @s[nbt={Inventory:[{Slot:6b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.6 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:7b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 7.. run scoreboard players set @s ec_menu 1007
execute if entity @s[nbt={Inventory:[{Slot:7b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.7 from entity @s enderchest.19
execute if entity @s[nbt={Inventory:[{Slot:8b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] if score page ec_misc matches 8.. run scoreboard players set @s ec_menu 1008
execute if entity @s[nbt={Inventory:[{Slot:8b,id:"minecraft:paper",components:{"minecraft:item_name": "page" }}]}] run item replace entity @s hotbar.8 from entity @s enderchest.19


clear @s paper[item_name= "page" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:paper",count:1,components:{"minecraft:item_name": "page" }}}]

function ec:ec_menus/auction/shop_page
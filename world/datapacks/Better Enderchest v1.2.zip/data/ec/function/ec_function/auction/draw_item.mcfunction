$data modify entity @n[type=chest_minecart,tag=draw_menu] Items[{Slot:$(draw)b}].id set from storage auction shop.$(draw_page).$(draw).id
$data modify entity @n[type=chest_minecart,tag=draw_menu] Items[{Slot:$(draw)b}].components set from storage auction shop.$(draw_page).$(draw).components
# $say $(draw)



$data modify storage auction draw_sync set from storage auction shop.$(draw_page).$(draw).ec_id

function ec:ec_function/auction/sync_id with storage auction
execute if score @s ec_auction_buy_rate matches 64 unless score count ec_misc matches 64.. run scoreboard players operation prize ec_misc *= count ec_misc 
execute if score @s ec_auction_buy_rate matches 64 if score count ec_misc matches 64.. run scoreboard players operation prize ec_misc *= @s ec_auction_buy_rate 

$item modify entity @n[type=chest_minecart,tag=draw_menu] container.$(draw) ec:auction/item
$item modify entity @n[type=chest_minecart,tag=draw_menu] container.$(draw) {function:"set_lore",mode:"append",entity:"this",lore:[[{"text": "Seller: ","italic": false,"color": "dark_green"},{"nbt": "players.$(player)","storage": "playername","interpret": true,"italic":false,"color": "green"}]]}
$item modify entity @n[type=chest_minecart,tag=draw_menu] container.$(draw) {function:set_components,components:{custom_data:{better_ec:1b}}}
# $item modify entity @n[type=chest_minecart,tag=draw_menu] container.$(draw) {function:"set_lore",mode:"append",entity:"this",lore:[{"nbt": "players.$(player)","storage": "playername","interpret": true,"italic":false,"color": "green"}]}
$data modify storage auction shop.$(current_page).$(current_id_on_page).id set from storage auction sell.id
$data modify storage auction shop_id.$(current_id).id set from storage auction sell.id
$data modify storage auction shop.$(current_page).$(current_id_on_page).components set from storage auction sell.components
$data modify storage auction shop_id.$(current_id).components set from storage auction sell.components
$execute store result storage auction shop.$(current_page).$(current_id_on_page).ec_id int 1 run scoreboard players get current ec_misc
$execute store result storage auction shop_id.$(current_id).ec_id int 1 run scoreboard players get current ec_misc

$execute store result score $(current_id) ec_auction_prize run scoreboard players get @s ec_auction_prize
$execute store result score $(current_id) ec_auction_count run scoreboard players get @s ec_auction_count
$execute store result score $(current_id) ec_auction_player run scoreboard players get @s ec_chest_id

execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[check_max_stack]}
data modify entity @n[type=chest_minecart,tag=check_max_stack] Items[{Slot:0b}].id set from storage auction sell.id
item modify entity @n[type=chest_minecart,tag=check_max_stack] container.0 {function:set_count,count:99}
$execute store result score max_$(current_id) ec_auction_count run data get entity @n[type=chest_minecart,tag=check_max_stack] Items[{Slot:0b}].count
data merge entity @n[type=chest_minecart,tag=check_max_stack] {Items:[]}
kill @n[type=chest_minecart,tag=check_max_stack]

$execute if data storage auction sell.components."minecraft:max_stack_size" store result score max_$(current_id) ec_auction_count run data get storage auction sell.components."minecraft:max_stack_size"

execute store result storage playername current int 1 run scoreboard players get @s ec_chest_id
execute run function ec:store_player_name with storage playername

scoreboard players add current ec_misc 1
scoreboard players add current_on_page ec_misc 1

execute as @a[scores={ec_menu=1000..}] run function ec:ec_menus/auction/shop_page
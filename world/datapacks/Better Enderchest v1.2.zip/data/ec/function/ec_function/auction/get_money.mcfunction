$execute if score $(get_money) ec_auction_stored_money matches 1.. run tellraw @s [{"text": "Somebody bought an item you sold! You recieve: ","color": "white"},{"score": {"objective": "ec_auction_stored_money","name": "$(get_money)"},"color":"yellow"},{"text":"€","color":"gold"}]
$scoreboard players operation @s ec_money += $(get_money) ec_auction_stored_money
$scoreboard players set $(get_money) ec_auction_stored_money 0

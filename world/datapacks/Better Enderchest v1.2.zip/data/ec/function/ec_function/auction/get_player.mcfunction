$execute store result storage auction player int 1 run scoreboard players get $(draw_id) ec_auction_player



function ec:ec_function/auction/draw_item with storage auction
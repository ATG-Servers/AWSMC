$execute store result storage auction draw_id int 1 run data get storage auction shop.$(draw_page).$(draw).ec_id



function ec:ec_function/auction/get_player with storage auction
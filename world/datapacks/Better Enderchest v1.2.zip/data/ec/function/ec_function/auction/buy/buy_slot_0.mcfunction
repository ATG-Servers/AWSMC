clear @s *[custom_data={better_ec:1b}]
kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{better_ec:1b}}}}]

execute store result storage auction buy_page int 1 run scoreboard players get @s ec_auction_page
data modify storage auction buy_slot set value 0

function ec:ec_function/auction/start_get_item with storage auction

function ec:ec_menus/auction/shop_page
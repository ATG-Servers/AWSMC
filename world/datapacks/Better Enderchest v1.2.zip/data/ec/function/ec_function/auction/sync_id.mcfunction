$scoreboard players operation prize ec_misc = $(draw_sync) ec_auction_prize
$scoreboard players operation count ec_misc = $(draw_sync) ec_auction_count
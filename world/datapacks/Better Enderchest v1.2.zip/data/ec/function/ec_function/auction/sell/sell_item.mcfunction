clear @s nether_star[custom_name= {"italic":false,"text":"Sell Item"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sell Item"} }}}]

execute if score @s ec_menu matches 56 at @s if score @s ec_money >= fee ec_misc run playsound entity.villager.trade master @s
execute unless score @s ec_menu matches 56 at @s run playsound entity.villager.no master @s

execute unless score @s ec_money >= fee ec_misc run tellraw @s {"text": "Not enough money to pay the fee!","color": "red"}
execute if score @s ec_menu matches 56 if score @s ec_money >= fee ec_misc run function ec:ec_function/auction/start_add_item
execute if score @s ec_menu matches 56 if score @s ec_money >= fee ec_misc run scoreboard players set auction_item_placed ec_misc 0
execute if score @s ec_menu matches 56 if score @s ec_money >= fee ec_misc run scoreboard players operation @s ec_money -= fee ec_misc

scoreboard players set heavy_item ec_misc 0
execute if score @s ec_money >= fee ec_misc if score @s ec_menu matches 56 run function ec:ec_function/auction/open_auction
execute if score @s ec_money >= fee ec_misc if score @s ec_menu matches 55 run function ec:ec_menus/auction/sell_page
execute unless score @s ec_money >= fee ec_misc run function ec:ec_menus/auction/sell_page
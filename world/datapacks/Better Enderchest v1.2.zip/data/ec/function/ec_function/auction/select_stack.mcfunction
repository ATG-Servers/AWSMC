clear @s player_head[custom_name= {"italic":false,"text":"Stack"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Stack"} }}}]

scoreboard players set @s ec_auction_buy_rate 64

function ec:ec_menus/auction/shop_page
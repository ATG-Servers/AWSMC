
data remove storage auction shop
scoreboard players set order_id ec_misc 0
scoreboard players set order_slot ec_misc 0
scoreboard players set order_page ec_misc 0

function ec:ec_function/auction/order_items

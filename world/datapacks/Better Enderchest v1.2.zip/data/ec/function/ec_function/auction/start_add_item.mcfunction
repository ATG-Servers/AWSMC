execute unless score current ec_misc matches 1.. run scoreboard players set current ec_misc 0
execute unless score current_on_page ec_misc matches 1.. run scoreboard players set current_on_page ec_misc 0

execute unless score page ec_misc matches 1.. run scoreboard players set page ec_misc 0

execute store result storage auction current_prize int 1 run scoreboard players get current ec_auction_prize
# function ec:ec_function/auction/calculate_page
execute if score current_on_page ec_misc matches 18 run scoreboard players add page ec_misc 1
execute if score current_on_page ec_misc matches 18 run scoreboard players set current_on_page ec_misc 0

execute store result storage auction current_page int 1 run scoreboard players get page ec_misc
execute store result storage auction current_id int 1 run scoreboard players get current ec_misc
execute store result storage auction current_id_on_page int 1 run scoreboard players get current_on_page ec_misc

function ec:ec_function/auction/add_item with storage auction

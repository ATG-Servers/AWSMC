
execute unless entity @a[scores={ec_menu=55..56}] run scoreboard players set @s ec_auction_prize 1
execute unless entity @a[scores={ec_menu=55..56}] run scoreboard players set refill ec_misc 0
clear @s nether_star[custom_name= {"italic":false,"text":"Sell Items"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sell Items"} }}}]
execute at @s unless entity @a[scores={ec_menu=55..56}] run playsound minecraft:ui.button.click master @s ~ ~ ~
execute as @s unless entity @a[scores={ec_menu=55..56}] run function ec:ec_menus/auction/sell_page
execute if entity @a[scores={ec_menu=55..56}] run function ec:ec_menus/auction/auction_page
execute if entity @a[scores={ec_menu=55..56}] run tellraw @s {"text": "Another player is just selling their Items. Please wait a moment!","color": "red"}
execute unless entity @a[scores={ec_menu=55..56}] run scoreboard players set @s ec_menu 55
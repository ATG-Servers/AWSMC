$data modify storage auction buy_id set from storage auction shop.$(buy_page).$(buy_slot).ec_id


function ec:ec_function/auction/get_max_stack_size with storage auction
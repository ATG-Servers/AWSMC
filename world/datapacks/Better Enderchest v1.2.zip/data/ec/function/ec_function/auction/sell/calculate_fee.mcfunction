scoreboard players operation fee ec_misc = @s ec_auction_count
scoreboard players operation fee ec_misc *= @s ec_auction_prize
scoreboard players operation fee ec_misc /= Iron ec_sell_values
item modify entity @s enderchest.22 ec:auction/fee
clear @s barrier[custom_name= {"italic":false,"text":"Cancel Process"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Cancel Process"} }}}]

execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[sell]}
execute if score auction_item_placed ec_misc matches 1 at @s run data modify entity @n[type=chest_minecart,tag=sell] Items[{Slot:0b}].id set from storage auction sell.id
execute if score auction_item_placed ec_misc matches 1 at @s run data modify entity @n[type=chest_minecart,tag=sell] Items[{Slot:0b}].components set from storage auction sell.components
execute if score auction_item_placed ec_misc matches 1 at @s store result entity @n[type=chest_minecart,tag=sell] Items[{Slot:0b}].count int 1 run scoreboard players get @s ec_auction_count
scoreboard players set auction_item_placed ec_misc 0
# execute at @s run item modify entity @n[type=chest_minecart,tag=sell] container.0 {function:set_custom_data,tag:{better_ec:{}}}

execute at @s run kill @n[type=chest_minecart,tag=sell]

scoreboard players set @s ec_menu 54
function ec:ec_menus/auction/auction_page
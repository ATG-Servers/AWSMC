execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[get_item]}
$scoreboard players set multiplier ec_misc $(max_stack_size)

$scoreboard players operation buy_prize ec_misc = $(buy_id) ec_auction_prize
$execute if score @s ec_auction_buy_rate matches 64 if score $(buy_id) ec_auction_count matches $(max_stack_size).. run scoreboard players operation buy_prize ec_misc *= multiplier ec_misc

$execute if score @s ec_auction_buy_rate matches 64 unless score $(buy_id) ec_auction_count matches $(max_stack_size).. run scoreboard players operation buffer ec_misc = $(buy_id) ec_auction_count
$execute if score @s ec_auction_buy_rate matches 64 unless score $(buy_id) ec_auction_count matches $(max_stack_size).. run scoreboard players operation buy_prize ec_misc *= buffer ec_misc
$execute if score @s ec_money >= buy_prize ec_misc if score $(buy_id) ec_auction_count matches 1.. run data modify entity @n[type=chest_minecart,tag=get_item] Items[{Slot:0b}].id set from storage auction shop.$(buy_page).$(buy_slot).id 
$execute if score @s ec_money >= buy_prize ec_misc if score $(buy_id) ec_auction_count matches 1.. run data modify entity @n[type=chest_minecart,tag=get_item] Items[{Slot:0b}].components set from storage auction shop.$(buy_page).$(buy_slot).components

$execute if score @s ec_money >= buy_prize ec_misc if score $(buy_id) ec_auction_count matches 1.. if score $(buy_id) ec_auction_count matches $(max_stack_size).. if score @s ec_auction_buy_rate matches 64 run item modify entity @n[type=chest_minecart,tag=get_item] container.0 {function:set_count,count:$(max_stack_size)}
$execute if score @s ec_money >= buy_prize ec_misc if score $(buy_id) ec_auction_count matches 1.. unless score $(buy_id) ec_auction_count matches $(max_stack_size).. if score @s ec_auction_buy_rate matches 64 store result entity @n[type=chest_minecart,tag=get_item] Items[{Slot:0b}].count int 1 run scoreboard players get $(buy_id) ec_auction_count
$execute if score @s ec_money >= buy_prize ec_misc if score $(buy_id) ec_auction_count matches 1.. run scoreboard players set buy ec_misc 1

execute unless score @s ec_money >= buy_prize ec_misc run tellraw @s {text:"Not enough money!",color:"red"}
# $say $(buy_seller)


execute if score @s ec_auction_buy_rate matches 1.. if score buy ec_misc matches 1 run scoreboard players operation @s ec_money -= buy_prize ec_misc
$execute if score @s ec_auction_buy_rate matches 1.. if score buy ec_misc matches 1 run scoreboard players operation $(buy_seller) ec_auction_stored_money += buy_prize ec_misc
execute if score @s ec_auction_buy_rate matches 1.. if score buy ec_misc matches 1 run data modify storage auction get_money set from storage auction buy_seller
# $execute if score @s ec_auction_buy_rate matches 1.. if score buy ec_misc matches 1 as @a[scores={ec_chest_id=$(buy_seller)}] run function ec:ec_function/auction/get_money with storage auction
$execute if score @s ec_auction_buy_rate matches 1 if score buy ec_misc matches 1 run scoreboard players operation $(buy_id) ec_auction_count -= @s ec_auction_buy_rate
$execute if score @s ec_auction_buy_rate matches 64 if score buy ec_misc matches 1 unless score $(buy_id) ec_auction_count matches $(max_stack_size).. run scoreboard players set $(buy_id) ec_auction_count 0
$execute if score @s ec_auction_buy_rate matches 64 if score buy ec_misc matches 1 if score $(buy_id) ec_auction_count matches $(max_stack_size).. run scoreboard players remove $(buy_id) ec_auction_count $(max_stack_size)

$execute if score $(buy_id) ec_auction_count matches 0 run scoreboard players set delete_id ec_misc $(buy_id)
$execute if score $(buy_id) ec_auction_count matches 0 store result storage auction delete_id int 1 run scoreboard players get delete_id ec_misc
$execute if score $(buy_id) ec_auction_count matches 0 store result storage auction delete_id_page int 1 run scoreboard players get @s ec_auction_page

$execute if score $(buy_id) ec_auction_count matches 0 run function ec:ec_function/auction/delete_item with storage auction
# $execute if score $(buy_id) ec_auction_count matches 0 run function ec:ec_function/auction/back_to_auction 
scoreboard players set buy ec_misc 0
data remove entity @n[type=chest_minecart,tag=get_item] Items[{Slot:0b}].components."minecraft:custom_data".better_ec
# execute if entity @n[type=chest_minecart,tag=get_item,nbt={Items:[{Slot:0b,components:{"minecraft:custom_data":{}}}]}] run data remove entity @n[type=chest_minecart,tag=get_item] Items[{Slot:0b}].components."minecraft:custom_data"
# item modify entity @n[type=chest_minecart,tag=get_item] container.0 {function:set_custom_data,tag:{better_ec:0b}}


execute at @s run kill @n[type=chest_minecart,tag=get_item]
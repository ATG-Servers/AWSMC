$execute unless score $(order_id) ec_auction_count matches 0 run data modify storage auction shop.$(order_page).$(order_slot) set from storage auction shop_id.$(order_id)
$execute unless score $(order_id) ec_auction_count matches 0 run scoreboard players add order_slot ec_misc 1
scoreboard players add order_id ec_misc 1
execute if score order_slot ec_misc matches 18 run scoreboard players add order_page ec_misc 1
execute if score order_slot ec_misc matches 18 run scoreboard players set order_slot ec_misc 0

execute unless score order_id ec_misc >= current ec_misc run function ec:ec_function/auction/order_items
execute if score order_id ec_misc >= current ec_misc run function ec:ec_function/auction/finish_ordering


scoreboard players set auction_item_placed ec_misc 0
scoreboard players set @s ec_menu 54
scoreboard players set heavy_item ec_misc 0
execute at @s run playsound ui.button.click master @s ~ ~ ~
clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]


execute as @s run function ec:ec_menus/auction/auction_page
clear @s player_head[custom_name= {"italic":false,"text":"Single Item"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Single Item"} }}}]

scoreboard players set @s ec_auction_buy_rate 1

function ec:ec_menus/auction/shop_page
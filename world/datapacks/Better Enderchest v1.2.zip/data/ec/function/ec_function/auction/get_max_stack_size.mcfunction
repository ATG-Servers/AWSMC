# $execute store result storage auction max_stack_size int 1 run scoreboard players get max_$(current_id) ec_auction_count
# $execute store result storage auction buy_seller int 1 run scoreboard players get $(current_id) ec_auction_player

$execute store result storage auction max_stack_size int 1 run scoreboard players get max_$(buy_id) ec_auction_count
$execute store result storage auction buy_seller int 1 run scoreboard players get $(buy_id) ec_auction_player


function ec:ec_function/auction/get_item with storage auction
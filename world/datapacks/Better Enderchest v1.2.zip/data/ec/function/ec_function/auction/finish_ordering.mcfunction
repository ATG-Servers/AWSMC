scoreboard players operation current_on_page ec_misc = order_slot ec_misc
scoreboard players operation page ec_misc = order_page ec_misc
# execute if score current_on_page ec_misc matches 0 run scoreboard players remove page ec_misc 1
execute as @a[scores={ec_menu=1000..}] run function ec:ec_function/auction/shop
execute if score draw_page ec_misc < page ec_misc at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score draw_page ec_misc < page ec_misc at @s run playsound entity.villager.no master @s ~ ~ ~
execute if score draw_page ec_misc < page ec_misc run scoreboard players add @s ec_auction_page 1
execute if score draw_page ec_misc < page ec_misc run scoreboard players add @s ec_menu 1





clear @s player_head[custom_name= {"italic":false,"text":"Page Forward"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Page Forward"} }}}]

function ec:ec_menus/auction/shop_page
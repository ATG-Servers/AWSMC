clear @s player_head[custom_name= {"italic":false,"text":"Increase Prize"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Increase Prize"} }}}]

execute at @s if score @s ec_menu matches 56 run playsound minecraft:ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_menu matches 56 run playsound minecraft:entity.villager.no master @s ~ ~ ~

execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "1" }}]}] run scoreboard players set @s ec_bank_interaction 1
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "10" }}]}] run scoreboard players set @s ec_bank_interaction 10
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "100" }}]}] run scoreboard players set @s ec_bank_interaction 100
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "1000" }}]}] run scoreboard players set @s ec_bank_interaction 1000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "10000" }}]}] run scoreboard players set @s ec_bank_interaction 10000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "100000" }}]}] run scoreboard players set @s ec_bank_interaction 100000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "1000000" }}]}] run scoreboard players set @s ec_bank_interaction 1000000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "10000000" }}]}] run scoreboard players set @s ec_bank_interaction 10000000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "100000000" }}]}] run scoreboard players set @s ec_bank_interaction 100000000
execute if entity @s[nbt={EnderItems:[{Slot:15b,components:{"minecraft:custom_name": "1000000000" }}]}] run scoreboard players set @s ec_bank_interaction 1000000000



execute if score @s ec_menu matches 56 if entity @s[nbt={EnderItems:[{Slot:15b}]}] run scoreboard players operation @s ec_auction_prize += @s ec_bank_interaction
execute if score @s ec_menu matches 56 if entity @s[nbt=!{EnderItems:[{Slot:15b}]}] run scoreboard players operation @s ec_auction_prize += @s ec_interaction


item replace entity @s player.cursor from entity @s enderchest.15
scoreboard players set @s ec_bank_interaction 1
function ec:ec_menus/auction/sell_page
execute if score @s ec_menu matches 56 run function ec:ec_function/auction/sell/display_iten
scoreboard players set operate ec_misc 18
scoreboard players operation page ec_misc = current ec_misc
scoreboard players operation page ec_misc /= operate ec_misc
scoreboard players add page ec_misc 1
clear @s gray_stained_glass_pane[custom_name= {"italic":false,"text":"Place Item Here"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gray_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place Item Here"} }}}]

execute unless score @s ec_auction_prize matches 1.. run scoreboard players set @s ec_auction_prize 1
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run scoreboard players set auction_item_placed ec_misc 1
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run item replace entity @s enderchest.8 from entity @s enderchest.4
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 store result score @s ec_auction_count run data get entity @s EnderItems[{Slot:8b}].count
# execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run function ec:ec_function/auction/sell/display_iten


execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run data modify storage auction sell.id set from entity @s EnderItems[{Slot:8b}].id
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run data remove storage auction sell.components 
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run data modify storage auction sell.components set from entity @s EnderItems[{Slot:8b}].components
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 if entity @s[nbt={EnderItems:[{Slot:8b,count:1}]}] run scoreboard players set heavy_item ec_misc 1
# execute if score @s ec_menu matches 55 run data remove storage auction sell.components."minecraft:custom_data"
# execute if score @s ec_menu matches 55 run data modify storage auction sell.components."minecraft:custom_data" set value {better_ec:1b}


# execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run item modify entity @s enderchest.8 {function:set_custom_data,tag:{"better_ec":1b}}
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run item modify entity @s enderchest.8 {function:set_count,count:1}


# execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 run item modify entity @s enderchest.4 {function:set_custom_data,tag:{"better_ec":1b}}
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 run data modify storage auction sell_temp set from storage auction sell

execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 store success score check_id ec_misc run data modify storage auction sell_temp.id set from entity @s EnderItems[{Slot:4b}].id
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 store success score check_comp ec_misc run data modify storage auction sell_temp.components set from entity @s EnderItems[{Slot:4b}].components

execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 if score check_id ec_misc matches 0 if score check_comp ec_misc matches 0 store result score add_count ec_misc run data get entity @s EnderItems[{Slot:4b}].count
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 if score check_id ec_misc matches 0 if score check_comp ec_misc matches 0 run scoreboard players operation @s ec_auction_count += add_count ec_misc
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 if score check_id ec_misc matches 0 if score check_comp ec_misc matches 0 run scoreboard players set refill ec_misc 1
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 if score check_id ec_misc matches 0 if score check_comp ec_misc matches 0 run item replace entity @s enderchest.18 with air
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_id ec_misc matches 0 run item replace entity @s player.cursor from entity @s enderchest.4
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_id ec_misc matches 0 run item modify entity @s player.cursor {function:set_custom_data,tag:{better_ec:0b}}
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_id ec_misc matches 0 run tellraw @s {"text": "The item you entered did not match your selected Item!","color": "red"}


execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_comp ec_misc matches 0 run item replace entity @s player.cursor from entity @s enderchest.4
# execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_comp ec_misc matches 0 run item modify entity @s player.cursor {function:set_custom_data,tag:{better_ec:{}}}
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 unless score check_comp ec_misc matches 0 if score check_id ec_misc matches 0 run tellraw @s {"text": "The item you entered had other properties than the one you selected!","color": "red"}


execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 56 if score check_id ec_misc matches 0 if score check_comp ec_misc matches 0 run function ec:ec_function/auction/sell/display_iten

# recomendet price
execute if items entity @s enderchest.4 #ec:prizes/1 run function ec:ec_function/auction/sell/recommended_price {price:1}
execute if items entity @s enderchest.4 #ec:prizes/2 run function ec:ec_function/auction/sell/recommended_price {price:2}
execute if items entity @s enderchest.4 #ec:prizes/3 run function ec:ec_function/auction/sell/recommended_price {price:3}
execute if items entity @s enderchest.4 #ec:prizes/4 run function ec:ec_function/auction/sell/recommended_price {price:4}
execute if items entity @s enderchest.4 #ec:prizes/5 run function ec:ec_function/auction/sell/recommended_price {price:5}
execute if items entity @s enderchest.4 #ec:prizes/6 run function ec:ec_function/auction/sell/recommended_price {price:6}
execute if items entity @s enderchest.4 #ec:prizes/7 run function ec:ec_function/auction/sell/recommended_price {price:7}
execute if items entity @s enderchest.4 #ec:prizes/8 run function ec:ec_function/auction/sell/recommended_price {price:8}
execute if items entity @s enderchest.4 #ec:prizes/9 run function ec:ec_function/auction/sell/recommended_price {price:9}
execute if items entity @s enderchest.4 #ec:prizes/10 run function ec:ec_function/auction/sell/recommended_price {price:10}
execute if items entity @s enderchest.4 #ec:prizes/12 run function ec:ec_function/auction/sell/recommended_price {price:12}
execute if items entity @s enderchest.4 #ec:prizes/14 run function ec:ec_function/auction/sell/recommended_price {price:14}
execute if items entity @s enderchest.4 #ec:prizes/16 run function ec:ec_function/auction/sell/recommended_price {price:16}
execute if items entity @s enderchest.4 #ec:prizes/18 run function ec:ec_function/auction/sell/recommended_price {price:18}
execute if items entity @s enderchest.4 #ec:prizes/20 run function ec:ec_function/auction/sell/recommended_price {price:20}
execute if items entity @s enderchest.4 #ec:prizes/22 run function ec:ec_function/auction/sell/recommended_price {price:22}
execute if items entity @s enderchest.4 #ec:prizes/25 run function ec:ec_function/auction/sell/recommended_price {price:25}
execute if items entity @s enderchest.4 #ec:prizes/28 run function ec:ec_function/auction/sell/recommended_price {price:28}
execute if items entity @s enderchest.4 #ec:prizes/30 run function ec:ec_function/auction/sell/recommended_price {price:30}
execute if items entity @s enderchest.4 #ec:prizes/33 run function ec:ec_function/auction/sell/recommended_price {price:33}
execute if items entity @s enderchest.4 #ec:prizes/37 run function ec:ec_function/auction/sell/recommended_price {price:37}
execute if items entity @s enderchest.4 #ec:prizes/41 run function ec:ec_function/auction/sell/recommended_price {price:41}
execute if items entity @s enderchest.4 #ec:prizes/47 run function ec:ec_function/auction/sell/recommended_price {price:47}
execute if items entity @s enderchest.4 #ec:prizes/51 run function ec:ec_function/auction/sell/recommended_price {price:51}
execute if items entity @s enderchest.4 #ec:prizes/56 run function ec:ec_function/auction/sell/recommended_price {price:56}
execute if items entity @s enderchest.4 #ec:prizes/60 run function ec:ec_function/auction/sell/recommended_price {price:60}
execute if items entity @s enderchest.4 #ec:prizes/63 run function ec:ec_function/auction/sell/recommended_price {price:63}
execute if items entity @s enderchest.4 #ec:prizes/68 run function ec:ec_function/auction/sell/recommended_price {price:68}
execute if items entity @s enderchest.4 #ec:prizes/75 run function ec:ec_function/auction/sell/recommended_price {price:75}
execute if items entity @s enderchest.4 #ec:prizes/80 run function ec:ec_function/auction/sell/recommended_price {price:80}
execute if items entity @s enderchest.4 #ec:prizes/90 run function ec:ec_function/auction/sell/recommended_price {price:90}
execute if items entity @s enderchest.4 #ec:prizes/95 run function ec:ec_function/auction/sell/recommended_price {price:95}
execute if items entity @s enderchest.4 #ec:prizes/100 run function ec:ec_function/auction/sell/recommended_price {price:100}
execute if items entity @s enderchest.4 #ec:prizes/111 run function ec:ec_function/auction/sell/recommended_price {price:111}
execute if items entity @s enderchest.4 #ec:prizes/125 run function ec:ec_function/auction/sell/recommended_price {price:125}
execute if items entity @s enderchest.4 #ec:prizes/140 run function ec:ec_function/auction/sell/recommended_price {price:140}
execute if items entity @s enderchest.4 #ec:prizes/160 run function ec:ec_function/auction/sell/recommended_price {price:160}
execute if items entity @s enderchest.4 #ec:prizes/180 run function ec:ec_function/auction/sell/recommended_price {price:180}
execute if items entity @s enderchest.4 #ec:prizes/200 run function ec:ec_function/auction/sell/recommended_price {price:200}
execute if items entity @s enderchest.4 #ec:prizes/215 run function ec:ec_function/auction/sell/recommended_price {price:215}
execute if items entity @s enderchest.4 #ec:prizes/250 run function ec:ec_function/auction/sell/recommended_price {price:250}
execute if items entity @s enderchest.4 #ec:prizes/290 run function ec:ec_function/auction/sell/recommended_price {price:290}
execute if items entity @s enderchest.4 #ec:prizes/350 run function ec:ec_function/auction/sell/recommended_price {price:350}
execute if items entity @s enderchest.4 #ec:prizes/450 run function ec:ec_function/auction/sell/recommended_price {price:450}
execute if items entity @s enderchest.4 #ec:prizes/500 run function ec:ec_function/auction/sell/recommended_price {price:500}
execute if items entity @s enderchest.4 #ec:prizes/850 run function ec:ec_function/auction/sell/recommended_price {price:850}
execute if items entity @s enderchest.4 #ec:prizes/1k run function ec:ec_function/auction/sell/recommended_price {price:1000}
execute if items entity @s enderchest.4 #ec:prizes/1.3k run function ec:ec_function/auction/sell/recommended_price {price:1300}
execute if items entity @s enderchest.4 #ec:prizes/1.8k run function ec:ec_function/auction/sell/recommended_price {price:1800}
execute if items entity @s enderchest.4 #ec:prizes/2.2k run function ec:ec_function/auction/sell/recommended_price {price:2200}
execute if items entity @s enderchest.4 #ec:prizes/2.8k run function ec:ec_function/auction/sell/recommended_price {price:2800}
execute if items entity @s enderchest.4 #ec:prizes/3.6k run function ec:ec_function/auction/sell/recommended_price {price:3600}
execute if items entity @s enderchest.4 #ec:prizes/4.4k run function ec:ec_function/auction/sell/recommended_price {price:4400}
execute if items entity @s enderchest.4 #ec:prizes/5.5k run function ec:ec_function/auction/sell/recommended_price {price:5500}
execute if items entity @s enderchest.4 #ec:prizes/7k run function ec:ec_function/auction/sell/recommended_price {price:7000}
execute if items entity @s enderchest.4 #ec:prizes/15k run function ec:ec_function/auction/sell/recommended_price {price:15000}
execute if items entity @s enderchest.4 #ec:prizes/40k run function ec:ec_function/auction/sell/recommended_price {price:40000}
execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] if score @s ec_menu matches 55 run item modify entity @s enderchest.8 ec:auction/sell_display
function ec:ec_function/auction/sell/calculate_fee

execute if entity @s[nbt={EnderItems:[{Slot:4b}]}] run scoreboard players set @s ec_menu 56
function ec:ec_menus/auction/sell_page
item replace entity @s enderchest.4 with gray_stained_glass_pane[custom_name= {"italic":false,"text":"Place Item Here"} ,custom_data={"better_ec":1b}]
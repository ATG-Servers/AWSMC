$scoreboard players set @s ec_auction_prize $(price)



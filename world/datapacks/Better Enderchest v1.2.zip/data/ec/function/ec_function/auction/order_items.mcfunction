execute store result storage auction order_id int 1 run scoreboard players get order_id ec_misc
execute store result storage auction order_slot int 1 run scoreboard players get order_slot ec_misc
execute store result storage auction order_page int 1 run scoreboard players get order_page ec_misc

function ec:ec_function/auction/order_id with storage auction
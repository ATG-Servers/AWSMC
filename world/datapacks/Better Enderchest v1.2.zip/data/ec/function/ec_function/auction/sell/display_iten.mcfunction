execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[sell]}

execute at @s run data modify entity @n[type=chest_minecart,tag=sell] Items[{Slot:0b}] set from storage auction sell
execute at @s run item modify entity @n[type=chest_minecart,tag=sell] container.0 {function:set_custom_data,tag:{better_ec:1b}}
execute at @s run item replace entity @s enderchest.8 from entity @n[type=chest_minecart,tag=sell] container.0
item modify entity @s enderchest.8 ec:auction/sell_display


execute at @s run data merge entity @n[type=chest_minecart,tag=sell] {Items:[]}

execute at @s run kill @n[type=chest_minecart,tag=sell]

clear @s *[custom_data={"better_ec":1b}]
kill @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{"better_ec":1b}}}}]

scoreboard players set @s ec_menu 54
scoreboard players set @s ec_auction_count 0
scoreboard players set @s ec_auction_prize 1


clear @s lectern[custom_name= {"italic":false,"text":"Market"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lectern",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Market"} }}}]
execute at @s run playsound minecraft:ui.button.click master @s ~ ~ ~
execute as @s run function ec:ec_menus/auction/auction_page
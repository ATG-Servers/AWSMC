execute at @s unless score @s ec_menu matches ..1000 run playsound ui.button.click master @s ~ ~ ~
execute at @s if score @s ec_menu matches ..1000 run playsound entity.villager.no master @s ~ ~ ~
execute unless score @s ec_menu matches ..1000 run scoreboard players remove @s ec_auction_page 1
execute unless score @s ec_menu matches ..1000 run scoreboard players remove @s ec_menu 1



clear @s player_head[custom_name= {"italic":false,"text":"Page Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Page Back"} }}}]

function ec:ec_menus/auction/shop_page
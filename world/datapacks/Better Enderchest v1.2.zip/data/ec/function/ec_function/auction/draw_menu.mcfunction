execute unless score draw ec_misc matches 1.. run scoreboard players set draw ec_misc 0
execute if score draw ec_misc matches 0 at @s run summon chest_minecart ~ ~ ~ {OnGround:1b,Tags:[draw_menu],NoGravity:1b}
execute store result storage auction draw int 1 run scoreboard players get draw ec_misc
execute store result storage auction draw_page int 1 run scoreboard players get draw_page ec_misc
function ec:ec_function/auction/get_id with storage auction
scoreboard players add draw ec_misc 1
execute unless score draw ec_misc matches 18.. run function ec:ec_function/auction/draw_menu
execute if score draw ec_misc matches 18.. run scoreboard players set draw ec_misc 0
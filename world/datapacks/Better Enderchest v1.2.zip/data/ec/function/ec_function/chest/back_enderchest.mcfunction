scoreboard players set @s ec_menu 1

clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]

execute store result storage enderchest current int 1 run scoreboard players get @s ec_chest_id
execute store result storage enderchest current_page int 1 run scoreboard players get @s ec_chest_page
function ec:ec_function/chest/write_storage with storage enderchest
execute at @s run playsound block.chest.close master

execute as @s run function ec:ec_menus/main_page_1


execute if score @s ec_menu matches 1 at @s run playsound block.chest.open master @s ~ ~ ~ 40
scoreboard players set @s ec_menu 2
execute unless score @s ec_chest_page matches 1.. run scoreboard players set @s ec_chest_page 1
execute unless score @s ec_chest_page_max matches 1.. run scoreboard players set @s ec_chest_page_max 1
clear @s chest[custom_name= {"italic":false,"text":"Enderchest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:chest",components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest"} }}}]

execute unless score @s ec_chest_id matches 0.. run scoreboard players add current ec_chest_id 1
execute unless score @s ec_chest_id matches 0.. run scoreboard players operation @s ec_chest_id = current ec_chest_id


execute at @s run summon chest_minecart ~ ~3 ~ {NoGravity:1b,Tags:["enderchest"]}
execute store result storage enderchest current int 1 run scoreboard players get @s ec_chest_id
execute store result storage enderchest current_page int 1 run scoreboard players get @s ec_chest_page
function ec:ec_function/chest/read_storage with storage enderchest



execute as @s run function ec:ec_menus/enderchest_page_1


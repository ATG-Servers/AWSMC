$data modify storage enderchest ec.$(current).$(current_page) set from entity @s EnderItems

scoreboard players add @s ec_chest_page_max 1
scoreboard players operation @s ec_money -= @s ec_chest_next_page_prize
item replace entity @s hotbar.8 from entity @s enderchest.8

scoreboard players operation @s ec_chest_next_page_prize *= price_multiplier_chest ec_shop_price
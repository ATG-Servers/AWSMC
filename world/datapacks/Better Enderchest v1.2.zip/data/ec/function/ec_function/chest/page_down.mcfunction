clear @s player_head[custom_name= {"italic":false,"text":"Page Down"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",components:{"minecraft:custom_name": {"italic":false,"text":"Page Down"} }}}]

execute store result storage enderchest current int 1 run scoreboard players get @s ec_chest_id
execute store result storage enderchest current_page int 1 run scoreboard players get @s ec_chest_page
function ec:ec_function/chest/write_storage with storage enderchest

execute if score @s ec_chest_page matches 1 at @s run playsound entity.villager.no master @s
execute unless score @s ec_chest_page matches 1 at @s run playsound item.book.page_turn master @s
execute unless score @s ec_chest_page matches 1 run scoreboard players remove @s ec_chest_page 1




function ec:ec_function/chest/chest
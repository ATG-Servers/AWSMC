$data modify entity @n[tag=enderchest,type=chest_minecart] Items set from storage enderchest ec.$(current).$(current_page)

item replace entity @s enderchest.0 from entity @n[tag=enderchest,type=chest_minecart] container.0
item replace entity @s enderchest.1 from entity @n[tag=enderchest,type=chest_minecart] container.1
item replace entity @s enderchest.2 from entity @n[tag=enderchest,type=chest_minecart] container.2
item replace entity @s enderchest.3 from entity @n[tag=enderchest,type=chest_minecart] container.3
item replace entity @s enderchest.4 from entity @n[tag=enderchest,type=chest_minecart] container.4
item replace entity @s enderchest.5 from entity @n[tag=enderchest,type=chest_minecart] container.5
item replace entity @s enderchest.6 from entity @n[tag=enderchest,type=chest_minecart] container.6
item replace entity @s enderchest.7 from entity @n[tag=enderchest,type=chest_minecart] container.7
# item replace entity @s enderchest.8 from entity @n[tag=enderchest,type=chest_minecart] container.8
item replace entity @s enderchest.9 from entity @n[tag=enderchest,type=chest_minecart] container.9
item replace entity @s enderchest.10 from entity @n[tag=enderchest,type=chest_minecart] container.10
item replace entity @s enderchest.11 from entity @n[tag=enderchest,type=chest_minecart] container.11
item replace entity @s enderchest.12 from entity @n[tag=enderchest,type=chest_minecart] container.12
item replace entity @s enderchest.13 from entity @n[tag=enderchest,type=chest_minecart] container.13
item replace entity @s enderchest.14 from entity @n[tag=enderchest,type=chest_minecart] container.14
item replace entity @s enderchest.15 from entity @n[tag=enderchest,type=chest_minecart] container.15
item replace entity @s enderchest.16 from entity @n[tag=enderchest,type=chest_minecart] container.16
# item replace entity @s enderchest.17 from entity @n[tag=enderchest,type=chest_minecart] container.17
item replace entity @s enderchest.18 from entity @n[tag=enderchest,type=chest_minecart] container.18
item replace entity @s enderchest.19 from entity @n[tag=enderchest,type=chest_minecart] container.19
item replace entity @s enderchest.20 from entity @n[tag=enderchest,type=chest_minecart] container.20
item replace entity @s enderchest.21 from entity @n[tag=enderchest,type=chest_minecart] container.21
item replace entity @s enderchest.22 from entity @n[tag=enderchest,type=chest_minecart] container.22
item replace entity @s enderchest.23 from entity @n[tag=enderchest,type=chest_minecart] container.23
item replace entity @s enderchest.24 from entity @n[tag=enderchest,type=chest_minecart] container.24
item replace entity @s enderchest.25 from entity @n[tag=enderchest,type=chest_minecart] container.25
item replace entity @s enderchest.26 with hopper[custom_name= {"italic":false,"text":"Back"} ]
data merge entity @n[type=chest_minecart,tag=enderchest] {Items:[]}
kill @n[tag=enderchest,type=chest_minecart]
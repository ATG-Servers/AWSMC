execute store result storage enderchest current int 1 run scoreboard players get @s ec_chest_id
execute store result storage enderchest current_page int 1 run scoreboard players get @s ec_chest_page
function ec:ec_function/chest/write_storage with storage enderchest

execute if score @s ec_chest_page = @s ec_chest_page_max unless score @s ec_money >= @s ec_chest_next_page_prize at @s run playsound entity.villager.no master @s

execute if score @s ec_chest_page = @s ec_chest_page_max if score @s ec_money >= @s ec_chest_next_page_prize if entity @s[nbt={Inventory:[{Slot:8b,id:"minecraft:player_head",components:{"minecraft:custom_name":{"text":"Page Up",italic:false}}}]}] at @s run function ec:ec_function/chest/buy_next_page
# execute if score @s ec_chest_page = @s ec_chest_page_max if entity @s run item replace entity @s[nbt={Inventory:[{Slot:8b,id:"minecraft:player_head"}]}] hotbar.8 from entity @s enderchest.8
execute unless score @s ec_chest_page = @s ec_chest_page_max at @s run playsound item.book.page_turn master @s
execute unless score @s ec_chest_page = @s ec_chest_page_max run scoreboard players add @s ec_chest_page 1




clear @s player_head[custom_name= {"italic":false,"text":"Page Up"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",components:{"minecraft:custom_name": {"italic":false,"text":"Page Up"} }}}]

function ec:ec_function/chest/chest
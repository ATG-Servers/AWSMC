clear @s furnace[custom_name= {"italic":false,"text":"Money Furnace"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:furnace",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Money Furnace"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add furnace ec_layout 1
execute if score furnace ec_layout matches 2 run scoreboard players set furnace ec_layout 0

function ec:ec_menus/settings/layout_page
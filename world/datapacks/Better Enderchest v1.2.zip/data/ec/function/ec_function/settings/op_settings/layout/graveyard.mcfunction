clear @s skeleton_skull[custom_name= {"italic":false,"text":"Graveyard"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:skeleton_skull",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Graveyard"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add grave ec_layout 1
execute if score grave ec_layout matches 2 run scoreboard players set grave ec_layout 0

function ec:ec_menus/settings/layout_page
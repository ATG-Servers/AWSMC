scoreboard players set @s ec_menu 49
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s name_tag[custom_name= {"italic":false,"text":"Teams"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:name_tag",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Teams"} }}}]

data modify storage team name set value {"text":"","italic": false} 
data modify storage team sufix set value {"text":""} 
data modify storage team prefix set value {"text":""} 
data modify storage team color set value "white"



function ec:ec_menus/settings/teams_page
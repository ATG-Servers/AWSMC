clear @s ender_pearl[item_name= "tpp" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_pearl",count:1,components:{"minecraft:item_name": "tpp" }}}]

function ec:ec_menus/settings/tpp_page
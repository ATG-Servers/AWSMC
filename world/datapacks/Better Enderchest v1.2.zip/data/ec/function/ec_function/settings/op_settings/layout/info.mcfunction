clear @s oak_hanging_sign[custom_name= {"italic":false,"text":"Information"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:oak_hanging_sign",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Information"} }}}]


function ec:ec_menus/settings/layout_page
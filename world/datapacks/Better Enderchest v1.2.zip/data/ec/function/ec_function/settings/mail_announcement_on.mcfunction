clear @s nautilus_shell[custom_name= {"italic":false,"text":"Mail Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nautilus_shell",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Mail Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}}]

clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Mail Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}}]


execute if entity @s[tag=no_mail_announcement] run tag @s remove no_mail_announcement

function ec:ec_menus/settings/settings_page
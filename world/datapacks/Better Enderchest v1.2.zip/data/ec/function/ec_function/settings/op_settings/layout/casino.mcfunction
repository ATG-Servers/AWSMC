clear @s sunflower[custom_name= {"italic":false,"text":"Casino"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sunflower",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Casino"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add casino ec_layout 1
execute if score casino ec_layout matches 2 run scoreboard players set casino ec_layout 0

function ec:ec_menus/settings/layout_page
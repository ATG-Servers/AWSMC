clear @s smithing_table[custom_name= {"italic":false,"text":"Smithing Table"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:smithing_table",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Smithing Table"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add smith ec_layout 1
execute if score smith ec_layout matches 2 run scoreboard players set smith ec_layout 0

function ec:ec_menus/settings/layout_page
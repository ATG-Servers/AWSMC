clear @s hopper_minecart[custom_name= {"italic":false,"text":"Trashcan"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper_minecart",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Trashcan"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add trash ec_layout 1
execute if score trash ec_layout matches 2 run scoreboard players set trash ec_layout 0

function ec:ec_menus/settings/layout_page
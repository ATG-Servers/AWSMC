scoreboard players set @s ec_menu 33

clear @s nether_star[custom_name= {"italic":false,"text":"Create Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Create Bossbar"} }}}]
execute at @s run playsound entity.wither.spawn master @s ~ ~ ~

scoreboard players set bossbar ec_bossbar 1

scoreboard players set value ec_bossbar 100
scoreboard players set max ec_bossbar 100
scoreboard players set score ec_bossbar 0
scoreboard players set visibility ec_bossbar 1

bossbar set enderchest color white
bossbar set enderchest players @a
bossbar set enderchest value 100
scoreboard players set value ec_bossbar 100
data modify storage bossbar name set value {"text":"Better Enderchest","color":"gold"}
bossbar set enderchest name [{"storage": "bossbar","nbt": "name","interpret": true}]


function ec:ec_menus/settings/bossbar_page
clear @s iron_trapdoor[custom_name= {"italic":false,"text":"Set Suffix"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:iron_trapdoor",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Suffix"} }}}]
execute if entity @s[nbt={EnderItems:[{Slot:15b}]}] at @s run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:15b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:15b}]}] at @s run tellraw @s {"text": "Click again with renamed Item!","color": "red"}
data modify storage team sufix set from entity @s EnderItems[{Slot:15b}].components."minecraft:custom_name"
item replace entity @s player.cursor from entity @s enderchest.15
function ec:ec_menus/settings/teams_page
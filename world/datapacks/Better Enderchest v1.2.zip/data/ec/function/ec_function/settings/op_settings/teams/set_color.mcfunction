clear @s lime_dye[custom_name= {"italic":false,"text":"Set Color"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_dye",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Color"} }}}]
execute if entity @s[nbt={EnderItems:[{Slot:18b}]}] at @s run playsound item.dye.use master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:18b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:18b}]}] at @s run tellraw @s {"text": "Click again with Dye!","color": "red"}
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:blue_dye"}]}] run data modify storage team color set value "dark_blue"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:lime_dye"}]}] run data modify storage team color set value "green"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:red_dye"}]}] run data modify storage team color set value "dark_red"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:purple_dye"}]}] run data modify storage team color set value "dark_purple"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:green_dye"}]}] run data modify storage team color set value "dark_green"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:orange_dye"}]}] run data modify storage team color set value "gold"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:brown_dye"}]}] run data modify storage team color set value "black"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:yellow_dye"}]}] run data modify storage team color set value "yellow"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:white_dye"}]}] run data modify storage team color set value "white"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:light_gray_dye"}]}] run data modify storage team color set value "gray"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:gray_dye"}]}] run data modify storage team color set value "darl_gray"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:cyan_dye"}]}] run data modify storage team color set value "aqua"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:light_blue_dye"}]}] run data modify storage team color set value "blue"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:magenta_dye"}]}] run data modify storage team color set value "light_purple"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:pink_dye"}]}] run data modify storage team color set value "light_purple"
execute as @s if entity @s[nbt={EnderItems:[{Slot:18b,id:"minecraft:black_dye"}]}] run data modify storage team color set value "black"

item replace entity @s player.cursor from entity @s enderchest.18
function ec:ec_menus/settings/teams_page
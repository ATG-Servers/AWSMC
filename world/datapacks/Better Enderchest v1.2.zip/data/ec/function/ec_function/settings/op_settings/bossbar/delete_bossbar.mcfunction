clear @s barrier[custom_name= {"italic":false,"text":"Delete Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Delete Bossbar"} }}}]
execute at @s run playsound block.fire.extinguish master @s ~ ~ ~

bossbar set enderchest players
scoreboard players set bossbar ec_bossbar 0
scoreboard players set @s ec_menu 31
scoreboard players set score ec_bossbar 0

function ec:ec_menus/settings/op_settings_page
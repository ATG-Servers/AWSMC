clear @s music_disc_relic[custom_name= {"italic":false,"text":"Allow Bossbar Toggle"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:music_disc_relic",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Allow Bossbar Toggle"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add visibility ec_bossbar 1
execute if score visibility ec_bossbar matches 2 run scoreboard players set visibility ec_bossbar 0

function ec:ec_menus/settings/bossbar_page
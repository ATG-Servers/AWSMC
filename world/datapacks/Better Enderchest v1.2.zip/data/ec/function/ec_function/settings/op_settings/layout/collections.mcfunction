clear @s dragon_egg[custom_name= {"italic":false,"text":"Collections"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:dragon_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Collections"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add coll ec_layout 1
execute if score coll ec_layout matches 2 run scoreboard players set coll ec_layout 0

function ec:ec_menus/settings/layout_page
clear @s emerald[custom_name= {"italic":false,"text":"Shop"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Shop"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add shop ec_layout 1
execute if score shop ec_layout matches 3 run scoreboard players set shop ec_layout 0

function ec:ec_menus/settings/layout_page
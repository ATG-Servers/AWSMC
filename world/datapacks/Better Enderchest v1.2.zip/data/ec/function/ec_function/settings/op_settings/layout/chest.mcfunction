clear @s chest[custom_name= {"italic":false,"text":"Enderchest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add chest ec_layout 1
execute if score chest ec_layout matches 2 run scoreboard players set chest ec_layout 0

function ec:ec_menus/settings/layout_page
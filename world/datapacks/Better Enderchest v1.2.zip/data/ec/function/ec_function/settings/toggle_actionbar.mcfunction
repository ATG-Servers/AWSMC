execute if entity @s[nbt=!{EnderItems:[{Slot:11b}]}] run item replace entity @s enderchest.11 from entity @s player.cursor
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s paper[custom_name= {"italic":false,"text":"Toggle Actionbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:paper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Hide Actionbar"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Hide Actionbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Hide Actionbar"} }}}]

clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Hide Actionbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Hide Actionbar"} }}}]

title @s actionbar " "
# execute if entity @s[nbt={EnderItems:[{Slot:11b,id:"minecraft:lime_stained_glass_pane"}]}] run tag @s add no_actionbar
# execute if entity @s[nbt={EnderItems:[{Slot:11b,id:"minecraft:red_stained_glass_pane"}]}] run tag @s remove no_actionbar

execute if entity @s[tag=no_actionbar] run tag @s add no_actionbar_process
execute if entity @s[tag=!no_actionbar_process] run tag @s add no_actionbar
execute if entity @s[tag=no_actionbar_process] run tag @s remove no_actionbar
tag @s remove no_actionbar_process

function ec:ec_menus/settings/settings_page
scoreboard players enable @a[tag=no_enderchest] enderchest
execute at @s run playsound block.ender_chest.open master @s ~ ~ ~

execute as @a[tag=no_enderchest,scores={ec_check_enderchest=1..}] run scoreboard players add @s ec_no_enderchest_announcement 1
execute as @a[tag=no_enderchest,scores={ec_check_enderchest=1..}] if score @s ec_no_enderchest_announcement matches 1 run tellraw @s {"text": "Open Custom Enderchest with: /trigger enderchest","color": "red"}
execute as @a[tag=no_enderchest,scores={ec_check_enderchest=1..}] if score @s ec_no_enderchest_announcement matches 5.. run scoreboard players set @s ec_no_enderchest_announcement 0
execute as @a[tag=no_enderchest,scores={ec_check_enderchest=1..}] run scoreboard players set @s ec_check_enderchest 0



execute as @a[scores={enderchest=1..}] run scoreboard players set @s ec_menu 1
execute as @a[scores={enderchest=1..}] run tag @s remove no_enderchest
execute as @a[scores={enderchest=1..}] run function ec:ec_menus/main_page_1


execute as @a[scores={enderchest=1..}] run scoreboard players set @s enderchest 0

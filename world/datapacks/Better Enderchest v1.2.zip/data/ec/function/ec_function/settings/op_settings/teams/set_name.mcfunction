clear @s name_tag[custom_name= {"italic":false,"text":"Set Name"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:name_tag",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Name"} }}}]
execute if entity @s[nbt={EnderItems:[{Slot:13b}]}] at @s run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:13b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:13b}]}] at @s run tellraw @s {"text": "Click again with renamed Item!","color": "red"}
data modify storage team name set from entity @s EnderItems[{Slot:13b}].components."minecraft:custom_name"
item replace entity @s player.cursor from entity @s enderchest.13
function ec:ec_menus/settings/teams_page
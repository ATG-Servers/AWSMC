scoreboard players set @s ec_menu 32
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s music_disc_precipice[custom_name= {"italic":false,"text":"Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:music_disc_precipice",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar"} }}}]


function ec:ec_menus/settings/bossbar_page
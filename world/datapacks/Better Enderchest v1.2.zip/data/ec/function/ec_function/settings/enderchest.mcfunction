execute if entity @s[nbt=!{EnderItems:[{Slot:15b}]}] run item replace entity @s enderchest.14 from entity @s player.cursor
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s ender_chest[custom_name= {"italic":false,"text":"Switch to normal Enderchest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Switch to normal Enderchest"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Enderchest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest"} }}}]

clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Enderchest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest"} }}}]


execute if entity @s[nbt={EnderItems:[{Slot:15b,id:"minecraft:lime_stained_glass_pane"}]}] run tag @s add no_enderchest
execute if entity @s[nbt={EnderItems:[{Slot:15b,id:"minecraft:red_stained_glass_pane"}]}] run tag @s remove no_enderchest

scoreboard players set @s ec_menu 0
item replace entity @s enderchest.0 with air
item replace entity @s enderchest.1 with air
item replace entity @s enderchest.2 with air
item replace entity @s enderchest.3 with air
item replace entity @s enderchest.4 with air
item replace entity @s enderchest.5 with air
item replace entity @s enderchest.6 with air
item replace entity @s enderchest.7 with air
item replace entity @s enderchest.8 with air
item replace entity @s enderchest.9 with air
item replace entity @s enderchest.10 with air
item replace entity @s enderchest.11 with air
item replace entity @s enderchest.12 with air
item replace entity @s enderchest.13 with air
item replace entity @s enderchest.14 with air
item replace entity @s enderchest.15 with air
item replace entity @s enderchest.16 with air
item replace entity @s enderchest.17 with air
item replace entity @s enderchest.18 with air
item replace entity @s enderchest.19 with air
item replace entity @s enderchest.20 with air
item replace entity @s enderchest.21 with air
item replace entity @s enderchest.22 with air
item replace entity @s enderchest.23 with air
item replace entity @s enderchest.24 with air
item replace entity @s enderchest.25 with air
item replace entity @s enderchest.26 with air

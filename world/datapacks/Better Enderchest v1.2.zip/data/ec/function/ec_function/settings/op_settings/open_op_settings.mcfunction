scoreboard players set @s ec_menu 31
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s golden_apple[custom_name= {"italic":false,"text":"OP Settings"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:golden_apple",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"OP Settings"} }}}]


function ec:ec_menus/settings/op_settings_page
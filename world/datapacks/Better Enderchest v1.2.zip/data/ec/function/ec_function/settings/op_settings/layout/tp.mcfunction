clear @s ender_pearl[custom_name= {"italic":false,"text":"Teleporter"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_pearl",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Teleporter"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add tp ec_layout 1
execute if score tp ec_layout matches 2 run scoreboard players set tp ec_layout 0

function ec:ec_menus/settings/layout_page
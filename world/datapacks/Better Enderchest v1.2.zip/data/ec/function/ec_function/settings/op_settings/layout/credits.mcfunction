clear @s slime_ball[custom_name= {"italic":false,"text":"Credits"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:slime_ball",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Credits"} }}}]
execute at @s run playsound entity.villager.no master @s ~ ~ ~

tellraw @s {"text": "Are you serious? Do you realy want to keep the players from finding out about my other packs?"}
damage @s 2 generic_kill by SturmBueffel100

function ec:ec_menus/settings/layout_page
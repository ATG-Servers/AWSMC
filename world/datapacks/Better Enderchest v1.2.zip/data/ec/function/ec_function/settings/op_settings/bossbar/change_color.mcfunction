clear @s lime_dye[custom_name= {"italic":false,"text":"Change Color"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_dye",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Change Color"} }}}]
execute at @s run playsound item.dye.use master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:21b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~

execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:blue_dye"}]}] run bossbar set enderchest color blue
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:lime_dye"}]}] run bossbar set enderchest color green
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:red_dye"}]}] run bossbar set enderchest color red
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:purple_dye"}]}] run bossbar set enderchest color purple 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:green_dye"}]}] run bossbar set enderchest color green
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:orange_dye"}]}] run bossbar set enderchest color yellow
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:brown_dye"}]}] run bossbar set enderchest color red 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:yellow_dye"}]}] run bossbar set enderchest color yellow 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:white_dye"}]}] run bossbar set enderchest color white 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:light_gray_dye"}]}] run bossbar set enderchest color white 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:gray_dye"}]}] run bossbar set enderchest color white 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:cyan_dye"}]}] run bossbar set enderchest color blue 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:light_blue_dye"}]}] run bossbar set enderchest color blue 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:magenta_dye"}]}] run bossbar set enderchest color purple 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:pink_dye"}]}] run bossbar set enderchest color pink 
execute as @s if entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:black_dye"}]}] run bossbar set enderchest color purple 

function ec:ec_menus/settings/bossbar_page
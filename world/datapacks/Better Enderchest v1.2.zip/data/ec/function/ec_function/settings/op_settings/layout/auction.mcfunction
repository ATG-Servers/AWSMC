clear @s lectern[custom_name= {"italic":false,"text":"Auction"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lectern",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Auction"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add auction ec_layout 1
execute if score auction ec_layout matches 2 run scoreboard players set auction ec_layout 0

function ec:ec_menus/settings/layout_page

$team add $(current) $(name)

$team modify $(current) prefix $(prefix)
$team modify $(current) suffix $(sufix)
$team modify $(current) color $(color)

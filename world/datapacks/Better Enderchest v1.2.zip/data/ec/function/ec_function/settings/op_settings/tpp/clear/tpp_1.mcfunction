clear @s barrier[custom_name= {"italic":false,"text":"Clear Point"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Clear Point"} }}}]
execute at @s run playsound block.fire.extinguish master @s ~ ~ ~
scoreboard players set tpp_1 ec_tpp 0
data remove storage tpp 1


function ec:ec_menus/settings/tpp_page
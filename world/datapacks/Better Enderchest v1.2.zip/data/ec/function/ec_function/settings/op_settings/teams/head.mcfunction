clear @s player_head[item_name= {"text":"player"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:item_name": {"text":"player"} }}}]
function ec:ec_menus/settings/teams_page
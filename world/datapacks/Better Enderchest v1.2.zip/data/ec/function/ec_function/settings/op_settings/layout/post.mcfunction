clear @s writable_book[custom_name= {"italic":false,"text":"Post"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:writable_book",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Post"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add post ec_layout 1
execute if score post ec_layout matches 2 run scoreboard players set post ec_layout 0

function ec:ec_menus/settings/layout_page
#sets the value to the maximum
clear @s warped_hanging_sign[custom_name= {"italic":false,"text":"Bossbar Value"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:warped_hanging_sign",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar Value"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players operation value ec_bossbar = max ec_bossbar

execute store result bossbar enderchest value run scoreboard players get value ec_bossbar
function ec:ec_menus/settings/bossbar_page
clear @s cobweb[custom_name= {"italic":false,"text":"Tic Tac Toe"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:cobweb",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Tic Tac Toe"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add ttt ec_layout 1
execute if score ttt ec_layout matches 2 run scoreboard players set ttt ec_layout 0

function ec:ec_menus/settings/layout_page
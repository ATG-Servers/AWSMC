clear @s name_tag[custom_name= {"italic":false,"text":"Set Name"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:name_tag",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Name"} }}}]
execute at @s unless entity @s[nbt={EnderItems:[{Slot:2b}]}] run playsound entity.villager.no master @s ~ ~ ~
execute at @s if entity @s[nbt={EnderItems:[{Slot:2b}]}] run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:2b}]}] run tellraw @s {"text": "Click again with a renamed Item!","color": "red"}
execute if entity @s[nbt={EnderItems:[{Slot:2b}]}] run data modify storage tpp 1.name set from entity @s EnderItems[{Slot:2b}].components."minecraft:custom_name"

item replace entity @s player.cursor from entity @s enderchest.2

function ec:ec_menus/settings/tpp_page
clear @s breeze_rod[custom_name= {"italic":false,"text":"Toggle Score"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:breeze_rod",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Toggle Score"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add score ec_bossbar 1
execute if score score ec_bossbar matches 2 run scoreboard players set score ec_bossbar 0
execute if score score ec_bossbar matches 0 run bossbar set enderchest name [{"storage": "bossbar","nbt": "name","interpret": true}]

function ec:ec_menus/settings/bossbar_page
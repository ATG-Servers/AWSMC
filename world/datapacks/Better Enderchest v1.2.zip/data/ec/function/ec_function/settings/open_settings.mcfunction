scoreboard players set @s ec_menu 30
execute at @s run playsound ui.button.click master @s ~ ~ ~
clear @s apple[custom_name= {"italic":false,"text":"Settings"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:apple",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Settings"} }}}]
clear @s golden_apple[custom_name= {"italic":false,"text":"Settings","color": "white"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:golden_apple",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Settings","color": "white"} }}}]

function ec:ec_menus/settings/settings_page
clear @s diamond[custom_name= {"italic":false,"text":"Bank"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bank"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add bank ec_layout 1
execute if score bank ec_layout matches 2 run scoreboard players set bank ec_layout 0

function ec:ec_menus/settings/layout_page
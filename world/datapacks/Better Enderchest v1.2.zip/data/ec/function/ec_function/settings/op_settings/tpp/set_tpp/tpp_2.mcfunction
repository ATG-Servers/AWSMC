scoreboard players set @s tpp 0
execute at @s run playsound block.end_portal.spawn master @s ~ ~ ~

execute store result score tpp_2 ec_x run data get entity @s Pos[0]
execute store result score tpp_2 ec_y run data get entity @s Pos[1]
execute store result score tpp_2 ec_z run data get entity @s Pos[2]
tellraw @s ["",{"text":"Teleport Point #2 created at ","color":"light_purple"},{"score":{"name":"@s","objective":"ec_x"},"color":"dark_purple"},{"text":" | ","color":"dark_gray"},{"score":{"name":"@s","objective":"ec_y"},"color":"dark_purple"},{"text":" | ","color":"dark_gray"},{"score":{"name":"@s","objective":"ec_z"},"color":"dark_purple"}]

execute at @s if dimension overworld run scoreboard players set tpp_2 ec_tpp_dimension 0
execute at @s if dimension the_nether run scoreboard players set tpp_2 ec_tpp_dimension 1
execute at @s if dimension the_end run scoreboard players set tpp_2 ec_tpp_dimension 2
data modify storage tpp 2.item set value "minecraft:ender_pearl"
data modify storage tpp 2.name set value {"text":"TP Point #2"}
scoreboard players set tpp_2 ec_tpp 1
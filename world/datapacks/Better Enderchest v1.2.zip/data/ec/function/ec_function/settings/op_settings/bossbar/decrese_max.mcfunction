clear @s player_head[custom_name= {"italic":false,"text":"Decrese Max"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Decrese Max"} }}}]
execute unless score max ec_bossbar matches ..1 at @s run playsound ui.button.click master @s ~ ~ ~
execute if score max ec_bossbar matches ..1 at @s run playsound entity.villager.no master @s ~ ~ ~

execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "1" }}]}] run scoreboard players set @s ec_bank_interaction 1
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "10" }}]}] run scoreboard players set @s ec_bank_interaction 10
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "100" }}]}] run scoreboard players set @s ec_bank_interaction 100
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "1000" }}]}] run scoreboard players set @s ec_bank_interaction 1000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "10000" }}]}] run scoreboard players set @s ec_bank_interaction 10000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "100000" }}]}] run scoreboard players set @s ec_bank_interaction 100000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "1000000" }}]}] run scoreboard players set @s ec_bank_interaction 1000000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "10000000" }}]}] run scoreboard players set @s ec_bank_interaction 10000000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "100000000" }}]}] run scoreboard players set @s ec_bank_interaction 100000000
execute if entity @s[nbt={EnderItems:[{Slot:11b,components:{"minecraft:custom_name": "1000000000" }}]}] run scoreboard players set @s ec_bank_interaction 1000000000

execute if entity @s[nbt={EnderItems:[{Slot:11b}]}] run scoreboard players operation max ec_bossbar -= @s ec_bank_interaction
execute if entity @s[nbt=!{EnderItems:[{Slot:11b}]}] run scoreboard players operation max ec_bossbar -= @s ec_interaction

execute if score max ec_bossbar matches ..1 run scoreboard players set max ec_bossbar 1
execute if score value ec_bossbar > max ec_bossbar run scoreboard players operation value ec_bossbar = max ec_bossbar

item replace entity @s player.cursor from entity @s enderchest.11
scoreboard players set @s ec_bank_interaction 1
execute store result bossbar enderchest max run scoreboard players get max ec_bossbar
execute store result bossbar enderchest value run scoreboard players get value ec_bossbar
function ec:ec_menus/settings/bossbar_page
clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Set Interaction Rate"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Interaction Rate"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

execute unless entity @s[nbt={EnderItems:[{Slot:18b}]}] run tellraw @s {"text": "Click again with renamed Item!","color": "red"}
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "1" }}]}] run scoreboard players set @s ec_interaction 1
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "10" }}]}] run scoreboard players set @s ec_interaction 10
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "100" }}]}] run scoreboard players set @s ec_interaction 100
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "1000" }}]}] run scoreboard players set @s ec_interaction 1000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "10000" }}]}] run scoreboard players set @s ec_interaction 10000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "100000" }}]}] run scoreboard players set @s ec_interaction 100000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "1000000" }}]}] run scoreboard players set @s ec_interaction 1000000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "10000000" }}]}] run scoreboard players set @s ec_interaction 10000000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "100000000" }}]}] run scoreboard players set @s ec_interaction 100000000
execute if entity @s[nbt={EnderItems:[{Slot:18b,components:{"minecraft:custom_name": "1000000000" }}]}] run scoreboard players set @s ec_interaction 1000000000

item replace entity @s player.cursor from entity @s enderchest.18

function ec:ec_menus/settings/settings_page
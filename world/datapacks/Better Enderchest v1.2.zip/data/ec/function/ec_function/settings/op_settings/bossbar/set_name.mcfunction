clear @s name_tag[custom_name= {"italic":false,"text":"Set Name"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:name_tag",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Set Name"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:22b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:22b}]}] run tellraw @s {"text": "Click again with renamed Item!","color": "red"}
execute if entity @s[nbt={EnderItems:[{Slot:22b}]}] run data modify storage bossbar name set from entity @s EnderItems[{Slot:22b}].components."minecraft:custom_name"

bossbar set enderchest name [{"storage": "bossbar","nbt": "name","interpret": true}]

item replace entity @s player.cursor from entity @s enderchest.22

function ec:ec_menus/settings/bossbar_page
scoreboard players set @s ec_menu 52
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s ender_chest[custom_name= {"italic":false,"text":"Customize Layout"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Customize Layout"} }}}]

function ec:ec_menus/settings/layout_page
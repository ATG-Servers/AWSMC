clear @s nether_star[custom_name= {"italic":false,"text":"Create Team"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Create Team"} }}}]
execute at @s run playsound entity.wither.spawn master @s ~ ~ ~

execute store result storage team current int 1 run scoreboard players get current ec_team
function ec:ec_function/settings/op_settings/teams/create with storage team
scoreboard players add current ec_team 1
tellraw @s ["","Team ",{"nbt":"current","storage":"team"}," created!"," (",{"nbt":"prefix","storage":"team","interpret":true},{"nbt":"name","storage":"team","interpret":true},{"nbt":"sufix","storage":"team","interpret":true},")"]
data remove storage team sufix
data remove storage team prefix
data remove storage team name
data remove storage team color

function ec:ec_function/settings/op_settings/open_op_settings
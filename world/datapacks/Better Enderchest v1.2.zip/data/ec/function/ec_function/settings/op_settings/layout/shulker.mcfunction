clear @s lime_shulker_box[custom_name= {"italic":false,"text":"Shulker Box Loader"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_shulker_box",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Shulker Box Loader"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add shulker ec_layout 1
execute if score shulker ec_layout matches 2 run scoreboard players set shulker ec_layout 0

function ec:ec_menus/settings/layout_page
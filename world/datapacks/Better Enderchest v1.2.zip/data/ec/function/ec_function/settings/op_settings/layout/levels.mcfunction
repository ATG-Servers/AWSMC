clear @s experience_bottle[custom_name= {"italic":false,"text":"Levels"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:experience_bottle",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Levels"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add level ec_layout 1
execute if score level ec_layout matches 3 run scoreboard players set level ec_layout 0

function ec:ec_menus/settings/layout_page
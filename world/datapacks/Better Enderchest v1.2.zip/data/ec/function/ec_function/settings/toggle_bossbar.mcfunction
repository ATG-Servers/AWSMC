execute if entity @s[nbt=!{EnderItems:[{Slot:13b}]}] run item replace entity @s enderchest.13 from entity @s player.cursor
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s music_disc_precipice[custom_name= {"italic":false,"text":"Toggle Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:music_disc_precipice",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Toggle Bossbar"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar"} }}}]

clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"Bossbar"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar"} }}}]


execute if entity @s[nbt={EnderItems:[{Slot:13b,id:"minecraft:lime_stained_glass_pane"}]}] run tag @s add no_bossbar
execute if entity @s[nbt={EnderItems:[{Slot:13b,id:"minecraft:red_stained_glass_pane"}]}] run tag @s remove no_bossbar

function ec:ec_menus/settings/settings_page
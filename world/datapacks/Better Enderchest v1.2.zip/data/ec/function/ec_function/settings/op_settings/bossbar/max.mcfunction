clear @s crimson_hanging_sign[custom_name= {"italic":false,"text":"Bossbar Max"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:crimson_hanging_sign",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar Max"} }}}]


function ec:ec_menus/settings/bossbar_page
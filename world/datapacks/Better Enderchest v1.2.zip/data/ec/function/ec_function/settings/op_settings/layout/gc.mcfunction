clear @s barrel[custom_name= {"italic":false,"text":"Group Chest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrel",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Group Chest"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add gc ec_layout 1
execute if score gc ec_layout matches 2 run scoreboard players set gc ec_layout 0

function ec:ec_menus/settings/layout_page
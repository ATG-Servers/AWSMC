clear @s anvil[custom_name= {"italic":false,"text":"Anvil"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:anvil",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Anvil"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players add anvil ec_layout 1
execute if score anvil ec_layout matches 2 run scoreboard players set anvil ec_layout 0

function ec:ec_menus/settings/layout_page
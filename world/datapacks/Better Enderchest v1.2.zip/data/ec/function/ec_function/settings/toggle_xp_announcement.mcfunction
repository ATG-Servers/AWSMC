execute if entity @s[nbt=!{EnderItems:[{Slot:14b}]}] run item replace entity @s enderchest.14 from entity @s player.cursor
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s name_tag[custom_name= {"italic":false,"text":"XP Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:name_tag",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"XP Announcement"} }}}]

clear @s red_stained_glass_pane[custom_name= {"italic":false,"text":"XP Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"XP Announcement"} }}}]

clear @s lime_stained_glass_pane[custom_name= {"italic":false,"text":"XP Announcement"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"XP Announcement"} }}}]


# execute if entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:lime_stained_glass_pane"}]}] run tag @s add no_xp_announcement
# execute if entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:red_stained_glass_pane"}]}] run tag @s remove no_xp_announcement

execute if entity @s[tag=no_xp_announcement] run tag @s add no_xp_announcement_process
execute if entity @s[tag=!no_xp_announcement_process] run tag @s add no_xp_announcement
execute if entity @s[tag=no_xp_announcement_process] run tag @s remove no_xp_announcement
tag @s remove no_xp_announcement_process

function ec:ec_menus/settings/settings_page
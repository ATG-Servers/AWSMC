item replace entity @s player.cursor with air
# execute if entity @s[nbt={Inventory:[{Slot:0b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.0 with air
# execute if entity @s[nbt={Inventory:[{Slot:1b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.1 with air
# execute if entity @s[nbt={Inventory:[{Slot:2b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.2 with air
# execute if entity @s[nbt={Inventory:[{Slot:3b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.3 with air
# execute if entity @s[nbt={Inventory:[{Slot:4b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.4 with air
# execute if entity @s[nbt={Inventory:[{Slot:5b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.5 with air
# execute if entity @s[nbt={Inventory:[{Slot:6b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.6 with air
# execute if entity @s[nbt={Inventory:[{Slot:7b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.7 with air
# execute if entity @s[nbt={Inventory:[{Slot:8b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s hotbar.8 with air
# execute if entity @s[nbt={Inventory:[{Slot:9b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.0 with air
# execute if entity @s[nbt={Inventory:[{Slot:10b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.1 with air
# execute if entity @s[nbt={Inventory:[{Slot:11b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.2 with air
# execute if entity @s[nbt={Inventory:[{Slot:12b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.3 with air
# execute if entity @s[nbt={Inventory:[{Slot:13b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.4 with air
# execute if entity @s[nbt={Inventory:[{Slot:14b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.5 with air
# execute if entity @s[nbt={Inventory:[{Slot:15b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.6 with air
# execute if entity @s[nbt={Inventory:[{Slot:16b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.7 with air
# execute if entity @s[nbt={Inventory:[{Slot:17b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.8 with air
# execute if entity @s[nbt={Inventory:[{Slot:18b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.9 with air
# execute if entity @s[nbt={Inventory:[{Slot:19b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.10 with air
# execute if entity @s[nbt={Inventory:[{Slot:20b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.11 with air
# execute if entity @s[nbt={Inventory:[{Slot:21b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.12 with air
# execute if entity @s[nbt={Inventory:[{Slot:22b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.13 with air
# execute if entity @s[nbt={Inventory:[{Slot:23b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.14 with air
# execute if entity @s[nbt={Inventory:[{Slot:24b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.15 with air
# execute if entity @s[nbt={Inventory:[{Slot:25b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.16 with air
# execute if entity @s[nbt={Inventory:[{Slot:26b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.17 with air
# execute if entity @s[nbt={Inventory:[{Slot:27b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.18 with air
# execute if entity @s[nbt={Inventory:[{Slot:28b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.19 with air
# execute if entity @s[nbt={Inventory:[{Slot:29b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.20 with air
# execute if entity @s[nbt={Inventory:[{Slot:30b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.21 with air
# execute if entity @s[nbt={Inventory:[{Slot:31b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.22 with air
# execute if entity @s[nbt={Inventory:[{Slot:32b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.23 with air
# execute if entity @s[nbt={Inventory:[{Slot:33b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.24 with air
# execute if entity @s[nbt={Inventory:[{Slot:34b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.25 with air
# execute if entity @s[nbt={Inventory:[{Slot:35b,components:{"minecraft:custom_data":{tpp:1}}}]}] run item replace entity @s inventory.26 with air
execute at @s unless entity @s[nbt={EnderItems:[{Slot:15b}]}] run playsound entity.villager.no master @s ~ ~ ~
execute at @s if entity @s[nbt={EnderItems:[{Slot:15b}]}] run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:15b}]}] run tellraw @s {"text": "Click again with an Item!","color": "red"}
clear @s *[custom_data={tpp:1}]
kill @e[type=item,nbt={Item:{count:1,components:{"minecraft:custom_data":{tpp:1}}}}]

execute if entity @s[nbt={EnderItems:[{Slot:15b}]}] run data modify storage tpp 5.item set from entity @s EnderItems[{Slot:15b}].id
item replace entity @s player.cursor from entity @s enderchest.15

function ec:ec_menus/settings/tpp_page
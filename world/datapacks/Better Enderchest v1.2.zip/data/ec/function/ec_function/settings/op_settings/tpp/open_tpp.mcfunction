scoreboard players set @s ec_menu 36
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s ender_eye[custom_name= {"italic":false,"text":"TP Points"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_eye",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"TP Points"} }}}]


function ec:ec_menus/settings/tpp_page
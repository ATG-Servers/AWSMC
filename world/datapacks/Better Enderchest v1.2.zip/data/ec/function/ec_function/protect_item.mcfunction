data modify entity @s Item.components."minecraft:custom_data" set value {protect:1b}
kill @n[type=item,nbt={Item:{id:"minecraft:diamond",count:1}}]

execute at @s run playsound block.smithing_table.use master @p ~ ~ ~
particle ash ~ ~ ~ 0 0 0 1 100 normal
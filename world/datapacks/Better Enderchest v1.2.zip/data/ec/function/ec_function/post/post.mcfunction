scoreboard players set @s ec_menu 7
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s writable_book[custom_name= {"italic":false,"text":"Post"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:writable_book",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Post"} }}}]

execute as @s run function ec:ec_menus/post_page
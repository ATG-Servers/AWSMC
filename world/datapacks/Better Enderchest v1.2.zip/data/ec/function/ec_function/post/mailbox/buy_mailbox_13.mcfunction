scoreboard players set @s ec_menu 20
scoreboard players set @s ec_mailbox 13
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_13 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_13
clear @s ink_sac[custom_name= {"italic":false,"text":"Write Address"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ink_sac",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Write Address"} }}}]

execute if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] if score @s ec_mailbox matches 1.. at @s run playsound item.book.put master @s ~ ~ ~
execute unless data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless score @s ec_mailbox matches 1.. at @s run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_mailbox matches 1 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"1"] ],custom_name= {"text": "Address","italic": false} ,item_name= "1" ]
execute if score @s ec_mailbox matches 2 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"2"] ],custom_name= {"text": "Address","italic": false} ,item_name= "2" ]
execute if score @s ec_mailbox matches 3 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"3"] ],custom_name= {"text": "Address","italic": false} ,item_name= "3" ]
execute if score @s ec_mailbox matches 4 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"4"] ],custom_name= {"text": "Address","italic": false} ,item_name= "4" ]
execute if score @s ec_mailbox matches 5 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"5"] ],custom_name= {"text": "Address","italic": false} ,item_name= "5" ]
execute if score @s ec_mailbox matches 6 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"6"] ],custom_name= {"text": "Address","italic": false} ,item_name= "6" ]
execute if score @s ec_mailbox matches 7 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"7"] ],custom_name= {"text": "Address","italic": false} ,item_name= "7" ]
execute if score @s ec_mailbox matches 8 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"8"] ],custom_name= {"text": "Address","italic": false} ,item_name= "8" ]
execute if score @s ec_mailbox matches 9 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"9"] ],custom_name= {"text": "Address","italic": false} ,item_name= "9" ]
execute if score @s ec_mailbox matches 10 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"10"] ],custom_name= {"text": "Address","italic": false} ,item_name= "10" ]
execute if score @s ec_mailbox matches 11 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"11"] ],custom_name= {"text": "Address","italic": false} ,item_name= "11" ]
execute if score @s ec_mailbox matches 12 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"12"] ],custom_name= {"text": "Address","italic": false} ,item_name= "12" ]
execute if score @s ec_mailbox matches 13 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"13"] ],custom_name= {"text": "Address","italic": false} ,item_name= "13" ]
execute if score @s ec_mailbox matches 14 if data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor with paper[lore=[ [{"italic":false,"text":"Mailbox: "},"14"] ],custom_name= {"text": "Address","italic": false} ,item_name= "14" ]

execute unless score @s ec_mailbox matches 1..14 run tellraw @s {"text": "You don t have a Mailbox!", "color": "red"}
execute unless score @s ec_mailbox matches 1..14 run item replace entity @s player.cursor from entity @s enderchest.25
execute if score @s ec_mailbox matches 1..14 unless data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run tellraw @s {"text": "Click again with a paper!", "color": "red"}
execute if score @s ec_mailbox matches 1..14 unless data entity @s EnderItems[{Slot:25b,id:"minecraft:paper"}] run item replace entity @s player.cursor from entity @s enderchest.25
execute as @s run function ec:ec_menus/post_page
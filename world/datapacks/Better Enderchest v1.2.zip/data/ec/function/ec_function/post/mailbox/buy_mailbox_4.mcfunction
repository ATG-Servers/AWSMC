scoreboard players set @s ec_menu 11
scoreboard players set @s ec_mailbox 4
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_4 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_4
clear @s gold_ingot[custom_name= {"italic":false,"text":"Collect Money"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gold_ingot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Collect Money"} }}}]

execute at @s run playsound ui.button.click master @s ~ ~ ~

execute if score @s ec_menu matches 8 run scoreboard players operation @s ec_money += mailbox_1 ec_mail_money
execute if score @s ec_menu matches 8 run scoreboard players set mailbox_1 ec_mail_money 0
execute if score @s ec_menu matches 9 run scoreboard players operation @s ec_money += mailbox_2 ec_mail_money
execute if score @s ec_menu matches 9 run scoreboard players set mailbox_2 ec_mail_money 0
execute if score @s ec_menu matches 10 run scoreboard players operation @s ec_money += mailbox_3 ec_mail_money
execute if score @s ec_menu matches 10 run scoreboard players set mailbox_3 ec_mail_money 0
execute if score @s ec_menu matches 11 run scoreboard players operation @s ec_money += mailbox_4 ec_mail_money
execute if score @s ec_menu matches 11 run scoreboard players set mailbox_4 ec_mail_money 0
execute if score @s ec_menu matches 12 run scoreboard players operation @s ec_money += mailbox_5 ec_mail_money
execute if score @s ec_menu matches 12 run scoreboard players set mailbox_5 ec_mail_money 0
execute if score @s ec_menu matches 13 run scoreboard players operation @s ec_money += mailbox_6 ec_mail_money
execute if score @s ec_menu matches 13 run scoreboard players set mailbox_6 ec_mail_money 0
execute if score @s ec_menu matches 14 run scoreboard players operation @s ec_money += mailbox_7 ec_mail_money
execute if score @s ec_menu matches 14 run scoreboard players set mailbox_7 ec_mail_money 0
execute if score @s ec_menu matches 15 run scoreboard players operation @s ec_money += mailbox_8 ec_mail_money
execute if score @s ec_menu matches 15 run scoreboard players set mailbox_8 ec_mail_money 0
execute if score @s ec_menu matches 16 run scoreboard players operation @s ec_money += mailbox_9 ec_mail_money
execute if score @s ec_menu matches 16 run scoreboard players set mailbox_9 ec_mail_money 0
execute if score @s ec_menu matches 17 run scoreboard players operation @s ec_money += mailbox_10 ec_mail_money
execute if score @s ec_menu matches 17 run scoreboard players set mailbox_10 ec_mail_money 0
execute if score @s ec_menu matches 18 run scoreboard players operation @s ec_money += mailbox_11 ec_mail_money
execute if score @s ec_menu matches 18 run scoreboard players set mailbox_11 ec_mail_money 0
execute if score @s ec_menu matches 19 run scoreboard players operation @s ec_money += mailbox_12 ec_mail_money
execute if score @s ec_menu matches 19 run scoreboard players set mailbox_12 ec_mail_money 0
execute if score @s ec_menu matches 20 run scoreboard players operation @s ec_money += mailbox_13 ec_mail_money
execute if score @s ec_menu matches 20 run scoreboard players set mailbox_13 ec_mail_money 0
execute if score @s ec_menu matches 21 run scoreboard players operation @s ec_money += mailbox_14 ec_mail_money
execute if score @s ec_menu matches 21 run scoreboard players set mailbox_14 ec_mail_money 0

item replace entity @s enderchest.8 with gold_ingot[custom_name= {"italic":false,"text":"Collect Money"} ,custom_data={"better_ec":1b}]
execute if score @s ec_menu matches 8 run item modify entity @s enderchest.8 ec:mailbox/lore_money_1
execute if score @s ec_menu matches 9 run item modify entity @s enderchest.8 ec:mailbox/lore_money_2
execute if score @s ec_menu matches 10 run item modify entity @s enderchest.8 ec:mailbox/lore_money_3
execute if score @s ec_menu matches 11 run item modify entity @s enderchest.8 ec:mailbox/lore_money_4
execute if score @s ec_menu matches 12 run item modify entity @s enderchest.8 ec:mailbox/lore_money_5
execute if score @s ec_menu matches 13 run item modify entity @s enderchest.8 ec:mailbox/lore_money_6
execute if score @s ec_menu matches 14 run item modify entity @s enderchest.8 ec:mailbox/lore_money_7
execute if score @s ec_menu matches 15 run item modify entity @s enderchest.8 ec:mailbox/lore_money_8
execute if score @s ec_menu matches 16 run item modify entity @s enderchest.8 ec:mailbox/lore_money_9
execute if score @s ec_menu matches 17 run item modify entity @s enderchest.8 ec:mailbox/lore_money_10
execute if score @s ec_menu matches 18 run item modify entity @s enderchest.8 ec:mailbox/lore_money_11
execute if score @s ec_menu matches 19 run item modify entity @s enderchest.8 ec:mailbox/lore_money_12
execute if score @s ec_menu matches 20 run item modify entity @s enderchest.8 ec:mailbox/lore_money_13
execute if score @s ec_menu matches 21 run item modify entity @s enderchest.8 ec:mailbox/lore_money_14

execute if score @s ec_send_mail matches 1 run advancement grant @a[scores={ec_mailbox=1},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 2 run advancement grant @a[scores={ec_mailbox=2},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 3 run advancement grant @a[scores={ec_mailbox=3},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 4 run advancement grant @a[scores={ec_mailbox=4},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 5 run advancement grant @a[scores={ec_mailbox=5},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 6 run advancement grant @a[scores={ec_mailbox=6},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 7 run advancement grant @a[scores={ec_mailbox=7},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 8 run advancement grant @a[scores={ec_mailbox=8},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 9 run advancement grant @a[scores={ec_mailbox=9},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 10 run advancement grant @a[scores={ec_mailbox=10},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 11 run advancement grant @a[scores={ec_mailbox=11},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 12 run advancement grant @a[scores={ec_mailbox=12},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 13 run advancement grant @a[scores={ec_mailbox=13},tag=!no_mail_announcement] only ec:announce_mail
execute if score @s ec_send_mail matches 14 run advancement grant @a[scores={ec_mailbox=14},tag=!no_mail_announcement] only ec:announce_mail

schedule function ec:ec_function/post/clear_announcement 5t replace
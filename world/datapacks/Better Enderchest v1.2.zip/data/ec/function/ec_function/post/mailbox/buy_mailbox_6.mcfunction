scoreboard players set @s ec_menu 13
scoreboard players set @s ec_mailbox 6
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_6 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_6
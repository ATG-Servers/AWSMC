clear @s nautilus_shell[custom_name= {"italic":false,"text":"Mailbox #12"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nautilus_shell",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Mailbox #12"} }}}]
execute unless score @s ec_mailbox matches 0 unless score @s ec_mailbox matches 12 run tellraw @s {"text": "You already own a mailbox!","color": "red"} 
execute if score @s ec_mailbox matches 12 at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_mailbox matches 12 at @s run playsound entity.villager.no master @s ~ ~ ~

#buy_mailbox
execute as @s unless score mailbox_12 ec_mailbox matches 1 if score @s ec_money >= mailbox ec_shop_price as @s if score @s ec_mailbox matches 0 run function ec:ec_function/post/mailbox/buy_mailbox_12

#occupied_mailbox
execute unless score @s ec_mailbox matches 12 if score mailbox_12 ec_mailbox matches 1 run tellraw @s {"text": "Mailbox is occupied!","color": "red"}

#open mailbox
execute if score @s ec_mailbox matches 12 at @s run function ec:ec_menus/mailbox/mailbox_12
execute if score @s ec_mailbox matches 12 run scoreboard players set @s ec_menu 19


execute unless score @s ec_mailbox matches 12 run function ec:ec_menus/post_page




item replace entity @s player.cursor from entity @s enderchest.24
kill @n[type=item,nbt={Item:{id:"minecraft:red_stained_glass_pane",count:1}}]

item replace entity @s enderchest.24 with red_stained_glass_pane[tooltip_display={hide_tooltip:true}]
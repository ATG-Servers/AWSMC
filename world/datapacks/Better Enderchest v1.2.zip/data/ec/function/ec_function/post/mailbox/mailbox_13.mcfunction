clear @s nautilus_shell[custom_name= {"italic":false,"text":"Mailbox #13"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nautilus_shell",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Mailbox #13"} }}}]
execute unless score @s ec_mailbox matches 0 unless score @s ec_mailbox matches 13 run tellraw @s {"text": "You already own a mailbox!","color": "red"} 
execute if score @s ec_mailbox matches 13 at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_mailbox matches 13 at @s run playsound entity.villager.no master @s ~ ~ ~

#buy_mailbox
execute as @s unless score mailbox_13 ec_mailbox matches 1 if score @s ec_money >= mailbox ec_shop_price as @s if score @s ec_mailbox matches 0 run function ec:ec_function/post/mailbox/buy_mailbox_13

#occupied_mailbox
execute unless score @s ec_mailbox matches 13 if score mailbox_13 ec_mailbox matches 1 run tellraw @s {"text": "Mailbox is occupied!","color": "red"}

#open mailbox
execute if score @s ec_mailbox matches 13 at @s run function ec:ec_menus/mailbox/mailbox_13
execute if score @s ec_mailbox matches 13 run scoreboard players set @s ec_menu 20


execute unless score @s ec_mailbox matches 13 run function ec:ec_menus/post_page




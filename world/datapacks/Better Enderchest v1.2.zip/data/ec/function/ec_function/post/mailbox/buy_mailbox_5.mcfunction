scoreboard players set @s ec_menu 12
scoreboard players set @s ec_mailbox 5
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_5 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_5
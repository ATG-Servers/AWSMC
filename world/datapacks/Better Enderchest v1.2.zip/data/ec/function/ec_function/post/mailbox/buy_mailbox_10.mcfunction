scoreboard players set @s ec_menu 17
scoreboard players set @s ec_mailbox 10
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_10 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_10
clear @s feather[custom_name= {"italic":false,"text":"Select Consignee"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:feather",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Select Consignee"} }}}]

execute if entity @s[nbt={EnderItems:[{Slot:19b}]}] at @s run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:19b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~

tag @s remove ec_mailslot_1
tag @s remove ec_mailslot_2
tag @s remove ec_mailslot_3
tag @s remove ec_mailslot_4
tag @s remove ec_mailslot_5

item replace entity @s player.cursor from entity @s enderchest.19
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "1" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_1
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "2" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_2
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "3" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_3
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "4" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_4
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "5" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_5
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "6" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_6
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "7" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_7
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "8" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_8
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "9" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_9
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "10" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_10
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "11" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_11
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "12" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_12
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "13" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_13
execute if entity @s[nbt={EnderItems:[{Slot:19b,components:{"minecraft:item_name": "14" }}]}] at @s run function ec:ec_function/post/mailbox/load_send/mailbox_14
execute unless entity @s[nbt={EnderItems:[{Slot:19b,id:"minecraft:feather"}]}] run item replace entity @s enderchest.19 with feather[custom_name= {"italic":false,"text":"Select Consignee"} ,custom_data={"better_ec":1b}]

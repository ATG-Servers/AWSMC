clear @s barrier[custom_name= {"italic":false,"text":"Quit Mailbox"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Quit Mailbox"} }}}]
execute at @s run playsound entity.generic.burn master @s ~ ~ ~

execute if score @s ec_menu matches 8 run scoreboard players set mailbox_1 ec_mailbox 0
execute if score @s ec_menu matches 9 run scoreboard players set mailbox_2 ec_mailbox 0
execute if score @s ec_menu matches 10 run scoreboard players set mailbox_3 ec_mailbox 0
execute if score @s ec_menu matches 11 run scoreboard players set mailbox_4 ec_mailbox 0
execute if score @s ec_menu matches 12 run scoreboard players set mailbox_5 ec_mailbox 0
execute if score @s ec_menu matches 13 run scoreboard players set mailbox_6 ec_mailbox 0
execute if score @s ec_menu matches 14 run scoreboard players set mailbox_7 ec_mailbox 0
execute if score @s ec_menu matches 15 run scoreboard players set mailbox_8 ec_mailbox 0
execute if score @s ec_menu matches 16 run scoreboard players set mailbox_9 ec_mailbox 0
execute if score @s ec_menu matches 17 run scoreboard players set mailbox_10 ec_mailbox 0
execute if score @s ec_menu matches 18 run scoreboard players set mailbox_11 ec_mailbox 0
execute if score @s ec_menu matches 19 run scoreboard players set mailbox_12 ec_mailbox 0
execute if score @s ec_menu matches 20 run scoreboard players set mailbox_13 ec_mailbox 0
execute if score @s ec_menu matches 21 run scoreboard players set mailbox_14 ec_mailbox 0

scoreboard players set @s ec_mailbox 0
scoreboard players operation @s ec_money += mailbox_quit ec_shop_price
function ec:ec_function/back_to_post
scoreboard players set @s ec_menu 7
scoreboard players set @s ec_menu 10
scoreboard players set @s ec_mailbox 3
scoreboard players operation @s ec_money -= mailbox ec_shop_price
scoreboard players set mailbox_3 ec_mailbox 1
function ec:ec_menus/mailbox/mailbox_3
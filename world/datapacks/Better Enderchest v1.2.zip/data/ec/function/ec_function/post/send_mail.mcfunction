clear @s feather[custom_name= {"italic":false,"text":"Send Mail"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:feather",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Send Mail"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

summon chest_minecart ~ ~2 ~ {NoGravity:1b, Tags:[mailbox]}

execute if score @s ec_send_mail matches 1 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_1
execute if score @s ec_send_mail matches 2 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_2
execute if score @s ec_send_mail matches 3 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_3
execute if score @s ec_send_mail matches 4 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_4
execute if score @s ec_send_mail matches 5 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_5
execute if score @s ec_send_mail matches 6 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_6
execute if score @s ec_send_mail matches 7 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_7
execute if score @s ec_send_mail matches 8 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_8
execute if score @s ec_send_mail matches 9 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_9
execute if score @s ec_send_mail matches 10 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_10
execute if score @s ec_send_mail matches 11 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_11
execute if score @s ec_send_mail matches 12 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_12
execute if score @s ec_send_mail matches 13 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_13
execute if score @s ec_send_mail matches 14 run data modify entity @n[tag=mailbox] Items set from storage mailboxes mailbox_14

execute if score @s ec_money matches 10.. unless entity @s[nbt={EnderItems:[{Slot:20b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[type=chest_minecart,tag=mailbox] container.11 from entity @s enderchest.20
execute if score @s ec_money matches 10.. unless entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[type=chest_minecart,tag=mailbox] container.12 from entity @s enderchest.21
execute if score @s ec_money matches 10.. unless entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[type=chest_minecart,tag=mailbox] container.13 from entity @s enderchest.22
execute if score @s ec_money matches 10.. unless entity @s[nbt={EnderItems:[{Slot:23b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[type=chest_minecart,tag=mailbox] container.14 from entity @s enderchest.23
execute if score @s ec_money matches 10.. unless entity @s[nbt={EnderItems:[{Slot:24b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[type=chest_minecart,tag=mailbox] container.15 from entity @s enderchest.24

execute if score @s ec_send_mail matches 1 run data modify storage mailboxes mailbox_1 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 2 run data modify storage mailboxes mailbox_2 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 3 run data modify storage mailboxes mailbox_3 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 4 run data modify storage mailboxes mailbox_4 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 5 run data modify storage mailboxes mailbox_5 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 6 run data modify storage mailboxes mailbox_6 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 7 run data modify storage mailboxes mailbox_7 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 8 run data modify storage mailboxes mailbox_8 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 9 run data modify storage mailboxes mailbox_9 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 10 run data modify storage mailboxes mailbox_10 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 11 run data modify storage mailboxes mailbox_11 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 12 run data modify storage mailboxes mailbox_12 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 13 run data modify storage mailboxes mailbox_13 set from entity @n[type=chest_minecart,tag=mailbox] Items
execute if score @s ec_send_mail matches 14 run data modify storage mailboxes mailbox_14 set from entity @n[type=chest_minecart,tag=mailbox] Items

data merge entity @n[type=chest_minecart,tag=mailbox] {Items:[]}
kill @n[tag=mailbox]

tag @s remove ec_mailslot_1
tag @s remove ec_mailslot_2
tag @s remove ec_mailslot_3
tag @s remove ec_mailslot_4
tag @s remove ec_mailslot_5

execute if score @s ec_money matches 10.. run function ec:ec_function/post/announce_mail

item replace entity @s player.cursor from entity @s enderchest.19

execute if score @s ec_money matches 10.. run function ec:ec_function/post/post
execute unless score @s ec_money matches 10.. run function ec:ec_menus/post_page_mail
execute unless score @s ec_money matches 10.. run tellraw @s {"text": "You don t have enough money!","color": "red"}
execute if score @s ec_money matches 10.. run scoreboard players remove @s ec_money 10

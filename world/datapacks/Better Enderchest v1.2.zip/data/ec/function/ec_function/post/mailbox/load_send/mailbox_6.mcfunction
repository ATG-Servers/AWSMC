function ec:ec_menus/post_page_mail
summon chest_minecart ~ ~2 ~ {NoGravity:1b, Tags:[mailbox]}
scoreboard players set @s ec_send_mail 6


data modify entity @n[tag=mailbox,type=chest_minecart] Items set from storage mailboxes mailbox_6
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:11b}] run tag @s add ec_mailslot_1
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:12b}] run tag @s add ec_mailslot_2
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:13b}] run tag @s add ec_mailslot_3
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:14b}] run tag @s add ec_mailslot_4
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:15b}] run tag @s add ec_mailslot_5
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:11b}] run item replace entity @n[tag=mailbox,type=chest_minecart] container.11 with red_stained_glass_pane
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:12b}] run item replace entity @n[tag=mailbox,type=chest_minecart] container.12 with red_stained_glass_pane
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:13b}] run item replace entity @n[tag=mailbox,type=chest_minecart] container.13 with red_stained_glass_pane
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:14b}] run item replace entity @n[tag=mailbox,type=chest_minecart] container.14 with red_stained_glass_pane
execute if data entity @n[tag=mailbox,type=chest_minecart] Items[{Slot:15b}] run item replace entity @n[tag=mailbox,type=chest_minecart] container.15 with red_stained_glass_pane
item replace entity @s enderchest.20 from entity @n[tag=mailbox,type=chest_minecart] container.11
item replace entity @s enderchest.21 from entity @n[tag=mailbox,type=chest_minecart] container.12
item replace entity @s enderchest.22 from entity @n[tag=mailbox,type=chest_minecart] container.13
item replace entity @s enderchest.23 from entity @n[tag=mailbox,type=chest_minecart] container.14
item replace entity @s enderchest.24 from entity @n[tag=mailbox,type=chest_minecart] container.15

data merge entity @n[type=chest_minecart,tag=mailbox] {Items:[]}
kill @n[tag=mailbox,type=chest_minecart]

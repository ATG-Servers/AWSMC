clear @s gray_stained_glass_pane[custom_name= {"italic":false,"text":"No Consignee selected"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gray_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"No Consignee selected"} }}}]


execute as @s run function ec:ec_menus/post_page

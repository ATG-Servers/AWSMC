execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[smithing]}

execute at @s run item replace entity @n[type=chest_minecart,tag=smithing] container.0 with netherite_helmet[item_name= {"color":"dark_green","text":"Mythril Helmet"} ,unbreakable={},custom_model_data={floats:[1]},custom_data={mythril:1b},attribute_modifiers=[{id:"ec_armor_helmet",type:"armor",amount:5,operation:"add_value",slot:"chest"}]] 1
execute at @s run data modify entity @n[tag=smithing,type=chest_minecart] Items[{Slot:0b}].components set from entity @s EnderItems[{Slot:13b}].components
execute at @s run item modify entity @n[tag=smithing,type=chest_minecart] container.0 {function:set_lore,mode:"insert",offset:0,entity:"this",lore:[{text:"Mythril",color:"green",italic:false}]}
execute at @s run item modify entity @n[tag=smithing,type=chest_minecart] container.0 {function:set_components,components:{unbreakable:{},custom_data:{mythril:1b},custom_model_data:{floats:[1]},tooltip_display:{hidden_components:[trim]},attribute_modifiers:[{id:"ec_armor_helmet",type:"armor",amount:5,operation:"add_value",slot:"chest"}],trim:{material:"emerald",pattern:"spire"}}}
execute at @s run item replace entity @n enderchest.13 from entity @n[tag=smithing,type=chest_minecart] container.0
execute at @s run item replace entity @n[tag=smithing,type=chest_minecart] container.0 with air
execute at @s run kill @n[tag=smithing,type=chest_minecart]
clear @s emerald[item_name= "mythril" ] 1

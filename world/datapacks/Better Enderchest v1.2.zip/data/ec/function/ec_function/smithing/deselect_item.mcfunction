scoreboard players set @s ec_menu 28
function ec:ec_menus/smithing_page
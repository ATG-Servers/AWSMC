clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Place your Item here!"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place your Item here!"} }}}]
execute at @s run playsound block.smithing_table.use master @s ~ ~ ~

execute if entity @s[nbt={EnderItems:[{Slot:13b}]}] run scoreboard players set @s ec_menu 29
execute if entity @s[nbt={EnderItems:[{Slot:13b}]}] run function ec:ec_menus/smithing_page_item
execute unless entity @s[nbt={EnderItems:[{Slot:13b}]}] run function ec:ec_menus/smithing_page


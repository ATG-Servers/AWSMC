execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[smithing]}

execute at @s run item replace entity @n[type=chest_minecart,tag=smithing] container.0 with netherite_boots[item_name= {"color":"dark_green","text":"Mythril Boots"} ,unbreakable={},custom_model_data={floats:[1]},custom_data={mythril:1b},attribute_modifiers=[{id:"ec_boots_safe_fall_distance",type:"safe_fall_distance",amount:1,operation:"add_value",slot:"feet"},{id:"ec_armor_boots",type:"armor",amount:5,operation:"add_value",slot:"feet"}]] 1
execute at @s run data modify entity @n[tag=smithing,type=chest_minecart] Items[{Slot:0b}].components set from entity @s EnderItems[{Slot:13b}].components
execute at @s run item modify entity @n[tag=smithing,type=chest_minecart] container.0 {function:set_lore,mode:"insert",offset:0,entity:"this",lore:[{text:"Mythril",color:"green",italic:false}]}
execute at @s run item modify entity @n[tag=smithing,type=chest_minecart] container.0 {function:set_components,components:{unbreakable:{},tooltip_display:{hidden_components:["trim"]},custom_data:{mythril:1b},custom_model_data:{floats:[1]},attribute_modifiers:[{id:"ec_boots_safe_fall_distance",type:"safe_fall_distance",amount:1,operation:"add_value",slot:"feet"},{id:"ec_armor_boots",type:"armor",amount:5,operation:"add_value",slot:"feet"}],trim:{material:"emerald",pattern:"sentry"}}}
execute at @s run item replace entity @n enderchest.13 from entity @n[tag=smithing,type=chest_minecart] container.0
execute at @s run item replace entity @n[tag=smithing,type=chest_minecart] container.0 with air
execute at @s run kill @n[tag=smithing,type=chest_minecart]
clear @s emerald[item_name= "mythril" ] 1

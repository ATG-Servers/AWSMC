scoreboard players set @s ec_menu 28
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s smithing_table[custom_name= {"italic":false,"text":"Smithing Table"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:smithing_table",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Smithing Table"} }}}]

function ec:ec_menus/smithing_page
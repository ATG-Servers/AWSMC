clear @s mangrove_sign[custom_name= {"italic":false,"text":"Italic False"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_sign",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Italic False"} }}}]
execute at @s run playsound block.sign.waxed_interact_fail master @s ~ ~ ~

execute as @s run item modify entity @s enderchest.13 ec:smithing/italic
function ec:ec_menus/smithing_page_item

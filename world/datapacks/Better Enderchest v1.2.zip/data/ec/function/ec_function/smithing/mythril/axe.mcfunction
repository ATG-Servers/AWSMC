clear @s emerald[custom_name= {"color":"dark_green","italic":false,"text":"Forge Mythril"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald",count:1,components:{"minecraft:custom_name": {"color":"dark_green","italic":false,"text":"Forge Mythril"} }}}]

execute if entity @s[nbt={Inventory:[{id:"minecraft:emerald",components:{"minecraft:item_name": "mythril" }}]}] unless entity @s[nbt={EnderItems:[{id:"minecraft:netherite_axe",Slot:13b,components:{"minecraft:custom_data":{mythril:1b}}}]}] run function ec:ec_function/smithing/mythril/transform/axe
item replace entity @s enderchest.15 with emerald[custom_name= {"color":"dark_green","italic":false,"text":"Forge Mythril"} ,enchantment_glint_override=true]
clear @s lime_dye[custom_name= {"italic":false,"text":"Change Color [Click with Dye]"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:lime_dye",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Change Color [Click with Dye]"} }}}]
execute at @s run playsound item.dye.use master @s ~ ~ ~
execute as @s unless entity @s[nbt={EnderItems:[{Slot:10b}]}] run tellraw @s {"text": "Click again with Dye","color": "red"}
execute as @s unless entity @s[nbt={EnderItems:[{Slot:10b}]}] at @s run playsound entity.villager.no master @s ~ ~ ~
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:blue_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/blue
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:lime_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/lime
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:red_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/red
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:purple_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/purple
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:green_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/green
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:orange_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/orange
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:brown_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/brown
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:yellow_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/yellow
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:white_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/white
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:light_gray_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/light_gray
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:gray_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/gray
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:cyan_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/cyan
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:light_blue_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/light_blue
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:magenta_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/magenta
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:pink_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/pink
execute as @s if entity @s[nbt={EnderItems:[{Slot:10b,id:"minecraft:black_dye"}]}] run item modify entity @s enderchest.13 ec:smithing/color/black
function ec:ec_menus/smithing_page_item
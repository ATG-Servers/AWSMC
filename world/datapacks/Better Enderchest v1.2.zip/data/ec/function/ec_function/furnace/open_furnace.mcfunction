scoreboard players set @s ec_menu 25
execute at @s run playsound ui.button.click master @s ~ ~ ~
clear @s furnace[custom_name= {"italic":false,"text":"Money Furnace"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:furnace",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Money Furnace"} }}}]


execute as @s run function ec:ec_menus/furnace_page
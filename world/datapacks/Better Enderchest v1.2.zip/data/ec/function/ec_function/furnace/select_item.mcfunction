clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Place your Item here!"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place your Item here!"} }}}]

execute if entity @s[nbt={EnderItems:[{Slot:12b}]}] run scoreboard players set @s ec_menu 26
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run scoreboard players set @s ec_menu 25
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run item replace entity @s enderchest.12 with white_stained_glass_pane[custom_name= {"italic":false,"text":"Place your Item here!"} ,custom_data={"better_ec":1b}]


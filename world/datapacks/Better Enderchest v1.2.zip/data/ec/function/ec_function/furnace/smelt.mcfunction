clear @s coal[custom_name= {"italic":false,"text":"Smelt Item"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:coal",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Smelt Item"} }}}]
execute if score @s ec_menu matches 25 run tellraw @s {"text": "No Item selected!","color": "red"}

execute at @s run playsound block.furnace.fire_crackle master @s ~ ~ ~


execute unless score @s ec_menu matches 25 store result score @s ec_smelt run data get entity @s EnderItems[{Slot:12b}].count
execute unless score @s ec_menu matches 25 run scoreboard players operation @s ec_smelt *= furnace ec_shop_price
execute unless score @s ec_menu matches 25 unless score @s ec_money >= @s ec_smelt run tellraw @s ["",{"text":"Not enough money! You need ","color":"red"},{"score":{"name":"@s","objective":"ec_smelt"},"color":"red"},{"text":"€","color":"red"}]
execute unless score @s ec_menu matches 25 if score @s ec_money >= @s ec_smelt run item replace entity @s enderchest.14 from entity @s enderchest.12
execute unless score @s ec_menu matches 25 if score @s ec_money >= @s ec_smelt run item modify entity @s enderchest.14 ec:furnace
execute unless score @s ec_menu matches 25 if score @s ec_money >= @s ec_smelt run item replace entity @s enderchest.12 with white_stained_glass_pane[custom_name= {"italic":false,"text":"Place your Item here!"} ,custom_data={"better_ec":1b}]
execute unless score @s ec_menu matches 25 if score @s ec_money >= @s ec_smelt run scoreboard players operation @s ec_money -= @s ec_smelt
execute unless score @s ec_menu matches 25 if score @s ec_money >= @s ec_smelt run scoreboard players set @s ec_menu 25
#scoreboard players set @s ec_smelt 0

item replace entity @s enderchest.10 with coal[custom_name= {"italic":false,"text":"Smelt Item"} ,lore=[ {"text": "2€ per Item","italic": false} ],custom_data={"better_ec":1b}]
item modify entity @s enderchest.10 ec:set_lore_furnace
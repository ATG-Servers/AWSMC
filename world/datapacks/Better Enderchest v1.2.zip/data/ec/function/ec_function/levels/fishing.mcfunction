clear @s fishing_rod[item_name= "fishing" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:item_name": "fishing" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:ec_menus/levels_page
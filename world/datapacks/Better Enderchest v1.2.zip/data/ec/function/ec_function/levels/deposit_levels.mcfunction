clear @s glass_bottle[custom_name= {"italic":false,"text":"Deposit All Levels"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:glass_bottle",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Deposit All Levels"} }}}]
execute at @s run playsound item.bottle.empty master @s ~ ~ ~

scoreboard players operation @s ec_level_store += @s ec_level
xp set @s 0 levels

function ec:ec_menus/levels_page
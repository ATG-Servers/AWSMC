clear @s diamond_pickaxe[item_name= "mining" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_pickaxe",count:1,components:{"minecraft:item_name": "mining" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:ec_menus/levels_page
clear @s diamond_boots[item_name= "acrobatics" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_boots",count:1,components:{"minecraft:item_name": "acrobatics" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:ec_menus/levels_page
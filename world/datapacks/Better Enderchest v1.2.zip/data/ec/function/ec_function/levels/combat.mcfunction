clear @s diamond_sword[item_name= "combat" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:item_name": "combat" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:ec_menus/levels_page
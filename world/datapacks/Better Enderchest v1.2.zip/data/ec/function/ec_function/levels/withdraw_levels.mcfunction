clear @s experience_bottle[custom_name= {"italic":false,"text":"Withdraw All Levels"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:experience_bottle",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Withdraw All Levels"} }}}]
execute at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~

data modify storage add_level level set value {}
execute store result storage add_level level.level int 1 run scoreboard players get @s ec_level_store
function ec:ec_function/levels/add_levels with storage add_level level
scoreboard players set @s ec_level_store 0
data modify storage add_level level set value {}

function ec:ec_menus/levels_page
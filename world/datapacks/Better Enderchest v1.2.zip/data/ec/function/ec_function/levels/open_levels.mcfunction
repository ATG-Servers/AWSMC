scoreboard players set @s ec_menu 27
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s experience_bottle[custom_name= {"italic":false,"text":"Levels"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:experience_bottle",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Levels"} }}}]

function ec:ec_menus/levels_page
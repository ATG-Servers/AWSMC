clear @s totem_of_undying[item_name= "mortal" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:totem_of_undying",count:1,components:{"minecraft:item_name": "mortal" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:ec_menus/levels_page
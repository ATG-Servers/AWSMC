scoreboard players set @s ec_menu 5
scoreboard players set @s ec_inshop 1
clear @s player_head[custom_name= {"italic":false,"text":"Heads"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Heads"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_heads
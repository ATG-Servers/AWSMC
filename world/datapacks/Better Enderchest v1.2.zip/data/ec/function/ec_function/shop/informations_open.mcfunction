scoreboard players set @s ec_menu 44
scoreboard players set @s ec_inshop 0
clear @s compass[custom_name= {"italic":false,"text":"Information"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:compass",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Information"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_information
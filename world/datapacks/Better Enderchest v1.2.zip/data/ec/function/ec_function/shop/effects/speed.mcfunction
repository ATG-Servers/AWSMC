clear @s potion[custom_name= {"italic":false,"text":"Speed"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Speed"} }}}]

execute if score @s ec_money >= effects_2 ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= effects_2 ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute if score @s ec_money >= effects_2 ec_shop_price run tag @s add ec_effect

execute if entity @s[tag=effect_speed] run tellraw @s {"text": "Already Bought","color": "red"}
execute unless entity @s[tag=effect_speed] if score @s ec_money >= effects_2 ec_shop_price run tellraw @s {"text": "Speed unlocked"}
execute unless entity @s[tag=effect_speed] if score @s ec_money >= effects_2 ec_shop_price run effect give @s speed infinite 0 true
execute unless entity @s[tag=effect_speed] if score @s ec_money >= effects_2 ec_shop_price run tag @s add effect_speed+
execute unless entity @s[tag=effect_speed] if score @s ec_money >= effects_2 ec_shop_price run scoreboard players operation @s ec_money -= effects_2 ec_shop_price
tag @a[tag=effect_speed+] add effect_speed
tag @a remove effect_speed+
execute unless entity @s[tag=effect_speed] unless score @s ec_money >= effects_2 ec_shop_price run tellraw @s {"text": "Not Enough Money!","color": "red"}
function ec:ec_menus/shop/shop_effects
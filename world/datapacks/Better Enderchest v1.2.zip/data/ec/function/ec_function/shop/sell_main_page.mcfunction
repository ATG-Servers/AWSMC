clear @s emerald_block[custom_name= {"italic":false,"text":"Sell"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald_block",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sell"} }}}]

# #coal
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:coal"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:coal"}] run scoreboard players operation @s ec_sell *= Coal ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:coal"}] run scoreboard players operation @s ec_money += @s ec_sell

# #copper
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:copper_ingot"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:copper_ingot"}] run scoreboard players operation @s ec_sell *= Copper ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:copper_ingot"}] run scoreboard players operation @s ec_money += @s ec_sell

# #iron
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:iron_ingot"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:iron_ingot"}] run scoreboard players operation @s ec_sell *= Iron ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:iron_ingot"}] run scoreboard players operation @s ec_money += @s ec_sell

# #gold
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:gold_ingot"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:gold_ingot"}] run scoreboard players operation @s ec_sell *= Gold ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:gold_ingot"}] run scoreboard players operation @s ec_money += @s ec_sell

# #emerald
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:emerald"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:emerald"}] run scoreboard players operation @s ec_sell *= Emerald ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:emerald"}] run scoreboard players operation @s ec_money += @s ec_sell

# #diamond
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:diamond"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:diamond"}] run scoreboard players operation @s ec_sell *= Diamond ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:diamond"}] run scoreboard players operation @s ec_money += @s ec_sell

# #netherite
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:netherite_ingot"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:netherite_ingot"}] run scoreboard players operation @s ec_sell *= Netherite ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:netherite_ingot"}] run scoreboard players operation @s ec_money += @s ec_sell

# #nether_star
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:nether_star"}] store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:nether_star"}] run scoreboard players operation @s ec_sell *= NetherStar ec_sell_values
# execute if data entity @s EnderItems[{Slot:12b,id:"minecraft:nether_star"}] run scoreboard players operation @s ec_money += @s ec_sell

#prevent_item_loss
execute if entity @s[nbt={EnderItems:[{Slot:12b}]}] at @s run playsound ui.button.click master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run item replace entity @s player.cursor from entity @s enderchest.12
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run tellraw @s ["",{"text":"You are not clicking this button with an Item!","color": "red"}]
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run execute at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless entity @s[nbt={EnderItems:[{Slot:12b}]}] run scoreboard players set successful ec_sell 1

execute if items entity @s enderchest.12 #ec:prizes/1 run function ec:ec_function/shop/sell_item_main_page {price:1}
execute if items entity @s enderchest.12 #ec:prizes/2 run function ec:ec_function/shop/sell_item_main_page {price:2}
execute if items entity @s enderchest.12 #ec:prizes/3 run function ec:ec_function/shop/sell_item_main_page {price:3}
execute if items entity @s enderchest.12 #ec:prizes/4 run function ec:ec_function/shop/sell_item_main_page {price:4}
execute if items entity @s enderchest.12 #ec:prizes/5 run function ec:ec_function/shop/sell_item_main_page {price:5}
execute if items entity @s enderchest.12 #ec:prizes/6 run function ec:ec_function/shop/sell_item_main_page {price:6}
execute if items entity @s enderchest.12 #ec:prizes/7 run function ec:ec_function/shop/sell_item_main_page {price:7}
execute if items entity @s enderchest.12 #ec:prizes/8 run function ec:ec_function/shop/sell_item_main_page {price:8}
execute if items entity @s enderchest.12 #ec:prizes/9 run function ec:ec_function/shop/sell_item_main_page {price:9}
execute if items entity @s enderchest.12 #ec:prizes/10 run function ec:ec_function/shop/sell_item_main_page {price:10}
execute if items entity @s enderchest.12 #ec:prizes/12 run function ec:ec_function/shop/sell_item_main_page {price:12}
execute if items entity @s enderchest.12 #ec:prizes/14 run function ec:ec_function/shop/sell_item_main_page {price:14}
execute if items entity @s enderchest.12 #ec:prizes/16 run function ec:ec_function/shop/sell_item_main_page {price:16}
execute if items entity @s enderchest.12 #ec:prizes/18 run function ec:ec_function/shop/sell_item_main_page {price:18}
execute if items entity @s enderchest.12 #ec:prizes/20 run function ec:ec_function/shop/sell_item_main_page {price:20}
execute if items entity @s enderchest.12 #ec:prizes/22 run function ec:ec_function/shop/sell_item_main_page {price:22}
execute if items entity @s enderchest.12 #ec:prizes/25 run function ec:ec_function/shop/sell_item_main_page {price:25}
execute if items entity @s enderchest.12 #ec:prizes/28 run function ec:ec_function/shop/sell_item_main_page {price:28}
execute if items entity @s enderchest.12 #ec:prizes/30 run function ec:ec_function/shop/sell_item_main_page {price:30}
execute if items entity @s enderchest.12 #ec:prizes/33 run function ec:ec_function/shop/sell_item_main_page {price:33}
execute if items entity @s enderchest.12 #ec:prizes/37 run function ec:ec_function/shop/sell_item_main_page {price:37}
execute if items entity @s enderchest.12 #ec:prizes/41 run function ec:ec_function/shop/sell_item_main_page {price:41}
execute if items entity @s enderchest.12 #ec:prizes/47 run function ec:ec_function/shop/sell_item_main_page {price:47}
execute if items entity @s enderchest.12 #ec:prizes/51 run function ec:ec_function/shop/sell_item_main_page {price:51}
execute if items entity @s enderchest.12 #ec:prizes/56 run function ec:ec_function/shop/sell_item_main_page {price:56}
execute if items entity @s enderchest.12 #ec:prizes/60 run function ec:ec_function/shop/sell_item_main_page {price:60}
execute if items entity @s enderchest.12 #ec:prizes/63 run function ec:ec_function/shop/sell_item_main_page {price:63}
execute if items entity @s enderchest.12 #ec:prizes/68 run function ec:ec_function/shop/sell_item_main_page {price:68}
execute if items entity @s enderchest.12 #ec:prizes/75 run function ec:ec_function/shop/sell_item_main_page {price:75}
execute if items entity @s enderchest.12 #ec:prizes/80 run function ec:ec_function/shop/sell_item_main_page {price:80}
execute if items entity @s enderchest.12 #ec:prizes/90 run function ec:ec_function/shop/sell_item_main_page {price:90}
execute if items entity @s enderchest.12 #ec:prizes/95 run function ec:ec_function/shop/sell_item_main_page {price:95}
execute if items entity @s enderchest.12 #ec:prizes/100 run function ec:ec_function/shop/sell_item_main_page {price:100}
execute if items entity @s enderchest.12 #ec:prizes/111 run function ec:ec_function/shop/sell_item_main_page {price:111}
execute if items entity @s enderchest.12 #ec:prizes/125 run function ec:ec_function/shop/sell_item_main_page {price:125}
execute if items entity @s enderchest.12 #ec:prizes/140 run function ec:ec_function/shop/sell_item_main_page {price:140}
execute if items entity @s enderchest.12 #ec:prizes/160 run function ec:ec_function/shop/sell_item_main_page {price:160}
execute if items entity @s enderchest.12 #ec:prizes/180 run function ec:ec_function/shop/sell_item_main_page {price:180}
execute if items entity @s enderchest.12 #ec:prizes/200 run function ec:ec_function/shop/sell_item_main_page {price:200}
execute if items entity @s enderchest.12 #ec:prizes/215 run function ec:ec_function/shop/sell_item_main_page {price:215}
execute if items entity @s enderchest.12 #ec:prizes/250 run function ec:ec_function/shop/sell_item_main_page {price:250}
execute if items entity @s enderchest.12 #ec:prizes/290 run function ec:ec_function/shop/sell_item_main_page {price:290}
execute if items entity @s enderchest.12 #ec:prizes/350 run function ec:ec_function/shop/sell_item_main_page {price:350}
execute if items entity @s enderchest.12 #ec:prizes/450 run function ec:ec_function/shop/sell_item_main_page {price:450}
execute if items entity @s enderchest.12 #ec:prizes/500 run function ec:ec_function/shop/sell_item_main_page {price:500}
execute if items entity @s enderchest.12 #ec:prizes/850 run function ec:ec_function/shop/sell_item_main_page {price:850}
execute if items entity @s enderchest.12 #ec:prizes/1k run function ec:ec_function/shop/sell_item_main_page {price:1000}
execute if items entity @s enderchest.12 #ec:prizes/1.3k run function ec:ec_function/shop/sell_item_main_page {price:1300}
execute if items entity @s enderchest.12 #ec:prizes/1.8k run function ec:ec_function/shop/sell_item_main_page {price:1800}
execute if items entity @s enderchest.12 #ec:prizes/2.2k run function ec:ec_function/shop/sell_item_main_page {price:1200}
execute if items entity @s enderchest.12 #ec:prizes/2.8k run function ec:ec_function/shop/sell_item_main_page {price:2800}
execute if items entity @s enderchest.12 #ec:prizes/3.6k run function ec:ec_function/shop/sell_item_main_page {price:3600}
execute if items entity @s enderchest.12 #ec:prizes/4.4k run function ec:ec_function/shop/sell_item_main_page {price:4400}
execute if items entity @s enderchest.12 #ec:prizes/5.5k run function ec:ec_function/shop/sell_item_main_page {price:5500}
execute if items entity @s enderchest.12 #ec:prizes/7k run function ec:ec_function/shop/sell_item_main_page {price:7000}
execute if items entity @s enderchest.12 #ec:prizes/15k run function ec:ec_function/shop/sell_item_main_page {price:15000}
execute if items entity @s enderchest.12 #ec:prizes/40k run function ec:ec_function/shop/sell_item_main_page {price:40000}



# execute if items entity @s enderchest.12 #ec:prizes/1 store result score @s ec_sell run data get entity @s EnderItems[{Slot:12b}].count
# execute if items entity @s enderchest.12 #ec:prizes/1 store result score @s ec_sell run scoreboard players operation @s ec_sell *= Coal ec_sell_values
# execute if items entity @s enderchest.12 #ec:prizes/1 store result score @s ec_sell run scoreboard players operation @s ec_money += @s ec_sell

execute unless score successful ec_sell matches 1 run item replace entity @s player.cursor from entity @s enderchest.12
execute unless score successful ec_sell matches 1 run tellraw @s ["",{"text":"The item your trying to sell is not recognized by this pack. Unless the item is from a mod, please contact me about it!","color": "red"}]
execute unless score successful ec_sell matches 1 run execute at @s run playsound entity.villager.no master @s ~ ~ ~

scoreboard players set successful ec_sell 0

execute as @s run function ec:ec_menus/main_page_1
scoreboard players set @s ec_menu 4
scoreboard players set @s ec_inshop 1
execute at @s run playsound ui.button.click master @s ~ ~ ~
clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]

execute as @s run function ec:ec_menus/shop/shop_main_page
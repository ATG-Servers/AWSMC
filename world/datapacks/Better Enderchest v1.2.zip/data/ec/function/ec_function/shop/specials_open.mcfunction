scoreboard players set @s ec_menu 48
scoreboard players set @s ec_inshop 1
clear @s nether_star[custom_name= {"italic":false,"text":"Special Items"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Special Items"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_specials
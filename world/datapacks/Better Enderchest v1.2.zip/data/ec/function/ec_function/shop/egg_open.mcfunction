scoreboard players set @s ec_menu 42
scoreboard players set @s ec_inshop 1
clear @s slime_spawn_egg[custom_name= {"italic":false,"text":"Spawn Eggs"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:slime_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Spawn Eggs"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_egg
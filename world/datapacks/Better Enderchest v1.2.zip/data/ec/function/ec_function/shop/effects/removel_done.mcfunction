gamerule send_command_feedback true
tag @a remove remove_effect
 
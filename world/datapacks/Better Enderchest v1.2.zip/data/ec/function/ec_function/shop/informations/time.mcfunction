clear @s clock[custom_name= {"italic":false,"text":"Time"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:clock",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Time"} }}}]

execute if score @s ec_money >= information ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= information ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~

execute unless entity @s[tag=info_time] unless score @s ec_money >= information ec_shop_price run tellraw @s {"text": "Not enough Money!","color": "red"}
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_time] run scoreboard players operation @s ec_money -= information ec_shop_price
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_time] run tag @s add info_time
execute if entity @s[tag=info_time] run scoreboard players set @s ec_actionbar 17

function ec:ec_menus/shop/shop_information
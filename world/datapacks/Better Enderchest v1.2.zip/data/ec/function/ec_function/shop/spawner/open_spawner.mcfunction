scoreboard players set @s ec_menu 43
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s spawner[custom_name= {"italic":false,"text":"Buy Spawner"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:spawner",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Spawner"} }}}]

execute as @s run function ec:ec_menus/shop/shop_egg_buy_spawner
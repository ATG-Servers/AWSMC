tag @s add sell_all
item replace entity @s hotbar.8 from entity @s enderchest.18
scoreboard players set sell_slot ec_sell 0
execute store result storage sell current_slot int 1 run scoreboard players get sell_slot ec_sell
function ec:ec_function/shop/sell_slot with storage sell


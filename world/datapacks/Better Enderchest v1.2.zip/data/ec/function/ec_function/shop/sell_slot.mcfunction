$item replace entity @a[tag=sell_all,limit=1] enderchest.18 from entity @a[tag=sell_all,limit=1] inventory.$(current_slot)
$item replace entity @a[tag=sell_all,limit=1] inventory.$(current_slot) with air

execute unless score sell_slot ec_sell matches 27 run scoreboard players add sell_slot ec_sell 1
execute unless score sell_slot ec_sell matches 27 run execute store result storage sell current_slot int 1 run scoreboard players get sell_slot ec_sell
execute unless score sell_slot ec_sell matches 27 run schedule function ec:ec_function/shop/next_slot 1t append

execute if score sell_slot ec_sell matches 27 run data remove storage sell current_slot
execute if score sell_slot ec_sell matches 27 run tag @a[tag=sell_all,limit=1] remove sell_all
 
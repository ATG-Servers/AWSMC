scoreboard players set @s ec_menu 50
scoreboard players set @s ec_inshop 1
clear @s diamond[custom_name= {"italic":false,"text":"Materials"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Materials"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_materials
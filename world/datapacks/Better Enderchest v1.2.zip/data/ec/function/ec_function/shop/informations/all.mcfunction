clear @s end_crystal[custom_name= {"italic":false,"text":"Everything At Once"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:end_crystal",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Everything At Once"} }}}]

execute if score @s ec_money >= all_information ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= all_information ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~

execute unless entity @s[tag=info_all] unless score @s ec_money >= all_information ec_shop_price run tellraw @s {"text": "Not enough Money!","color": "red"}
execute if score @s ec_money >= all_information ec_shop_price unless entity @s[tag=info_all] run scoreboard players operation @s ec_money -= all_information ec_shop_price
execute if score @s ec_money >= all_information ec_shop_price unless entity @s[tag=info_all] run tag @s add info_all
execute if entity @s[tag=info_all] run scoreboard players set @s ec_actionbar 21

function ec:ec_menus/shop/shop_information
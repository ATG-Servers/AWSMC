scoreboard players set @s ec_menu 53
scoreboard players set @s ec_inshop 1
clear @s note_block[custom_name= {"italic":false,"text":"Sounds"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:note_block",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sounds"} }}}]
execute at @s run playsound block.note_block.pling master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/sounds_page
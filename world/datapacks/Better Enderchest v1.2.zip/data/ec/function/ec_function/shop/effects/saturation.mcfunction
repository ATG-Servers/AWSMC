clear @s potion[custom_name= {"italic":false,"text":"Saturation"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sturation"} }}}]

execute if score @s ec_money >= effects_2 ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= effects_2 ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute if score @s ec_money >= effects_2 ec_shop_price run tag @s add ec_effect

execute if entity @s[tag=effect_saturation] run tellraw @s {"text": "Already Bought","color": "red"}
execute unless entity @s[tag=effect_saturation] if score @s ec_money >= effects_2 ec_shop_price run tellraw @s {"text": "Saturation unlocked"}
execute unless entity @s[tag=effect_saturation] if score @s ec_money >= effects_2 ec_shop_price run effect give @s saturation infinite 0 true
execute unless entity @s[tag=effect_saturation] if score @s ec_money >= effects_2 ec_shop_price run tag @s add effect_saturation+
execute unless entity @s[tag=effect_saturation] if score @s ec_money >= effects_2 ec_shop_price run scoreboard players operation @s ec_money -= effects_2 ec_shop_price
tag @a[tag=effect_saturation+] add effect_saturation
tag @a remove effect_saturation+
execute unless entity @s[tag=effect_saturation] unless score @s ec_money >= effects_2 ec_shop_price run tellraw @s {"text": "Not Enough Money!","color": "red"}
function ec:ec_menus/shop/shop_effects
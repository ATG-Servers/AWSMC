clear @s skeleton_spawn_egg[custom_name= {"italic":false,"text":"Sacrifice Skeleton Spawn"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:skeleton_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Skeleton Spawn"} }}}]
execute if entity @s[tag=skeleton_sacrifized] run tellraw @s {"text": "Already Sacrifized","color": "red"}
execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run give @s spawner[block_entity_data={id:"minecraft:mob_spawner",SpawnData:{entity:{id:"minecraft:skeleton"}}}]

execute unless entity @s[tag=skeleton_sacrifized] unless score @s ec_money >= spawner ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run tellraw @s {"text":"Skeleton Spawn Sacrificed!"}

execute if score @s ec_money >= spawner ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= spawner ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~


execute if score @s ec_money >= spawner ec_shop_price unless entity @s[tag=skeleton_sacrifized] as @s run function ec:ec_menus/shop/shop_egg
execute if entity @s[tag=skeleton_sacrifized] run function ec:ec_menus/shop/shop_egg_buy_spawner
execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run scoreboard players set @s ec_menu 42
execute unless score @s ec_money >= spawner ec_shop_price run function ec:ec_menus/shop/shop_egg_buy_spawner

execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run scoreboard players operation @s ec_money -= spawner ec_shop_price
execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run item replace entity @s enderchest.12 with skeleton_spawn_egg[custom_name= {"italic":false,"text":"Buy Skeleton Spawn"} ,lore=[ " " , {"color":"gray","italic":false,"text":"Sacrifized"} ],enchantment_glint_override=true]
execute unless entity @s[tag=skeleton_sacrifized] if score @s ec_money >= spawner ec_shop_price run tag @s add skeleton_sacrifized



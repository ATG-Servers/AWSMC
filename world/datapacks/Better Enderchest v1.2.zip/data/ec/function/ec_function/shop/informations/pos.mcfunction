clear @s compass[custom_name= {"italic":false,"text":"Position"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:compass",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Position"} }}}]

execute if score @s ec_money >= information ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= information ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~

execute unless entity @s[tag=info_pos] unless score @s ec_money >= information ec_shop_price run tellraw @s {"text": "Not enough Money!","color": "red"}
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_pos] run scoreboard players operation @s ec_money -= information ec_shop_price
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_pos] run tag @s add info_pos
execute if entity @s[tag=info_pos] run scoreboard players set @s ec_actionbar 18

function ec:ec_menus/shop/shop_information
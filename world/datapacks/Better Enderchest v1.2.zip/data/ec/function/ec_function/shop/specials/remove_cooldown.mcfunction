
execute as @a[scores={ec_celebrator_cooldown=1..}] if score @s ec_celebrator_cooldown matches 1 run tellraw @s {"text": "Cooldown Over!"}
execute as @a[scores={ec_celebrator_cooldown=1..}] if score @s ec_celebrator_cooldown matches 1 at @s run playsound entity.player.levelup master @s ~ ~ ~
execute as @a[scores={ec_celebrator_cooldown=1..}] if score @s ec_celebrator_cooldown matches 1 at @s run tag @a remove firework_cooldown
execute as @a[scores={ec_celebrator_cooldown=1..}] run scoreboard players remove @s ec_celebrator_cooldown 1

execute as @a[scores={ec_celebrator_cooldown=1..}] if score @s ec_celebrator_cooldown matches 1.. run schedule function ec:ec_function/shop/specials/remove_cooldown 1t
# tag @a remove firework_cooldown

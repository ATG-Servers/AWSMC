scoreboard players set @s ec_menu 47
scoreboard players set @s ec_inshop 1
clear @s potion[custom_name= {"italic":false,"text":"Effects"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Effects"} }}}]
execute at @s run playsound block.brewing_stand.brew master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_effects
clear @s wolf_spawn_egg[custom_name= {"italic":false,"text":"Sacrifice Wolf Spawn"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:wolf_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Wolf Spawn"} }}}]
execute if entity @s[tag=wolf_sacrifized] run tellraw @s {"text": "Already Sacrifized","color": "red"}
execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run give @s spawner[block_entity_data={id:"minecraft:mob_spawner",SpawnData:{entity:{id:"minecraft:wolf"}}}]

execute unless entity @s[tag=wolf_sacrifized] unless score @s ec_money >= spawner ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run tellraw @s {"text":"Wolf Spawn Sacrificed!"}

execute if score @s ec_money >= spawner ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= spawner ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~


execute if score @s ec_money >= spawner ec_shop_price unless entity @s[tag=wolf_sacrifized] as @s run function ec:ec_menus/shop/shop_egg
execute if entity @s[tag=wolf_sacrifized] run function ec:ec_menus/shop/shop_egg_buy_spawner
execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run scoreboard players set @s ec_menu 42
execute unless score @s ec_money >= spawner ec_shop_price run function ec:ec_menus/shop/shop_egg_buy_spawner

execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run scoreboard players operation @s ec_money -= spawner ec_shop_price
execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run item replace entity @s enderchest.21 with wolf_spawn_egg[custom_name= {"italic":false,"text":"Buy Wolf Spawn"} ,lore=[ " " , {"color":"gray","italic":false,"text":"Sacrifized"} ],enchantment_glint_override=true]
execute unless entity @s[tag=wolf_sacrifized] if score @s ec_money >= spawner ec_shop_price run tag @s add wolf_sacrifized



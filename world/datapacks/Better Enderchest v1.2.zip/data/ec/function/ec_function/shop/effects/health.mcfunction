clear @s potion[custom_name= {"italic":false,"text":"Health Boost"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:potion",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Health Boost"} }}}]

execute if score @s ec_money >= effects_3 ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= effects_3 ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute if score @s ec_money >= effects_3 ec_shop_price run tag @s add ec_effect

execute if entity @s[tag=effect_health] run tellraw @s {"text": "Already Bought","color": "red"}
execute unless entity @s[tag=effect_health] if score @s ec_money >= effects_3 ec_shop_price run tellraw @s {"text": "Health Boost unlocked"}
execute unless entity @s[tag=effect_health] if score @s ec_money >= effects_3 ec_shop_price run effect give @s health_boost infinite 0 true
execute unless entity @s[tag=effect_health] if score @s ec_money >= effects_3 ec_shop_price run tag @s add effect_health+
execute unless entity @s[tag=effect_health] if score @s ec_money >= effects_3 ec_shop_price run scoreboard players operation @s ec_money -= effects_3 ec_shop_price
tag @a[tag=effect_health+] add effect_health
tag @a remove effect_health+
execute unless entity @s[tag=effect_health] unless score @s ec_money >= effects_3 ec_shop_price run tellraw @s {"text": "Not Enough Money!","color": "red"}
function ec:ec_menus/shop/shop_effects
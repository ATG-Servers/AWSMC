
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~ ~2 ~3 {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;655104],fade_colors:[I;1457429]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~6 ~2 ~-6 {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;16711680],fade_colors:[I;4001294]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~-6 ~2 ~ {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;16770560],fade_colors:[I;8881938]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~6 ~2 ~6 {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;524543],fade_colors:[I;1842311]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~6 ~2 ~ {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;16713198],fade_colors:[I;8857476]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~ ~2 ~-3 {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;16757507],fade_colors:[I;8873756]}]}}}}
execute unless entity @s[scores={ec_celebrator_cooldown=1..}] at @s run summon firework_rocket ~ ~10 ~ {FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",has_twinkle:true,has_trail:true,colors:[I;6488150],fade_colors:[I;4325429]}]}}}}
tellraw @s[scores={ec_celebrator_cooldown=1..},tag=!firework_cooldown] {"text": "You are on cooldown!","color": "red"}
tag @s[scores={ec_celebrator_cooldown=1..}] add firework_cooldown
execute unless score @s ec_celebrator_cooldown matches 1.. run scoreboard players set @s ec_celebrator_cooldown 100

advancement revoke @a only ec:check_celebrator
execute as @s run function ec:ec_function/shop/specials/remove_cooldown
# schedule function ec:ec_function/shop/specials/remove_cooldown 5s replace
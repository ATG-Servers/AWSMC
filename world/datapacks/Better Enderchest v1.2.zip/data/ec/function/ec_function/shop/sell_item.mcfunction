execute store result score @s ec_sell run data get entity @s EnderItems[{Slot:18b}].count
scoreboard players operation count_buffer ec_sell = @s ec_sell 
$scoreboard players set sell ec_sell_values $(price)
scoreboard players operation @s ec_sell *= sell ec_sell_values
scoreboard players operation @s ec_money += @s ec_sell
tellraw @s ["",{"text":"[Shop]: ","color":"yellow"},{"text":"You received "},{"score":{"name":"@s","objective":"ec_sell"},"color":"yellow"},{"text":"€ ","color":"yellow"},{"text":"from selling "},{"score":{"name":"count_buffer","objective":"ec_sell"},"color":"light_purple"},{"text":"x ","color":"light_purple"},{"nbt":"EnderItems[{Slot:18b}].id","entity":"@s","color":"light_purple"},{"text":" ("},{"score":{"name":"sell","objective":"ec_sell_values"},"color":"yellow"},{"text":"€ ","color":"yellow"},{"text":"per piece)"}]
scoreboard players set successful ec_sell 1
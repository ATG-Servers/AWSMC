clear @s golden_carrot[custom_name= {"italic":false,"text":"Food"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:golden_carrot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Food"} }}}]

execute if score @s ec_money >= information ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_money >= information ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~

execute unless entity @s[tag=info_sat] unless score @s ec_money >= information ec_shop_price run tellraw @s {"text": "Not enough Money!","color": "red"}
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_sat] run scoreboard players operation @s ec_money -= information ec_shop_price
execute if score @s ec_money >= information ec_shop_price unless entity @s[tag=info_sat] run tag @s add info_sat
execute if entity @s[tag=info_sat] run scoreboard players set @s ec_actionbar 20

function ec:ec_menus/shop/shop_information
scoreboard players set @s ec_menu 45
scoreboard players set @s ec_inshop 1
clear @s enchanted_book[custom_name= {"italic":false,"text":"Enchantments"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Enchantments"} }}}]
execute at @s run playsound block.enchantment_table.use master @s ~ ~ ~


execute as @s run function ec:ec_menus/shop/shop_enchantments
clear @s end_stone[item_name= "endstone_storage" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:end_stone",count:1,components:{"minecraft:item_name": "endstone_storage" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players set @s ec_storage 0
execute if score @s ec_collections_end_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:6b}].count
execute if score @s ec_collections_end_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] run scoreboard players operation @s ec_endstone_storage += @s ec_storage

execute if score @s ec_collections_end_stone_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] unless score @s ec_endstone_storage matches 64.. unless score @s ec_endstone_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_end_stone_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] unless score @s ec_endstone_storage matches 64.. unless score @s ec_endstone_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:end_stone"}
execute if score @s ec_collections_end_stone_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] unless score @s ec_endstone_storage matches 64.. unless score @s ec_endstone_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_endstone_storage 
execute if score @s ec_collections_end_stone_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] unless score @s ec_endstone_storage matches 64.. unless score @s ec_endstone_storage matches 0 run scoreboard players set @s ec_endstone_storage 0
execute if score @s ec_collections_end_stone_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if score @s ec_collections_end_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] if score @s ec_endstone_storage matches 64.. run give @s end_stone 64
execute if score @s ec_collections_end_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:6b,id:"minecraft:end_stone"}]}] if score @s ec_endstone_storage matches 64.. run scoreboard players remove @s ec_endstone_storage 64



function ec:ec_menus/storage_page
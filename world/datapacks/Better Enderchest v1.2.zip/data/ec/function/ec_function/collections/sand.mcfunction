clear @s sand[item_name= "sand_collection" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sand",count:1,components:{"minecraft:item_name": "sand_collection" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

execute if score @s ec_collections_sand_stage matches 4 if score @s ec_collections_sand matches 1000000.. run scoreboard players add @s ec_money 5000
execute if score @s ec_collections_sand_stage matches 4 if score @s ec_collections_sand matches 1000000.. run scoreboard players set @s ec_collections_sand_stage 5

execute if score @s ec_collections_sand_stage matches 3 if score @s ec_collections_sand matches 100000.. run scoreboard players add @s ec_money 1000
execute if score @s ec_collections_sand_stage matches 3 if score @s ec_collections_sand matches 100000.. run scoreboard players set @s ec_collections_next_goal_sand 1000000
execute if score @s ec_collections_sand_stage matches 3 if score @s ec_collections_sand matches 100000.. run scoreboard players set @s ec_collections_sand_stage 4

execute if score @s ec_collections_sand_stage matches 2 if score @s ec_collections_sand matches 10000.. run scoreboard players add @s ec_money 500
execute if score @s ec_collections_sand_stage matches 2 if score @s ec_collections_sand matches 10000.. run scoreboard players set @s ec_collections_next_goal_sand 100000
execute if score @s ec_collections_sand_stage matches 2 if score @s ec_collections_sand matches 10000.. run scoreboard players set @s ec_collections_sand_stage 3

execute if score @s ec_collections_sand_stage matches 1 if score @s ec_collections_sand matches 1000.. run scoreboard players add @s ec_money 200
execute if score @s ec_collections_sand_stage matches 1 if score @s ec_collections_sand matches 1000.. run scoreboard players set @s ec_collections_next_goal_sand 10000
execute if score @s ec_collections_sand_stage matches 1 if score @s ec_collections_sand matches 1000.. run scoreboard players set @s ec_collections_sand_stage 2

execute if score @s ec_collections_sand_stage matches 0 if score @s ec_collections_sand matches 100.. run scoreboard players add @s ec_money 100
execute if score @s ec_collections_sand_stage matches 0 if score @s ec_collections_sand matches 100.. run scoreboard players set @s ec_collections_next_goal_sand 1000
execute if score @s ec_collections_sand_stage matches 0 if score @s ec_collections_sand matches 100.. run scoreboard players set @s ec_collections_sand_stage 1


execute as @s run function ec:ec_menus/collections_page
#you always take out the item you put in as the last
#when there is no item left the item selected switches

clear @s deepslate[item_name= "deepslate_storage" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:deepslate",count:1,components:{"minecraft:item_name": "deepslate_storage" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players set @s ec_storage 0
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:4b}].count
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] run scoreboard players operation @s ec_deepslate_storage += @s ec_storage
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] run tag @s remove storage_deepslate_cobbled
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] run tag @s add storage_deepslate

execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:4b}].count
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] run scoreboard players operation @s ec_cobble_deepslate_storage += @s ec_storage
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] run tag @s remove storage_deepslate
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] run tag @s add storage_deepslate_cobbled

execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_deepslate_storage matches 64.. unless score @s ec_deepslate_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_deepslate_storage matches 64.. unless score @s ec_deepslate_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:deepslate"}
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_deepslate_storage matches 64.. unless score @s ec_deepslate_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_deepslate_storage 
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_deepslate_storage matches 64.. unless score @s ec_deepslate_storage matches 0 run scoreboard players set @s ec_deepslate_storage 0
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate_cobbled] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_cobble_deepslate_storage matches 64.. unless score @s ec_cobble_deepslate_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate_cobbled] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_cobble_deepslate_storage matches 64.. unless score @s ec_cobble_deepslate_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:cobbled_deepslate"}
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate_cobbled] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_cobble_deepslate_storage matches 64.. unless score @s ec_cobble_deepslate_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_cobble_deepslate_storage 
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate_cobbled] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] unless score @s ec_cobble_deepslate_storage matches 64.. unless score @s ec_cobble_deepslate_storage matches 0 run scoreboard players set @s ec_cobble_deepslate_storage 0
execute if score @s ec_collections_deepslate_stage matches 3.. if entity @s[tag=storage_deepslate_cobbled] at @s unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if entity @s[tag=storage_deepslate] if score @s ec_collections_deepslate_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] if score @s ec_deepslate_storage matches 64.. run give @s deepslate 64
execute if entity @s[tag=storage_deepslate] if score @s ec_collections_deepslate_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] if score @s ec_deepslate_storage matches 64.. run scoreboard players remove @s ec_deepslate_storage 64

execute if entity @s[tag=storage_deepslate_cobbled] if score @s ec_collections_deepslate_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] if score @s ec_cobble_deepslate_storage matches 64.. run give @s cobbled_deepslate 64
execute if entity @s[tag=storage_deepslate_cobbled] if score @s ec_collections_deepslate_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:deepslate"}]}] unless entity @s[nbt={EnderItems:[{Slot:4b,id:"minecraft:cobbled_deepslate"}]}] if score @s ec_cobble_deepslate_storage matches 64.. run scoreboard players remove @s ec_cobble_deepslate_storage 64

execute if score @s ec_cobble_deepslate_storage matches 0 run tag @s remove storage_deepslate_cobbled
execute if score @s ec_cobble_deepslate_storage matches 0 run tag @s add storage_deepslate

execute if score @s ec_deepslate_storage matches 0 run tag @s remove storage_deepslate
execute if score @s ec_deepslate_storage matches 0 run tag @s add storage_deepslate_cobbled

function ec:ec_menus/storage_page
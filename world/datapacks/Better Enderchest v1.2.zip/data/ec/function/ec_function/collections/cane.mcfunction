clear @s sugar_cane[item_name= "cane_collection" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sugar_cane",count:1,components:{"minecraft:item_name": "cane_collection" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~


execute if score @s ec_collections_cane_stage matches 4 if score @s ec_collections_cane matches 1000000.. run scoreboard players add @s ec_money 5000
execute if score @s ec_collections_cane_stage matches 4 if score @s ec_collections_cane matches 1000000.. run scoreboard players set @s ec_collections_cane_stage 5

execute if score @s ec_collections_cane_stage matches 3 if score @s ec_collections_cane matches 100000.. run scoreboard players add @s ec_money 1000
execute if score @s ec_collections_cane_stage matches 3 if score @s ec_collections_cane matches 100000.. run scoreboard players set @s ec_collections_next_goal_cane 1000000
execute if score @s ec_collections_cane_stage matches 3 if score @s ec_collections_cane matches 100000.. run scoreboard players set @s ec_collections_cane_stage 4

execute if score @s ec_collections_cane_stage matches 2 if score @s ec_collections_cane matches 10000.. run scoreboard players add @s ec_money 500
execute if score @s ec_collections_cane_stage matches 2 if score @s ec_collections_cane matches 10000.. run scoreboard players set @s ec_collections_next_goal_cane 100000
execute if score @s ec_collections_cane_stage matches 2 if score @s ec_collections_cane matches 10000.. run scoreboard players set @s ec_collections_cane_stage 3

execute if score @s ec_collections_cane_stage matches 1 if score @s ec_collections_cane matches 1000.. run scoreboard players add @s ec_money 200
execute if score @s ec_collections_cane_stage matches 1 if score @s ec_collections_cane matches 1000.. run scoreboard players set @s ec_collections_next_goal_cane 10000
execute if score @s ec_collections_cane_stage matches 1 if score @s ec_collections_cane matches 1000.. run scoreboard players set @s ec_collections_cane_stage 2

execute if score @s ec_collections_cane_stage matches 0 if score @s ec_collections_cane matches 100.. run scoreboard players add @s ec_money 100
execute if score @s ec_collections_cane_stage matches 0 if score @s ec_collections_cane matches 100.. run scoreboard players set @s ec_collections_next_goal_cane 1000
execute if score @s ec_collections_cane_stage matches 0 if score @s ec_collections_cane matches 100.. run scoreboard players set @s ec_collections_cane_stage 1


execute as @s run function ec:ec_menus/collections_page
clear @s sugar_cane[item_name= "cane_storage" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sugar_cane",count:1,components:{"minecraft:item_name": "cane_storage" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players set @s ec_storage 0
execute if score @s ec_collections_cane_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:7b}].count
execute if score @s ec_collections_cane_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] run scoreboard players operation @s ec_cane_storage += @s ec_storage

execute if score @s ec_collections_cane_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] unless score @s ec_cane_storage matches 64.. unless score @s ec_cane_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_cane_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] unless score @s ec_cane_storage matches 64.. unless score @s ec_cane_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:sugar_cane"}
execute if score @s ec_collections_cane_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] unless score @s ec_cane_storage matches 64.. unless score @s ec_cane_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_cane_storage 
execute if score @s ec_collections_cane_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] unless score @s ec_cane_storage matches 64.. unless score @s ec_cane_storage matches 0 run scoreboard players set @s ec_cane_storage 0
execute if score @s ec_collections_cane_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if score @s ec_collections_cane_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] if score @s ec_cane_storage matches 64.. run give @s sugar_cane 64
execute if score @s ec_collections_cane_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:7b,id:"minecraft:sugar_cane"}]}] if score @s ec_cane_storage matches 64.. run scoreboard players remove @s ec_cane_storage 64



function ec:ec_menus/storage_page
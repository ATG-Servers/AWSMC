#you always take out the item you put in as the last
#when there is no item left the item selected switches
clear @s stone[item_name= "stone_storage" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:stone",count:1,components:{"minecraft:item_name": "stone_storage" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players set @s ec_storage 0
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:3b}].count
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] run scoreboard players operation @s ec_stone_storage += @s ec_storage
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] run tag @s remove storage_cobble
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] run tag @s add storage_stone

execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:3b}].count
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] run scoreboard players operation @s ec_cobble_stone_storage += @s ec_storage
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] run tag @s remove storage_stone
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] run tag @s add storage_cobble

execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_stone] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_stone_storage matches 64.. unless score @s ec_stone_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_stone] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_stone_storage matches 64.. unless score @s ec_stone_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:stone"}
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_stone] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_stone_storage matches 64.. unless score @s ec_stone_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_stone_storage 
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_stone] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_stone_storage matches 64.. unless score @s ec_stone_storage matches 0 run scoreboard players set @s ec_stone_storage 0
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_stone] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_cobble] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_cobble_stone_storage matches 64.. unless score @s ec_cobble_stone_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_cobble] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_cobble_stone_storage matches 64.. unless score @s ec_cobble_stone_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:cobblestone"}
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_cobble] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_cobble_stone_storage matches 64.. unless score @s ec_cobble_stone_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_cobble_stone_storage 
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_cobble] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] unless score @s ec_cobble_stone_storage matches 64.. unless score @s ec_cobble_stone_storage matches 0 run scoreboard players set @s ec_cobble_stone_storage 0
execute if score @s ec_collections_stone_stage matches 3.. if entity @s[tag=storage_cobble] at @s unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if entity @s[tag=storage_stone] if score @s ec_collections_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] if score @s ec_stone_storage matches 64.. run give @s stone 64
execute if entity @s[tag=storage_stone] if score @s ec_collections_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] if score @s ec_stone_storage matches 64.. run scoreboard players remove @s ec_stone_storage 64

execute if entity @s[tag=storage_cobble] if score @s ec_collections_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] if score @s ec_cobble_stone_storage matches 64.. run give @s cobblestone 64
execute if entity @s[tag=storage_cobble] if score @s ec_collections_stone_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:stone"}]}] unless entity @s[nbt={EnderItems:[{Slot:3b,id:"minecraft:cobblestone"}]}] if score @s ec_cobble_stone_storage matches 64.. run scoreboard players remove @s ec_cobble_stone_storage 64

execute if score @s ec_cobble_stone_storage matches 0 run tag @s remove storage_cobble
execute if score @s ec_cobble_stone_storage matches 0 run tag @s add storage_stone

execute if score @s ec_stone_storage matches 0 run tag @s remove storage_stone
execute if score @s ec_stone_storage matches 0 run tag @s add storage_cobble

function ec:ec_menus/storage_page
scoreboard players set @s ec_menu 23
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s dragon_egg[custom_name= {"italic":false,"text":"Collections"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:dragon_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Collections"} }}}]

execute as @s run function ec:ec_menus/collections_page
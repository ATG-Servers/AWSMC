scoreboard players set @s ec_menu 34
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s barrel[custom_name= {"italic":false,"text":"Storage"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrel",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Storage"} }}}]

execute as @s run function ec:ec_menus/storage_page
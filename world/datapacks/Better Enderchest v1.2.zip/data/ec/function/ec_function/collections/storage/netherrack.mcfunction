clear @s netherrack[item_name= "netherrack_storage" ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:netherrack",count:1,components:{"minecraft:item_name": "netherrack_storage" }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

scoreboard players set @s ec_storage 0
execute if score @s ec_collections_netherrack_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] store result score @s ec_storage run data get entity @s EnderItems[{Slot:5b}].count
execute if score @s ec_collections_netherrack_stage matches 3.. if entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] run scoreboard players operation @s ec_netherrack_storage += @s ec_storage

execute if score @s ec_collections_netherrack_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] unless score @s ec_netherrack_storage matches 64.. unless score @s ec_netherrack_storage matches 0 run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:[storage]}
execute if score @s ec_collections_netherrack_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] unless score @s ec_netherrack_storage matches 64.. unless score @s ec_netherrack_storage matches 0 run data modify entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}] set value {id:"minecraft:netherrack"}
execute if score @s ec_collections_netherrack_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] unless score @s ec_netherrack_storage matches 64.. unless score @s ec_netherrack_storage matches 0 store result entity @n[type=chest_minecart,tag=storage] Items.[{Slot:0b}].count int 1 run scoreboard players get @s ec_netherrack_storage 
execute if score @s ec_collections_netherrack_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] unless score @s ec_netherrack_storage matches 64.. unless score @s ec_netherrack_storage matches 0 run scoreboard players set @s ec_netherrack_storage 0
execute if score @s ec_collections_netherrack_stage matches 3.. at @s unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] run kill @n[type=chest_minecart,tag=storage]

execute if score @s ec_collections_netherrack_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] if score @s ec_netherrack_storage matches 64.. run give @s netherrack 64
execute if score @s ec_collections_netherrack_stage matches 3.. unless entity @s[nbt={EnderItems:[{Slot:5b,id:"minecraft:netherrack"}]}] if score @s ec_netherrack_storage matches 64.. run scoreboard players remove @s ec_netherrack_storage 64



function ec:ec_menus/storage_page
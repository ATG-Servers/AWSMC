#refreshs the collections page
clear @s ender_eye[custom_name= {"italic":false,"text":"Refresh"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_eye",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Refresh"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

execute as @s run function ec:ec_menus/collections_page
clear @s dirt[custom_name= {"italic":false,"text":"Dirt"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:dirt",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Dirt"} }}}]

execute at @s if score @s ec_money >= dirt ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= dirt ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= dirt ec_shop_price run give @s dirt[max_stack_size=99,custom_data={betterec:true}] 99
execute unless score @s ec_money >= dirt ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= dirt ec_shop_price run tellraw @s [{"text":"Dirt Bought!"}]
execute if score @s ec_money >= dirt ec_shop_price run scoreboard players operation @s ec_money -= dirt ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_specials
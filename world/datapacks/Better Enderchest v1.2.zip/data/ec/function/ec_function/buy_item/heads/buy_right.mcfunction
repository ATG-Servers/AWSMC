clear @s player_head[custom_name= {"italic":false,"text":"Buy Right"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Right"} }}}]

execute at @s if score @s ec_money >= heads ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= heads ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= heads ec_shop_price run give @s player_head[custom_name= {"italic":false,"text":"Right"} ,profile={id:[I;-690089179,345198584,-1553951209,-1566713524],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTFjMmUyOTE5MWNiYmZhZWM0OWYyYzY0MWE0MGFhODA4ZDQ5ODQ2YjcwNWRmM2M5ZjAyYjIzOTZkYThlMTE2In19fQ=="}]}] 1
execute unless score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Right Head Bought!"}
execute if score @s ec_money >= heads ec_shop_price run scoreboard players operation @s ec_money -= heads ec_shop_price


execute as @s run function ec:ec_menus/shop/shop_heads
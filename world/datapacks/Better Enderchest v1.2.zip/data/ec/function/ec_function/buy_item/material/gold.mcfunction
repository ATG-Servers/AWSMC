clear @s gold_ingot[custom_name= {"italic":false,"text":"Buy Gold"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gold_ingot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Gold"} }}}]

execute at @s if score @s ec_money >= gold ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= gold ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= gold ec_shop_price run give @s gold_ingot 1
execute unless score @s ec_money >= gold ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= gold ec_shop_price run tellraw @s {"text":"Gold Bought!"}
execute if score @s ec_money >= gold ec_shop_price run scoreboard players operation @s ec_money -= gold ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_materials
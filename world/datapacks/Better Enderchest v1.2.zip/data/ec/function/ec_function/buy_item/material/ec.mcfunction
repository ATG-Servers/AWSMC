clear @s ender_chest[custom_name= {"italic":false,"text":"Buy Ender Chest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Ender Chest"} }}}]

execute at @s if score @s ec_money >= enderchest ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= enderchest ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= enderchest ec_shop_price run give @s ender_chest 1
execute unless score @s ec_money >= enderchest ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= enderchest ec_shop_price run tellraw @s {"text":"Ender Chest Bought!","color": "dark_purple"}
execute if score @s ec_money >= enderchest ec_shop_price run scoreboard players operation @s ec_money -= enderchest ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_materials
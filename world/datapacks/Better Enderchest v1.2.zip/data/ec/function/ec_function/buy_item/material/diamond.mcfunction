clear @s diamond[custom_name= {"italic":false,"text":"Buy Diamond"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Diamond"} }}}]

execute at @s if score @s ec_money >= diamond ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= diamond ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= diamond ec_shop_price run give @s diamond 1
execute unless score @s ec_money >= diamond ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= diamond ec_shop_price run tellraw @s {"text":"Diamond Bought!"}
execute if score @s ec_money >= diamond ec_shop_price run scoreboard players operation @s ec_money -= diamond ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_materials
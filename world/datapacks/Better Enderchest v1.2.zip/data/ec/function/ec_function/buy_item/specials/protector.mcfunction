clear @s iron_golem_spawn_egg[custom_name= {"italic":false,"text":"Protector"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:iron_golem_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Protector"} }}}]

execute at @s if score @s ec_money >= protector ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= protector ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= protector ec_shop_price run give @s iron_golem_spawn_egg[entity_data={id:"minecraft:pufferfish"}]
execute unless score @s ec_money >= protector ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= protector ec_shop_price run tellraw @s [{"text":"Protector Bought!"}]
execute if score @s ec_money >= protector ec_shop_price run scoreboard players operation @s ec_money -= protector ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_specials
clear @s redstone[custom_name= {"italic":false,"text":"Buy Redstone"} ] 64
kill @e[type=item,nbt={Item:{id:"minecraft:redstone",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Redstone"} }}}]

execute at @s if score @s ec_money >= redstone ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= redstone ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= redstone ec_shop_price run give @s redstone 64
execute unless score @s ec_money >= redstone ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= redstone ec_shop_price run tellraw @s {"text":"Redstone Bought!"}
execute if score @s ec_money >= redstone ec_shop_price run scoreboard players operation @s ec_money -= redstone ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_materials
clear @s breeze_rod[custom_name= {"italic":false,"text":"Highlighter"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:breeze_rod",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Highlighter"} }}}]

execute at @s if score @s ec_money >= highlighter ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= highlighter ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= highlighter ec_shop_price run give @s breeze_rod[custom_name= [{"italic":false,"text":"Highlighter"},{"text": ""}] ,custom_data={betterec:true},max_stack_size=1] 1
execute unless score @s ec_money >= highlighter ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= highlighter ec_shop_price run tellraw @s [{"text":"Highlighter Bought!"}]
execute if score @s ec_money >= highlighter ec_shop_price run scoreboard players operation @s ec_money -= highlighter ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_specials
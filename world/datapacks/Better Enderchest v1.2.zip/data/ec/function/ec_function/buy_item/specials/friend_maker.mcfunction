clear @s gray_stained_glass_pane[custom_name= {"italic":false,"text":"Friend Maker"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:gray_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Friend Maker"} }}}]

execute at @s if score @s ec_money >= friend_maker ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= friend_maker ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= friend_maker ec_shop_price run give @s light_gray_stained_glass_pane[tooltip_display={hide_tooltip:true},custom_name= {"text": "You are my friend now!","italic": false} ,max_stack_size=1] 1
execute unless score @s ec_money >= friend_maker ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= friend_maker ec_shop_price run tellraw @s [{"text":"Friend Maker Bought!"},"\n",{"text": "Look Closer!"}]
execute if score @s ec_money >= friend_maker ec_shop_price run scoreboard players operation @s ec_money -= friend_maker ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_specials
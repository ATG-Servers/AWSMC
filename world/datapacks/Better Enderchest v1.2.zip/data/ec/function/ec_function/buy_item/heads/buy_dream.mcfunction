clear @s player_head[custom_name= {"italic":false,"text":"Buy Dream"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Dream"} }}}]

execute at @s if score @s ec_money >= heads ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= heads ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= heads ec_shop_price run give @s player_head[custom_name= {"italic":false,"text":"Dream"} ,profile={id:[I;-995245452,910576926,-1563427938,1252034012],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvOGM1NjVhZDVkM2RjM2QwNDkxMTRhYzc0MjA0NzYyMjhmYzI0NWVhODRmOTNjYjI3M2ZiNTNhZmQyYjllOTQxZCJ9fX0="}]}] 1
execute unless score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Dream Head Bought!"}
execute if score @s ec_money >= heads ec_shop_price run scoreboard players operation @s ec_money -= heads ec_shop_price


execute as @s run function ec:ec_menus/shop/shop_heads
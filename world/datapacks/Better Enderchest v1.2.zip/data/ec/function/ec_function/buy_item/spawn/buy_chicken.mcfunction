clear @s chicken_spawn_egg[custom_name= {"italic":false,"text":"Buy Chicken Spawn"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:chicken_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Chicken Spawn"} }}}]

execute at @s if score @s ec_money >= eggs_1 ec_shop_price unless entity @s[tag=chicken_sacrifized] run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= eggs_1 ec_shop_price run playsound entity.villager.no master @s ~ ~ ~
execute at @s if entity @s[tag=chicken_sacrifized] run playsound entity.villager.no master @s ~ ~ ~

execute if entity @s[tag=chicken_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] run tellraw @s {"text": "Already Sacrifized","color": "red"}
execute if entity @s[tag=chicken_sacrifized] if entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] run tellraw @s {"text": "Spawner Sacrifized","color": "green"}
execute if entity @s[tag=chicken_sacrifized] if entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] run tag @s remove chicken_sacrifized

execute unless entity @s[tag=chicken_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_1 ec_shop_price run give @s chicken_spawn_egg
execute unless entity @s[tag=chicken_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] unless score @s ec_money >= eggs_1 ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute unless entity @s[tag=chicken_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_1 ec_shop_price run tellraw @s {"text":"Chicken Spawn Bought!"}
execute unless entity @s[tag=chicken_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:2b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_1 ec_shop_price run scoreboard players operation @s ec_money -= eggs_1 ec_shop_price
 

execute as @s run function ec:ec_menus/shop/shop_egg
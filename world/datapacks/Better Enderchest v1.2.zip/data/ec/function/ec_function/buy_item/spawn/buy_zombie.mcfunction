clear @s zombie_spawn_egg[custom_name= {"italic":false,"text":"Buy Zombie Spawn"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:zombie_spawn_egg",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Zombie Spawn"} }}}]

execute at @s if score @s ec_money >= eggs_2 ec_shop_price unless entity @s[tag=zombie_sacrifized] run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= eggs_2 ec_shop_price run playsound entity.villager.no master @s ~ ~ ~
execute at @s if entity @s[tag=zombie_sacrifized] run playsound entity.villager.no master @s ~ ~ ~

execute if entity @s[tag=zombie_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] run tellraw @s {"text": "Already Sacrifized","color": "red"}
execute if entity @s[tag=zombie_sacrifized] if entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] run tellraw @s {"text": "Spawner Sacrifized","color": "green"}
execute if entity @s[tag=zombie_sacrifized] if entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] run tag @s remove zombie_sacrifized

execute unless entity @s[tag=zombie_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_2 ec_shop_price run give @s zombie_spawn_egg
execute unless entity @s[tag=zombie_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] unless score @s ec_money >= eggs_2 ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute unless entity @s[tag=zombie_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_2 ec_shop_price run tellraw @s {"text":"Zombie Spawn Bought!"}
execute unless entity @s[tag=zombie_sacrifized] unless entity @s[nbt={EnderItems:[{Slot:14b,id:"minecraft:spawner"}]}] if score @s ec_money >= eggs_2 ec_shop_price run scoreboard players operation @s ec_money -= eggs_2 ec_shop_price
 

execute as @s run function ec:ec_menus/shop/shop_egg
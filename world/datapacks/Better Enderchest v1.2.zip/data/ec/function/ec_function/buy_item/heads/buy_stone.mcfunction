clear @s player_head[custom_name= {"italic":false,"text":"Buy Stone"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Stone"} }}}]

execute at @s if score @s ec_money >= heads ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= heads ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= heads ec_shop_price run give @s player_head[custom_name= {"italic":false,"text":"Stone"} ,profile={id:[I;399728080,-582922312,-1248013616,1492266146],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNGUwOTViNmUwOWY2MWZkNGJiNWM0ZmYyYzRhMGE3Zjk2NGYxY2U5NWZjMzljMGNmOTQyMjU2ZmI3YWJjMzY1MCJ9fX0="}]}] 1
execute unless score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Stone Head Bought!"}
execute if score @s ec_money >= heads ec_shop_price run scoreboard players operation @s ec_money -= heads ec_shop_price


execute as @s run function ec:ec_menus/shop/shop_heads
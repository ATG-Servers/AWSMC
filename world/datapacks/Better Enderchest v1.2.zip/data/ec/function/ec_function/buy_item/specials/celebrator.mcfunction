clear @s glowstone_dust[custom_name= {"italic":false,"text":"Celebrator"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:glowstone_dust",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Celebrator"} }}}]

execute at @s if score @s ec_money >= celebrator ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= celebrator ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= celebrator ec_shop_price run give @s glowstone_dust[custom_data={betterec:true},custom_name= {"italic":false,"text":"Celebrator "} ,consumable={consume_seconds:100000,has_consume_particles:false,animation:"none"},max_stack_size=1]
execute unless score @s ec_money >= celebrator ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= celebrator ec_shop_price run tellraw @s [{"text":"Celebrator Bought!"}]
execute if score @s ec_money >= celebrator ec_shop_price run scoreboard players operation @s ec_money -= celebrator ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_specials
clear @s emerald[custom_name= {"italic":false,"text":"Buy Mythril"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Mythril"} }}}]

execute at @s if score @s ec_money >= mythril ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= mythril ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= mythril ec_shop_price run give @s emerald[custom_name= {"text": "Mythril","italic": false,"color": "green"} ,item_name= "mythril" ,enchantment_glint_override=true] 1
execute unless score @s ec_money >= mythril ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= mythril ec_shop_price run tellraw @s {"text":"Mythril Bought!"}
execute if score @s ec_money >= mythril ec_shop_price run scoreboard players operation @s ec_money -= mythril ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_materials
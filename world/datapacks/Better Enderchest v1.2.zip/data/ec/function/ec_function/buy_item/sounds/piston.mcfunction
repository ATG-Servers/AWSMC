clear @s player_head[custom_name= {"italic":false,"text":"Buy Piston Ambient"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Piston Ambient"} }}}]

execute at @s if score @s ec_money >= sound_2 ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= sound_2 ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= sound_2 ec_shop_price run give @s player_head[custom_name= {"text": "Sound","italic": false} ,lore=[ "" , {"text": "Sound: Piston Ambient","italic": false,"color": "gray"} , {"text": "Place this on a note Block","italic": false,"color": "gray"} ],note_block_sound="minecraft:block.piston.extend",profile={id:[I;996537807,-1231534460,-2024641515,-530816022],properties:[{name:"textures",value:"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjIyZTQwYjRiZmJjYzA0MzMwNDRkODZkNjc2ODVmMDU2NzAyNTkwNDI3MWQwYTc0OTk2YWZiZTNmOWJlMmMwZiJ9fX0="}]}]
execute unless score @s ec_money >= sound_2 ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= sound_2 ec_shop_price run tellraw @s {"text":"Piston Ambient Bought!"}
execute if score @s ec_money >= sound_2 ec_shop_price run scoreboard players operation @s ec_money -= sound_2 ec_shop_price




execute as @s run function ec:ec_menus/shop/sounds_page
clear @s enchanted_book[custom_name= {"italic":false,"text":"Buy Book"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}}]

execute at @s if score @s ec_money >= enchantements ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= enchantements ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= enchantements ec_shop_price run give @s enchanted_book[stored_enchantments={knockback:3}] 1
execute unless score @s ec_money >= enchantements ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= enchantements ec_shop_price run tellraw @s {"text":"Book Bought!"}
execute if score @s ec_money >= enchantements ec_shop_price run scoreboard players operation @s ec_money -= enchantements ec_shop_price




execute as @s run function ec:ec_menus/shop/shop_enchantments
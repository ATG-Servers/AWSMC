clear @s player_head[custom_name= {"italic":false,"text":"Buy Your Head"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Your Head"} }}}]

execute at @s if score @s ec_money >= heads ec_shop_price run playsound ui.button.click master @s ~ ~ ~
execute at @s unless score @s ec_money >= heads ec_shop_price run playsound entity.villager.no master @s ~ ~ ~

execute if score @s ec_money >= heads ec_shop_price at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b,Tags:["your_head"]}
execute if score @s ec_money >= heads ec_shop_price run item replace entity @n[type=chest_minecart,tag=your_head] container.0 with player_head
execute if score @s ec_money >= heads ec_shop_price run item modify entity @n[type=chest_minecart,tag=your_head] container.0 ec:player_head
execute if score @s ec_money >= heads ec_shop_price run kill @n[type=chest_minecart,tag=your_head]
execute unless score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Not enough Money!","color":"red"}
execute if score @s ec_money >= heads ec_shop_price run tellraw @s {"text":"Your Head Head Bought!"}
execute if score @s ec_money >= heads ec_shop_price run scoreboard players operation @s ec_money -= heads ec_shop_price


execute as @s run function ec:ec_menus/shop/shop_heads
# calculates the prize for combining to items in an anvil

execute store result score @s ec_anvil_cost run data get entity @s EnderItems[{Slot:11b}].components."minecraft:repair_cost"
scoreboard players operation buff ec_anvil_cost = @s ec_anvil_cost
execute store result score @s ec_anvil_cost run data get entity @s EnderItems[{Slot:13b}].components."minecraft:repair_cost"
scoreboard players operation @s ec_anvil_cost += buff ec_anvil_cost
scoreboard players operation @s ec_anvil_cost *= Iron ec_sell_values
scoreboard players set buff ec_anvil_cost 0

# if both items don t have a cost component yet the prize is set to 10
execute as @a if score @s ec_anvil_cost matches 0 run scoreboard players set @s ec_anvil_cost 10
item modify entity @s enderchest.22 ec:anvil/prize
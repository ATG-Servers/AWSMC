#selects item #2
clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Place second Item here"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place second Item here"} }}}]

execute unless data entity @s EnderItems[{Slot:13b}] run item replace entity @s enderchest.13 with white_stained_glass_pane[custom_name= {"italic":false,"text":"Place second Item here"} ,custom_data={"better_ec":1b}]
function ec:ec_function/anvil/calculate_prize
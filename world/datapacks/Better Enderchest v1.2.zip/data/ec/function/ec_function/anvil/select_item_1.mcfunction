#selects item #1
clear @s white_stained_glass_pane[custom_name= {"italic":false,"text":"Place first Item here"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:white_stained_glass_pane",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place first Item here"} }}}]

execute unless data entity @s EnderItems[{Slot:11b}] run item replace entity @s enderchest.11 with white_stained_glass_pane[custom_name= {"italic":false,"text":"Place first Item here"} ,custom_data={"better_ec":1b}]

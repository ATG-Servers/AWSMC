#opens the anvil menu
scoreboard players set @s ec_menu 46

clear @s anvil[custom_name= {"italic":false,"text":"Anvil"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:anvil",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Anvil"} }}}]
execute at @s run playsound minecraft:ui.button.click master @s ~ ~ ~
function ec:ec_menus/anvil_page
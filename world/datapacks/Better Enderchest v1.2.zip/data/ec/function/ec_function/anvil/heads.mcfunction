# removes the playerheads from the player s inventory when they are taken out of the enderchest
clear @s player_head[custom_name= {"italic":false,"text":"+"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"+"} }}}]

clear @s player_head[custom_name= {"italic":false,"text":"-->"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"-->"} }}}]

execute unless data entity @s EnderItems[{Slot:12b,id:"minecraft:player_head"}] run item replace entity @s player.cursor from entity @s enderchest.12
execute unless data entity @s EnderItems[{Slot:14b,id:"minecraft:player_head"}] run item replace entity @s player.cursor from entity @s enderchest.14



function ec:ec_menus/anvil_page
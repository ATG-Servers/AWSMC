# double or nothing
clear @s netherite_ingot[custom_name= {"italic":false,"text":"Double or Nothing"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:netherite_ingot",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Double or Nothing"} }}}]

execute at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_bet matches 1.. at @s run playsound entity.villager.no master @s ~ ~ ~
gamerule send_command_feedback false
execute store result score don ec_bet run random value 1..10
execute if score don ec_bet matches 1..4 run scoreboard players operation @s ec_bet += @s ec_bet
execute if score don ec_bet matches 1..4 if score @s ec_bet matches 1.. at @s run playsound entity.player.levelup
execute if score don ec_bet matches 1..4 if score @s ec_bet matches 1.. run tellraw @s {"text": "Double!","color": "green"}
execute if score don ec_bet matches 5..10 if score @s ec_bet matches 1.. run tellraw @s {"text": "Nothing!","color": "red"}
execute if score don ec_bet matches 5..10 run scoreboard players set @s ec_bet 0
execute if score don ec_bet matches 5..10 at @s if score @s ec_bet matches 1.. run playsound entity.generic.explode
gamerule send_command_feedback true



function ec:ec_menus/casino_page
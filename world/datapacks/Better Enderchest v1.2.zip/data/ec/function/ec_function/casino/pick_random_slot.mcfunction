# randomizes the randomizer even more :)
$execute if entity @n[type=chest_minecart,tag=random,nbt={Items:[{Slot:$(slot)b}]}] run item replace entity @s enderchest.4 from entity @n[type=chest_minecart,tag=random] container.$(slot)

$execute unless entity @n[type=chest_minecart,tag=random,nbt={Items:[{Slot:$(slot)b}]}] run item replace entity @s enderchest.4 from entity @n[type=chest_minecart,tag=random] container.0
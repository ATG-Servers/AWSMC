clear @s redstone[custom_name= {"italic":false,"text":"Gamble Everything"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:redstone",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Empty Pot"} }}}]
execute at @s if score @s ec_money matches 1.. run playsound minecraft:block.composter.empty master @s ~ ~ ~
execute at @s unless score @s ec_money matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~
scoreboard players operation @s ec_bet += @s ec_money
scoreboard players set @s ec_money 0

function ec:ec_menus/casino_page
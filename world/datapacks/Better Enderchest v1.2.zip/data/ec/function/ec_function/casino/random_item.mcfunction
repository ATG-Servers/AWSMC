clear @s spawner[custom_name= {"italic":false,"text":"Random Item"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:spawner",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Random Item"} }}}]
execute if score @s ec_bet >= random_item ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_bet >= random_item ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless score @s ec_bet >= random_item ec_shop_price at @s run tellraw @s {text:"Not enough money bet!",color:red}
execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b, Tags:[restore_item]}
item replace entity @n[type=chest_minecart,tag=restore_item] container.0 from entity @s enderchest.4
kill @n[type=chest_minecart,tag=restore_item]
item replace entity @s enderchest.4 with air

execute if score @s ec_bet >= random_item ec_shop_price at @s run summon chest_minecart ~ ~2 ~ {NoGravity:1b, Tags:[random]}
execute if score @s ec_bet >= random_item ec_shop_price at @s run loot replace entity @n[tag=random,type=chest_minecart] container.0 loot ec:random_item

execute if score @s ec_bet >= random_item ec_shop_price store result storage random slot int 1 run random value 0..17
execute if score @s ec_bet >= random_item ec_shop_price run function ec:ec_function/casino/pick_random_slot with storage random
execute if score @s ec_bet >= random_item ec_shop_price run data merge entity @n[type=chest_minecart,tag=random] {Items:[]}
execute if score @s ec_bet >= random_item ec_shop_price run kill @n[type=chest_minecart,tag=random]
execute if score @s ec_bet >= random_item ec_shop_price run scoreboard players operation @s ec_bet -= random_item ec_shop_price



function ec:ec_menus/casino_page
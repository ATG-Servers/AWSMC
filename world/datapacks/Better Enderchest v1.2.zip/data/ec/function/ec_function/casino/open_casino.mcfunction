scoreboard players set @s ec_menu 37
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s sunflower[custom_name= {"italic":false,"text":"Casino"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sunflower",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Casino"} }}}]

function ec:ec_menus/casino_page
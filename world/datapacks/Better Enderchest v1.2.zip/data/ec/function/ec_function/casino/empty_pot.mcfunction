clear @s emerald[custom_name= {"italic":false,"text":"Empty Pot"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:emerald",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Empty Pot"} }}}]
execute at @s if score @s ec_bet matches 1.. run playsound minecraft:block.composter.fill master @s ~ ~ ~
execute at @s unless score @s ec_bet matches 1.. run playsound minecraft:entity.villager.no master @s ~ ~ ~
scoreboard players operation @s ec_money += @s ec_bet
scoreboard players set @s ec_bet 0

function ec:ec_menus/casino_page
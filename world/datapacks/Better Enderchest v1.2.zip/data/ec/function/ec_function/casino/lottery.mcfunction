clear @s diamond[custom_name= {"italic":false,"text":"Lottery"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Lottery"} }}}]
execute if score @s ec_bet >= lottery_price ec_shop_price at @s run playsound ui.button.click master @s ~ ~ ~
execute unless score @s ec_bet >= lottery_price ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless score @s ec_bet >= lottery_price ec_shop_price at @s run tellraw @s {text:"Not enough money bet!",color:red}
execute if score @s ec_bet >= lottery_price ec_shop_price run scoreboard players operation lottery_pot ec_bet += lottery_add_pot ec_shop_price
execute if score @s ec_bet >= lottery_price ec_shop_price store result score lottery ec_bet run random value 1..1000
execute if score @s ec_bet >= lottery_price ec_shop_price if score lottery ec_bet matches 42 run tellraw @a [{"text": "Server: ","color": "yellow"},{"selector": "@s","color": "gold"},{"text": " has won ","color": "white"},{"score": {"name": "lottery_pot","objective": "ec_bet"},"color": "gold"},{"text": "€ in the lottery!","color": "white"}]
execute if score @s ec_bet >= lottery_price ec_shop_price if score lottery ec_bet matches 42 as @a at @s run playsound block.end_portal.spawn master @s ~ ~ ~
execute if score @s ec_bet >= lottery_price ec_shop_price if score lottery ec_bet matches 42 run scoreboard players operation @s ec_bet += lottery_pot ec_bet
execute if score @s ec_bet >= lottery_price ec_shop_price if score lottery ec_bet matches 42 run scoreboard players set lottery_pot ec_bet 0
execute if score @s ec_bet >= lottery_price ec_shop_price run scoreboard players operation @s ec_bet -= lottery_price ec_shop_price

function ec:ec_menus/casino_page
clear @s sunflower[custom_name= {"italic":false,"text":"Place Bet"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:sunflower",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Place Bet"} }}}]

function ec:ec_menus/casino_page
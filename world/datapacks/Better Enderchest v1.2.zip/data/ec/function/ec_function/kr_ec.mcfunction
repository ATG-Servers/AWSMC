scoreboard players set @s kr_ec_cross 1
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s command_block[custom_name= {"italic":false,"text":"Simple Command GUI"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:command_block",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Simple Command GUI"} }}}]

# scoreboard players set @s kr_ec_cross 0
function ec:ec_menus/main_page_1
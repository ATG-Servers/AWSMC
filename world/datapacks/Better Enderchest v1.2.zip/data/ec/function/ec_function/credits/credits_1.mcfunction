execute at @s run playsound ui.button.click master @s ~ ~ ~


clear @s diamond[custom_name= {"color":"green","italic":false,"text":"Sturmbueffel100"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond",count:1,components:{"minecraft:custom_name": {"color":"green","italic":false,"text":"Sturmbueffel100"} }}}]

tellraw @s ["",{"text":"Server: ","color":"yellow"},{"text":"[Planet Minecraft]","click_event":{"action":"open_url","url":"https://www.planetminecraft.com/member/sturmbueffel100/"}}]

execute as @s run function ec:ec_menus/credits_page
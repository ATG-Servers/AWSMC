scoreboard players set @s ec_menu 3
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s slime_ball[custom_name= {"italic":false,"text":"Credits"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:slime_ball",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Credits"} }}}]


execute as @s run function ec:ec_menus/credits_page


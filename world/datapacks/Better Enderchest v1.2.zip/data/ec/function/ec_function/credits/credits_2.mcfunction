execute at @s run playsound ui.button.click master @s ~ ~ ~


clear @s redstone[custom_name= {"italic":false,"text":"Inspired by:"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:redstone",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Inspired by:"} }}}]

tellraw @s ["",{"text":"Server: ","color":"yellow"},"Sparkofphoenix","\n",{"text":"Server: ","color":"yellow"},{"text":"[Planet Minecraft]","click_event":{"action":"open_url","url":"https://www.planetminecraft.com/member/sparkofphoenix/"}},"\n",{"text":"Server: ","color":"yellow"},{"text":"[YouTube]","color":"dark_red","click_event":{"action":"open_url","url":"https://www.youtube.com/@SparkofPhoenix"}},"\n",{"text":"Server: ","color":"yellow"},{"text":"[Twitch]","color":"dark_purple","click_event":{"action":"open_url","url":"https://www.twitch.tv/sparkofphoenixtv"}}]

execute as @s run function ec:ec_menus/credits_page
execute at @s run playsound ui.button.click master @s ~ ~ ~


clear @s chest[custom_name= {"italic":false,"text":"Want more?"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Want more?"} }}}]

tellraw @s [{"text":""},{"text":"Server: ","color":"yellow"},{"text":"[Simple Command GUI]","click_event":{"action":"open_url","url":"https://www.planetminecraft.com/data-pack/simple-command-gui-visual-command-interface/"}}]

execute as @s run function ec:ec_menus/credits_page
scoreboard players set @s set_home 0

execute store result score @s ec_x_home run data get entity @s Pos[0]
execute store result score @s ec_y_home run data get entity @s Pos[1]
execute store result score @s ec_z_home run data get entity @s Pos[2]
clear @s oak_planks[custom_name= {"italic":false,"text":"Home"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:oak_planks",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Home"} }}}]

execute if score @s ec_x_home matches -2147483648..2147483647 store result storage home x int 1 run scoreboard players get @s ec_x_home
execute if score @s ec_x_home matches -2147483648..2147483647 store result storage home y int 1 run scoreboard players get @s ec_y_home
execute if score @s ec_x_home matches -2147483648..2147483647 store result storage home z int 1 run scoreboard players get @s ec_z_home

execute if score @s ec_money >= tp_home ec_shop_price unless score @s ec_x_home matches -2147483648..2147483647 run tellraw @s {"text": "Set your home with /trigger set_home first!","color": "red"}


execute if score @s ec_money >= tp_home ec_shop_price if score @s ec_x_home matches -2147483648..2147483647 run function ec:ec_function/tp/home/tp_coords with storage home
execute if score @s ec_money >= tp_home ec_shop_price if score @s ec_x_home matches -2147483648..2147483647 at @s run playsound entity.player.teleport master @s ~ ~ ~
execute if score @s ec_money >= tp_home ec_shop_price if score @s ec_x_home matches -2147483648..2147483647 run scoreboard players operation @s ec_money -= tp_home ec_shop_price
execute unless score @s ec_money >= tp_home ec_shop_price run tellraw @s {text:"Not enough money!",color:red}

function ec:ec_menus/teleporter_page
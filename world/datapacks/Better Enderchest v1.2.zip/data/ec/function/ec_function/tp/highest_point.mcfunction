clear @s player_head[custom_name= {"italic":false,"text":"Highest Block"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Highest Block"} }}}]


execute at @s positioned over world_surface run tp @s ~ ~ ~
execute at @s run playsound entity.player.teleport master @s ~ ~ ~
function ec:ec_menus/teleporter_page
execute if score @s ec_menu matches 37 run scoreboard players operation @s ec_money += @s ec_bet
execute if score @s ec_menu matches 37 run scoreboard players set @s ec_bet 0
execute at @s run playsound ui.button.click master @s ~ ~ ~

execute if score @s ec_menu matches 6 run scoreboard players operation @s ec_money += @s ec_send_money
execute if score @s ec_menu matches 6 run scoreboard players set @s ec_send_money 0

execute at @s run summon chest_minecart ~ ~ ~ {NoGravity:1b, Tags:[restore_item]}

execute if score @s ec_menu matches 29 run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.13
execute if score @s ec_menu matches 26 run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.12
execute if score @s ec_menu matches 25 run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.14
execute if score @s ec_menu matches 37 run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.4
execute if score @s ec_menu matches 39 run function ec:ec_function/shulker/safe_changes
execute if score @s ec_menu matches 39..40 run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s player.cursor
execute if score @s ec_menu matches 39..40 run item replace entity @s player.cursor with air
execute if score @s ec_menu matches 46 unless entity @s[nbt={EnderItems:[{Slot:11b,id:"minecraft:white_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.11
execute if score @s ec_menu matches 46 unless entity @s[nbt={EnderItems:[{Slot:13b,id:"minecraft:white_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.1 from entity @s enderchest.13
execute if score @s ec_menu matches 46 run item replace entity @n[tag=restore_item,type=chest_minecart] container.2 from entity @s enderchest.15

#restore item mail
execute if score @s ec_menu matches 22 unless entity @s[nbt={EnderItems:[{Slot:20b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.0 from entity @s enderchest.20
execute if score @s ec_menu matches 22 unless entity @s[nbt={EnderItems:[{Slot:21b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.1 from entity @s enderchest.21
execute if score @s ec_menu matches 22 unless entity @s[nbt={EnderItems:[{Slot:22b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.2 from entity @s enderchest.22
execute if score @s ec_menu matches 22 unless entity @s[nbt={EnderItems:[{Slot:23b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.3 from entity @s enderchest.23
execute if score @s ec_menu matches 22 unless entity @s[nbt={EnderItems:[{Slot:24b,id:"minecraft:red_stained_glass_pane"}]}] run item replace entity @n[tag=restore_item,type=chest_minecart] container.4 from entity @s enderchest.24

#graveyard
execute if score @s ec_menu matches 57 if score @s ec_has_died matches 100.. run scoreboard players set @s ec_has_died 0
execute if score @s ec_menu matches 57 if score @s ec_has_died matches 1..100 run scoreboard players set @s ec_has_died 100

kill @n[tag=restore_item,type=chest_minecart]

scoreboard players set @s ec_menu 1

clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]

tag @s remove ec_mailslot_1
tag @s remove ec_mailslot_2
tag @s remove ec_mailslot_3
tag @s remove ec_mailslot_4
tag @s remove ec_mailslot_5

scoreboard players set @s ec_inshop 0

execute as @s run function ec:ec_menus/main_page_1
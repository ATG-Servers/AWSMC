scoreboard players set @s ec_menu 41

clear @s player_head[custom_name= {"italic":false,"text":"Statistics"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:player_head",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Statistics"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:stats/calculate_distance
function ec:ec_menus/stats_page
clear @s ender_chest[custom_name= {"italic":false,"text":"Enderchest Opened"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest Opened"} }}}]

clear @s clock[custom_name= {"italic":false,"text":"Time Played"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:clock",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Time Played"} }}}]

clear @s totem_of_undying[custom_name= {"italic":false,"text":"Deaths"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:totem_of_undying",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Deaths"} }}}]

clear @s diamond_sword[custom_name= {"italic":false,"text":"Kills"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Kills"} }}}]

clear @s barrier[custom_name= {"italic":false,"text":"Game Left"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrier",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Game Left"} }}}]

clear @s diamond_boots[custom_name= {"italic":false,"text":"Distance Traveled"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_boots",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Distance Traveled"} }}}]
execute at @s run playsound ui.button.click master @s ~ ~ ~

function ec:stats/calculate_distance
function ec:ec_menus/stats_page
execute if score open ec_group_chest matches 1 unless entity @a[scores={ec_group_chest=1}] run scoreboard players set closed ec_group_chest 1
execute if score open ec_group_chest matches 1 unless entity @a[scores={ec_group_chest=1}] run scoreboard players set open ec_group_chest 0
schedule function ec:ec_function/group_chest/check_force_leave 1s replace
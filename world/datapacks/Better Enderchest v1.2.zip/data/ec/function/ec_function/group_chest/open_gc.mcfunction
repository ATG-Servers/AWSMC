clear @s barrel[custom_name= {"italic":false,"text":"Group Chest"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:barrel",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Group Chest"} }}}]
execute at @s run playsound block.barrel.open master @s ~ ~ ~

execute if score open ec_group_chest matches 0 run scoreboard players set @s ec_menu 51
execute unless score open ec_group_chest matches 0 run tellraw @s [{"text": "The Group Chest is currently opend by "},{"selector": "@p[scores={ec_group_chest=1}]"}]
execute unless score open ec_group_chest matches 0 at @s run playsound block.chest.locked master @s ~ ~ ~
execute if score open ec_group_chest matches 0 run function ec:ec_menus/gc_page
execute unless score open ec_group_chest matches 0 run function ec:ec_menus/main_page_1

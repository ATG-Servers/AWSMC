scoreboard players reset * ec_group_chest
scoreboard players set open ec_group_chest 0
scoreboard players set closed ec_group_chest 0
scoreboard players set @a ec_group_chest 0
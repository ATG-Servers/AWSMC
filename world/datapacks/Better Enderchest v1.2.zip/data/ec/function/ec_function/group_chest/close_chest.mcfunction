clear @s hopper[custom_name= {"italic":false,"text":"Back"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:hopper",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}}]
execute at @s run playsound block.barrel.close master @s ~ ~ ~

scoreboard players set @s ec_menu 1
scoreboard players set @s ec_group_chest 0
scoreboard players set open ec_group_chest 0

data modify storage group_chest Items set from entity @s EnderItems

function ec:ec_menus/main_page_1
scoreboard players set @p[tag=group_chest] ec_group_chest 1
scoreboard players set open ec_group_chest 1

tag @a remove group_chest
execute at @s run summon chest_minecart ~ ~ ~ {Tags:[graveyard_inventory],NoGravity:1b}
$data modify entity @n[type=chest_minecart,tag=graveyard_inventory] Items set from storage graveyard player.$(current_player).inventory

execute at @s run item replace entity @s enderchest.0 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.0
execute at @s run item replace entity @s enderchest.1 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.1
execute at @s run item replace entity @s enderchest.2 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.2
execute at @s run item replace entity @s enderchest.3 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.3
execute at @s run item replace entity @s enderchest.4 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.4
execute at @s run item replace entity @s enderchest.5 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.5
execute at @s run item replace entity @s enderchest.6 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.6
execute at @s run item replace entity @s enderchest.7 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.7
execute at @s run item replace entity @s enderchest.8 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.8
execute at @s run item replace entity @s enderchest.9 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.9
execute at @s run item replace entity @s enderchest.10 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.10
execute at @s run item replace entity @s enderchest.11 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.11
execute at @s run item replace entity @s enderchest.12 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.12
execute at @s run item replace entity @s enderchest.13 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.13
execute at @s run item replace entity @s enderchest.14 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.14
execute at @s run item replace entity @s enderchest.15 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.15
execute at @s run item replace entity @s enderchest.16 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.16
execute at @s run item replace entity @s enderchest.17 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.17
execute at @s run item replace entity @s enderchest.18 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.18
execute at @s run item replace entity @s enderchest.19 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.19
execute at @s run item replace entity @s enderchest.20 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.20
execute at @s run item replace entity @s enderchest.21 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.21
execute at @s run item replace entity @s enderchest.22 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.22
execute at @s run item replace entity @s enderchest.23 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.23
execute at @s run item replace entity @s enderchest.24 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.24
execute at @s run item replace entity @s enderchest.25 from entity @n[type=chest_minecart,tag=graveyard_inventory] container.25

item modify entity @s enderchest.0 {function:set_components,components:{custom_data:{ec_graveyard_slot:0b}}}
item modify entity @s enderchest.1 {function:set_components,components:{custom_data:{ec_graveyard_slot:1b}}}
item modify entity @s enderchest.2 {function:set_components,components:{custom_data:{ec_graveyard_slot:2b}}}
item modify entity @s enderchest.3 {function:set_components,components:{custom_data:{ec_graveyard_slot:3b}}}
item modify entity @s enderchest.4 {function:set_components,components:{custom_data:{ec_graveyard_slot:4b}}}
item modify entity @s enderchest.5 {function:set_components,components:{custom_data:{ec_graveyard_slot:5b}}}
item modify entity @s enderchest.6 {function:set_components,components:{custom_data:{ec_graveyard_slot:6b}}}
item modify entity @s enderchest.7 {function:set_components,components:{custom_data:{ec_graveyard_slot:7b}}}
item modify entity @s enderchest.8 {function:set_components,components:{custom_data:{ec_graveyard_slot:8b}}}
item modify entity @s enderchest.9 {function:set_components,components:{custom_data:{ec_graveyard_slot:9b}}}
item modify entity @s enderchest.10 {function:set_components,components:{custom_data:{ec_graveyard_slot:10b}}}
item modify entity @s enderchest.11 {function:set_components,components:{custom_data:{ec_graveyard_slot:11b}}}
item modify entity @s enderchest.12 {function:set_components,components:{custom_data:{ec_graveyard_slot:12b}}}
item modify entity @s enderchest.13 {function:set_components,components:{custom_data:{ec_graveyard_slot:13b}}}
item modify entity @s enderchest.14 {function:set_components,components:{custom_data:{ec_graveyard_slot:14b}}}
item modify entity @s enderchest.15 {function:set_components,components:{custom_data:{ec_graveyard_slot:15b}}}
item modify entity @s enderchest.16 {function:set_components,components:{custom_data:{ec_graveyard_slot:16b}}}
item modify entity @s enderchest.17 {function:set_components,components:{custom_data:{ec_graveyard_slot:17b}}}
item modify entity @s enderchest.18 {function:set_components,components:{custom_data:{ec_graveyard_slot:18b}}}
item modify entity @s enderchest.19 {function:set_components,components:{custom_data:{ec_graveyard_slot:19b}}}
item modify entity @s enderchest.20 {function:set_components,components:{custom_data:{ec_graveyard_slot:20b}}}
item modify entity @s enderchest.21 {function:set_components,components:{custom_data:{ec_graveyard_slot:21b}}}
item modify entity @s enderchest.22 {function:set_components,components:{custom_data:{ec_graveyard_slot:22b}}}
item modify entity @s enderchest.23 {function:set_components,components:{custom_data:{ec_graveyard_slot:23b}}}
item modify entity @s enderchest.24 {function:set_components,components:{custom_data:{ec_graveyard_slot:24b}}}
item modify entity @s enderchest.25 {function:set_components,components:{custom_data:{ec_graveyard_slot:25b}}}


scoreboard players set graveyard_slot ec_misc 0
execute store result storage graveyard slot_import int 1 run scoreboard players get graveyard_slot ec_misc
function ec:ec_function/graveyard/inventory/get_prize with storage graveyard

execute at @s run data merge entity @n[type=chest_minecart,tag=graveyard_inventory] {Items:[]}
execute at @s run kill @n[type=chest_minecart,tag=graveyard_inventory]


scoreboard players set @s ec_menu 59
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s diamond_pickaxe[custom_name= {"italic":false,"text":"Hotbar & Armor"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_pickaxe",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Hotbar & Armor"} }}}]

function ec:ec_menus/graveyard/hotbar_page
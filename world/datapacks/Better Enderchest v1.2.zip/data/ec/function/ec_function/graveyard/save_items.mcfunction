data remove storage graveyard buffer
$data remove storage graveyard player.$(current_player)
function ec:ec_function/back_to_main_page

data modify storage graveyard buffer.inventory[{Slot:0b}].id set from entity @s Inventory[{Slot:9b}].id
data modify storage graveyard buffer.inventory[{Slot:1b}].id set from entity @s Inventory[{Slot:10b}].id
data modify storage graveyard buffer.inventory[{Slot:2b}].id set from entity @s Inventory[{Slot:11b}].id
data modify storage graveyard buffer.inventory[{Slot:3b}].id set from entity @s Inventory[{Slot:12b}].id
data modify storage graveyard buffer.inventory[{Slot:4b}].id set from entity @s Inventory[{Slot:13b}].id
data modify storage graveyard buffer.inventory[{Slot:5b}].id set from entity @s Inventory[{Slot:14b}].id
data modify storage graveyard buffer.inventory[{Slot:6b}].id set from entity @s Inventory[{Slot:15b}].id
data modify storage graveyard buffer.inventory[{Slot:7b}].id set from entity @s Inventory[{Slot:16b}].id
data modify storage graveyard buffer.inventory[{Slot:8b}].id set from entity @s Inventory[{Slot:17b}].id
data modify storage graveyard buffer.inventory[{Slot:9b}].id set from entity @s Inventory[{Slot:18b}].id
data modify storage graveyard buffer.inventory[{Slot:10b}].id set from entity @s Inventory[{Slot:19b}].id
data modify storage graveyard buffer.inventory[{Slot:11b}].id set from entity @s Inventory[{Slot:20b}].id
data modify storage graveyard buffer.inventory[{Slot:12b}].id set from entity @s Inventory[{Slot:21b}].id
data modify storage graveyard buffer.inventory[{Slot:13b}].id set from entity @s Inventory[{Slot:22b}].id
data modify storage graveyard buffer.inventory[{Slot:14b}].id set from entity @s Inventory[{Slot:23b}].id
data modify storage graveyard buffer.inventory[{Slot:15b}].id set from entity @s Inventory[{Slot:24b}].id
data modify storage graveyard buffer.inventory[{Slot:16b}].id set from entity @s Inventory[{Slot:25b}].id
data modify storage graveyard buffer.inventory[{Slot:17b}].id set from entity @s Inventory[{Slot:26b}].id
data modify storage graveyard buffer.inventory[{Slot:18b}].id set from entity @s Inventory[{Slot:27b}].id
data modify storage graveyard buffer.inventory[{Slot:19b}].id set from entity @s Inventory[{Slot:28b}].id
data modify storage graveyard buffer.inventory[{Slot:20b}].id set from entity @s Inventory[{Slot:29b}].id
data modify storage graveyard buffer.inventory[{Slot:21b}].id set from entity @s Inventory[{Slot:30b}].id
data modify storage graveyard buffer.inventory[{Slot:22b}].id set from entity @s Inventory[{Slot:31b}].id
data modify storage graveyard buffer.inventory[{Slot:23b}].id set from entity @s Inventory[{Slot:32b}].id
data modify storage graveyard buffer.inventory[{Slot:24b}].id set from entity @s Inventory[{Slot:33b}].id
data modify storage graveyard buffer.inventory[{Slot:25b}].id set from entity @s Inventory[{Slot:34b}].id

data modify storage graveyard buffer.hotbar[{Slot:18b}].id set from entity @s Inventory[{Slot:35b}].id

data modify storage graveyard buffer.inventory[{Slot:0b}].count set from entity @s Inventory[{Slot:9b}].count
data modify storage graveyard buffer.inventory[{Slot:1b}].count set from entity @s Inventory[{Slot:10b}].count
data modify storage graveyard buffer.inventory[{Slot:2b}].count set from entity @s Inventory[{Slot:11b}].count
data modify storage graveyard buffer.inventory[{Slot:3b}].count set from entity @s Inventory[{Slot:12b}].count
data modify storage graveyard buffer.inventory[{Slot:4b}].count set from entity @s Inventory[{Slot:13b}].count
data modify storage graveyard buffer.inventory[{Slot:5b}].count set from entity @s Inventory[{Slot:14b}].count
data modify storage graveyard buffer.inventory[{Slot:6b}].count set from entity @s Inventory[{Slot:15b}].count
data modify storage graveyard buffer.inventory[{Slot:7b}].count set from entity @s Inventory[{Slot:16b}].count
data modify storage graveyard buffer.inventory[{Slot:8b}].count set from entity @s Inventory[{Slot:17b}].count
data modify storage graveyard buffer.inventory[{Slot:9b}].count set from entity @s Inventory[{Slot:18b}].count
data modify storage graveyard buffer.inventory[{Slot:10b}].count set from entity @s Inventory[{Slot:19b}].count
data modify storage graveyard buffer.inventory[{Slot:11b}].count set from entity @s Inventory[{Slot:20b}].count
data modify storage graveyard buffer.inventory[{Slot:12b}].count set from entity @s Inventory[{Slot:21b}].count
data modify storage graveyard buffer.inventory[{Slot:13b}].count set from entity @s Inventory[{Slot:22b}].count
data modify storage graveyard buffer.inventory[{Slot:14b}].count set from entity @s Inventory[{Slot:23b}].count
data modify storage graveyard buffer.inventory[{Slot:15b}].count set from entity @s Inventory[{Slot:24b}].count
data modify storage graveyard buffer.inventory[{Slot:16b}].count set from entity @s Inventory[{Slot:25b}].count
data modify storage graveyard buffer.inventory[{Slot:17b}].count set from entity @s Inventory[{Slot:26b}].count
data modify storage graveyard buffer.inventory[{Slot:18b}].count set from entity @s Inventory[{Slot:27b}].count
data modify storage graveyard buffer.inventory[{Slot:19b}].count set from entity @s Inventory[{Slot:28b}].count
data modify storage graveyard buffer.inventory[{Slot:20b}].count set from entity @s Inventory[{Slot:29b}].count
data modify storage graveyard buffer.inventory[{Slot:21b}].count set from entity @s Inventory[{Slot:30b}].count
data modify storage graveyard buffer.inventory[{Slot:22b}].count set from entity @s Inventory[{Slot:31b}].count
data modify storage graveyard buffer.inventory[{Slot:23b}].count set from entity @s Inventory[{Slot:32b}].count
data modify storage graveyard buffer.inventory[{Slot:24b}].count set from entity @s Inventory[{Slot:33b}].count
data modify storage graveyard buffer.inventory[{Slot:25b}].count set from entity @s Inventory[{Slot:34b}].count

data modify storage graveyard buffer.hotbar[{Slot:18b}].count set from entity @s Inventory[{Slot:35b}].count

data modify storage graveyard buffer.inventory[{Slot:0b}].components set from entity @s Inventory[{Slot:9b}].components
data modify storage graveyard buffer.inventory[{Slot:1b}].components set from entity @s Inventory[{Slot:10b}].components
data modify storage graveyard buffer.inventory[{Slot:2b}].components set from entity @s Inventory[{Slot:11b}].components
data modify storage graveyard buffer.inventory[{Slot:3b}].components set from entity @s Inventory[{Slot:12b}].components
data modify storage graveyard buffer.inventory[{Slot:4b}].components set from entity @s Inventory[{Slot:13b}].components
data modify storage graveyard buffer.inventory[{Slot:5b}].components set from entity @s Inventory[{Slot:14b}].components
data modify storage graveyard buffer.inventory[{Slot:6b}].components set from entity @s Inventory[{Slot:15b}].components
data modify storage graveyard buffer.inventory[{Slot:7b}].components set from entity @s Inventory[{Slot:16b}].components
data modify storage graveyard buffer.inventory[{Slot:8b}].components set from entity @s Inventory[{Slot:17b}].components
data modify storage graveyard buffer.inventory[{Slot:9b}].components set from entity @s Inventory[{Slot:18b}].components
data modify storage graveyard buffer.inventory[{Slot:10b}].components set from entity @s Inventory[{Slot:19b}].components
data modify storage graveyard buffer.inventory[{Slot:11b}].components set from entity @s Inventory[{Slot:20b}].components
data modify storage graveyard buffer.inventory[{Slot:12b}].components set from entity @s Inventory[{Slot:21b}].components
data modify storage graveyard buffer.inventory[{Slot:13b}].components set from entity @s Inventory[{Slot:22b}].components
data modify storage graveyard buffer.inventory[{Slot:14b}].components set from entity @s Inventory[{Slot:23b}].components
data modify storage graveyard buffer.inventory[{Slot:15b}].components set from entity @s Inventory[{Slot:24b}].components
data modify storage graveyard buffer.inventory[{Slot:16b}].components set from entity @s Inventory[{Slot:25b}].components
data modify storage graveyard buffer.inventory[{Slot:17b}].components set from entity @s Inventory[{Slot:26b}].components
data modify storage graveyard buffer.inventory[{Slot:18b}].components set from entity @s Inventory[{Slot:27b}].components
data modify storage graveyard buffer.inventory[{Slot:19b}].components set from entity @s Inventory[{Slot:28b}].components
data modify storage graveyard buffer.inventory[{Slot:20b}].components set from entity @s Inventory[{Slot:29b}].components
data modify storage graveyard buffer.inventory[{Slot:21b}].components set from entity @s Inventory[{Slot:30b}].components
data modify storage graveyard buffer.inventory[{Slot:22b}].components set from entity @s Inventory[{Slot:31b}].components
data modify storage graveyard buffer.inventory[{Slot:23b}].components set from entity @s Inventory[{Slot:32b}].components
data modify storage graveyard buffer.inventory[{Slot:24b}].components set from entity @s Inventory[{Slot:33b}].components
data modify storage graveyard buffer.inventory[{Slot:25b}].components set from entity @s Inventory[{Slot:34b}].components

data modify storage graveyard buffer.hotbar[{Slot:18}].components set from entity @s Inventory[{Slot:35b}].components

data modify storage graveyard buffer.hotbar[{Slot:9b}].id set from entity @s Inventory[{Slot:0b}].id
data modify storage graveyard buffer.hotbar[{Slot:10b}].id set from entity @s Inventory[{Slot:1b}].id
data modify storage graveyard buffer.hotbar[{Slot:11b}].id set from entity @s Inventory[{Slot:2b}].id
data modify storage graveyard buffer.hotbar[{Slot:12b}].id set from entity @s Inventory[{Slot:3b}].id
data modify storage graveyard buffer.hotbar[{Slot:13b}].id set from entity @s Inventory[{Slot:4b}].id
data modify storage graveyard buffer.hotbar[{Slot:14b}].id set from entity @s Inventory[{Slot:5b}].id
data modify storage graveyard buffer.hotbar[{Slot:15b}].id set from entity @s Inventory[{Slot:6b}].id
data modify storage graveyard buffer.hotbar[{Slot:16b}].id set from entity @s Inventory[{Slot:7b}].id
data modify storage graveyard buffer.hotbar[{Slot:17b}].id set from entity @s Inventory[{Slot:8b}].id

data modify storage graveyard buffer.hotbar[{Slot:9b}].count set from entity @s Inventory[{Slot:0b}].count
data modify storage graveyard buffer.hotbar[{Slot:10b}].count set from entity @s Inventory[{Slot:1b}].count
data modify storage graveyard buffer.hotbar[{Slot:11b}].count set from entity @s Inventory[{Slot:2b}].count
data modify storage graveyard buffer.hotbar[{Slot:12b}].count set from entity @s Inventory[{Slot:3b}].count
data modify storage graveyard buffer.hotbar[{Slot:13b}].count set from entity @s Inventory[{Slot:4b}].count
data modify storage graveyard buffer.hotbar[{Slot:14b}].count set from entity @s Inventory[{Slot:5b}].count
data modify storage graveyard buffer.hotbar[{Slot:15b}].count set from entity @s Inventory[{Slot:6b}].count
data modify storage graveyard buffer.hotbar[{Slot:16b}].count set from entity @s Inventory[{Slot:7b}].count
data modify storage graveyard buffer.hotbar[{Slot:17b}].count set from entity @s Inventory[{Slot:8b}].count

data modify storage graveyard buffer.hotbar[{Slot:9b}].components set from entity @s Inventory[{Slot:0b}].components
data modify storage graveyard buffer.hotbar[{Slot:10b}].components set from entity @s Inventory[{Slot:1b}].components
data modify storage graveyard buffer.hotbar[{Slot:11b}].components set from entity @s Inventory[{Slot:2b}].components
data modify storage graveyard buffer.hotbar[{Slot:12b}].components set from entity @s Inventory[{Slot:3b}].components
data modify storage graveyard buffer.hotbar[{Slot:13b}].components set from entity @s Inventory[{Slot:4b}].components
data modify storage graveyard buffer.hotbar[{Slot:14b}].components set from entity @s Inventory[{Slot:5b}].components
data modify storage graveyard buffer.hotbar[{Slot:15b}].components set from entity @s Inventory[{Slot:6b}].components
data modify storage graveyard buffer.hotbar[{Slot:16b}].components set from entity @s Inventory[{Slot:7b}].components
data modify storage graveyard buffer.hotbar[{Slot:17b}].components set from entity @s Inventory[{Slot:8b}].components

data modify storage graveyard buffer.hotbar[{Slot:22b}].id set from entity @s equipment.offhand.id
data modify storage graveyard buffer.hotbar[{Slot:22b}].count set from entity @s equipment.offhand.count
data modify storage graveyard buffer.hotbar[{Slot:22b}].components set from entity @s equipment.offhand
data modify storage graveyard buffer.hotbar[{Slot:1b}].id set from entity @s equipment.head.id
data modify storage graveyard buffer.hotbar[{Slot:1b}].count set from entity @s equipment.head.count
data modify storage graveyard buffer.hotbar[{Slot:1b}].components set from entity @s equipment.head.components
data modify storage graveyard buffer.hotbar[{Slot:7b}].id set from entity @s equipment.feet.id
data modify storage graveyard buffer.hotbar[{Slot:7b}].count set from entity @s equipment.feet.count
data modify storage graveyard buffer.hotbar[{Slot:7b}].components set from entity @s equipment.feet.components
data modify storage graveyard buffer.hotbar[{Slot:5b}].id set from entity @s equipment.legs.id
data modify storage graveyard buffer.hotbar[{Slot:5b}].count set from entity @s equipment.legs.count
data modify storage graveyard buffer.hotbar[{Slot:5b}].components set from entity @s equipment.legs.components
data modify storage graveyard buffer.hotbar[{Slot:3b}].id set from entity @s equipment.chest.id
data modify storage graveyard buffer.hotbar[{Slot:3b}].count set from entity @s equipment.chest.count
data modify storage graveyard buffer.hotbar[{Slot:3b}].components set from entity @s equipment.chest.components

$data modify storage graveyard player.$(current_player) set from storage graveyard buffer
execute at @s run summon chest_minecart ~ ~ ~ {Tags:[graveyard_hotbar],NoGravity:1b}
$data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items set from storage graveyard player.$(current_player).hotbar

execute at @s run item replace entity @s enderchest.9 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.9
execute at @s run item replace entity @s enderchest.10 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.10
execute at @s run item replace entity @s enderchest.11 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.11
execute at @s run item replace entity @s enderchest.12 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.12
execute at @s run item replace entity @s enderchest.13 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.13
execute at @s run item replace entity @s enderchest.14 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.14
execute at @s run item replace entity @s enderchest.15 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.15
execute at @s run item replace entity @s enderchest.16 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.16
execute at @s run item replace entity @s enderchest.17 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.17

item modify entity @s enderchest.9 {function:set_components,components:{custom_data:{ec_graveyard_slot:9b}}}
item modify entity @s enderchest.10 {function:set_components,components:{custom_data:{ec_graveyard_slot:10b}}}
item modify entity @s enderchest.11 {function:set_components,components:{custom_data:{ec_graveyard_slot:11b}}}
item modify entity @s enderchest.12 {function:set_components,components:{custom_data:{ec_graveyard_slot:12b}}}
item modify entity @s enderchest.13 {function:set_components,components:{custom_data:{ec_graveyard_slot:13b}}}
item modify entity @s enderchest.14 {function:set_components,components:{custom_data:{ec_graveyard_slot:14b}}}
item modify entity @s enderchest.15 {function:set_components,components:{custom_data:{ec_graveyard_slot:15b}}}
item modify entity @s enderchest.16 {function:set_components,components:{custom_data:{ec_graveyard_slot:16b}}}
item modify entity @s enderchest.17 {function:set_components,components:{custom_data:{ec_graveyard_slot:17b}}}

execute at @s run item replace entity @s enderchest.22 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.22
execute at @s run item replace entity @s enderchest.1 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.1
execute at @s run item replace entity @s enderchest.3 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.3
execute at @s run item replace entity @s enderchest.5 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.5
execute at @s run item replace entity @s enderchest.7 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.7

item modify entity @s enderchest.22 {function:set_components,components:{custom_data:{ec_graveyard_slot:22b}}}
item modify entity @s enderchest.1 {function:set_components,components:{custom_data:{ec_graveyard_slot:1b}}}
item modify entity @s enderchest.3 {function:set_components,components:{custom_data:{ec_graveyard_slot:3b}}}
item modify entity @s enderchest.5 {function:set_components,components:{custom_data:{ec_graveyard_slot:5b}}}
item modify entity @s enderchest.7 {function:set_components,components:{custom_data:{ec_graveyard_slot:7b}}}

execute at @s run item replace entity @s enderchest.18 from entity @n[type=chest_minecart,tag=graveyard_hotbar] container.18
item modify entity @s enderchest.18 {function:set_components,components:{custom_data:{ec_graveyard_slot:18b}}}

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:0b}].id set from storage graveyard player.$(current_player).hotbar[{Slot:9b}].id
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:0b}].count set from storage graveyard player.$(current_player).hotbar[{Slot:9b}].count
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:0b}].components set from storage graveyard player.$(current_player).hotbar[{Slot:9b}].components

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:1b}].id set from storage graveyard player.$(current_player).head.id
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:1b}].count set from storage graveyard player.$(current_player).head.count
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:1b}].components set from storage graveyard player.$(current_player).head.components

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:2b}].id set from storage graveyard player.$(current_player).chest.id
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:2b}].count set from storage graveyard player.$(current_player).chest.count
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:2b}].components set from storage graveyard player.$(current_player).chest.components

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:3b}].id set from storage graveyard player.$(current_player).legs.id
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:3b}].count set from storage graveyard player.$(current_player).legs.count
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:3b}].components set from storage graveyard player.$(current_player).legs.components

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:4b}].id set from storage graveyard player.$(current_player).feet.id
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:4b}].count set from storage graveyard player.$(current_player).feet.count
# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items[{Slot:4b}].components set from storage graveyard player.$(current_player).feet.components

# $data modify entity @n[type=chest_minecart,tag=graveyard_hotbar] Items set from storage graveyard player.$(current_player).hotbar




execute at @s run data merge entity @n[type=chest_minecart,tag=graveyard_hotbar] {Items:[]}

scoreboard players set graveyard_slot ec_misc 0
execute store result storage graveyard slot_import int 1 run scoreboard players get graveyard_slot ec_misc
function ec:ec_function/graveyard/inventory/get_prize with storage graveyard

execute at @s run kill @n[type=chest_minecart,tag=graveyard_hotbar]
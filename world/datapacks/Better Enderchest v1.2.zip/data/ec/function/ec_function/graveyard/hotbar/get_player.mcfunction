$data modify storage graveyard slot set value $(slot)
execute store result storage graveyard current_id int 1 run scoreboard players get @s ec_chest_id
function ec:ec_function/graveyard/hotbar/buy_slot with storage graveyard

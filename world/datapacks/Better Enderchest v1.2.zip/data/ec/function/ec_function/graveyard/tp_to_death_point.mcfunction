execute unless score @s ec_money >= tp_death ec_shop_price at @s run playsound entity.villager.no master @s ~ ~ ~
execute unless score @s ec_money >= tp_death ec_shop_price at @s run tellraw @s {text:"Not enough Money!",color:red}

clear @s ender_pearl[custom_name= {"italic":false,"text":"Teleport to Death Point"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:ender_pearl",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Teleport to Death Point"} }}}]

data modify storage graveyard tp.dimension set from entity @s LastDeathLocation.dimension
data modify storage graveyard tp.x set from entity @s LastDeathLocation.pos[0]
data modify storage graveyard tp.y set from entity @s LastDeathLocation.pos[1]
data modify storage graveyard tp.z set from entity @s LastDeathLocation.pos[2]

execute if score @s ec_money >= tp_death ec_shop_price at @s run function ec:ec_function/graveyard/real_tp with storage graveyard tp


function ec:ec_menus/graveyard/graveyard_page
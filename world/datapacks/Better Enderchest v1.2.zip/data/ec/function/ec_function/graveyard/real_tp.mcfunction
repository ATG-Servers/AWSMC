execute at @s run playsound entity.enderman.teleport master @s ~ ~ ~
scoreboard players operation @s ec_money -= tp_death ec_shop_price

$execute in $(dimension) run tp @s $(x) $(y) $(z)
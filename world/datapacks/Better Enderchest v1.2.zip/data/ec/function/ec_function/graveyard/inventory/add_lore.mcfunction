$item modify entity @s enderchest.$(slot_import) {function:set_lore,mode:"replace_all",entity:this,lore:[[{text:"$(prize)€",color:gold,italic:false}]]}

execute unless score graveyard_slot ec_misc matches 26.. run scoreboard players add graveyard_slot ec_misc 1
execute unless score graveyard_slot ec_misc matches 26.. store result storage graveyard slot_import int 1 run scoreboard players get graveyard_slot ec_misc
execute unless score graveyard_slot ec_misc matches 26.. run function ec:ec_function/graveyard/inventory/get_prize with storage graveyard
scoreboard players set @s ec_menu 57
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s skeleton_skull[custom_name= {"italic":false,"text":"Graveyard"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:skeleton_skull",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Graveyard"} }}}]

function ec:ec_menus/graveyard/graveyard_page
scoreboard players set @s ec_menu 58
execute at @s run playsound ui.button.click master @s ~ ~ ~

clear @s chest[custom_name= {"italic":false,"text":"Inventory"} ] 1
kill @e[type=item,nbt={Item:{id:"minecraft:chest",count:1,components:{"minecraft:custom_name": {"italic":false,"text":"Inventory"} }}}]

function ec:ec_menus/graveyard/inventory_page
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/1 run scoreboard players set graveyard_lore_prize ec_misc 1
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/2 run scoreboard players set graveyard_lore_prize ec_misc 2
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/3 run scoreboard players set graveyard_lore_prize ec_misc 3
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/4 run scoreboard players set graveyard_lore_prize ec_misc 4
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/5 run scoreboard players set graveyard_lore_prize ec_misc 5
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/6 run scoreboard players set graveyard_lore_prize ec_misc 6
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/7 run scoreboard players set graveyard_lore_prize ec_misc 7
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/8 run scoreboard players set graveyard_lore_prize ec_misc 8
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/9 run scoreboard players set graveyard_lore_prize ec_misc 9
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/10 run scoreboard players set graveyard_lore_prize ec_misc 10
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/12 run scoreboard players set graveyard_lore_prize ec_misc 12
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/14 run scoreboard players set graveyard_lore_prize ec_misc 14
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/16 run scoreboard players set graveyard_lore_prize ec_misc 16
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/18 run scoreboard players set graveyard_lore_prize ec_misc 18
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/20 run scoreboard players set graveyard_lore_prize ec_misc 20
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/22 run scoreboard players set graveyard_lore_prize ec_misc 22
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/25 run scoreboard players set graveyard_lore_prize ec_misc 25
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/28 run scoreboard players set graveyard_lore_prize ec_misc 28
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/30 run scoreboard players set graveyard_lore_prize ec_misc 30
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/33 run scoreboard players set graveyard_lore_prize ec_misc 33
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/37 run scoreboard players set graveyard_lore_prize ec_misc 37
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/41 run scoreboard players set graveyard_lore_prize ec_misc 41
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/47 run scoreboard players set graveyard_lore_prize ec_misc 47
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/51 run scoreboard players set graveyard_lore_prize ec_misc 51
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/56 run scoreboard players set graveyard_lore_prize ec_misc 56
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/60 run scoreboard players set graveyard_lore_prize ec_misc 60
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/63 run scoreboard players set graveyard_lore_prize ec_misc 63
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/68 run scoreboard players set graveyard_lore_prize ec_misc 68
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/75 run scoreboard players set graveyard_lore_prize ec_misc 75
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/80 run scoreboard players set graveyard_lore_prize ec_misc 80
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/90 run scoreboard players set graveyard_lore_prize ec_misc 90
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/95 run scoreboard players set graveyard_lore_prize ec_misc 95
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/100 run scoreboard players set graveyard_lore_prize ec_misc 100
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/111 run scoreboard players set graveyard_lore_prize ec_misc 111
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/125 run scoreboard players set graveyard_lore_prize ec_misc 125
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/140 run scoreboard players set graveyard_lore_prize ec_misc 140
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/160 run scoreboard players set graveyard_lore_prize ec_misc 160
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/180 run scoreboard players set graveyard_lore_prize ec_misc 180
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/200 run scoreboard players set graveyard_lore_prize ec_misc 200
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/215 run scoreboard players set graveyard_lore_prize ec_misc 215
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/250 run scoreboard players set graveyard_lore_prize ec_misc 250
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/290 run scoreboard players set graveyard_lore_prize ec_misc 290
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/350 run scoreboard players set graveyard_lore_prize ec_misc 350
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/450 run scoreboard players set graveyard_lore_prize ec_misc 50
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/500 run scoreboard players set graveyard_lore_prize ec_misc 500
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/850 run scoreboard players set graveyard_lore_prize ec_misc 850
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/1k run scoreboard players set graveyard_lore_prize ec_misc 1000
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/1.3k run scoreboard players set graveyard_lore_prize ec_misc 1300
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/1.8k run scoreboard players set graveyard_lore_prize ec_misc 1800
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/2.2k run scoreboard players set graveyard_lore_prize ec_misc 1800
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/2.8k run scoreboard players set graveyard_lore_prize ec_misc 2800
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/3.6k run scoreboard players set graveyard_lore_prize ec_misc 3600
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/4.4k run scoreboard players set graveyard_lore_prize ec_misc 400
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/5.5k run scoreboard players set graveyard_lore_prize ec_misc 5500
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/7k run scoreboard players set graveyard_lore_prize ec_misc 7000
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/15k run scoreboard players set graveyard_lore_prize ec_misc 15000
$execute if items entity @s enderchest.$(slot_import) #ec:prizes/40k run scoreboard players set graveyard_lore_prize ec_misc 40000

$execute store result score graveyard_lore_count ec_misc run data get entity @s EnderItems[{Slot:$(slot_import)b}].count
scoreboard players operation graveyard_lore_prize ec_misc *= graveyard_lore_count ec_misc
execute store result storage graveyard prize int 1 run scoreboard players get graveyard_lore_prize ec_misc


function ec:ec_function/graveyard/inventory/add_lore with storage graveyard
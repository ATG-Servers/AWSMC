execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:9b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:9}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:10b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:10}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:11b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:11}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:12b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:12}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:13b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:13}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:14b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:14}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:15b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:15}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:16b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:16}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:17b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:17}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:22b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:22}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:1b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:1}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:3b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:3}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:5b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:5}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:7b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:7}
execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{ec_graveyard_slot:18b}}}]} run function ec:ec_function/graveyard/hotbar/get_player {slot:18}


execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:9b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:9}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:10b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:10}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:11b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:11}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:12b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:12}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:13b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:13}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:14b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:14}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:15b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:15}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:16b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:16}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:17b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:17}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:22b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:22}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:1b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:1}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:3b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:3}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:5b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:5}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:7b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:7}
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data={ec_graveyard_slot:18b}] run function ec:ec_function/graveyard/hotbar/get_player {slot:18}

execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=57}] run function ec:ec_function/back_to_main_page
execute as @a[nbt=!{EnderItems:[{id:"minecraft:chest",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Inventory"} }}]}] if entity @s[scores={ec_menu=57}] run function ec:ec_function/graveyard/inventory/open_inventory
execute as @a[nbt=!{EnderItems:[{id:"minecraft:diamond_pickaxe",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Hotbar & Armor"} }}]}] if entity @s[scores={ec_menu=57}] run function ec:ec_function/graveyard/hotbar/open_hotbar
execute unless score tp ec_layout matches 1 as @a[nbt=!{EnderItems:[{id:"minecraft:ender_pearl",Slot:15b,components:{"minecraft:custom_name": {"italic":false,"text":"Teleport to Death Point"} }}]}] if entity @s[scores={ec_menu=57}] run function ec:ec_function/graveyard/tp_to_death_point

execute as @a if score @s ec_menu matches 58 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{}}}]} run function ec:ec_check/graveyard/check_for_slot
execute as @a if score @s ec_menu matches 58 if items entity @s player.cursor *[custom_data] run function ec:ec_check/graveyard/check_for_slot

execute as @a if score @s ec_menu matches 59 if data entity @s {Inventory:[{components:{"minecraft:custom_data":{}}}]} run function ec:ec_check/graveyard/check_for_slot_hotbar
execute as @a if score @s ec_menu matches 59 if items entity @s player.cursor *[custom_data] run function ec:ec_check/graveyard/check_for_slot_hotbar

execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=58..59}] run function ec:ec_function/graveyard/back_tp_graveyard

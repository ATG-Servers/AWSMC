execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/back_to_main_page

execute as @a[nbt=!{EnderItems:[{id:"minecraft:sunflower",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Place Bet"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/bet_money
execute as @a[nbt=!{EnderItems:[{id:"minecraft:emerald",Slot:18b,components:{"minecraft:custom_name": {"italic":false,"text":"Empty Pot"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/empty_pot
execute as @a[nbt=!{EnderItems:[{id:"minecraft:netherite_ingot",Slot:10b,components:{"minecraft:custom_name": {"italic":false,"text":"Double or Nothing"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/don
execute as @a[nbt=!{EnderItems:[{id:"minecraft:spawner",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Random Item"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/random_item
execute as @a[nbt=!{EnderItems:[{id:"minecraft:redstone",Slot:25b,components:{"minecraft:custom_name": {"italic":false,"text":"Gamble Everything"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/gamble_all
execute as @a[nbt=!{EnderItems:[{id:"minecraft:diamond",Slot:16b,components:{"minecraft:custom_name": {"italic":false,"text":"Lottery"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/lottery


execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:24b,components:{"minecraft:custom_name": {"italic":false,"text":"Add Money"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/add
execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Subtract Money"} }}]}] if entity @s[scores={ec_menu=37}] run function ec:ec_function/casino/subtract
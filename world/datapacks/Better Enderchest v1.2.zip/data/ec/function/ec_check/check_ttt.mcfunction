execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/back_from_ttt
execute as @a[nbt=!{EnderItems:[{id:"minecraft:red_stained_glass_pane",Slot:8b,components:{"minecraft:item_name": "Player 1" }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/player
execute as @a[nbt=!{EnderItems:[{id:"minecraft:blue_stained_glass_pane",Slot:17b,components:{"minecraft:item_name": "Player 2" }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/player
execute as @a[nbt=!{EnderItems:[{Slot:10b,components:{"minecraft:item_name": "player" }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/player

execute as @a[nbt=!{EnderItems:[{Slot:3b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_1
execute as @a[nbt=!{EnderItems:[{Slot:4b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_2
execute as @a[nbt=!{EnderItems:[{Slot:5b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_3
execute as @a[nbt=!{EnderItems:[{Slot:12b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_4
execute as @a[nbt=!{EnderItems:[{Slot:13b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_5
execute as @a[nbt=!{EnderItems:[{Slot:14b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_6
execute as @a[nbt=!{EnderItems:[{Slot:21b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_7
execute as @a[nbt=!{EnderItems:[{Slot:22b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_8
execute as @a[nbt=!{EnderItems:[{Slot:23b,components:{"minecraft:item_name": " " }}]}] if entity @s[scores={ec_menu=24}] run function ec:ec_function/ttt/tiles/tile_9
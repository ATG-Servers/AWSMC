execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/back_to_shop

execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Night Vision"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/vision
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Luck"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/luck
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Conduit"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/conduit
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"Saturation"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/saturation

execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Jump Boost"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/leaping
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Speed"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/speed
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Haste"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/haste
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"Fire Resistance"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/fire

execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Resistance"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/resistance
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:21b,components:{"minecraft:custom_name": {"italic":false,"text":"Strength"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/strength
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Health Boost"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/health
execute as @a[nbt=!{EnderItems:[{id:"minecraft:potion",Slot:23b,components:{"minecraft:custom_name": {"italic":false,"text":"Regeneration"} }}]}] if entity @s[scores={ec_menu=47}] run function ec:ec_function/shop/effects/regeneration

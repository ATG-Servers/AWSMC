execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=42..43}] run function ec:ec_function/shop/back_to_shop

execute as @a[nbt=!{EnderItems:[{id:"minecraft:chicken_spawn_egg",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Chicken Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_chicken
execute as @a[nbt=!{EnderItems:[{id:"minecraft:cow_spawn_egg",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Cow Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_cow
execute as @a[nbt=!{EnderItems:[{id:"minecraft:pig_spawn_egg",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Pig Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_pig
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sheep_spawn_egg",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Sheep Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_sheep

execute as @a[nbt=!{EnderItems:[{id:"minecraft:creeper_spawn_egg",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Creeper Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_creeper
execute as @a[nbt=!{EnderItems:[{id:"minecraft:skeleton_spawn_egg",Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Skeleton Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_skeleton
execute as @a[nbt=!{EnderItems:[{id:"minecraft:spider_spawn_egg",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Spider Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_spider
execute as @a[nbt=!{EnderItems:[{id:"minecraft:zombie_spawn_egg",Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Zombie Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_zombie

execute as @a[nbt=!{EnderItems:[{id:"minecraft:cat_spawn_egg",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Cat Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_cat
execute as @a[nbt=!{EnderItems:[{id:"minecraft:wolf_spawn_egg",Slot:21b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Wolf Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_wolf
execute as @a[nbt=!{EnderItems:[{id:"minecraft:villager_spawn_egg",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Villager Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_villager
execute as @a[nbt=!{EnderItems:[{id:"minecraft:iron_golem_spawn_egg",Slot:23b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Iron Golem Spawn"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/buy_item/spawn/buy_golem

# spawner
execute as @a[nbt=!{EnderItems:[{id:"minecraft:spawner",Slot:16b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Spawner"} }}]}] if entity @s[scores={ec_menu=42}] run function ec:ec_function/shop/spawner/open_spawner

execute as @a[nbt=!{EnderItems:[{id:"minecraft:chicken_spawn_egg",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Chicken Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/chicken
execute as @a[nbt=!{EnderItems:[{id:"minecraft:cow_spawn_egg",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Cow Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/cow
execute as @a[nbt=!{EnderItems:[{id:"minecraft:pig_spawn_egg",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Pig Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/pig
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sheep_spawn_egg",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Sheep Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/sheep

execute as @a[nbt=!{EnderItems:[{id:"minecraft:creeper_spawn_egg",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Creeper Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/creeper
execute as @a[nbt=!{EnderItems:[{id:"minecraft:skeleton_spawn_egg",Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Skeleton Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/skeleton
execute as @a[nbt=!{EnderItems:[{id:"minecraft:spider_spawn_egg",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Spider Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/spider
execute as @a[nbt=!{EnderItems:[{id:"minecraft:zombie_spawn_egg",Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Zombie Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/zombie

execute as @a[nbt=!{EnderItems:[{id:"minecraft:cat_spawn_egg",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Cat Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/cat
execute as @a[nbt=!{EnderItems:[{id:"minecraft:wolf_spawn_egg",Slot:21b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Wolf Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/wolf
execute as @a[nbt=!{EnderItems:[{id:"minecraft:villager_spawn_egg",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Villager Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/villager
execute as @a[nbt=!{EnderItems:[{id:"minecraft:iron_golem_spawn_egg",Slot:23b,components:{"minecraft:custom_name": {"italic":false,"text":"Sacrifice Iron Golem Spawn"} }}]}] if entity @s[scores={ec_menu=43}] run function ec:ec_function/shop/spawner/golem

execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/shop/back_to_shop

execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/unbreaking
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/efficiency
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/fortune
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/sharpness

execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/looting
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/knockback
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/protection
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/feather_falling

execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/frost_walker
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:21b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/quick_charge
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/multishot
execute as @a[nbt=!{EnderItems:[{id:"minecraft:enchanted_book",Slot:23b,components:{"minecraft:custom_name": {"italic":false,"text":"Buy Book"} }}]}] if entity @s[scores={ec_menu=45}] run function ec:ec_function/buy_item/enchants/power

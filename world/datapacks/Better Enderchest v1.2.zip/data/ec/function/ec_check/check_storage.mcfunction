execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/back_to_collections

execute as @a[nbt=!{EnderItems:[{id:"minecraft:dirt",Slot:0b,components:{"minecraft:item_name": "dirt_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/dirt
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sand",Slot:1b,components:{"minecraft:item_name": "sand_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/sand
execute as @a[nbt=!{EnderItems:[{id:"minecraft:oak_log",Slot:2b,components:{"minecraft:item_name": "wood_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/wood
execute as @a[nbt=!{EnderItems:[{id:"minecraft:stone",Slot:3b,components:{"minecraft:item_name": "stone_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/stone
execute as @a[nbt=!{EnderItems:[{id:"minecraft:deepslate",Slot:4b,components:{"minecraft:item_name": "deepslate_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/deepslate
execute as @a[nbt=!{EnderItems:[{id:"minecraft:netherrack",Slot:5b,components:{"minecraft:item_name": "netherrack_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/netherrack
execute as @a[nbt=!{EnderItems:[{id:"minecraft:end_stone",Slot:6b,components:{"minecraft:item_name": "endstone_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/endstone
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sugar_cane",Slot:7b,components:{"minecraft:item_name": "cane_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/cane
execute as @a[nbt=!{EnderItems:[{id:"minecraft:bamboo",Slot:8b,components:{"minecraft:item_name": "bamboo_storage" }}]}] if entity @s[scores={ec_menu=34}] run function ec:ec_function/collections/storage/bamboo

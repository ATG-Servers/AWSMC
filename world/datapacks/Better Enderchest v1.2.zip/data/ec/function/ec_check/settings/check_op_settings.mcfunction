execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=31}] run function ec:ec_function/back_to_settings
execute as @a[nbt=!{EnderItems:[{id:"minecraft:music_disc_precipice",Slot:1b,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar"} }}]}] if entity @s[scores={ec_menu=31}] run function ec:ec_function/settings/op_settings/bossbar/open_bossbar
execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_eye",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"TP Points"} }}]}] if entity @s[scores={ec_menu=31}] run function ec:ec_function/settings/op_settings/tpp/open_tpp
execute as @a[nbt=!{EnderItems:[{id:"minecraft:name_tag",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Teams"} }}]}] if entity @s[scores={ec_menu=31}] run function ec:ec_function/settings/op_settings/teams/open_teams
execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_chest",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Customize Layout"} }}]}] if entity @s[scores={ec_menu=31}] run function ec:ec_function/settings/op_settings/layout/open_layout


execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=32..33}] run function ec:ec_function/settings/op_settings/back_to_op_settings

execute as @a[nbt=!{EnderItems:[{id:"minecraft:nether_star",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Create Bossbar"} }}]}] if entity @s[scores={ec_menu=32}] if score bossbar ec_bossbar matches 0 run function ec:ec_function/settings/op_settings/bossbar/create_bossbar

execute as @a[nbt=!{EnderItems:[{id:"minecraft:warped_hanging_sign",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar Value"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/value
execute as @a[nbt=!{EnderItems:[{id:"minecraft:crimson_hanging_sign",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar Max"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/max

execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:6b,components:{"minecraft:custom_name": {"italic":false,"text":"Increse Value"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/increse_value
execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Decrese Value"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/decrese_value

execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:15b,components:{"minecraft:custom_name": {"italic":false,"text":"Increse Max"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/increse_max
execute as @a[nbt=!{EnderItems:[{id:"minecraft:player_head",Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Decrese Max"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/decrese_max

execute as @a[nbt=!{EnderItems:[{id:"minecraft:name_tag",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Set Name"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/set_name
execute as @a[nbt=!{EnderItems:[{id:"minecraft:lime_dye",Slot:21b,components:{"minecraft:custom_name": {"italic":false,"text":"Change Color"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/change_color
execute as @a[nbt=!{EnderItems:[{id:"minecraft:breeze_rod",Slot:23b,components:{"minecraft:custom_name": {"italic":false,"text":"Toggle Score"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/toggle_score
execute as @a[nbt=!{EnderItems:[{id:"minecraft:music_disc_relic",Slot:18b,components:{"minecraft:custom_name": {"italic":false,"text":"Allow Bossbar Toggle"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/toggle_bossbar
execute as @a[nbt=!{EnderItems:[{id:"minecraft:barrier",Slot:0b,components:{"minecraft:custom_name": {"italic":false,"text":"Delete Bossbar"} }}]}] if entity @s[scores={ec_menu=33}] run function ec:ec_function/settings/op_settings/bossbar/delete_bossbar

execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_pearl",Slot:11b,components:{"minecraft:item_name": "tpp" }}]}] if entity @s[scores={ec_menu=36}] run function ec:ec_function/settings/op_settings/tpp/reload
execute if score tpp_1 ec_tpp matches 1 as @a[nbt=!{EnderItems:[{id:"minecraft:name_tag",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Set Name"} }}]}] if entity @s[scores={ec_menu=36}] run function ec:ec_function/settings/op_settings/tpp/set_name/tpp_1
execute if score tpp_1 ec_tpp matches 1 as @a[nbt=!{EnderItems:[{id:"minecraft:barrier",Slot:20b,components:{"minecraft:custom_name": {"italic":false,"text":"Clear Point"} }}]}] if entity @s[scores={ec_menu=36}] run function ec:ec_function/settings/op_settings/tpp/clear/tpp_1

execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/back_to_main_page
execute as @a[nbt=!{EnderItems:[{id:"minecraft:paper",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Toggle Actionbar"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_actionbar
execute as @a[nbt=!{EnderItems:[{Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Hide Actionbar"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_actionbar

execute as @a[nbt=!{EnderItems:[{id:"minecraft:nautilus_shell",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}]}] if entity @s[scores={ec_menu=30}] if entity @s[tag=no_mail_announcement] run function ec:ec_function/settings/mail_announcement_on
execute as @a[nbt=!{EnderItems:[{Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}]}] if entity @s[scores={ec_menu=30}] if entity @s[tag=no_mail_announcement] run function ec:ec_function/settings/mail_announcement_on

execute as @a[nbt=!{EnderItems:[{id:"minecraft:nautilus_shell",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}]}] if entity @s[scores={ec_menu=30}] if entity @s[tag=!no_mail_announcement] run function ec:ec_function/settings/mail_announcement_off
execute as @a[nbt=!{EnderItems:[{Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Mail Announcement"} }}]}] if entity @s[scores={ec_menu=30}] if entity @s[tag=!no_mail_announcement] run function ec:ec_function/settings/mail_announcement_off

execute as @a[nbt=!{EnderItems:[{id:"minecraft:name_tag",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"XP Announcement"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_xp_announcement
execute as @a[nbt=!{EnderItems:[{Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"XP Announcement"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_xp_announcement

execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_chest",Slot:6b,components:{"minecraft:custom_name": {"italic":false,"text":"Switch to normal Enderchest"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/enderchest
execute as @a[nbt=!{EnderItems:[{Slot:15b,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/enderchest

execute if score bossbar ec_bossbar matches 1 if score visibility ec_bossbar matches 1 as @a[nbt=!{EnderItems:[{id:"minecraft:music_disc_precipice",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Toggle Bossbar"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_bossbar
execute if score bossbar ec_bossbar matches 1 if score visibility ec_bossbar matches 1 as @a[nbt=!{EnderItems:[{Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Bossbar"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/toggle_bossbar


execute as @a[tag=ec_op,nbt=!{EnderItems:[{id:"minecraft:golden_apple",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"OP Settings"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/op_settings/open_op_settings

execute as @a[nbt=!{EnderItems:[{Slot:18b,id:"minecraft:white_stained_glass_pane",components:{"minecraft:custom_name": {"italic":false,"text":"Set Interaction Rate"} }}]}] if entity @s[scores={ec_menu=30}] run function ec:ec_function/settings/interaction_rate
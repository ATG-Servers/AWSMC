execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/back_to_main_page
execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_chest",Slot:2b,components:{"minecraft:custom_name": {"italic":false,"text":"Enderchest Opened"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{id:"minecraft:clock",Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Time Played"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{id:"minecraft:totem_of_undying",Slot:4b,components:{"minecraft:custom_name": {"italic":false,"text":"Deaths"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{id:"minecraft:diamond_sword",Slot:5b,components:{"minecraft:custom_name": {"italic":false,"text":"Kills"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{id:"minecraft:barrier",Slot:6b,components:{"minecraft:custom_name": {"italic":false,"text":"Game Left"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{id:"minecraft:diamond_boots",Slot:3b,components:{"minecraft:custom_name": {"italic":false,"text":"Distance Traveled"} }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/remove_items
execute as @a[nbt=!{EnderItems:[{Slot:22b,components:{"minecraft:item_name": "playtime" }}]}] if entity @s[scores={ec_menu=41}] run function ec:ec_function/stats/select_playtime


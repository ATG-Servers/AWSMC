execute as @a[nbt=!{EnderItems:[{id:"minecraft:hopper",Slot:26b,components:{"minecraft:custom_name": {"italic":false,"text":"Back"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/back_to_main_page
execute as @a[nbt=!{EnderItems:[{id:"minecraft:ender_eye",Slot:18b,components:{"minecraft:custom_name": {"italic":false,"text":"Refresh"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/refresh
execute as @a[nbt=!{EnderItems:[{id:"minecraft:barrel",Slot:22b,components:{"minecraft:custom_name": {"italic":false,"text":"Storage"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/storage/open_storage

execute as @a[nbt=!{EnderItems:[{id:"minecraft:dirt",Slot:0b,components:{"minecraft:item_name": "dirt_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/dirt
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sand",Slot:1b,components:{"minecraft:item_name": "sand_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/sand
execute as @a[nbt=!{EnderItems:[{id:"minecraft:oak_log",Slot:2b,components:{"minecraft:item_name": "wood_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/wood
execute as @a[nbt=!{EnderItems:[{id:"minecraft:stone",Slot:3b,components:{"minecraft:item_name": "stone_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/stone
execute as @a[nbt=!{EnderItems:[{id:"minecraft:deepslate",Slot:4b,components:{"minecraft:item_name": "deepslate_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/deepslate
execute as @a[nbt=!{EnderItems:[{id:"minecraft:netherrack",Slot:5b,components:{"minecraft:item_name": "netherrack_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/netherrack
execute as @a[nbt=!{EnderItems:[{id:"minecraft:end_stone",Slot:6b,components:{"minecraft:item_name": "end_stone_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/end_stone
execute as @a[nbt=!{EnderItems:[{id:"minecraft:sugar_cane",Slot:7b,components:{"minecraft:item_name": "cane_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/cane
execute as @a[nbt=!{EnderItems:[{id:"minecraft:bamboo",Slot:8b,components:{"minecraft:item_name": "bamboo_collection" }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/bamboo

execute as @a[nbt=!{EnderItems:[{Slot:9b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Dirt"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_dirt
execute as @a[nbt=!{EnderItems:[{Slot:10b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Sand"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_sand
execute as @a[nbt=!{EnderItems:[{Slot:11b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Oak Log"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_wood
execute as @a[nbt=!{EnderItems:[{Slot:12b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Stone"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_stone
execute as @a[nbt=!{EnderItems:[{Slot:13b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Deepslate"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_deepslate
execute as @a[nbt=!{EnderItems:[{Slot:14b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Netherrack"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_netherrack
execute as @a[nbt=!{EnderItems:[{Slot:15b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: End Stone"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_end_stone
execute as @a[nbt=!{EnderItems:[{Slot:16b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Sugar Cane"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_cane
execute as @a[nbt=!{EnderItems:[{Slot:17b,components:{"minecraft:custom_name": {"italic":false,"text":"Actionbar: Bamboo"} }}]}] if entity @s[scores={ec_menu=23}] run function ec:ec_function/collections/select_bamboo

tellraw @a {"text": "Enderchest successfully installed!","color": "dark_purple"}
tellraw @a[tag=!ec_op] {"text": "Type /tag @s add ec_op to gain operator rights!","color": "red"}

gamerule immediate_respawn true
gamerule show_death_messages false
gamerule keep_inventory true

forceload add 0 0 0 0 
bossbar add minecraft:enderchest {"text": "Better Enderchest"}
scoreboard players set installed ec_menu 1

scoreboard objectives add ec_menu dummy
scoreboard objectives add ec_money dummy
scoreboard objectives add ec_actionbar dummy
scoreboard objectives add ec_sell dummy
scoreboard objectives add ec_sell_values dummy
scoreboard objectives add ec_bank dummy
scoreboard objectives add ec_bank_interaction dummy
scoreboard objectives add ec_death deathCount
scoreboard objectives add ec_mailbox dummy
scoreboard objectives add ec_send_mail dummy
scoreboard objectives add ec_send_money dummy
scoreboard objectives add ec_mail_money dummy
scoreboard objectives add ec_tic_tac_toe dummy
scoreboard objectives add ec_smelt dummy
scoreboard objectives add ec_level_store dummy
scoreboard objectives add ec_level level
scoreboard objectives add enderchest trigger
scoreboard objectives add ec_check_enderchest custom:open_enderchest
scoreboard objectives add ec_bossbar dummy
scoreboard objectives add ec_interaction dummy
scoreboard objectives add ec_storage dummy
scoreboard objectives add ec_x_home dummy
scoreboard objectives add ec_y_home dummy
scoreboard objectives add ec_z_home dummy
scoreboard objectives add set_home trigger
scoreboard objectives add ec_tpp dummy
scoreboard objectives add ec_x dummy
scoreboard objectives add ec_y dummy
scoreboard objectives add ec_z dummy
scoreboard objectives add tpp trigger
scoreboard objectives add ec_chest_id dummy
scoreboard objectives add ec_bet dummy
scoreboard objectives add ec_spawner_place minecraft.used:spawner
scoreboard objectives add ec_spawner_mined mined:spawner
scoreboard objectives add ec_gametime dummy
scoreboard objectives add ec_rot_pitch dummy
scoreboard objectives add ec_rot_yaw dummy
scoreboard objectives add time_mode trigger
scoreboard objectives add ec_saturation dummy
scoreboard objectives add ec_tpp_dimension dummy
scoreboard objectives add remove_effect trigger
scoreboard objectives add ec_team dummy
scoreboard objectives add ec_anvil_cost dummy
scoreboard objectives add ec_group_chest dummy
scoreboard objectives add ec_layout dummy
scoreboard objectives add ec_no_enderchest_announcement dummy
scoreboard objectives add ec_celebrator_cooldown dummy
scoreboard objectives add ec_tp_cooldown dummy

scoreboard objectives add ec_mining_level dummy
scoreboard objectives add ec_mining_needed dummy
scoreboard objectives add ec_mining_xp dummy
scoreboard objectives add ec_check_diamond_pic minecraft.used:diamond_pickaxe
scoreboard objectives add ec_check_iron_pic minecraft.used:iron_pickaxe
scoreboard objectives add ec_check_netherite_pic minecraft.used:netherite_pickaxe
scoreboard objectives add ec_check_gold_pic minecraft.used:golden_pickaxe
scoreboard objectives add ec_check_stone_pic minecraft.used:stone_pickaxe
scoreboard objectives add ec_check_wood_pic minecraft.used:wooden_pickaxe
scoreboard objectives add ec_check_copper_pic minecraft.used:copper_pickaxe
scoreboard objectives add ec_mining_speed dummy
scoreboard objectives add ec_mining_needed_change dummy

scoreboard objectives add ec_acrobatics_level dummy
scoreboard objectives add ec_acrobatics_needed dummy
scoreboard objectives add ec_acrobatics_xp dummy
scoreboard objectives add ec_acrobatics_needed_change dummy
scoreboard objectives add ec_check_fall custom:fall_one_cm
scoreboard objectives add ec_max_fallen_blocks dummy

scoreboard objectives add ec_combat_level dummy
scoreboard objectives add ec_combat_needed dummy
scoreboard objectives add ec_combat_xp dummy
scoreboard objectives add ec_combat_needed_change dummy
scoreboard objectives add ec_check_damage custom:damage_dealt
scoreboard objectives add ec_attack_speed dummy

scoreboard objectives add ec_fishing_level dummy
scoreboard objectives add ec_fishing_needed dummy
scoreboard objectives add ec_fishing_xp dummy
scoreboard objectives add ec_fishing_needed_change dummy
scoreboard objectives add ec_check_fishing custom:fish_caught
scoreboard objectives add ec_fishing_bonus dummy

scoreboard objectives add ec_mortal_level dummy
scoreboard objectives add ec_mortal_needed dummy
scoreboard objectives add ec_mortal_xp dummy
scoreboard objectives add ec_mortal_needed_change dummy
scoreboard objectives add ec_mortal_bonus dummy


scoreboard objectives add ec_collections_dirt mined:dirt
scoreboard objectives add ec_collections_dirt_stage dummy
scoreboard objectives add ec_collections_next_goal_dirt dummy

scoreboard objectives add ec_collections_sand mined:sand
scoreboard objectives add ec_collections_sand_stage dummy
scoreboard objectives add ec_collections_next_goal_sand dummy

scoreboard objectives add ec_collections_wood mined:oak_log
scoreboard objectives add ec_collections_wood_stage dummy
scoreboard objectives add ec_collections_next_goal_wood dummy

scoreboard objectives add ec_collections_stone mined:stone
scoreboard objectives add ec_collections_cobblestone mined:cobblestone
scoreboard objectives add ec_collections_stone_stage dummy
scoreboard objectives add ec_collections_next_goal_stone dummy

scoreboard objectives add ec_collections_deepslate mined:deepslate
scoreboard objectives add ec_collections_cobbled_deepslate mined:cobbled_deepslate
scoreboard objectives add ec_collections_deepslate_stage dummy
scoreboard objectives add ec_collections_next_goal_deepslate dummy

scoreboard objectives add ec_collections_netherrack mined:netherrack
scoreboard objectives add ec_collections_netherrack_stage dummy
scoreboard objectives add ec_collections_next_goal_netherrack dummy

scoreboard objectives add ec_collections_end_stone mined:end_stone
scoreboard objectives add ec_collections_end_stone_stage dummy
scoreboard objectives add ec_collections_next_goal_end_stone dummy

scoreboard objectives add ec_collections_cane mined:sugar_cane
scoreboard objectives add ec_collections_cane_stage dummy
scoreboard objectives add ec_collections_next_goal_cane dummy
scoreboard objectives add ec_collections_cane_place minecraft.used:sugar_cane

scoreboard objectives add ec_collections_bamboo mined:bamboo
scoreboard objectives add ec_collections_bamboo_stage dummy
scoreboard objectives add ec_collections_next_goal_bamboo dummy

scoreboard objectives add ec_dirt_storage dummy
scoreboard objectives add ec_sand_storage dummy
scoreboard objectives add ec_wood_storage dummy
scoreboard objectives add ec_stone_storage dummy
scoreboard objectives add ec_cobble_stone_storage dummy
scoreboard objectives add ec_deepslate_storage dummy
scoreboard objectives add ec_cobble_deepslate_storage dummy
scoreboard objectives add ec_netherrack_storage dummy
scoreboard objectives add ec_endstone_storage dummy
scoreboard objectives add ec_cane_storage dummy
scoreboard objectives add ec_bamboo_storage dummy

scoreboard objectives add ec_inshop dummy

# stats
scoreboard objectives add ec_stats_death deathCount

scoreboard objectives add ec_stats_distance dummy
scoreboard objectives add ec_stats_distance_walk custom:walk_one_cm
scoreboard objectives add ec_stats_distance_sprint custom:sprint_one_cm
scoreboard objectives add ec_stats_distance_swim custom:swim_one_cm
scoreboard objectives add ec_stats_distance_fly custom:fly_one_cm
scoreboard objectives add ec_stats_distance_boat custom:boat_one_cm
scoreboard objectives add ec_stats_distance_crouch custom:crouch_one_cm
scoreboard objectives add ec_stats_distance_walk_water custom:walk_on_water_one_cm
scoreboard objectives add ec_stats_distance_walk_under_water custom:walk_under_water_one_cm

scoreboard objectives add ec_stats_player_kills custom:player_kills
scoreboard objectives add ec_stats_mob_kills custom:mob_kills
scoreboard objectives add ec_stats_kills dummy

scoreboard objectives add ec_stats_game_left custom:leave_game

scoreboard objectives add ec_stats_play_time custom:play_time
scoreboard objectives add ec_stats_play_time_sec dummy
scoreboard objectives add ec_stats_play_time_min dummy
scoreboard objectives add ec_stats_play_time_h dummy
scoreboard objectives add ec_stats_play_time_day dummy

scoreboard objectives add ec_stats_open_enderchest custom:open_enderchest

# # # # #
execute as @a unless score prize ec_smelt matches 1.. run scoreboard players set prize ec_smelt 2

scoreboard players set Iron ec_sell_values 10
scoreboard players set Copper ec_sell_values 5
scoreboard players set Coal ec_sell_values 1
scoreboard players set Gold ec_sell_values 20
scoreboard players set Emerald ec_sell_values 50
scoreboard players set Diamond ec_sell_values 100
scoreboard players set Netherite ec_sell_values 200
scoreboard players set NetherStar ec_sell_values 500

execute as @a unless score @s ec_menu matches 1.. unless entity @s[tag=no_enderchest] run scoreboard players set @a ec_menu 1
execute as @a unless score @s ec_actionbar matches 1.. run scoreboard players set @a ec_actionbar 1
execute as @a unless score @s ec_stats_death matches 1.. run scoreboard players set @a ec_stats_death 0
execute as @a unless score @s ec_stats_game_left matches 1.. run scoreboard players set @a ec_stats_game_left 0
execute as @a unless score @s ec_stats_mob_kills matches 1.. run scoreboard players set @a ec_stats_mob_kills 0
execute as @a unless score @s ec_stats_player_kills matches 1.. run scoreboard players set @a ec_stats_player_kills 0
execute as @a unless score @s ec_interaction matches 1.. run scoreboard players set @a ec_interaction 1
scoreboard players set @a ec_bank_interaction 1
scoreboard players reset @a ec_tic_tac_toe 
execute as @a unless score @s ec_money matches 1.. run scoreboard players set @s ec_money 0
execute as @a unless score @s ec_level_store matches 1.. run scoreboard players set @s ec_level_store 0
execute as @a unless score @s ec_bank matches 1.. run scoreboard players set @s ec_bank 0
execute as @a unless score @s ec_send_money matches 1.. run scoreboard players set @s ec_send_money 0
execute as @a unless score @s ec_mailbox matches 1.. run scoreboard players set @s ec_mailbox 0
execute as @a unless score @s ec_bet matches 1.. run scoreboard players set @s ec_bet 0
execute unless score current ec_team matches 1.. run scoreboard players set current ec_team 1


execute as @a unless score @s ec_mining_needed matches 1.. run scoreboard players set @s ec_mining_needed 100
execute as @a unless score @s ec_mining_needed matches 1.. run scoreboard players set @s ec_mining_needed_change 0

execute as @a unless score @s ec_acrobatics_needed matches 1.. run scoreboard players set @s ec_acrobatics_needed 50
execute as @a unless score @s ec_acrobatics_needed_change matches 1.. run scoreboard players set @s ec_acrobatics_needed_change 0

execute as @a unless score @s ec_combat_needed matches 1.. run scoreboard players set @s ec_combat_needed 1000
execute as @a unless score @s ec_combat_needed_change matches 1.. run scoreboard players set @s ec_combat_needed_change 0

execute as @a unless score @s ec_fishing_needed matches 1.. run scoreboard players set @s ec_fishing_needed 10
execute as @a unless score @s ec_fishing_needed_change matches 1.. run scoreboard players set @s ec_fishing_needed_change 0

execute as @a unless score @s ec_mortal_needed matches 1.. run scoreboard players set @s ec_mortal_needed 50
execute as @a unless score @s ec_mortal_needed_change matches 1.. run scoreboard players set @s ec_mortal_needed_change 0

execute as @a unless score @s ec_collections_dirt matches 1.. run scoreboard players set @s ec_collections_dirt 0
execute as @a unless score @s ec_collections_dirt_stage matches 1.. run scoreboard players set @s ec_collections_dirt_stage 0
execute as @a unless score @s ec_collections_next_goal_dirt matches 1.. run scoreboard players set @s ec_collections_next_goal_dirt 100

execute as @a unless score @s ec_collections_sand matches 1.. run scoreboard players set @s ec_collections_sand 0
execute as @a unless score @s ec_collections_sand_stage matches 1.. run scoreboard players set @s ec_collections_sand_stage 0
execute as @a unless score @s ec_collections_next_goal_sand matches 1.. run scoreboard players set @s ec_collections_next_goal_sand 100

execute as @a unless score @s ec_collections_wood matches 1.. run scoreboard players set @s ec_collections_wood 0
execute as @a unless score @s ec_collections_wood_stage matches 1.. run scoreboard players set @s ec_collections_wood_stage 0
execute as @a unless score @s ec_collections_next_goal_wood matches 1.. run scoreboard players set @s ec_collections_next_goal_wood 100

execute as @a unless score @s ec_collections_stone matches 1.. run scoreboard players set @s ec_collections_stone 0
execute as @a unless score @s ec_collections_stone_stage matches 1.. run scoreboard players set @s ec_collections_stone_stage 0
execute as @a unless score @s ec_collections_next_goal_stone matches 1.. run scoreboard players set @s ec_collections_next_goal_stone 100

execute as @a unless score @s ec_collections_deepslate matches 1.. run scoreboard players set @s ec_collections_deepslate 0
execute as @a unless score @s ec_collections_deepslate_stage matches 1.. run scoreboard players set @s ec_collections_deepslate_stage 0
execute as @a unless score @s ec_collections_next_goal_deepslate matches 1.. run scoreboard players set @s ec_collections_next_goal_deepslate 100

execute as @a unless score @s ec_collections_netherrack matches 1.. run scoreboard players set @s ec_collections_netherrack 0
execute as @a unless score @s ec_collections_netherrack_stage matches 1.. run scoreboard players set @s ec_collections_netherrack_stage 0
execute as @a unless score @s ec_collections_next_goal_netherrack matches 1.. run scoreboard players set @s ec_collections_next_goal_netherrack 100

execute as @a unless score @s ec_collections_end_stone matches 1.. run scoreboard players set @s ec_collections_end_stone 0
execute as @a unless score @s ec_collections_end_stone_stage matches 1.. run scoreboard players set @s ec_collections_end_stone_stage 0
execute as @a unless score @s ec_collections_next_goal_end_stone matches 1.. run scoreboard players set @s ec_collections_next_goal_end_stone 100

execute as @a unless score @s ec_collections_cane matches 1.. run scoreboard players set @s ec_collections_cane 0
execute as @a unless score @s ec_collections_cane_stage matches 1.. run scoreboard players set @s ec_collections_cane_stage 0
execute as @a unless score @s ec_collections_next_goal_cane matches 1.. run scoreboard players set @s ec_collections_next_goal_cane 100

execute as @a unless score @s ec_collections_bamboo matches 1.. run scoreboard players set @s ec_collections_bamboo 0
execute as @a unless score @s ec_collections_bamboo_stage matches 1.. run scoreboard players set @s ec_collections_bamboo_stage 0
execute as @a unless score @s ec_collections_next_goal_bamboo matches 1.. run scoreboard players set @s ec_collections_next_goal_bamboo 100

execute as @a unless score @s ec_dirt_storage matches 1.. run scoreboard players set @s ec_dirt_storage 0
execute as @a unless score @s ec_sand_storage matches 1.. run scoreboard players set @s ec_sand_storage 0
execute as @a unless score @s ec_wood_storage matches 1.. run scoreboard players set @s ec_wood_storage 0
execute as @a unless score @s ec_stone_storage matches 1.. run scoreboard players set @s ec_stone_storage 0
execute as @a unless score @s ec_cobble_stone_storage matches 1.. run scoreboard players set @s ec_cobble_stone_storage 0
execute as @a unless score @s ec_deepslate_storage matches 1.. run scoreboard players set @s ec_deepslate_storage 0
execute as @a unless score @s ec_cobble_deepslate_storage matches 1.. run scoreboard players set @s ec_cobble_deepslate_storage 0
execute as @a unless score @s ec_netherrack_storage matches 1.. run scoreboard players set @s ec_netherrack_storage 0
execute as @a unless score @s ec_endstone_storage matches 1.. run scoreboard players set @s ec_endstone_storage 0
execute as @a unless score @s ec_cane_storage matches 1.. run scoreboard players set @s ec_cane_storage 0
execute as @a unless score @s ec_bamboo_storage matches 1.. run scoreboard players set @s ec_bamboo_storage 0

execute as @a unless score @s ec_combat_xp matches 1.. run scoreboard players set @s ec_combat_xp 0
execute as @a unless score @s ec_mining_xp matches 1.. run scoreboard players set @s ec_mining_xp 0
execute as @a unless score @s ec_fishing_xp matches 1.. run scoreboard players set @s ec_fishing_xp 0
execute as @a unless score @s ec_mortal_xp matches 1.. run scoreboard players set @s ec_mortal_xp 0
execute as @a unless score @s ec_acrobatics_xp matches 1.. run scoreboard players set @s ec_acrobatics_xp 0

execute as @a unless score @s ec_combat_level matches 1.. run scoreboard players set @s ec_combat_level 0
execute as @a unless score @s ec_mining_level matches 1.. run scoreboard players set @s ec_mining_level 0
execute as @a unless score @s ec_acrobatics_level matches 1.. run scoreboard players set @s ec_acrobatics_level 0
execute as @a unless score @s ec_fishing_level matches 1.. run scoreboard players set @s ec_fishing_level 0
execute as @a unless score @s ec_mortal_level matches 1.. run scoreboard players set @s ec_mortal_level 0

execute as @a unless score @s ec_stats_play_time_day matches 1.. run scoreboard players set @s ec_stats_play_time_day 0
execute as @a unless score @s ec_stats_play_time_h matches 1.. run scoreboard players set @s ec_stats_play_time_h 0
execute as @a unless score @s ec_stats_play_time_min matches 1.. run scoreboard players set @s ec_stats_play_time_min 0
execute as @a unless score @s ec_stats_play_time_sec matches 1.. run scoreboard players set @s ec_stats_play_time_sec 0

scoreboard players set correct_time ec_gametime 1000
execute as @a unless score @s time_mode matches 0.. run scoreboard players set @s time_mode 0

execute unless score max ec_bossbar matches 1.. run scoreboard players set max ec_bossbar 100
execute unless score value ec_bossbar matches 1.. run scoreboard players set value ec_bossbar 0
execute unless score bossbar ec_bossbar matches 1.. run scoreboard players set bossbar ec_bossbar 0
execute unless score visibility ec_bossbar matches 0.. run scoreboard players set visibility ec_bossbar 1
execute unless score score ec_bossbar matches 1.. run scoreboard players set score ec_bossbar 0

execute unless score cooldown ec_tp_cooldown matches 1.. run scoreboard players set cooldown ec_tp_cooldown 40

execute unless score current ec_chest_id matches 0.. run scoreboard players set current ec_chest_id 0
scoreboard players set 9 ec_money 9
scoreboard players set open ec_group_chest 0
execute as @a run tag @s add no_xp_announcement
# layout
execute unless score shulker ec_layout matches 0 run scoreboard players set shulker ec_layout 1
execute unless score chest ec_layout matches 0.. run scoreboard players set chest ec_layout 0
execute unless score post ec_layout matches 0.. run scoreboard players set post ec_layout 0
execute unless score gc ec_layout matches 0.. run scoreboard players set gc ec_layout 0
execute unless score casino ec_layout matches 0.. run scoreboard players set casino ec_layout 0
execute unless score anvil ec_layout matches 0.. run scoreboard players set anvil ec_layout 1
execute unless score furnace ec_layout matches 0.. run scoreboard players set furnace ec_layout 0
execute unless score shop ec_layout matches 0.. run scoreboard players set shop ec_layout 0
execute unless score coll ec_layout matches 0.. run scoreboard players set coll ec_layout 0
execute unless score bank ec_layout matches 0.. run scoreboard players set bank ec_layout 0
execute unless score smith ec_layout matches 0.. run scoreboard players set smith ec_layout 0
execute unless score tp ec_layout matches 0.. run scoreboard players set tp ec_layout 0
execute unless score trash ec_layout matches 0.. run scoreboard players set trash ec_layout 0
execute unless score level ec_layout matches 0.. run scoreboard players set level ec_layout 0
execute unless score ttt ec_layout matches 0.. run scoreboard players set ttt ec_layout 0
execute unless score settings ec_layout matches 0.. run scoreboard players set settings ec_layout 0
execute unless score stats ec_layout matches 0.. run scoreboard players set stats ec_layout 0
execute unless score credits ec_layout matches 0.. run scoreboard players set credits ec_layout 0


# # # # # v1.1
scoreboard objectives add ec_auction_prize dummy
scoreboard objectives add ec_auction_count dummy
scoreboard objectives add ec_misc dummy
scoreboard objectives add ec_auction_get_item dummy
scoreboard objectives add ec_auction_page dummy
scoreboard objectives add ec_auction_buy_rate dummy
scoreboard objectives add ec_auction_player dummy
scoreboard objectives add ec_auction_stored_money dummy
scoreboard objectives add ec_check_quit custom:leave_game
scoreboard objectives add ec_shop_price dummy
scoreboard objectives add ec_open dummy
scoreboard objectives add kr_ec_cross dummy


scoreboard players set ec kr_ec_cross 1
execute unless score current ec_misc matches 1.. run scoreboard players set current ec_misc 0
execute unless score current ec_auction_prize matches 1.. run scoreboard players set current ec_auction_prize 0

# # # # # v1.2
scoreboard objectives add ec_chest_page dummy
scoreboard objectives add ec_chest_page_max dummy
scoreboard objectives add ec_chest_next_page_prize dummy
scoreboard objectives add ec_shulker_load_page dummy
scoreboard objectives add ec_has_died deathCount

execute unless score @s ec_chest_next_page_prize matches 1.. run scoreboard players operation @s ec_chest_next_page_prize += start_price_chest ec_shop_price

execute as @a[tag=!no_enderchest] if score @s ec_menu matches 1 run execute as @a run function ec:ec_menus/main_page_1
function ec:ec_function/group_chest/check_force_leave
schedule function ec:reset/debug_page 1s replace


tellraw @a {"text": "Thank You for using Better Enderchests!","color": "gold"}
function ec:reset/clear_data_deinstall
datapack disable "file/Enderchest"

scoreboard objectives remove ec_menu
scoreboard objectives remove ec_money
scoreboard objectives remove ec_actionbar
scoreboard objectives remove ec_sell
scoreboard objectives remove ec_sell_values
scoreboard objectives remove ec_bank
scoreboard objectives remove ec_bank_interaction
scoreboard objectives remove ec_death 
scoreboard objectives remove ec_mailbox
scoreboard objectives remove ec_send_mail
scoreboard objectives remove ec_send_money
scoreboard objectives remove ec_mail_money
scoreboard objectives remove ec_tic_tac_toe
scoreboard objectives remove ec_smelt
scoreboard objectives remove ec_level_store
scoreboard objectives remove ec_level 
scoreboard objectives remove enderchest 
scoreboard objectives remove ec_check_enderchest
scoreboard objectives remove ec_bossbar
scoreboard objectives remove ec_interaction
scoreboard objectives remove ec_storage
scoreboard objectives remove ec_x_home
scoreboard objectives remove ec_y_home
scoreboard objectives remove ec_z_home
scoreboard objectives remove set_home 
scoreboard objectives remove ec_tpp
scoreboard objectives remove ec_x
scoreboard objectives remove ec_y
scoreboard objectives remove ec_z
scoreboard objectives remove tpp 
scoreboard objectives remove ec_chest_id
scoreboard objectives remove ec_bet
scoreboard objectives remove ec_spawner_place
scoreboard objectives remove ec_spawner_mined
scoreboard objectives remove ec_gametime
scoreboard objectives remove ec_rot_pitch
scoreboard objectives remove ec_rot_yaw
scoreboard objectives remove time_mode 
scoreboard objectives remove ec_saturation
scoreboard objectives remove ec_tpp_dimension
scoreboard objectives remove remove_effect 
scoreboard objectives remove ec_team
scoreboard objectives remove ec_anvil_cost
scoreboard objectives remove ec_group_chest
scoreboard objectives remove ec_layout
scoreboard objectives remove ec_no_enderchest_announcement
scoreboard objectives remove ec_celebrator_cooldown
scoreboard objectives remove ec_tp_cooldown

scoreboard objectives remove ec_mining_level
scoreboard objectives remove ec_mining_needed
scoreboard objectives remove ec_mining_xp
scoreboard objectives remove ec_check_diamond_pic
scoreboard objectives remove ec_check_iron_pic
scoreboard objectives remove ec_check_netherite_pic
scoreboard objectives remove ec_check_gold_pic
scoreboard objectives remove ec_check_stone_pic 
scoreboard objectives remove ec_check_wood_pic
scoreboard objectives remove ec_check_copper_pic
scoreboard objectives remove ec_mining_speed
scoreboard objectives remove ec_mining_needed_change

scoreboard objectives remove ec_acrobatics_level
scoreboard objectives remove ec_acrobatics_needed
scoreboard objectives remove ec_acrobatics_xp
scoreboard objectives remove ec_acrobatics_needed_change
scoreboard objectives remove ec_check_fall
scoreboard objectives remove ec_max_fallen_blocks

scoreboard objectives remove ec_combat_level
scoreboard objectives remove ec_combat_needed
scoreboard objectives remove ec_combat_xp
scoreboard objectives remove ec_combat_needed_change
scoreboard objectives remove ec_check_damage
scoreboard objectives remove ec_attack_speed

scoreboard objectives remove ec_fishing_level
scoreboard objectives remove ec_fishing_needed
scoreboard objectives remove ec_fishing_xp
scoreboard objectives remove ec_fishing_needed_change
scoreboard objectives remove ec_check_fishing 
scoreboard objectives remove ec_fishing_bonus

scoreboard objectives remove ec_mortal_level
scoreboard objectives remove ec_mortal_needed
scoreboard objectives remove ec_mortal_xp
scoreboard objectives remove ec_mortal_needed_change
scoreboard objectives remove ec_mortal_bonus


scoreboard objectives remove ec_collections_dirt 
scoreboard objectives remove ec_collections_dirt_stage
scoreboard objectives remove ec_collections_next_goal_dirt

scoreboard objectives remove ec_collections_sand 
scoreboard objectives remove ec_collections_sand_stage
scoreboard objectives remove ec_collections_next_goal_sand

scoreboard objectives remove ec_collections_wood 
scoreboard objectives remove ec_collections_wood_stage
scoreboard objectives remove ec_collections_next_goal_wood

scoreboard objectives remove ec_collections_stone 
scoreboard objectives remove ec_collections_cobblestone
scoreboard objectives remove ec_collections_stone_stage
scoreboard objectives remove ec_collections_next_goal_stone

scoreboard objectives remove ec_collections_deepslate 
scoreboard objectives remove ec_collections_cobbled_deepslate
scoreboard objectives remove ec_collections_deepslate_stage
scoreboard objectives remove ec_collections_next_goal_deepslate

scoreboard objectives remove ec_collections_netherrack
scoreboard objectives remove ec_collections_netherrack_stage
scoreboard objectives remove ec_collections_next_goal_netherrack

scoreboard objectives remove ec_collections_end_stone 
scoreboard objectives remove ec_collections_end_stone_stage
scoreboard objectives remove ec_collections_next_goal_end_stone

scoreboard objectives remove ec_collections_cane
scoreboard objectives remove ec_collections_cane_stage
scoreboard objectives remove ec_collections_next_goal_cane
scoreboard objectives remove ec_collections_cane_place 

scoreboard objectives remove ec_collections_bamboo 
scoreboard objectives remove ec_collections_bamboo_stage
scoreboard objectives remove ec_collections_next_goal_bamboo

scoreboard objectives remove ec_dirt_storage
scoreboard objectives remove ec_sand_storage
scoreboard objectives remove ec_wood_storage
scoreboard objectives remove ec_stone_storage
scoreboard objectives remove ec_cobble_stone_storage
scoreboard objectives remove ec_deepslate_storage
scoreboard objectives remove ec_cobble_deepslate_storage
scoreboard objectives remove ec_netherrack_storage
scoreboard objectives remove ec_endstone_storage
scoreboard objectives remove ec_cane_storage
scoreboard objectives remove ec_bamboo_storage

scoreboard objectives remove ec_inshop


scoreboard objectives remove ec_stats_death 

scoreboard objectives remove ec_stats_distance
scoreboard objectives remove ec_stats_distance_walk 
scoreboard objectives remove ec_stats_distance_sprint 
scoreboard objectives remove ec_stats_distance_swim 
scoreboard objectives remove ec_stats_distance_fly 
scoreboard objectives remove ec_stats_distance_boat 
scoreboard objectives remove ec_stats_distance_crouch 
scoreboard objectives remove ec_stats_distance_walk_water 
scoreboard objectives remove ec_stats_distance_walk_under_water 

scoreboard objectives remove ec_stats_player_kills 
scoreboard objectives remove ec_stats_mob_kills 
scoreboard objectives remove ec_stats_kills

scoreboard objectives remove ec_stats_game_left 

scoreboard objectives remove ec_stats_play_time 
scoreboard objectives remove ec_stats_play_time_sec
scoreboard objectives remove ec_stats_play_time_min
scoreboard objectives remove ec_stats_play_time_h
scoreboard objectives remove ec_stats_play_time_day

scoreboard objectives remove ec_stats_open_enderchest

scoreboard objectives remove ec_auction_stored_money
scoreboard objectives remove ec_auction_player
scoreboard objectives remove ec_auction_count
scoreboard objectives remove ec_auction_get_item
scoreboard objectives remove ec_check_quit
scoreboard objectives remove ec_auction_buy_rate
scoreboard objectives remove ec_misc
scoreboard objectives remove ec_auction_page
scoreboard objectives remove ec_auction_prize

scoreboard objectives remove ec_open
scoreboard objectives remove ec_shop_price
scoreboard objectives remove kr_ec_cross

scoreboard objectives remove ec_chest_next_page_prize
scoreboard objectives remove ec_chest_page
scoreboard objectives remove ec_chest_page_max
scoreboard objectives remove ec_has_died
scoreboard objectives remove ec_shulker_load_page




data remove storage enderchest enderchest
data remove storage mailboxes mailbox_1
data remove storage mailboxes mailbox_2
data remove storage mailboxes mailbox_3
data remove storage mailboxes mailbox_4
data remove storage mailboxes mailbox_5
data remove storage mailboxes mailbox_6
data remove storage mailboxes mailbox_7
data remove storage mailboxes mailbox_8
data remove storage mailboxes mailbox_9
data remove storage mailboxes mailbox_10
data remove storage mailboxes mailbox_11
data remove storage mailboxes mailbox_12
data remove storage mailboxes mailbox_13
data remove storage mailboxes mailbox_14

data remove storage add_attack_speed speed
data remove storage add_fishing_bonus speed
data remove storage add_max_fallen_speed speed
data remove storage add_mining_speed speed
data remove storage add_mortal speed

data remove storage add_level level

data remove storage bossbar name
data remove storage home x
data remove storage home y
data remove storage home z
data remove storage random slot
data remove storage enderchest current
data remove storage team current
data remove storage team color
data remove storage team prefix
data remove storage team name
data remove storage team sufix
data remove storage time de_time
data remove storage time uk_time
data remove storage tp x
data remove storage tp y
data remove storage tp z
data remove storage tp dimension

data remove storage auction buy_slot
data remove storage auction delete_id_page
data remove storage auction draw_sync
data remove storage auction max_stack_size
data remove storage auction order_slot_old
data remove storage auction order_slot_new
data remove storage auction get_item
data remove storage auction sell_temp
data remove storage auction buy_id
data remove storage auction current_id_on_page
data remove storage auction get_money
data remove storage auction draw_page
data remove storage auction buy_seller
data remove storage auction order_slot
data remove storage auction current_page
data remove storage auction player
data remove storage auction sell
data remove storage auction draw
data remove storage auction draw_id
data remove storage auction delete_id
data remove storage auction order_page_old
data remove storage auction order_page
data remove storage auction current_prize
data remove storage auction current_id
data remove storage auction order_page_new
data remove storage auction buy_page
data remove storage auction order_id

data remove storage playername current
data remove storage playername players

data remove storage graveyard player
data remove storage graveyard slot
data remove storage graveyard current_player
data remove storage graveyard tp
data remove storage graveyard slot_import
data remove storage graveyard buffer
data remove storage graveyard hotbar
data remove storage graveyard current_id
data remove storage graveyard prize

item replace entity @a enderchest.0 with air
item replace entity @a enderchest.1 with air
item replace entity @a enderchest.2 with air
item replace entity @a enderchest.3 with air
item replace entity @a enderchest.4 with air
item replace entity @a enderchest.5 with air
item replace entity @a enderchest.6 with air
item replace entity @a enderchest.7 with air
item replace entity @a enderchest.8 with air
item replace entity @a enderchest.9 with air
item replace entity @a enderchest.10 with air
item replace entity @a enderchest.11 with air
item replace entity @a enderchest.12 with air
item replace entity @a enderchest.13 with air
item replace entity @a enderchest.14 with air
item replace entity @a enderchest.15 with air
item replace entity @a enderchest.16 with air
item replace entity @a enderchest.17 with air
item replace entity @a enderchest.18 with air
item replace entity @a enderchest.19 with air
item replace entity @a enderchest.20 with air
item replace entity @a enderchest.21 with air
item replace entity @a enderchest.22 with air
item replace entity @a enderchest.23 with air
item replace entity @a enderchest.24 with air
item replace entity @a enderchest.25 with air
item replace entity @a enderchest.26 with air

title @s actionbar " "


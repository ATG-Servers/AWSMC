#mc-build WASD content
execute as @s[tag=wasd.seat,tag=!wasd.has_passenger] run function wasd.tnt:zzz/199
execute if entity @p[tag=wasd.right_click,distance=..6,tag=wasd.tnt_cannon_passenger] as @s[tag=wasd.click_detection,tag=wasd.tnt_cannon] positioned ~ ~1 ~ as @e[tag=wasd.aa_gun_gun,sort=nearest,limit=1,distance=..0.0001] at @s run function wasd.tnt:tnt_cannon/aa_cannon_fire
#mc-build WASD content
execute as @e[tag=wasd.tnt_block] at @s run function wasd.tnt:zzz/1
#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_tnt wasd_data_packs 1
scoreboard objectives add w.tnt_settings dummy
#set up default data storage
data merge storage wasd.tnt {check_if_tnt:"minecraft:tnt"}
#enable crafter
scoreboard objectives add wasd.lib_setting dummy
scoreboard players set wasd.crafter wasd.lib_setting 1
function wasd.lib:on_load/text
function wasd.tnt:config
schedule function wasd.tnt:check_installed_packs 30t replace
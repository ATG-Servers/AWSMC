#mc-build WASD content
execute as @s[tag=wasd.template_tnt] run function wasd.tnt:zzz/82
execute as @s[tag=wasd.amethyst] run function wasd.tnt:zzz/84
execute as @s[tag=wasd.arrow] run function wasd.tnt:zzz/86
execute as @s[tag=wasd.bee] run function wasd.tnt:zzz/88
execute as @s[tag=wasd.magnetic] run function wasd.tnt:zzz/90
execute as @s[tag=wasd.tntnt] run function wasd.tnt:zzz/92
execute as @s[tag=wasd.sword] run function wasd.tnt:zzz/94
execute as @s[tag=wasd.inverted] run function wasd.tnt:zzz/96
execute as @s[tag=wasd.anvil] run function wasd.tnt:zzz/98
execute as @s[tag=wasd.cactus] run function wasd.tnt:zzz/100
execute as @s[tag=wasd.directional] run function wasd.tnt:zzz/102
execute as @s[tag=wasd.dripstone] run function wasd.tnt:zzz/104
execute as @s[tag=wasd.pickaxe] run function wasd.tnt:zzz/106
execute as @s[tag=wasd.potato] run function wasd.tnt:zzz/108
execute as @s[tag=wasd.slime] run function wasd.tnt:zzz/110
execute as @s[tag=wasd.sponge] run function wasd.tnt:zzz/112
execute as @s[tag=wasd.poison] run function wasd.tnt:zzz/114
function wasd.tnt:patron/entity
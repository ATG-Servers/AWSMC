#mc-build WASD content
execute as @s[gamemode=!creative,gamemode=!spectator] run tag @s remove wasd.invalid_target
execute as @s[gamemode=creative] run tag @s add wasd.invalid_target
execute as @s[gamemode=spectator] run tag @s add wasd.invalid_target
scoreboard players reset @s[scores={wasd.tnt_frame=1..}] wasd.tnt_frame
scoreboard players reset @s[scores={wasd.tnt_frame2=1..}] wasd.tnt_frame2
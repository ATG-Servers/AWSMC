#mc-build WASD content
execute as @s[tag=wasd.aa_cannon] run function wasd.tnt:tnt_cannon/aa_cannon
#mc-build WASD content
execute as @s[tag=wasd.amethyst] run function wasd.tnt:zzz/18
execute as @s[tag=wasd.arrow] run function wasd.tnt:zzz/22
execute as @s[tag=wasd.bee] run function wasd.tnt:zzz/26
execute as @s[tag=wasd.magnetic] run function wasd.tnt:zzz/30
execute as @s[tag=wasd.tntnt] run function wasd.tnt:zzz/34
execute as @s[tag=wasd.sword] run function wasd.tnt:zzz/38
execute as @s[tag=wasd.inverted] run function wasd.tnt:zzz/42
execute as @s[tag=wasd.anvil] run function wasd.tnt:zzz/46
execute as @s[tag=wasd.cactus] run function wasd.tnt:zzz/50
execute as @s[tag=wasd.directional] run function wasd.tnt:zzz/54
execute as @s[tag=wasd.dripstone] run function wasd.tnt:zzz/58
execute as @s[tag=wasd.pickaxe] run function wasd.tnt:zzz/62
execute as @s[tag=wasd.potato] run function wasd.tnt:zzz/66
execute as @s[tag=wasd.slime] run function wasd.tnt:zzz/70
execute as @s[tag=wasd.sponge] run function wasd.tnt:zzz/74
execute as @s[tag=wasd.poison] run function wasd.tnt:zzz/78
function wasd.tnt:patron/block
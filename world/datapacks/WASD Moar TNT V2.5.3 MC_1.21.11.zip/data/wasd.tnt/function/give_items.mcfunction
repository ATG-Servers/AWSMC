#mc-build WASD content
loot give @s loot wasd.tnt:amethyst
loot give @s loot wasd.tnt:arrow
loot give @s loot wasd.tnt:bee
loot give @s loot wasd.tnt:magnetic
loot give @s loot wasd.tnt:tntnt
loot give @s loot wasd.tnt:sword
loot give @s loot wasd.tnt:inverted
loot give @s loot wasd.tnt:anvil
loot give @s loot wasd.tnt:cactus
loot give @s loot wasd.tnt:directional
loot give @s loot wasd.tnt:dripstone
loot give @s loot wasd.tnt:pickaxe
loot give @s loot wasd.tnt:potato
loot give @s loot wasd.tnt:slime
loot give @s loot wasd.tnt:sponge
loot give @s loot wasd.tnt:poison
#mc-build WASD content
execute as @s[tag=wasd.amethyst] run function wasd.tnt:zzz/2
execute as @s[tag=wasd.arrow] run function wasd.tnt:zzz/3
execute as @s[tag=wasd.bee] run function wasd.tnt:zzz/4
execute as @s[tag=wasd.magnetic] run function wasd.tnt:zzz/5
execute as @s[tag=wasd.tntnt] run function wasd.tnt:zzz/6
execute as @s[tag=wasd.sword] run function wasd.tnt:zzz/7
execute as @s[tag=wasd.inverted] run function wasd.tnt:zzz/8
execute as @s[tag=wasd.anvil] run function wasd.tnt:zzz/9
execute as @s[tag=wasd.cactus] run function wasd.tnt:zzz/10
execute as @s[tag=wasd.directional] run function wasd.tnt:zzz/11
execute as @s[tag=wasd.dripstone] run function wasd.tnt:zzz/12
execute as @s[tag=wasd.pickaxe] run function wasd.tnt:zzz/13
execute as @s[tag=wasd.potato] run function wasd.tnt:zzz/14
execute as @s[tag=wasd.slime] run function wasd.tnt:zzz/15
execute as @s[tag=wasd.sponge] run function wasd.tnt:zzz/16
execute as @s[tag=wasd.poison] run function wasd.tnt:zzz/17
function wasd.tnt:patron/place
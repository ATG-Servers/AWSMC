#mc-build WASD content
execute unless block ~ ~-1 ~ dropper run function wasd.tnt:tnt_cannon/aa_cannon_remove
#determine if and which player is riding the TNT cannon
tag @a[tag=wasd.tnt_cannon_passenger,distance=..5] remove wasd.tnt_cannon_passenger
tag @s[tag=wasd.has_passenger] remove wasd.has_passenger
execute at @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.has_passenger,distance=..3] if score @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.has_passenger,limit=1,sort=nearest,distance=..0.001] wasd.uuid1 = @s wasd.uuid1 run function wasd.tnt:tnt_cannon/zzz/1
execute as @s[tag=wasd.has_passenger] run function wasd.tnt:tnt_cannon/zzz/3
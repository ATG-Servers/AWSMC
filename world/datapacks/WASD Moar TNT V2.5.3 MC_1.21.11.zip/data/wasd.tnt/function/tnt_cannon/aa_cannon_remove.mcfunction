#mc-build WASD content
loot spawn ~ ~ ~ loot wasd.tnt:patron/aa_cannon
execute as @e[type=item,sort=nearest,limit=1,distance=..2,nbt={OnGround:0b,Age:0s,Item:{id:"minecraft:dropper"}}] run kill @s
execute if block ~ ~ ~ dropper run setblock ~ ~ ~ air
execute at @e[type=interaction,tag=wasd.tnt_cannon,distance=..3] if score @e[type=interaction,tag=wasd.tnt_cannon,limit=1,sort=nearest,distance=..0.001] wasd.uuid1 = @s wasd.uuid1 run kill @e[type=interaction,tag=wasd.tnt_cannon,limit=1,sort=nearest,distance=..0.001]
#this one last
execute at @e[type=item_display,tag=wasd.tnt_cannon,distance=..2] if score @e[type=item_display,tag=wasd.tnt_cannon,limit=1,sort=nearest,distance=..0.001] wasd.uuid1 = @s wasd.uuid1 run kill @e[type=item_display,tag=wasd.tnt_cannon,limit=1,sort=nearest,distance=..0.001]
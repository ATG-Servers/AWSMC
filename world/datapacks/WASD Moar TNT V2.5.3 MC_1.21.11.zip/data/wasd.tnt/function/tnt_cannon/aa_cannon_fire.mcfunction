#mc-build WASD content
execute if data block ~ ~-2 ~ Items[0].components."minecraft:custom_data".wasd_custom_tnt run tag @s add wasd.has_ammo
scoreboard players reset @s wasd.temp4
execute if data block ~ ~-2 ~ Items[0] store success score @s wasd.temp4 run data modify storage minecraft:wasd.tnt check_if_tnt set from block ~ ~-2 ~ Items[0].id
data merge storage wasd.tnt {check_if_tnt:"minecraft:tnt"}
execute as @s[scores={wasd.temp4=0}] run function wasd.tnt:tnt_cannon/zzz/6
execute unless data block ~ ~-2 ~ Items[0] run function wasd.tnt:tnt_cannon/zzz/7
execute as @s[tag=wasd.has_ammo] at @s positioned ^ ^-0.4 ^5.5 run function wasd.tnt:tnt_cannon/zzz/8
execute as @s[tag=wasd.has_ammo] run function wasd.tnt:tnt_cannon/zzz/12
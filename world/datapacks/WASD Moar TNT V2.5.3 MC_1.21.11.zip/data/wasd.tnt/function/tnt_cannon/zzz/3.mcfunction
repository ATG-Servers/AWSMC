#mc-build WASD content
#rotate gun/turret on YAW
data modify entity @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_turret,sort=nearest,limit=1] Rotation[0] set from entity @p[tag=wasd.tnt_cannon_passenger,distance=..4] Rotation[0]
data modify entity @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_gun,sort=nearest,limit=1] Rotation[0] set from entity @p[tag=wasd.tnt_cannon_passenger,distance=..4] Rotation[0]
execute as @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_gun,sort=nearest,limit=1,tag=wasd.just_fired] run function wasd.tnt:tnt_cannon/zzz/4
#rotate gun pitch, with min/max pitches
execute if entity @p[tag=wasd.tnt_cannon_passenger,distance=..4] store result score @s wasd.temp run data get entity @p[tag=wasd.tnt_cannon_passenger,distance=..4] Rotation[1] 10000
execute store result score @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_gun,sort=nearest,limit=1] wasd.variables run data get entity @p[tag=wasd.tnt_cannon_passenger,distance=..4] SelectedItemSlot
execute if score @s wasd.temp matches 0.. run scoreboard players set @s wasd.temp 1
execute if score @s wasd.temp matches ..-500000 run scoreboard players set @s wasd.temp -500000
execute store result entity @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_gun,sort=nearest,limit=1] Rotation[1] float 0.0001 run scoreboard players get @s wasd.temp
#move seat
execute at @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.seat,distance=..3] if score @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.seat,sort=nearest,limit=1,distance=..0.001] wasd.uuid1 = @s wasd.uuid1 as @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.seat,sort=nearest,distance=..0.001] at @e[type=item_display,tag=wasd.tnt_cannon,tag=wasd.tnt_cannon_base,distance=..3] if score @e[type=item_display,tag=wasd.tnt_cannon,tag=wasd.tnt_cannon_base,limit=1,sort=nearest,distance=..0.001] wasd.uuid1 = @s wasd.uuid1 rotated as @p[tag=wasd.tnt_cannon_passenger,distance=..3] rotated ~ 0 run tp @s ^ ^0.25 ^-2 ~ ~
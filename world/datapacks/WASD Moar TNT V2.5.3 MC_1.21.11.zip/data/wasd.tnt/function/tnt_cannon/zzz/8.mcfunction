#mc-build WASD content
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.1 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.2 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.30000000000000004 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.4 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.5 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.6000000000000001 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.7000000000000001 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.8 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^0.9 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.1 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.2000000000000002 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.3 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.4000000000000001 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.5 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.6 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.7000000000000002 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.8 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^1.9000000000000001 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.1 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.2 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.3000000000000003 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.4000000000000004 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.5 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.6 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.7 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.8000000000000003 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^2.9000000000000004 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.1 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.2 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.3000000000000003 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.4000000000000004 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.5 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.6 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.7 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.8000000000000003 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^3.9000000000000004 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle poof ^ ^ ^4 ^ ^ ^100000000 0.000000005 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.30000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.4 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.6000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.7000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.8 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^0.9 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.2000000000000002 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.3 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.4000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.6 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.7000000000000002 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.8 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^1.9000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.3000000000000003 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.4000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.6 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.7 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.8000000000000003 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^2.9000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle flame ^ ^ ^3 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.30000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.4 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.6000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.7000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.8 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^0.9 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.2000000000000002 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.3 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.4000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.6 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.7000000000000002 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.8 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^1.9000000000000001 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.1 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.2 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.3000000000000003 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.4000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.5 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.6 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.7 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.8000000000000003 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^2.9000000000000004 ^ ^ ^100000000 0.000000004 0 force
execute positioned ^ ^ ^-1 run particle smoke ^ ^ ^3 ^ ^ ^100000000 0.000000004 0 force
execute rotated ~90 ~10 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~15 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~17.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~20 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~25 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~27.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~30 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~35 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~37.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~40 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~45 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~47.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~50 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~55 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~57.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~60 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~65 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~67.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~70 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~75 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~77.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~80 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~85 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~87.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~90 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~95 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~97.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~100 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~105 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~107.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~110 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~115 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~117.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~120 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~125 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~127.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~130 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~135 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~137.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~140 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~145 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~147.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~150 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~155 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~157.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~160 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~165 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~167.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~170 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~175 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~177.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~180 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~185 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~187.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~190 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~195 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~197.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~200 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~205 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~207.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~210 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~215 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~217.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~220 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~225 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~227.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~230 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~235 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~237.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~240 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~245 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~247.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~250 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~255 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~257.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~260 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~265 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~267.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~270 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~275 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~277.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~280 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~285 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~287.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~290 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~295 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~297.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~300 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~305 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~307.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~310 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~315 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~317.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~320 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~325 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~327.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~330 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~335 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~337.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~340 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~345 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~347.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~350 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~355 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~357.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~360 run particle poof ^ ^ ^ ^ ^ ^100000000 0.0000000015 0 force
execute rotated ~90 ~365 run particle flame ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
execute rotated ~90 ~367.5 run particle smoke ^ ^ ^ ^ ^ ^100000000 0.000000001 0 force
playsound entity.generic.explode player @a ~ ~ ~ 1 1
playsound entity.firework_rocket.blast player @a ~ ~ ~ 1 0.5
playsound entity.firework_rocket.blast player @a ~ ~ ~ 1 0.5
playsound entity.firework_rocket.blast player @a ~ ~ ~ 1 0.5
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 1 1
playsound entity.firework_rocket.large_blast player @a ~ ~ ~ 1 0.5
playsound entity.firework_rocket.large_blast player @a ~ ~ ~ 1 1
#do visual animation
data merge entity @s {start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.6f,2.3f],scale:[2.5f,2.5f,2.5f]}}
tag @s add wasd.just_fired
execute as @s[tag=!wasd.vanilla_tnt_ammo] run function wasd.tnt:tnt_cannon/zzz/9
execute as @s[tag=wasd.vanilla_tnt_ammo] run function wasd.tnt:tnt_cannon/zzz/11
execute as @s[scores={wasd.variables=0}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^10 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=1}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^13 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=2}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^16 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=3}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^19 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=4}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^22 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=5}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^25 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=6}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^28 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=7}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^31 run function wasd.lib:math/apply_motion
execute as @s[scores={wasd.variables=8}] as @e[tag=wasd.tnt_cannon_tnt,sort=nearest,limit=1] positioned ^ ^ ^34 run function wasd.lib:math/apply_motion
tag @s remove wasd.vanilla_tnt_ammo
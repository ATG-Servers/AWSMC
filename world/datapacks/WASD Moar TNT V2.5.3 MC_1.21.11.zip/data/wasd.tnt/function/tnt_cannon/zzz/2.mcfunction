#mc-build WASD content
scoreboard players set @s wasd.temp 0
execute on passengers run tag @s add wasd.tnt_cannon_passenger
execute on passengers on vehicle run scoreboard players set @s wasd.temp 1
execute as @s[scores={wasd.temp=0}] run tag @s remove wasd.has_passenger
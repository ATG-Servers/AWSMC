#mc-build WASD content
scoreboard players add @s wasd.temp2 1
execute as @s[scores={wasd.temp2=3..}] run function wasd.tnt:tnt_cannon/zzz/5
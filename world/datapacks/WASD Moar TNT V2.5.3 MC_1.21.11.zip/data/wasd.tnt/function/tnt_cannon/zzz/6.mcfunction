#mc-build WASD content
tag @s add wasd.has_ammo
tag @s add wasd.vanilla_tnt_ammo
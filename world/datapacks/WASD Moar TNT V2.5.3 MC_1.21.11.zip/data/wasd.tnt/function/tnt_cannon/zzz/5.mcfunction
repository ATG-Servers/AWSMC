#mc-build WASD content
scoreboard players reset @s wasd.temp2
tag @s remove wasd.just_fired
data merge entity @s {start_interpolation:0,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.6f,2.5f],scale:[2.5f,2.5f,2.5f]}}
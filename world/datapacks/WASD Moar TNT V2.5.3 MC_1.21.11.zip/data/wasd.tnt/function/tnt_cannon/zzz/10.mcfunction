#mc-build WASD content
data modify entity @s item.components."minecraft:custom_model_data" set from block ~ ~-2 ~ Items[0].components."minecraft:custom_model_data"
data modify entity @s Tags prepend from block ~ ~-2 ~ Items[0].components."minecraft:entity_data".Tags[2]
execute store result score @s wasd.x_angle run data get entity @e[tag=wasd.tnt_cannon,tag=wasd.aa_gun_gun,sort=nearest,limit=1] Rotation[0] 1
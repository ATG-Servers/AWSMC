#mc-build WASD content
playsound minecraft:block.dispenser.fail player @a ~ ~ ~ 1 2
playsound minecraft:block.dispenser.fail player @a ~ ~ ~ 1 2
playsound minecraft:block.dispenser.fail player @a ~ ~ ~ 1 2
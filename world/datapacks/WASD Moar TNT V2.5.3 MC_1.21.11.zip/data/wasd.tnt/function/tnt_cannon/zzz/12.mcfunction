#mc-build WASD content
execute store result score @s wasd.temp run data get block ~ ~-2 ~ Items[0].count
execute store result block ~ ~-2 ~ Items[0].count int 1 run scoreboard players operation @s wasd.temp -= 1 wasd.constants
execute as @s[scores={wasd.temp=0}] run data remove block ~ ~-2 ~ Items[0]
tag @s remove wasd.has_ammo
#mc-build WASD content
execute as @e[type=interaction,tag=wasd.tnt_cannon,tag=wasd.has_passenger,limit=1,sort=nearest,distance=..0.001] run function wasd.tnt:tnt_cannon/zzz/2
tag @s add wasd.has_passenger
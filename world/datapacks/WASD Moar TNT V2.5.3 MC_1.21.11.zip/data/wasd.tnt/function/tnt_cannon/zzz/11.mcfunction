#mc-build WASD content
summon tnt ~ ~ ~ {fuse:100,Tags:["wasd.tnt_cannon_tnt"]}
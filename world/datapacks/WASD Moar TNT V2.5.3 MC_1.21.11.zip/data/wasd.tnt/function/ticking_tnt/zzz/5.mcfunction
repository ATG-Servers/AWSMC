#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:all_mineable run function wasd.tnt:ticking_tnt/zzz/6
kill @s
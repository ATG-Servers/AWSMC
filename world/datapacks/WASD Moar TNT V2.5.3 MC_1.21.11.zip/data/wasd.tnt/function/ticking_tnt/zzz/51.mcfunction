#mc-build WASD content
tag @s add wasd.exploding
execute on vehicle run data merge entity @s {fuse:8}
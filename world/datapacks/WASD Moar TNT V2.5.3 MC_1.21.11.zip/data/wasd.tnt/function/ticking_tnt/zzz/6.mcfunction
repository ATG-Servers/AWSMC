#mc-build WASD content
particle block{block_state:{Name:"minecraft:stone"}} ~ ~ ~ 0.2 0.2 0.2 0 10 normal
playsound block.stone.break block @a ~ ~ ~ 0.5 1
loot spawn ~ ~ ~ mine ~ ~ ~
setblock ~ ~ ~ air replace
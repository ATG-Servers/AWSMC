#mc-build WASD content
tag @s add wasd.move
execute on vehicle run data merge entity @s {NoGravity:1b}
#mc-build WASD content
scoreboard players reset @s wasd.temp
summon tnt ~ ~-0.9 ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
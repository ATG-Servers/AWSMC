#mc-build WASD content
tag @s add wasd.ignore_grow
data merge entity @s {start_interpolation:-1,interpolation_duration:40,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.08f,0f],scale:[2.15f,2.15f,2.15f]}}
#mc-build WASD content
execute as @s[tag=wasd.north] on vehicle run data merge entity @s {Motion:[0.0,0.0,0.5]}
execute as @s[tag=wasd.south] on vehicle run data merge entity @s {Motion:[0.0,0.0,-0.5]}
execute as @s[tag=wasd.east] on vehicle run data merge entity @s {Motion:[-0.5,0.0,0.0]}
execute as @s[tag=wasd.west] on vehicle run data merge entity @s {Motion:[0.5,0.0,0.0]}
execute if predicate light_level:0 run setblock ~ ~ ~ torch keep
execute if block ^ ^-1 ^1 #wasd.tags:air run setblock ^ ^-1 ^1 cobblestone
execute positioned ^ ^1 ^1 run function wasd.lib:detection/vertical/3x3
execute as @e[type=marker,tag=wasd.location] at @s run function wasd.tnt:ticking_tnt/zzz/5
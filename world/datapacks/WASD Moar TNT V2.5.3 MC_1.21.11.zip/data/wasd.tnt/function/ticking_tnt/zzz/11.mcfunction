#mc-build WASD content
scoreboard players reset @s wasd.variables
playsound block.note_block.chime player @a ~ ~ ~ 1 1.2 1
execute store result score @s wasd.rng run random value 1..50
execute as @s run function wasd.tnt:ticking_tnt/zzz/12
#mc-build WASD content
execute on vehicle run kill @s
execute align y run tp @s ~ ~1 ~
execute store result entity @s Rotation[0] float 1 run scoreboard players get @s wasd.x_angle
tag @s add wasd.exempt
summon item_display ~ ~ ~ {teleport_duration:0,Tags:["wasd.custom_tnt","wasd.tnt_block","wasd.walking_leg","wasd.left_leg"],brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0.25f,-0.7f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:tnt/base_tnt_entity","minecraft:custom_model_data":{"floats":[6371050]}}}}
summon item_display ~ ~ ~ {teleport_duration:0,Tags:["wasd.custom_tnt","wasd.tnt_block","wasd.walking_leg","wasd.right_leg"],brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.25f,-0.7f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:tnt/base_tnt_entity","minecraft:custom_model_data":{"floats":[6371050]}}}}
ride @e[tag=wasd.walking_leg,tag=wasd.left_leg,sort=nearest,limit=1,distance=..0.001] mount @s
ride @e[tag=wasd.walking_leg,tag=wasd.right_leg,sort=nearest,limit=1,distance=..0.001] mount @s
execute store result entity @e[tag=wasd.walking_leg,tag=wasd.left_leg,sort=nearest,limit=1,distance=..0.001] Rotation[0] float 1 run scoreboard players get @s wasd.x_angle
execute store result entity @e[tag=wasd.walking_leg,tag=wasd.right_leg,sort=nearest,limit=1,distance=..0.001] Rotation[0] float 1 run scoreboard players get @s wasd.x_angle
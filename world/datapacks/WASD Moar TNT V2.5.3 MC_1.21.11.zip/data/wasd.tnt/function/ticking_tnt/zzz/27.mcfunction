#mc-build WASD content
scoreboard players reset @s wasd.variables
summon marker ~ ~ ~ {Tags:["wasd.lightning_rotation"]}
execute as @e[tag=wasd.lightning_rotation,sort=nearest,limit=1,distance=..0.1] at @s run function wasd.tnt:ticking_tnt/zzz/28
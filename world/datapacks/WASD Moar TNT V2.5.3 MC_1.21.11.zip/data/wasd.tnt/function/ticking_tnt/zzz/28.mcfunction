#mc-build WASD content
execute store result entity @s Rotation[0] float 1 run random value 1..360
execute store result score @s wasd.rng run random value 1..10
execute at @s[scores={wasd.rng=2}] positioned ^ ^ ^2 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/29
execute at @s[scores={wasd.rng=3}] positioned ^ ^ ^3 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/31
execute at @s[scores={wasd.rng=4}] positioned ^ ^ ^4 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/33
execute at @s[scores={wasd.rng=5}] positioned ^ ^ ^5 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/35
execute at @s[scores={wasd.rng=6}] positioned ^ ^ ^6 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/37
execute at @s[scores={wasd.rng=7}] positioned ^ ^ ^7 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/39
execute at @s[scores={wasd.rng=8}] positioned ^ ^ ^8 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/41
execute at @s[scores={wasd.rng=9}] positioned ^ ^ ^9 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/43
execute at @s[scores={wasd.rng=10}] positioned ^ ^ ^10 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/45
execute at @s[scores={wasd.rng=11}] positioned ^ ^ ^11 positioned over motion_blocking_no_leaves run function wasd.tnt:ticking_tnt/zzz/47
kill @s
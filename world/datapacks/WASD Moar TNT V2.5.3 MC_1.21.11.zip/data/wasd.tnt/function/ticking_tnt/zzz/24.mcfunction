#mc-build WASD content
execute as @s[tag=wasd.left_leg] run rotate @s ~ ~-15
execute as @s[tag=wasd.right_leg] run rotate @s ~ ~15
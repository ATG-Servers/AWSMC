#mc-build WASD content
playsound minecraft:block.crop.break player @a ~ ~ ~ 0.3 1
execute positioned ~ ~1 ~ run function wasd.lib:crops/grow/7x7
execute positioned ~ ~ ~ run function wasd.lib:crops/grow/7x7
execute positioned ~ ~-1 ~ run function wasd.lib:crops/grow/7x7
scoreboard players reset @s wasd.temp
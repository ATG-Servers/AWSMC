#mc-build WASD content
execute positioned ^ ^ ^0.5 if block ~ ~-2 ~ #wasd.tags:nonsolid unless block ~ ~-3 ~ #wasd.tags:nonsolid run tp @s ^ ^ ^-0.4
execute positioned ^ ^ ^0.5 if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid run tp @s ^ ^-1 ^-0.4
execute positioned ^ ^ ^0.5 unless block ~ ~-2 ~ #wasd.tags:nonsolid run tp @s ^ ^1 ^-0.4
execute if block ~ ~-4 ~ #wasd.tags:nonsolid run tag @s add wasd.should_explode
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.should_explode
execute positioned ~ ~-1 ~ if entity @e[type=#wasd.tags:mobs_player,distance=..2] run tag @s add wasd.should_explode
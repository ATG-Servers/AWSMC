#mc-build WASD content
execute on vehicle at @s run function wasd.tnt:ticking_tnt/zzz/8
#mc-build WASD content
summon minecraft:lightning_bolt
execute if score exploding_lightning w.tnt_settings matches 1 run function wasd.tnt:ticking_tnt/zzz/46
#mc-build WASD content
scoreboard players remove @s wasd.timer 1
execute unless block ~0.4 ~-1 ~ #wasd.tags:nonsolid run tag @s add wasd.should_walk
execute unless block ~ ~-1 ~0.4 #wasd.tags:nonsolid run tag @s add wasd.should_walk
execute unless block ~-0.4 ~-1 ~ #wasd.tags:nonsolid run tag @s add wasd.should_walk
execute unless block ~ ~-1 ~-0.4 #wasd.tags:nonsolid run tag @s add wasd.should_walk
#mc-build WASD content
execute positioned ~0.5 ~-0.01 ~0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~0.5 ~-0.01 ~-0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~-0.5 ~-0.01 ~0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~-0.5 ~-0.01 ~-0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~0.5 ~1.01 ~0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~0.5 ~1.01 ~-0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~-0.5 ~1.01 ~0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute positioned ~-0.5 ~1.01 ~-0.5 unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players set @s wasd.timer 901
execute as @s[scores={wasd.timer=901..}] run function wasd.tnt:explode/impact
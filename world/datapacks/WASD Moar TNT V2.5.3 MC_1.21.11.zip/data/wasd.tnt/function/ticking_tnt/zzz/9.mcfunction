#mc-build WASD content
scoreboard players reset @s wasd.temp
scoreboard players add @s wasd.variables 1
playsound entity.firework_rocket.launch player @a ~ ~ ~ 3 1
playsound entity.firework_rocket.launch player @a ~ ~ ~ 3 1
playsound entity.firework_rocket.launch player @a ~ ~ ~ 3 1
particle firework ~ ~0.5 ~ 0 0 0 0.1 20 force
particle large_smoke ~ ~0.5 ~ 0 0 0 0.1 20 force
summon item_display ~ ~ ~ {Rotation:[0F,-80F],view_range:3f,item_display:"head",Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.rocket_missile"],teleport_duration:1,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:abilities/rocket"}}}
execute as @e[tag=wasd.custom_tnt,tag=wasd.tnt_effect,tag=wasd.rocket_missile,sort=nearest,limit=1] store result entity @s Rotation[0] float 1 run random value 1..360
#mc-build WASD content
summon area_effect_cloud ^ ^1.7 ^0.7 {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"]}
execute positioned ~ ~1.7 ~ run tp @e[tag=wasd.laser_laser,sort=nearest,limit=1] ~ ~ ~ facing entity @e[tag=wasd.tnt_laser_target,sort=nearest,limit=1] feet
execute positioned ~ ~1.7 ~ as @e[tag=wasd.laser_laser,sort=nearest,limit=1] at @s run function wasd.tnt:tnt_effects/laser_laser
scoreboard players reset @s wasd.temp4
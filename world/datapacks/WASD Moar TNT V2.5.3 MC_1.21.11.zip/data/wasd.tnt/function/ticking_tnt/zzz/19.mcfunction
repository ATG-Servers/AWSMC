#mc-build WASD content
scoreboard players reset @s wasd.temp
playsound entity.generic.explode player @a ~ ~ ~ 2 1
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
particle flame ~ ~1 ~ 0.2 0.2 0.2 0.1 100 force
particle smoke ~ ~1 ~ 0.2 0.2 0.2 0.1 100 force
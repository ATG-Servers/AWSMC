#mc-build WASD content
execute on passengers run data merge entity @s {teleport_duration:10}
data merge entity @s {teleport_duration:1}
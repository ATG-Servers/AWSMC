#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:2,block_state:{Name:"minecraft:air"}}
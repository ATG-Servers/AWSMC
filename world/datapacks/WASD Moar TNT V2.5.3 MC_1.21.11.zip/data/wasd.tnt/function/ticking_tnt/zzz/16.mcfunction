#mc-build WASD content
scoreboard players reset @s wasd.variables
function wasd.tnt:ticking_tnt/zzz/17
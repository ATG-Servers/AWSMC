#mc-build WASD content
execute positioned ^ ^100 ^133 run function wasd.tnt:ticking_tnt/zzz/15
kill @s
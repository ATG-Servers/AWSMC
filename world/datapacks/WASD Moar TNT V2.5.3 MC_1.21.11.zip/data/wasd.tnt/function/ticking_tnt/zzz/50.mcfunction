#mc-build WASD content
execute at @s if entity @e[type=#wasd.tags:mobs_player,distance=..5] run tag @s add wasd.primed
execute at @s if entity @e[type=#wasd.tags:mobs_player,distance=..3] run tag @s add wasd.do_explode
execute as @s[tag=wasd.primed] unless entity @e[type=#wasd.tags:mobs_player,distance=..5] run tag @s add wasd.do_explode
execute as @s[tag=wasd.do_explode] unless entity @s[tag=wasd.exploding] run function wasd.tnt:ticking_tnt/zzz/51
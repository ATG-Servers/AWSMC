#mc-build WASD content
execute as @s[scores={wasd.timer=10..}] run function wasd.tnt:ticking_tnt/zzz/7
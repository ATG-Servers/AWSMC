#mc-build WASD content
execute as @s[tag=!wasd.move,scores={wasd.timer=60}] run function wasd.tnt:ticking_tnt/zzz/3
execute as @s[tag=wasd.move] run function wasd.tnt:ticking_tnt/zzz/4
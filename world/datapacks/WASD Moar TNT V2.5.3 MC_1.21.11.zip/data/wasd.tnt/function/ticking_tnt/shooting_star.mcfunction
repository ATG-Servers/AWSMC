#mc-build WASD content
scoreboard players add @s[tag=!wasd.shot_by_cannon] wasd.variables 1
scoreboard players add @s[tag=wasd.shot_by_cannon,scores={wasd.timer=60..}] wasd.variables 1
execute as @s[scores={wasd.variables=5..}] run function wasd.tnt:ticking_tnt/zzz/13
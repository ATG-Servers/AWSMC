#mc-build WASD content
execute as @s[scores={wasd.timer=2}] run function wasd.tnt:ticking_tnt/zzz/56
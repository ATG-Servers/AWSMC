#mc-build WASD content
scoreboard players add @s[scores={wasd.timer=40..}] wasd.variables 1
execute as @s[scores={wasd.variables=1}] store result score @s wasd.rng run random value 2..7
execute if score @s wasd.variables >= @s wasd.rng run function wasd.tnt:ticking_tnt/zzz/27
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=480..}] run function wasd.tnt:explode/laser
execute positioned ^ ^1.7 ^0.7 run function wasd.tnt:ticking_tnt/zzz/1
execute if entity @e[tag=wasd.tnt_possible_laser_target,tag=!wasd.not_a_target] run summon area_effect_cloud ^ ^1.7 ^0.7 {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.los_laser"]}
execute positioned ~ ~1.7 ~ run tp @e[tag=wasd.los_laser,sort=nearest,limit=1] ~ ~ ~ facing entity @e[tag=wasd.tnt_possible_laser_target,sort=nearest,limit=1,tag=!wasd.not_a_target] feet
execute positioned ~ ~1.7 ~ as @e[tag=wasd.los_laser,sort=nearest,limit=1] at @s run function wasd.tnt:tnt_effects/los_laser
execute if entity @e[tag=wasd.tnt_laser_target] run scoreboard players add @s wasd.temp4 1
execute as @s[scores={wasd.temp4=10..}] run function wasd.tnt:ticking_tnt/zzz/2
execute store result score @s wasd.temp run data get entity @s Rotation[0]
execute unless entity @e[tag=wasd.tnt_laser_target] store result entity @s Rotation[0] float 1 run scoreboard players operation @s wasd.temp += 3 wasd.constants
tp @s ~ ~ ~ facing entity @e[tag=wasd.tnt_laser_target,sort=nearest,limit=1]
tag @e[tag=wasd.tnt_possible_laser_target] remove wasd.tnt_possible_laser_target
tag @e[tag=wasd.tnt_laser_target] remove wasd.tnt_laser_target
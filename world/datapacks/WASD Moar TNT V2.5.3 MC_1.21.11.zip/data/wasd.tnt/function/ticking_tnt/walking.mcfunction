#mc-build WASD content
execute as @s[tag=wasd.shot_by_cannon,tag=!wasd.should_walk] run function wasd.tnt:ticking_tnt/zzz/20
execute as @s[scores={wasd.timer=1}] run function wasd.tnt:ticking_tnt/zzz/21
execute as @s[scores={wasd.timer=2}] run function wasd.tnt:ticking_tnt/zzz/22
scoreboard players add @s wasd.variables 1
execute as @s[scores={wasd.variables=2}] on passengers run function wasd.tnt:ticking_tnt/zzz/23
execute as @s[scores={wasd.variables=14}] on passengers run function wasd.tnt:ticking_tnt/zzz/24
scoreboard players reset @s[scores={wasd.variables=24..}] wasd.variables
execute as @s[scores={wasd.timer=3..}] run function wasd.tnt:ticking_tnt/zzz/25
tag @s[scores={wasd.timer=600..}] add wasd.should_explode
execute as @s[tag=wasd.should_explode] run function wasd.tnt:ticking_tnt/zzz/26
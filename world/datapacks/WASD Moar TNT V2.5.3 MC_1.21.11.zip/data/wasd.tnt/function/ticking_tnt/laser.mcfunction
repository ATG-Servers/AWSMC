#mc-build WASD content
execute as @s[type=!armor_stand] unless block ~ ~-0.75 ~ #wasd.tags:nonsolid run function wasd.tnt:ticking_tnt/zzz/0
#mc-build WASD content
scoreboard players add @s wasd.variables 1
execute as @s[scores={wasd.variables=6..}] run function wasd.tnt:ticking_tnt/zzz/16
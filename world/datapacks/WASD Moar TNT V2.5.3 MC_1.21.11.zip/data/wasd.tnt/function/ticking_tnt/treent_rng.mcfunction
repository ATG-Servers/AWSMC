#mc-build WASD content
execute store result score @s wasd.rng run random value 1..8
execute if score @s wasd.temp = @s wasd.rng run function wasd.tnt:ticking_tnt/treent_rng
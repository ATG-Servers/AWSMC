#mc-build WASD content
execute store result score @s wasd.x_angle run data get entity @p[scores={wasd.placed_item_frame=1..}] Rotation[0] 1
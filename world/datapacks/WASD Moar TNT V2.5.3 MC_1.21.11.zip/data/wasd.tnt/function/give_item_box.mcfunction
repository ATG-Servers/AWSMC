#mc-build WASD content
setblock ~ ~ ~ minecraft:red_shulker_box
loot insert ~ ~ ~ loot wasd.tnt:amethyst
loot insert ~ ~ ~ loot wasd.tnt:arrow
loot insert ~ ~ ~ loot wasd.tnt:bee
loot insert ~ ~ ~ loot wasd.tnt:magnetic
loot insert ~ ~ ~ loot wasd.tnt:tntnt
loot insert ~ ~ ~ loot wasd.tnt:sword
loot insert ~ ~ ~ loot wasd.tnt:inverted
loot insert ~ ~ ~ loot wasd.tnt:anvil
loot insert ~ ~ ~ loot wasd.tnt:cactus
loot insert ~ ~ ~ loot wasd.tnt:directional
loot insert ~ ~ ~ loot wasd.tnt:dripstone
loot insert ~ ~ ~ loot wasd.tnt:pickaxe
loot insert ~ ~ ~ loot wasd.tnt:potato
loot insert ~ ~ ~ loot wasd.tnt:slime
loot insert ~ ~ ~ loot wasd.tnt:sponge
loot insert ~ ~ ~ loot wasd.tnt:poison
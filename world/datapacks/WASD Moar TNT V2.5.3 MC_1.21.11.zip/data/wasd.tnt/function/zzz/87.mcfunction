#mc-build WASD content
function wasd.tnt:explode/arrow
execute on vehicle run kill @s
kill @s
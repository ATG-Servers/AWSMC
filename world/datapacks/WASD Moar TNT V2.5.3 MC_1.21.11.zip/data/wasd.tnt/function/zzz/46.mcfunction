#mc-build WASD content
#<TNT tag>
execute unless block ~ ~ ~ tnt run function wasd.tnt:zzz/47
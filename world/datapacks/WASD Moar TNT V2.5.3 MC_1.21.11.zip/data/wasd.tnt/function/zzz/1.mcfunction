#mc-build WASD content
setblock ~ ~ ~ air
summon tnt ~ ~ ~ {fuse:60}
#mc-build WASD content
execute if block ~ ~ ~1 #wasd.tags:pistons[extended=true,facing=north] run fill ~ ~ ~-1 ~ ~ ~-1 air replace minecraft:moving_piston
execute if block ~ ~ ~-1 #wasd.tags:pistons[extended=true,facing=south] run fill ~ ~ ~1 ~ ~ ~1 air replace minecraft:moving_piston
execute if block ~-1 ~ ~ #wasd.tags:pistons[extended=true,facing=east] run fill ~1 ~ ~ ~1 ~ ~ air replace minecraft:moving_piston
execute if block ~1 ~ ~ #wasd.tags:pistons[extended=true,facing=west] run fill ~-1 ~ ~ ~-1 ~ ~ air replace minecraft:moving_piston
execute if block ~ ~-1 ~ #wasd.tags:pistons[extended=true,facing=up] run fill ~ ~1 ~ ~ ~1 ~ air replace minecraft:moving_piston
execute if block ~ ~1 ~ #wasd.tags:pistons[extended=true,facing=down] run fill ~ ~-1 ~ ~ ~-1 ~ air replace minecraft:moving_piston
loot spawn ~ ~0.5 ~ loot wasd.tnt:sponge
kill @n[type=item,nbt={OnGround:0b,Age:0s,Item:{id:"minecraft:tnt"}}]
kill @s
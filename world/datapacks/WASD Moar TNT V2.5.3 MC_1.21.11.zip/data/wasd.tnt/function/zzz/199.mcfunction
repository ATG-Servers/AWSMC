#mc-build WASD content
ride @p[tag=wasd.right_click,distance=..6] mount @s
tag @s add wasd.has_passenger
#mc-build WASD content
execute if entity @e[type=tnt,sort=nearest,limit=1,distance=..0.1] run function wasd.tnt:zzz/72
execute as @s[tag=!wasd.explode] run function wasd.tnt:zzz/73
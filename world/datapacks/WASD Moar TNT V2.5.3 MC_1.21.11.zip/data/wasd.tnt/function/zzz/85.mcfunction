#mc-build WASD content
function wasd.tnt:explode/amethyst
execute on vehicle run kill @s
kill @s
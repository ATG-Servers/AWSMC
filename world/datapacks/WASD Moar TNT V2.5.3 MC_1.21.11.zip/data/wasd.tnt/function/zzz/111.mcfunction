#mc-build WASD content
function wasd.tnt:explode/slime
execute on vehicle run kill @s
kill @s
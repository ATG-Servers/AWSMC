#mc-build WASD content
function wasd.tnt:explode/sword
execute on vehicle run kill @s
kill @s
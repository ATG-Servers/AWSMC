#mc-build WASD content
function wasd.tnt:explode/dripstone
execute on vehicle run kill @s
kill @s
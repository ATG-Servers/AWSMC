#mc-build WASD content
function wasd.tnt:explode/template
execute on vehicle run kill @s
kill @s
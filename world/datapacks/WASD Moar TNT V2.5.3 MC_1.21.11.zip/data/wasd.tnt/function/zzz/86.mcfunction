#mc-build WASD content
#<Time until explosion> <Time until explosion cannon> <run. Function to run on explosion>
execute unless entity @s[tag=wasd.ignore_grow] on vehicle if entity @s[nbt={fuse:7s}] on passengers run data merge entity @s {start_interpolation:-1,interpolation_duration:7,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.483f,0f],scale:[1.15f,1.15f,1.15f]}}
execute on vehicle if entity @s[nbt={fuse:1s}] on passengers run function wasd.tnt:zzz/87
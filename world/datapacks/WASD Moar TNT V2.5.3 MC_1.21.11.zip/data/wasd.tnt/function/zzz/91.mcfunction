#mc-build WASD content
function wasd.tnt:explode/magnetic
execute on vehicle run kill @s
kill @s
#mc-build WASD content
function wasd.tnt:explode/directional
execute on vehicle run kill @s
kill @s
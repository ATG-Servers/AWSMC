#mc-build WASD content
data modify entity @s item.components."minecraft:item_model" set value "wasd:tnt/base_tnt_entity"
data modify entity @s transformation.translation[1] set value -0.483f
ride @s mount @n[type=tnt]
data merge entity @n[type=tnt] {block_state:{Name:"minecraft:air"}}
tag @s remove wasd.tnt_block
tag @s add wasd.tnt_entity
tag @s add wasd.explode
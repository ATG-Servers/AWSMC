#mc-build WASD content
#<TNT tag> <CMD>
summon tnt ~ ~ ~ {fuse:70s}
summon item_display ~ ~ ~ {Tags:["wasd.custom_tnt","wasd.tnt_entity","wasd.explode","wasd.sponge"],brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.483f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:tnt/base_tnt_entity","minecraft:custom_model_data":{"floats":[6371016]}}}}
ride @e[tag=wasd.custom_tnt,tag=wasd.explode,sort=nearest,limit=1] mount @e[type=tnt,sort=nearest,limit=1]
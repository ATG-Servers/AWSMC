#mc-build WASD content
function wasd.tnt:explode/bee
execute on vehicle run kill @s
kill @s
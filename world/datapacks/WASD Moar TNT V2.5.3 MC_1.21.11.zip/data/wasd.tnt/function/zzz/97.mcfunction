#mc-build WASD content
function wasd.tnt:explode/inverted
execute on vehicle run kill @s
kill @s
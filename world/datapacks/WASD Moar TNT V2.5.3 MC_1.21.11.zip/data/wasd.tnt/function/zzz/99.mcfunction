#mc-build WASD content
function wasd.tnt:explode/anvil
execute on vehicle run kill @s
kill @s
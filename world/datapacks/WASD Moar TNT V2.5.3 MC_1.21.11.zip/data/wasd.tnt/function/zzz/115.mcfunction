#mc-build WASD content
function wasd.tnt:explode/poison
execute on vehicle run kill @s
kill @s
#mc-build WASD content
function wasd.tnt:explode/sponge
execute on vehicle run kill @s
kill @s
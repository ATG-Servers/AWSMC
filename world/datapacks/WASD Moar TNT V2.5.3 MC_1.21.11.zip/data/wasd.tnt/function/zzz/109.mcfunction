#mc-build WASD content
function wasd.tnt:explode/potato
execute on vehicle run kill @s
kill @s
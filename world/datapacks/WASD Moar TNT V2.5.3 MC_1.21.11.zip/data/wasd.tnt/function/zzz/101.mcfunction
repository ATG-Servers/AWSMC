#mc-build WASD content
function wasd.tnt:explode/cactus
execute on vehicle run kill @s
kill @s
#mc-build WASD content
function wasd.tnt:explode/pickaxe
execute on vehicle run kill @s
kill @s
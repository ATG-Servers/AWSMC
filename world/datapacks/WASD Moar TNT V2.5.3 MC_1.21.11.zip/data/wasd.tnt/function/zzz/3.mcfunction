#mc-build WASD content
#<TNT tag> <CMD> <"normal" "face_me", "face_away"> <run (make a function run on place)>
setblock ~ ~ ~ tnt keep
execute if block ~ ~ ~ water run setblock ~ ~ ~ tnt

summon item_display ~ ~ ~ {Tags:["wasd.custom_tnt","wasd.tnt_block","wasd.arrow"],brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0.47f,0f],scale:[1.01f,1.01f,1.01f]},item:{id:"minecraft:glow_item_frame",count:1,components:{"minecraft:item_model":"wasd:tnt/base_tnt_block","minecraft:custom_model_data":{"floats":[6371003]}}}}

#mc-build WASD content
particle block{block_state:{Name:"minecraft:oak_leaves"}} ~ ~0.5 ~ 0.5 0.5 0.5 0.1 100
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
particle sneeze ~ ~0.5 ~ 0.5 0.5 0.5 0.1 100
execute positioned ~ ~1 ~ run function wasd.lib:detection/horizontal/rotated/7x7
execute positioned ~ ~0 ~ run function wasd.lib:detection/horizontal/rotated/7x7
execute positioned ~ ~-1 ~ run function wasd.lib:detection/horizontal/rotated/7x7
execute as @e[tag=wasd.location] at @s run function wasd.tnt:explode/zzz/26
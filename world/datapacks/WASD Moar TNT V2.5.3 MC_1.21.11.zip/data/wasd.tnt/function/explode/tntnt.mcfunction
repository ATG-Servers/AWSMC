#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon tnt ~ ~ ~ {fuse:100,Motion:[1.0,0.5,0.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-1.0,0.5,0.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.0,0.5,1.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.0,0.5,-1.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.8,0.5,0.8],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-0.8,0.5,0.8],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.8,0.5,-0.8],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-0.8,0.5,-0.8],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.4,0.7,0.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-0.4,0.7,0.0],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.0,0.7,0.4],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.0,0.7,-0.4],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.25,0.7,0.25],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-0.25,0.7,0.25],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[0.25,0.7,-0.25],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
summon tnt ~ ~ ~ {fuse:100,Motion:[-0.25,0.7,-0.25],Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.tntnt"]}
#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
execute positioned over motion_blocking_no_leaves run summon minecraft:lightning_bolt
#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
summon bee ~ ~ ~ {AngerTime:10000,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.angry_bee"],AngryAt:[I;1,1,1,1]}
particle dust{color:[0.0, 0.0, 0.0], scale:1.0} ~ ~1 ~ 1 1 1 1 50 force
particle dust{color:[1.0, 0.902, 0.0], scale:1.0} ~ ~1 ~ 1 1 1 1 50 force
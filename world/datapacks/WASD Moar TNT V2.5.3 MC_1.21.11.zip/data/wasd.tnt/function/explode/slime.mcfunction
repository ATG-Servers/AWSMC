#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
particle sneeze ~ ~0.5 ~ 0.1 0.1 0.1 0.3 200 normal
execute as @e[type=#wasd.tags:mobs_player,distance=..5] at @s run function wasd.tnt:explode/zzz/7
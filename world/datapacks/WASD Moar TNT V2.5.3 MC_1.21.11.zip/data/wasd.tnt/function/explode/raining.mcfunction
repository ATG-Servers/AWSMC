#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon marker ~ ~ ~ {Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.raining_center"]}
#mc-build WASD content
place template wasd.tnt:sphere_explosion_inner ~-13 ~-13 ~-13
place template wasd.tnt:sphere_explosion_outer ~-14 ~-14 ~-14 none none 0.3
summon tnt ~13 ~ ~ {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~-13 ~ ~ {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~13 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-13 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~9 ~ ~9 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~-9 ~ ~9 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~9 ~ ~-9 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
summon tnt ~-9 ~ ~-9 {fuse:0,explosion_power:13,block_state:{Name:"minecraft:air"}}
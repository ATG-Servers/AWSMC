#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon item_display ~ ~ ~ {view_range:3f,item_display:"head",Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.spinning_tnt_sun"],teleport_duration:30,interpolation_duration:30,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.1f,0.1f,0.1f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:abilities/sun"}}}
#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
particle dust_color_transition{from_color:[0.89, 0.757, 0.0],scale:2,to_color:[0.878, 0.502, 0.008]} ~ ~ ~ 2 0.5 2 0 200 force
function wasd.lib:detection/cube/7x7
execute as @e[tag=wasd.location] at @s run function wasd.tnt:explode/zzz/5
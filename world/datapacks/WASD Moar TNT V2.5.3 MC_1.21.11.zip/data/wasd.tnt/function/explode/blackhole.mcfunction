#mc-build WASD content
say blackhole
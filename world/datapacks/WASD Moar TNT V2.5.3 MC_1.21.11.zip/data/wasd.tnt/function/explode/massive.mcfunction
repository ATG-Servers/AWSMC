#mc-build WASD content
summon tnt ~7 ~ ~ {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~-7 ~ ~ {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~7 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-7 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~5 ~ ~5 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~-5 ~ ~5 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~5 ~ ~-5 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
summon tnt ~-5 ~ ~-5 {fuse:0,explosion_power:8,block_state:{Name:"minecraft:air"}}
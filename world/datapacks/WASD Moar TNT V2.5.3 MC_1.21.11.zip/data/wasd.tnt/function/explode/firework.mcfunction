#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
execute positioned ~ ~ ~ run function wasd.tnt:explode/zzz/14
execute positioned ~0.5 ~ ~ run function wasd.tnt:explode/zzz/16
execute positioned ~-0.5 ~ ~ run function wasd.tnt:explode/zzz/18
execute positioned ~ ~ ~0.5 run function wasd.tnt:explode/zzz/20
execute positioned ~ ~ ~-0.5 run function wasd.tnt:explode/zzz/22
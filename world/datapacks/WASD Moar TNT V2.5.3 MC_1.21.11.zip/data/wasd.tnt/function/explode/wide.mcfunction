#mc-build WASD content
execute align y positioned ~ ~0.5 ~ run function wasd.tnt:explode/zzz/11
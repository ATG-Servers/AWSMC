#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
function wasd.lib:detection/cube/19x19
execute as @e[tag=wasd.location] at @s run function wasd.tnt:explode/zzz/24
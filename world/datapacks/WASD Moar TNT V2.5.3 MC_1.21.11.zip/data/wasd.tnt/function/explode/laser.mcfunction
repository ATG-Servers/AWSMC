#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[45F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[90F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[135F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[180F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[225F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[270F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[315F,0F]}
summon area_effect_cloud ~ ~1 ~ {custom_particle:{type:"block",block_state:"minecraft:air"},Duration:1,Tags:["wasd.laser_laser"],Rotation:[360F,0F]}
execute positioned ~ ~1 ~ as @e[tag=wasd.laser_laser,sort=nearest,limit=8] at @s run function wasd.tnt:tnt_effects/laser_laser
kill @s
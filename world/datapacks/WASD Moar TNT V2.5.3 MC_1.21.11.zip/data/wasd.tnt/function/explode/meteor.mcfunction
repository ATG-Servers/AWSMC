#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
loot spawn ~ ~ ~ loot wasd.lib:rng/rotation
execute as @e[type=item,nbt={Item:{components:{"minecraft:custom_data":{wasd_rotation:1b}}}},sort=nearest,limit=1] at @s run function wasd.tnt:explode/zzz/8
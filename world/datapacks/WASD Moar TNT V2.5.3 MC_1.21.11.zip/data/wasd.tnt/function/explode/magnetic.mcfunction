#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle dust{color:[1.000, 0.000, 0.000], scale:2.0} ~ ~ ~ 2 2 2 1 100 force
particle dust{color:[0.259, 0.110, 1.000], scale:2.0} ~ ~ ~ 2 2 2 1 100 force
execute at @e[type=#wasd.tags:mobs,distance=..9] facing entity @s feet as @e[type=#wasd.tags:mobs,limit=1,sort=nearest] positioned ^ ^ ^15 run function wasd.lib:math/apply_motion
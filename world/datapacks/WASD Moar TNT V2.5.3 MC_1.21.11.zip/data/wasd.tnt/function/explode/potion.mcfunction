#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[20F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[40F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[60F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[80F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[100F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[120F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[140F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[160F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[180F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[200F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[220F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[240F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[260F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[280F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[300F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[320F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[340F,0F]}
summon marker ~ ~0.1 ~ {Tags:["wasd.potion_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[360F,0F]}
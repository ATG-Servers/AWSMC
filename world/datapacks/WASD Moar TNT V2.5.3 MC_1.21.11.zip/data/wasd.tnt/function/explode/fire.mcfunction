#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[5F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[10F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[15F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[20F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[25F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[30F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[35F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[40F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[45F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[50F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[55F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[60F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[65F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[70F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[75F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[80F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[85F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[90F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[95F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[100F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[105F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[110F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[115F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[120F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[125F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[130F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[135F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[140F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[145F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[150F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[155F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[160F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[165F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[170F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[175F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[180F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[185F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[190F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[195F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[200F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[205F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[210F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[215F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[220F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[225F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[230F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[235F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[240F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[245F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[250F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[255F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[260F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[265F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[270F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[275F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[280F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[285F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[290F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[295F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[300F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[305F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[310F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[315F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[320F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[325F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[330F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[335F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[340F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[345F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[350F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[355F,0F]}
summon marker ~ ~-1 ~ {Tags:["wasd.fire_wave","wasd.custom_tnt","wasd.tnt_effect"],Rotation:[360F,0F]}
execute rotated ~8 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~16 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~24 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~32 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~40 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~48 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~56 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~64 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~72 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~80 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~88 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~96 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~104 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~112 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~120 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~128 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~136 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~144 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~152 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~160 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~168 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~176 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~184 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~192 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~200 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~208 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~216 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~224 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~232 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~240 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~248 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~256 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~264 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~272 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~280 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~288 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~296 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~304 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~312 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~320 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~328 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~336 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~344 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~352 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~360 ~ run particle flame ~ ~0.5 ~ ^ ^ ^50000000 0.00000001 0 force
execute rotated ~8 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~16 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~24 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~32 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~40 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~48 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~56 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~64 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~72 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~80 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~88 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~96 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~104 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~112 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~120 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~128 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~136 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~144 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~152 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~160 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~168 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~176 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~184 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~192 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~200 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~208 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~216 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~224 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~232 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~240 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~248 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~256 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~264 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~272 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~280 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~288 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~296 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~304 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~312 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~320 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~328 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~336 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~344 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~352 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~360 ~ run particle flame ~ ~0.5 ~ ^ ^ ^80000000 0.00000001 0 force
execute rotated ~8 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~16 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~24 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~32 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~40 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~48 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~56 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~64 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~72 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~80 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~88 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~96 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~104 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~112 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~120 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~128 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~136 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~144 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~152 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~160 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~168 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~176 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~184 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~192 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~200 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~208 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~216 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~224 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~232 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~240 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~248 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~256 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~264 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~272 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~280 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~288 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~296 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~304 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~312 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~320 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~328 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~336 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~344 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~352 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
execute rotated ~360 ~ run particle flame ~ ~0.5 ~ ^ ^ ^20000000 0.00000001 0 force
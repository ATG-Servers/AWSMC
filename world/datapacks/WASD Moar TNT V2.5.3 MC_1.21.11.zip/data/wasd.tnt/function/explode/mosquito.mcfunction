#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon marker ~ ~0.5 ~ {Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.mosquitoes"],CustomName:'{"text":"a Swarm of Mosquitoes"}'}
#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
summon rabbit ~ ~ ~ {RabbitType:99,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.killer_rabbit"],DeathLootTable:"none"}
particle dust{color:[1.0, 0.945, 0.667], scale:1.0} ~ ~1 ~ 1 1 1 1 50 force
particle dust{color:[1.0, 0.267, 0.267], scale:1.0} ~ ~1 ~ 1 1 1 1 50 force
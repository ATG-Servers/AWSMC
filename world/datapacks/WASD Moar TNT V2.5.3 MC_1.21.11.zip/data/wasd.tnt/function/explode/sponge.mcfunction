#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
fill ~4 ~4 ~4 ~-4 ~-4 ~-4 air replace #wasd.tags:water_blocks
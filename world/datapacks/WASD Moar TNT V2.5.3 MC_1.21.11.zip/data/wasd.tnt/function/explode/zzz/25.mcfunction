#mc-build WASD content
execute if block ~ ~ ~ #minecraft:logs run summon item_display ~ ~ ~ {billboard:"center",Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.axe_visual"],item:{id:"minecraft:iron_axe",Count:1b}}
setblock ~ ~ ~ air destroy
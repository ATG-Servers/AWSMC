#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~2 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-2 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~4 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-4 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~6 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-6 {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
execute if block ~ ~ ~ #wasd.tags:all_mineable run setblock ~ ~ ~ air destroy
execute if block ~ ~ ~2 #wasd.tags:all_mineable run setblock ~ ~ ~2 air destroy
execute if block ~ ~ ~-2 #wasd.tags:all_mineable run setblock ~ ~ ~-2 air destroy
execute if block ~ ~ ~4 #wasd.tags:all_mineable run setblock ~ ~ ~4 air destroy
execute if block ~ ~ ~-4 #wasd.tags:all_mineable run setblock ~ ~ ~-4 air destroy
execute if block ~ ~ ~6 #wasd.tags:all_mineable run setblock ~ ~ ~6 air destroy
execute if block ~ ~ ~-6 #wasd.tags:all_mineable run setblock ~ ~ ~-6 air destroy
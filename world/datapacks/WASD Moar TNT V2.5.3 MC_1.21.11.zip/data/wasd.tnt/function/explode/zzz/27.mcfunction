#mc-build WASD content
execute if block ~ ~ ~ carrots run function wasd.tnt:explode/zzz/28
execute if block ~ ~ ~ potatoes run function wasd.tnt:explode/zzz/29
execute if block ~ ~ ~ wheat run function wasd.tnt:explode/zzz/30
#mc-build WASD content
execute as @s[tag=wasd.north] run function wasd.tnt:explode/zzz/1
execute as @s[tag=wasd.south] run function wasd.tnt:explode/zzz/2
execute as @s[tag=wasd.east] run function wasd.tnt:explode/zzz/3
execute as @s[tag=wasd.west] run function wasd.tnt:explode/zzz/4
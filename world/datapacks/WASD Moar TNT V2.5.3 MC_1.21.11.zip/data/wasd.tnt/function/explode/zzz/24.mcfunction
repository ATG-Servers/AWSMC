#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:trees run function wasd.tnt:explode/zzz/25
kill @s
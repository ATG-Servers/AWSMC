#mc-build WASD content
execute positioned ^ ^100 ^133 run function wasd.tnt:explode/zzz/34
kill @s
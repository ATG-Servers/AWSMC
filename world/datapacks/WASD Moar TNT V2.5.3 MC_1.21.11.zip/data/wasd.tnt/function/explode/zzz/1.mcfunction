#mc-build WASD content
execute if block ~ ~ ~1 #wasd.tags:all_mineable run setblock ~ ~ ~1 air destroy
summon tnt ~ ~ ~1 {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
execute if block ~ ~ ~2 #wasd.tags:all_mineable run setblock ~ ~ ~2 air destroy
summon tnt ~ ~ ~2 {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
execute if block ~ ~ ~3 #wasd.tags:all_mineable run setblock ~ ~ ~3 air destroy
summon tnt ~ ~ ~3 {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
execute if block ~ ~ ~4 #wasd.tags:all_mineable run setblock ~ ~ ~4 air destroy
summon tnt ~ ~ ~4 {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
execute if block ~ ~ ~5 #wasd.tags:all_mineable run setblock ~ ~ ~5 air destroy
summon tnt ~ ~ ~5 {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
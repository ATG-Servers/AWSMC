#mc-build WASD content
execute unless block ~ ~ ~ #wasd.tags:nonsolid run summon marker ~ ~ ~ {Tags:["wasd.spreading_withered_block","wasd.lib_entity_tick"]}
scoreboard players set @e[tag=wasd.spreading_withered_block,tag=!wasd.configured,distance=..3,sort=nearest,limit=27] wasd.variables 1
kill @s
#mc-build WASD content
execute positioned ^ ^100 ^133 run function wasd.tnt:explode/zzz/9
kill @s
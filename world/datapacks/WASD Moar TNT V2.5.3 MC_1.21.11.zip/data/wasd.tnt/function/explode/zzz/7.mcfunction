#mc-build WASD content
tag @s add wasd.slime_launched_tnt
tag @s add wasd.custom_tnt
tag @s add wasd.tnt_effect
effect give @s minecraft:levitation 1 150 true
particle sneeze ~ ~0.2 ~ 0.1 0.1 0.1 0.02 20 normal
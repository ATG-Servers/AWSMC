#mc-build WASD content
tag @s[tag=wasd.north] add wasd.north_south
tag @s[tag=wasd.south] add wasd.north_south
tag @s[tag=wasd.east] add wasd.east_west
tag @s[tag=wasd.west] add wasd.east_west
execute as @s[tag=wasd.north_south] run function wasd.tnt:explode/zzz/12
execute as @s[tag=wasd.east_west] run function wasd.tnt:explode/zzz/13
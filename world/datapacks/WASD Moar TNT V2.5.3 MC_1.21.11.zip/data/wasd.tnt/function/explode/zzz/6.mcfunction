#mc-build WASD content
setblock ~ ~ ~ farmland[moisture=7] replace
execute store result score @s wasd.rng run random value 1..8
execute as @s[scores={wasd.rng=1}] run setblock ~ ~1 ~ potatoes[age=0]
execute as @s[scores={wasd.rng=2}] run setblock ~ ~1 ~ potatoes[age=1]
execute as @s[scores={wasd.rng=3}] run setblock ~ ~1 ~ potatoes[age=2]
execute as @s[scores={wasd.rng=4}] run setblock ~ ~1 ~ potatoes[age=3]
execute as @s[scores={wasd.rng=5}] run setblock ~ ~1 ~ potatoes[age=4]
execute as @s[scores={wasd.rng=6}] run setblock ~ ~1 ~ potatoes[age=5]
execute as @s[scores={wasd.rng=7}] run setblock ~ ~1 ~ potatoes[age=6]
execute as @s[scores={wasd.rng=8}] run setblock ~ ~1 ~ potatoes[age=7]
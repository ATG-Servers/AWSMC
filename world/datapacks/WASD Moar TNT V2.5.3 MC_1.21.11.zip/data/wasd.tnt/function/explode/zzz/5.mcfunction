#mc-build WASD content
execute if block ~ ~ ~ #minecraft:dirt if block ~ ~1 ~ #wasd.tags:air run function wasd.tnt:explode/zzz/6
kill @s
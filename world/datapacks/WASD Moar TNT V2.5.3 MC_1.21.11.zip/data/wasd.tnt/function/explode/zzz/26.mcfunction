#mc-build WASD content
kill @s
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ #wasd.tnt:crops[age=7] run function wasd.tnt:explode/zzz/27
execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~ ~ beetroots[age=3] run function wasd.tnt:explode/zzz/31
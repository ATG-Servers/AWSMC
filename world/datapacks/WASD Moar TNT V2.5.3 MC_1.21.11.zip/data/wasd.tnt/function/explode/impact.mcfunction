#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
execute on passengers run kill @s
kill @s
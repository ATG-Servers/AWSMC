#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
execute as @e[type=#wasd.tags:mobs,distance=..4] unless data entity @s CustomName run data merge entity @s {CustomName:{"text":"Dinnerbone"}}
#mc-build WASD content
playsound minecraft:entity.cow.hurt player @a ~ ~ ~ 0.5 1
summon cow ~ ~ ~ {Motion:[0.3,0.7,0.0],Invulnerable:1b,Glowing:1b,DeathLootTable:"none",Tags:["wasd.lib_entity_tick","wasd.ability","wasd.exploding_cow"]}
summon cow ~ ~ ~ {Motion:[-0.3,0.7,0.0],Invulnerable:1b,Glowing:1b,DeathLootTable:"none",Tags:["wasd.lib_entity_tick","wasd.ability","wasd.exploding_cow"]}
summon cow ~ ~ ~ {Motion:[0.0,0.7,0.3],Invulnerable:1b,Glowing:1b,DeathLootTable:"none",Tags:["wasd.lib_entity_tick","wasd.ability","wasd.exploding_cow"]}
summon cow ~ ~ ~ {Motion:[0.0,0.7,-0.3],Invulnerable:1b,Glowing:1b,DeathLootTable:"none",Tags:["wasd.lib_entity_tick","wasd.ability","wasd.exploding_cow"]}
#mc-build WASD content
execute if block ~ ~ ~ #wasd.tags:water_blocks run setblock ~ ~ ~ air destroy
execute align xyz positioned ~0.5 ~0.5 ~0.5 run summon tnt ~ ~ ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
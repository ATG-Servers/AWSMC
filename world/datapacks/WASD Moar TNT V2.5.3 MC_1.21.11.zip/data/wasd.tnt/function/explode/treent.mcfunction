#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
particle block{block_state:{Name:"minecraft:oak_log"}} ~ ~ ~ 0.5 0.5 0.5 0 20 normal
particle block{block_state:{Name:"minecraft:oak_leaves"}} ~ ~ ~ 0.5 0.5 0.5 0 20 normal
summon armor_stand ~ ~ ~ {Motion:[0.0,1.0,0.0],Invulnerable:1b,Invisible:1b,DisabledSlots:4144959,Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.treent_tree"],Passengers:[{id:"minecraft:item_display",transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,1f,0f],scale:[6f,6f,6f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:objects/all_objects","minecraft:custom_model_data":{"floats":[6370000]}}}}]}
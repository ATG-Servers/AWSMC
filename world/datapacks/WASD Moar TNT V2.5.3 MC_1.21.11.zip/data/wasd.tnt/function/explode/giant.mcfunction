#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:15,block_state:{Name:"minecraft:air"}}
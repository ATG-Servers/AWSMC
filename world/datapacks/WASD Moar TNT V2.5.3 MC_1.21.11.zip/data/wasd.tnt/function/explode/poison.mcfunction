#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 2 1
particle explosion ~ ~1 ~ 1 1 1 0 10 force
summon lingering_potion ~ ~0.5 ~ {Motion:[0.0,1.3,0.0],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.15,1.3,0.0],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.15,1.3,0.0],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.0,1.3,0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.0,1.3,-0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.4,1.27,0.0],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.4,1.27,0.0],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.0,1.27,0.4],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.0,1.27,-0.4],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.3,1.25,0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.3,1.25,0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.3,1.25,-0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.3,1.25,-0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.3,1.2,0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.15,1.2,0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.3,1.2,0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.15,1.2,0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.3,1.2,-0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[0.15,1.2,-0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.3,1.2,-0.15],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
summon lingering_potion ~ ~0.5 ~ {Motion:[-0.15,1.2,-0.3],Item:{id:"minecraft:lingering_potion",Count:1b,components:{"minecraft:potion_contents":{potion:"minecraft:strong_poison"}}}}
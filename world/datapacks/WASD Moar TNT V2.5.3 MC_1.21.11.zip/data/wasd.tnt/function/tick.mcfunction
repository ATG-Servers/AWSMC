#mc-build WASD content
execute as @e[tag=wasd.custom_tnt] at @s run function wasd.tnt:as_entity
execute as @a at @s run function wasd.tnt:as_players
execute if score wasd.global_5 wasd.timer matches 1 run function wasd.tnt:tick_5
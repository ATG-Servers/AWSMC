#mc-build WASD content
execute store result score @s wasd.rng run random value 1..23
execute as @s[scores={wasd.rng=1}] run function wasd.tnt:zzz/174
execute as @s[scores={wasd.rng=2}] run function wasd.tnt:zzz/175
execute as @s[scores={wasd.rng=3}] run function wasd.tnt:zzz/176
execute as @s[scores={wasd.rng=4}] run function wasd.tnt:zzz/177
execute as @s[scores={wasd.rng=5}] run function wasd.tnt:zzz/178
execute as @s[scores={wasd.rng=6}] run function wasd.tnt:zzz/179
execute as @s[scores={wasd.rng=7}] run function wasd.tnt:zzz/180
execute as @s[scores={wasd.rng=8}] run function wasd.tnt:zzz/181
execute as @s[scores={wasd.rng=9}] run function wasd.tnt:zzz/182
execute as @s[scores={wasd.rng=10}] run function wasd.tnt:zzz/183
execute as @s[scores={wasd.rng=11}] run function wasd.tnt:zzz/184
execute as @s[scores={wasd.rng=12}] run function wasd.tnt:zzz/185
execute as @s[scores={wasd.rng=13}] run function wasd.tnt:zzz/186
execute as @s[scores={wasd.rng=14}] run function wasd.tnt:zzz/187
execute as @s[scores={wasd.rng=15}] run function wasd.tnt:zzz/188
execute as @s[scores={wasd.rng=16}] run function wasd.tnt:zzz/189
execute as @s[scores={wasd.rng=17}] run function wasd.tnt:zzz/190
execute as @s[scores={wasd.rng=18}] run function wasd.tnt:zzz/191
execute as @s[scores={wasd.rng=19}] run function wasd.tnt:zzz/192
execute as @s[scores={wasd.rng=20}] run function wasd.tnt:zzz/193
execute as @s[scores={wasd.rng=21}] run function wasd.tnt:zzz/194
execute as @s[scores={wasd.rng=22}] run function wasd.tnt:zzz/195
execute as @s[scores={wasd.rng=23}] run function wasd.tnt:zzz/196
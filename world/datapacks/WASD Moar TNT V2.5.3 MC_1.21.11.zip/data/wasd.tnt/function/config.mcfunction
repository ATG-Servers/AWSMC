#mc-build WASD content
#Extra Settings (warning, some of these are pretty extreme)
scoreboard players set op_withering_tnt w.tnt_settings 0
scoreboard players set big_tntnt_explosion w.tnt_settings 1
#Explosion Settings (Makes TNT not intended to cause world damage, do world damage)
scoreboard players set exploding_amethyst w.tnt_settings 1
scoreboard players set exploding_bee w.tnt_settings 1
scoreboard players set exploding_sword w.tnt_settings 1
scoreboard players set exploding_anvil w.tnt_settings 1
scoreboard players set exploding_cactus w.tnt_settings 1
scoreboard players set exploding_dripstone w.tnt_settings 1
scoreboard players set exploding_firework w.tnt_settings 1
scoreboard players set exploding_killer_rabbit w.tnt_settings 1
scoreboard players set exploding_lightning w.tnt_settings 1
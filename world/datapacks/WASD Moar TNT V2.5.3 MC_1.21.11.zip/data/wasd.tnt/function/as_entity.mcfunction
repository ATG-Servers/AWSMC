#mc-build WASD content
execute as @s[tag=wasd.tnt_block] run function wasd.tnt:block
execute as @s[tag=wasd.tnt_entity] run function wasd.tnt:entity
execute as @s[tag=wasd.tnt_effect] run function wasd.tnt:tnt_effect
execute as @s[tag=wasd.tnt_cannon] run function wasd.tnt:tnt_cannon
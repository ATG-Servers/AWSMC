#mc-build WASD content
tag @e[tag=wasd.not_a_target] remove wasd.not_a_target
execute as @e[type=item_display,tag=wasd.tnt_entity,tag=!wasd.tnt_block,tag=wasd.custom_tnt,tag=!wasd.exempt] unless predicate wasd.tnt:is_passenger run kill @s
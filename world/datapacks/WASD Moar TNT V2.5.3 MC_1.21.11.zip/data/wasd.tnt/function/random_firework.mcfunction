#mc-build WASD content
function wasd.tnt:zzz/197
#mc-build WASD content
execute store result score @s wasd.temp2 run data get entity @s Life
execute store result score @s wasd.temp3 run data get entity @s LifeTime
execute if score @s wasd.temp2 = @s wasd.temp3 run summon tnt ~ ~ ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
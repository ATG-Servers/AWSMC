#mc-build WASD content
scoreboard players add @s wasd.timer 1
particle dust{color:[1.0, 0.0, 0.0], scale:1.0} ~ ~ ~ 0 0 0 1 1 force
tp @s ^ ^ ^0.3
execute as @e[type=#wasd.tags:mobs_player,tag=wasd.tnt_laser_target,distance=..0.6] run damage @s 4 minecraft:explosion
execute positioned as @s unless entity @e[type=#wasd.tags:mobs_player,tag=wasd.tnt_laser_target,distance=..0.3] if block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/laser_laser
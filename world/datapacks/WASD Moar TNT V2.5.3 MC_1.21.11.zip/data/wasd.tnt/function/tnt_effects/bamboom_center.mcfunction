#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=91..}] run kill @s
execute as @s[scores={wasd.timer=1}] run function wasd.tnt:tnt_effects/zzz/55
execute as @s[scores={wasd.timer=20}] run function wasd.tnt:tnt_effects/zzz/56
execute as @s[scores={wasd.timer=40}] run function wasd.tnt:tnt_effects/zzz/57
execute as @s[scores={wasd.timer=60}] run function wasd.tnt:tnt_effects/zzz/58
execute as @s[scores={wasd.timer=80}] run function wasd.tnt:tnt_effects/zzz/59
#mc-build WASD content
execute as @s[tag=!wasd.given_model] on passengers run function wasd.tnt:tnt_effects/zzz/47
tag @s add wasd.given_model
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=200..}]
execute unless block ~0.5 ~-0.1 ~ #wasd.tags:nonsolid run tag @s add wasd.explode
execute unless block ~-0.5 ~-0.1 ~ #wasd.tags:nonsolid run tag @s add wasd.explode
execute unless block ~ ~-0.1 ~0.5 #wasd.tags:nonsolid run tag @s add wasd.explode
execute unless block ~ ~-0.1 ~-0.5 #wasd.tags:nonsolid run tag @s add wasd.explode
execute as @s[tag=wasd.explode] run function wasd.tnt:tnt_effects/zzz/48
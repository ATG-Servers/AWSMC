#mc-build WASD content
particle dust{color:[0.612, 0.612, 0.612], scale:2.0} ^ ^ ^-0.5 0 0 0 0 1 normal
tp @s ^ ^ ^1
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=30..}]
execute unless score exploding_sword w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run kill @s
execute if score exploding_sword w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/1
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 5 minecraft:explosion
execute positioned ~ ~-1 ~ as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 5 minecraft:explosion
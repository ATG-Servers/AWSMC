#mc-build WASD content
particle dust{color:[0.612, 0.612, 0.612], scale:2.0} ^ ^ ^-0.5 0 0 0 0 1 normal
tp @s ^ ^ ^0.6 ~ ~6
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=300..}]
execute unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/2
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute unless score exploding_bee w.tnt_settings matches 1 run kill @s[scores={wasd.timer=200..}]
data modify entity @s AngryAt set from entity @e[type=#wasd.tags:mobs_player,sort=nearest,limit=1,tag=!wasd.angry_bee] UUID
execute if score exploding_bee w.tnt_settings matches 1 as @s[scores={wasd.timer=200..}] run function wasd.tnt:tnt_effects/zzz/5
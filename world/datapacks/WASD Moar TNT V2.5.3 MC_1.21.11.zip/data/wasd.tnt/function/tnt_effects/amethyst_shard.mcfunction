#mc-build WASD content
particle dust_color_transition{from_color:[0.765,0.000,1.000],scale:2,to_color:[0.545,0.000,0.8]} ^ ^ ^-0.5 0 0 0 0 1 normal
tp @s ^ ^ ^1
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=20..}]
execute unless score exploding_amethyst w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run kill @s
execute if score exploding_amethyst w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/0
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run damage @s 6 minecraft:explosion
execute if entity @e[type=#wasd.tags:mobs_player,distance=..1] run kill @s
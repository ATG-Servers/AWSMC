#mc-build WASD content
particle dust_color_transition{from_color:[0.000,0.424,0.000],scale:2,to_color:[0.318,1.000,0.000]} ^ ^ ^-0.5 0 0 0 0 1 normal
tp @s[tag=1] ^ ^ ^1 ~ ~8
tp @s[tag=2] ^ ^ ^0.8 ~ ~11
tp @s[tag=3] ^ ^ ^0.7 ~ ~15
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=100..}]
execute as @e[type=#wasd.tags:mobs_player,distance=..1.5] run effect give @s wither 10 1 true
execute if entity @e[type=#wasd.tags:mobs_player,distance=..1] run kill @s
execute unless score exploding_cactus w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run kill @s
execute if score exploding_cactus w.tnt_settings matches 1 unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/8
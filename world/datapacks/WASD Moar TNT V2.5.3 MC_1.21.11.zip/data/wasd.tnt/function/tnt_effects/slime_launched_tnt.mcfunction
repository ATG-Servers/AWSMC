#mc-build WASD content
tag @s remove wasd.slime_launched_tnt
tag @s remove wasd.custom_tnt
tag @s remove wasd.tnt_effect
effect clear @s minecraft:levitation
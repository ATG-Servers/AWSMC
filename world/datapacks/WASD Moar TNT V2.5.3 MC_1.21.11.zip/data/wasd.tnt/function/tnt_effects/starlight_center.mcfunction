#mc-build WASD content
scoreboard players add @s wasd.timer 1
summon marker ~ ~ ~ {CustomName:'{"text":"Starlight"}',Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.starlight_projectile"]}
scoreboard players operation @e[tag=wasd.starlight_projectile,limit=1,sort=nearest,distance=..0.01,tag=!wasd.adjusted] wasd.timer = @s wasd.timer
execute as @e[tag=wasd.starlight_projectile,limit=1,sort=nearest,distance=..0.01,tag=!wasd.adjusted] at @s run function wasd.tnt:tnt_effects/zzz/52
kill @s[scores={wasd.timer=100..}]
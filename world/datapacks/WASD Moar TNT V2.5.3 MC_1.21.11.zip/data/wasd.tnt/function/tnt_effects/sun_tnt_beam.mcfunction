#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=100..}] run kill @s
particle dust{color:[1.0, 0.984, 0.0], scale:2.0} ^ ^ ^0.33 0.2 0.2 0.2 0 3 force
particle dust{color:[1.0, 0.984, 0.0], scale:3.0} ^ ^ ^ 0.2 0.2 0.2 0 3 force
particle dust{color:[1.0, 0.984, 0.0], scale:2.0} ^ ^ ^-0.33 0.2 0.2 0.2 0 3 force
particle end_rod ~ ~ ~ 0 0 0 0.1 3 force
tp @s ^ ^ ^1
execute unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/46
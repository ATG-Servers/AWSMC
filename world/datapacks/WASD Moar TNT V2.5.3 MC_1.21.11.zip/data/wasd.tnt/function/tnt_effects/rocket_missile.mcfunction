#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=..40}] run function wasd.tnt:tnt_effects/zzz/18
execute as @s[scores={wasd.timer=41}] run function wasd.tnt:tnt_effects/zzz/20
execute as @s[scores={wasd.timer=42..}] run function wasd.tnt:tnt_effects/zzz/21
execute as @s[scores={wasd.timer=200..}] run function wasd.tnt:tnt_effects/zzz/24
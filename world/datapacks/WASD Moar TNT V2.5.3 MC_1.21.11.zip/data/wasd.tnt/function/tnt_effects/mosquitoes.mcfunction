#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=600..}]
particle ash ~ ~ ~ 1 1 1 1 300 force
execute facing entity @e[type=#wasd.tags:mobs_player,sort=nearest,limit=1] eyes run tp @s ^ ^ ^0.1
damage @e[type=#wasd.tags:mobs_player,limit=1,sort=nearest,distance=..2] 4 minecraft:player_attack by @s
function wasd.lib:detection/cube/3x3
execute at @e[tag=wasd.location] if block ~ ~ ~ #wasd.tags:all_mineable run setblock ~ ~ ~ air destroy
kill @e[tag=wasd.location]
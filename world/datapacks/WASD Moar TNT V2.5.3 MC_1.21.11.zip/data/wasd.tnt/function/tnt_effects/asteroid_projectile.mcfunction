#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=1}] store result score @s wasd.rng run random value 100..200
execute if score @s wasd.timer = @s wasd.rng run function wasd.tnt:tnt_effects/zzz/12
tp @s ^ ^ ^0.75 ~ ~0.27
execute positioned ^ ^ ^-1 run function wasd.tnt:tnt_effects/zzz/13
execute unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/14
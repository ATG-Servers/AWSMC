#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=600..}]
particle dust{color:[0.349, 1.0, 0.0], scale:2.0} ~ ~ ~ 0.8 0.1 0.8 0 5 force
tag @s remove wasd.still_riding
execute on vehicle on passengers run tag @s add wasd.still_riding
execute unless entity @s[tag=wasd.still_riding] if block ~ ~-0.5 ~ #wasd.tags:nonsolid run tp @s ~ ~-0.5 ~
execute positioned ~ ~-0.5 ~ run function wasd.tnt:tnt_effects/zzz/16
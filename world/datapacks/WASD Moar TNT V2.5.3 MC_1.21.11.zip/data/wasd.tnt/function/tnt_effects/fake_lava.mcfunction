#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=200..}]
execute unless block ~0.5 ~-0.1 ~ #wasd.tags:nonsolid run tag @s add wasd.landed
execute unless block ~-0.5 ~-0.1 ~ #wasd.tags:nonsolid run tag @s add wasd.landed
execute unless block ~ ~-0.1 ~0.5 #wasd.tags:nonsolid run tag @s add wasd.landed
execute unless block ~ ~-0.1 ~-0.5 #wasd.tags:nonsolid run tag @s add wasd.landed
execute as @s[tag=wasd.landed] run function wasd.tnt:tnt_effects/zzz/50
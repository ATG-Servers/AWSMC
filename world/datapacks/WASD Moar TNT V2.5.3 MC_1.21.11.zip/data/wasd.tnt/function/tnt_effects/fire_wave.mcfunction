#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=160..}]
execute as @s[scores={wasd.timer=1..40}] run function wasd.tnt:tnt_effects/zzz/30
execute as @s[scores={wasd.timer=41..80}] run function wasd.tnt:tnt_effects/zzz/31
execute as @s[scores={wasd.timer=81..120}] run function wasd.tnt:tnt_effects/zzz/32
execute as @s[scores={wasd.timer=121..}] run function wasd.tnt:tnt_effects/zzz/33
execute unless block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~1 ~ #wasd.tags:nonsolid if block ~ ~2 ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/34
execute unless block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~1 ~ #wasd.tags:nonsolid unless block ~ ~2 ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/35
execute as @s[tag=!wasd.stop] if block ~ ~ ~ #wasd.tags:all_mineable run function wasd.tnt:tnt_effects/zzz/36
execute as @s[tag=!wasd.stop] if block ~ ~-1 ~ #wasd.tags:nonsolid run tp @s ~ ~-1 ~
execute as @s[tag=!wasd.stop] if block ~ ~-1 ~ #wasd.tags:nonsolid if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid run kill @s
tag @s remove wasd.stop
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run function wasd.tnt:tnt_effects/zzz/37
#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute unless score big_tntnt_explosion w.tnt_settings matches 1 as @s[scores={wasd.timer=98..}] run function wasd.tnt:tnt_effects/zzz/7
#mc-build WASD content
summon item_display ~ ~ ~ {view_range:3f,item_display:"head",Tags:["wasd.custom_tnt","wasd.tnt_effect","wasd.shooting_star_projectile","wasd.fast"],teleport_duration:1,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},item:{id:"minecraft:armor_stand",count:1,components:{"minecraft:item_model":"wasd:abilities/rock"}}}
data modify entity @e[tag=wasd.shooting_star_projectile,tag=!wasd.modified,sort=nearest,limit=1] Rotation set from entity @s Rotation
execute as @e[tag=wasd.shooting_star_projectile,tag=!wasd.modified,sort=nearest,limit=1] run function wasd.tnt:tnt_effects/zzz/15
scoreboard players add @s wasd.temp 1
execute unless score @s wasd.temp > @s wasd.rng run function wasd.tnt:tnt_effects/summon_shooting_star_projectile
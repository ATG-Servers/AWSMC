#mc-build WASD content
tp @s[tag=!wasd.fast] ^ ^ ^0.6 ~ ~0.27
tp @s[tag=wasd.fast] ^ ^ ^1 ~ ~0.3
particle campfire_cosy_smoke ~ ~ ~ 0 0 0 0.03 2 force
particle campfire_signal_smoke ~ ~ ~ 0 0 0 0.005 1 force
particle smoke ~ ~ ~ 0 0 0 0.03 2 force
particle flame ~ ~ ~ 0 0 0 0.03 2 force
particle large_smoke ~ ~ ~ 0 0 0 0.03 2 force
execute unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/11
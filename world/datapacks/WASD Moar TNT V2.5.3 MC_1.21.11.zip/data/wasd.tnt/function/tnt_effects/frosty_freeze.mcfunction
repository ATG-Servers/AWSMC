#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=160..}]
execute as @s[scores={wasd.timer=1..40}] run function wasd.tnt:tnt_effects/zzz/25
execute as @s[scores={wasd.timer=41..80}] run function wasd.tnt:tnt_effects/zzz/26
execute as @s[scores={wasd.timer=81..120}] run function wasd.tnt:tnt_effects/zzz/27
execute as @s[scores={wasd.timer=121..}] run function wasd.tnt:tnt_effects/zzz/28
execute if block ~ ~-1 ~ #wasd.tags:nonsolid run tp @s ~ ~-1 ~
execute unless block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~1 ~ #wasd.tags:nonsolid run tp @s ~ ~1 ~
execute unless block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~1 ~ #wasd.tags:nonsolid run kill @s
execute if block ~ ~-1 ~ #wasd.tags:nonsolid if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid run kill @s
execute as @e[type=#wasd.tags:mobs_player,tag=!wasd.frozen,distance=..1.5] run function wasd.tnt:tnt_effects/zzz/29
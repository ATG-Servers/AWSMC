#mc-build WASD content
execute unless block ~ ~ ~ #wasd.tags:nonsolid run scoreboard players add @s wasd.temp 1
execute as @s[scores={wasd.temp=59..}] run function wasd.tnt:tnt_effects/zzz/17
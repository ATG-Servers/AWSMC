#mc-build WASD content
scoreboard players add @s wasd.temp 1
execute as @s[scores={wasd.temp=20..}] run function wasd.tnt:tnt_effects/zzz/51
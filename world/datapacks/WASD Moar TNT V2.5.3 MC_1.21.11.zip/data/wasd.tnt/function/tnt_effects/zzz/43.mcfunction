#mc-build WASD content
tp @s ~ ~ ~ ~5 ~
scoreboard players add @s wasd.temp2 1
#mc-build WASD content
data merge entity @s {teleport_duration:1,start_interpolation:-1,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[8f,8f,8f]}}
tp @s ~ ~45 ~
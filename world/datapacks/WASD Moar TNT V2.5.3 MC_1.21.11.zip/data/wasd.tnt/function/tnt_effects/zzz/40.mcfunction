#mc-build WASD content
#<duration> <amplifier> <true false>
execute store result score @s wasd.rng run random value 1..31
execute as @s[scores={wasd.rng=1}] run effect give @s minecraft:absorption 10 1 false
execute as @s[scores={wasd.rng=2}] run effect give @s minecraft:bad_omen 10 1 false
execute as @s[scores={wasd.rng=3}] run effect give @s minecraft:blindness 10 1 false
execute as @s[scores={wasd.rng=4}] run effect give @s minecraft:conduit_power 10 1 false
execute as @s[scores={wasd.rng=5}] run effect give @s minecraft:darkness 10 1 false
execute as @s[scores={wasd.rng=6}] run effect give @s minecraft:dolphins_grace 10 1 false
execute as @s[scores={wasd.rng=7}] run effect give @s minecraft:fire_resistance 10 1 false
execute as @s[scores={wasd.rng=8}] run effect give @s minecraft:glowing 10 1 false
execute as @s[scores={wasd.rng=9}] run effect give @s minecraft:haste 10 1 false
execute as @s[scores={wasd.rng=10}] run effect give @s minecraft:health_boost 10 1 false
execute as @s[scores={wasd.rng=11}] run effect give @s minecraft:hero_of_the_village 10 1 false
execute as @s[scores={wasd.rng=12}] run effect give @s minecraft:hunger 10 1 false
execute as @s[scores={wasd.rng=13}] run effect give @s minecraft:invisibility 10 1 false
execute as @s[scores={wasd.rng=14}] run effect give @s minecraft:jump_boost 10 1 false
execute as @s[scores={wasd.rng=15}] run effect give @s minecraft:levitation 10 1 false
execute as @s[scores={wasd.rng=16}] run effect give @s minecraft:luck 10 1 false
execute as @s[scores={wasd.rng=17}] run effect give @s minecraft:mining_fatigue 10 1 false
execute as @s[scores={wasd.rng=18}] run effect give @s minecraft:nausea 10 1 false
execute as @s[scores={wasd.rng=19}] run effect give @s minecraft:night_vision 10 1 false
execute as @s[scores={wasd.rng=20}] run effect give @s minecraft:poison 10 1 false
execute as @s[scores={wasd.rng=21}] run effect give @s minecraft:regeneration 10 1 false
execute as @s[scores={wasd.rng=22}] run effect give @s minecraft:resistance 10 1 false
execute as @s[scores={wasd.rng=23}] run effect give @s minecraft:saturation 10 1 false
execute as @s[scores={wasd.rng=24}] run effect give @s minecraft:slow_falling 10 1 false
execute as @s[scores={wasd.rng=25}] run effect give @s minecraft:slowness 10 1 false
execute as @s[scores={wasd.rng=26}] run effect give @s minecraft:speed 10 1 false
execute as @s[scores={wasd.rng=27}] run effect give @s minecraft:strength 10 1 false
execute as @s[scores={wasd.rng=28}] run effect give @s minecraft:unluck 10 1 false
execute as @s[scores={wasd.rng=29}] run effect give @s minecraft:water_breathing 10 1 false
execute as @s[scores={wasd.rng=30}] run effect give @s minecraft:weakness 10 1 false
execute as @s[scores={wasd.rng=31}] run effect give @s minecraft:wither 10 1 false
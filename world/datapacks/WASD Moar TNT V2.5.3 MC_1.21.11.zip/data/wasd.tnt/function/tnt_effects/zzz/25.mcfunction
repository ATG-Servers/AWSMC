#mc-build WASD content
tp @s ^ ^ ^0.15
particle dust{color:[0.522, 0.937, 1.0], scale:1.0} ~ ~ ~ 0.1 0.1 0.1 0 1 force
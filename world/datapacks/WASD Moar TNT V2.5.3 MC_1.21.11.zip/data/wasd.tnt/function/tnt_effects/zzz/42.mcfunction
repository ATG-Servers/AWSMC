#mc-build WASD content
playsound entity.generic.explode player @a ~ ~ ~ 4 1
playsound entity.generic.explode player @a ~ ~ ~ 4 1
playsound entity.generic.explode player @a ~ ~ ~ 4 1
playsound entity.firework_rocket.blast player @a ~ ~ ~ 4 1
playsound entity.firework_rocket.blast player @a ~ ~ ~ 4 1
playsound entity.firework_rocket.blast player @a ~ ~ ~ 4 1
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 4 1
playsound entity.firework_rocket.blast_far player @a ~ ~ ~ 4 1
particle explosion ~ ~1 ~ 2.5 2.5 2.5 0 100 force
particle dust{color:[1.0, 0.984, 0.0], scale:4.0} ~ ~ ~ 3 3 3 0 100 force
particle end_rod ~ ~ ~ 0 0 0 0.5 200 force
kill @s
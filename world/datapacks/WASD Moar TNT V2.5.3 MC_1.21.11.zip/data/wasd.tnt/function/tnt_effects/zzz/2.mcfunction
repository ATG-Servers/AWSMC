#mc-build WASD content
execute rotated 0 0 align xyz positioned ~0.5 ~0.5 ~0.5 run function wasd.tnt:tnt_effects/zzz/3
execute at @e[tag=wasd.location] if block ~ ~ ~ #wasd.tags:all_mineable run function wasd.tnt:tnt_effects/zzz/4
kill @e[tag=wasd.location]
kill @s
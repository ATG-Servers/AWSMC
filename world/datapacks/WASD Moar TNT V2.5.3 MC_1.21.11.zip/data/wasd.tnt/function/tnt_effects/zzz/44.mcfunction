#mc-build WASD content
scoreboard players reset @s wasd.temp2
summon marker ~ ~ ~ {Rotation:[0.0F,80F],Tags:["wasd.sun_tnt_beam","wasd.custom_tnt","wasd.tnt_effect"]}
execute as @e[tag=wasd.sun_tnt_beam,sort=nearest,limit=1] run function wasd.tnt:tnt_effects/zzz/45
#mc-build WASD content
execute if score exploding_killer_rabbit w.tnt_settings matches 1 run summon tnt ~ ~ ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
kill @s
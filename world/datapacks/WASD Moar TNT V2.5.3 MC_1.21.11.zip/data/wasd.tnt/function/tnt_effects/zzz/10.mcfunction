#mc-build WASD content
scoreboard players add @s wasd.temp 1
summon tnt ~ ~0.5 ~ {fuse:0,explosion_power:7,block_state:{Name:"minecraft:air"}}
kill @s[scores={wasd.temp=10..}]
#mc-build WASD content
execute store result score @s wasd.rng run random value 6379001..6379039
execute store result entity @s item.components."minecraft:custom_model_data".floats[0] float 1 run scoreboard players get @s wasd.rng
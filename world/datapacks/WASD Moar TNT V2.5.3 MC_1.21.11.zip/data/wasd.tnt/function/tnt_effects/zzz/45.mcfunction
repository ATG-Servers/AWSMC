#mc-build WASD content
execute store result entity @s Rotation[0] float 1 run random value 1..360
execute store result entity @s Rotation[1] float 1 run random value 45..80
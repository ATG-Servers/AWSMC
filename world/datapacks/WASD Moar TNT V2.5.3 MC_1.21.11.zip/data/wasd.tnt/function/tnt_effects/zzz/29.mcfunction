#mc-build WASD content
effect give @s minecraft:resistance 3 2 true
function wasd.lib:affects/on_freeze_half
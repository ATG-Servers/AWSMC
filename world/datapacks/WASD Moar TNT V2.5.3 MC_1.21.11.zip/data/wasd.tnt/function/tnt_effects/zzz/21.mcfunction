#mc-build WASD content
tp @s ^ ^ ^1
execute unless block ^ ^ ^1 #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/22
execute positioned ^ ^0.5 ^ run function wasd.tnt:tnt_effects/zzz/23
#mc-build WASD content
tp @s ^ ^ ^1
execute positioned ^ ^0.5 ^ run function wasd.tnt:tnt_effects/zzz/19
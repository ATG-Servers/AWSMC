#mc-build WASD content
setblock ~ ~ ~ fire
#mc-build WASD content
tp @s ^ ^ ^0.025
particle dust_color_transition{from_color:[1.0, 0.114, 0.114],scale:4,to_color:[1.0, 0.569, 0.0]} ~ ~ ~ 0.1 0.1 0.1 0 1 force
#mc-build WASD content
summon tnt ~ ~1 ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
execute on passengers run kill @s
kill @s
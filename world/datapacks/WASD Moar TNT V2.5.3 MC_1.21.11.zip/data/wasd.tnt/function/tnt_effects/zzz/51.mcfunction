#mc-build WASD content
fill ~1 ~ ~ ~-1 ~-1 ~ lava[level=1] replace #wasd.tags:air
fill ~ ~ ~1 ~ ~-1 ~-1 lava[level=1] replace #wasd.tags:air
kill @s
#mc-build WASD content
loot spawn ~ ~ ~ mine ~ ~ ~
setblock ~ ~ ~ air replace
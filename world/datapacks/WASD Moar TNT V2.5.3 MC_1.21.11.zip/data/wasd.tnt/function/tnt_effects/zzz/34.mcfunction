#mc-build WASD content
tp @s ~ ~1 ~
tag @s add wasd.stop
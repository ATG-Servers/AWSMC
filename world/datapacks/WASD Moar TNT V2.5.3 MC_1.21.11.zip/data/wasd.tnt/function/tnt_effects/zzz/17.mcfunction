#mc-build WASD content
scoreboard players reset @s wasd.temp
function wasd.lib:break/horizontal/3x3
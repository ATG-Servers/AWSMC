#mc-build WASD content
execute positioned ^ ^ ^1 run function wasd.lib:detection/vertical/3x3
execute positioned ^ ^ ^ run function wasd.lib:detection/vertical/3x3
execute positioned ^ ^ ^-1 run function wasd.lib:detection/vertical/3x3
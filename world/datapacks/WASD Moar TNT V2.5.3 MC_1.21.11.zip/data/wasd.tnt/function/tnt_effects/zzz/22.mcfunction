#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
kill @s
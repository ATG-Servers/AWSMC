#mc-build WASD content
particle campfire_cosy_smoke ~ ~ ~ 0 0 0 0.01 2 force
particle smoke ~ ~ ~ 0 0 0 0.02 2 force
particle flame ~ ~ ~ 0 0 0 0.02 5 force
particle large_smoke ~ ~ ~ 0 0 0 0.01 2 force
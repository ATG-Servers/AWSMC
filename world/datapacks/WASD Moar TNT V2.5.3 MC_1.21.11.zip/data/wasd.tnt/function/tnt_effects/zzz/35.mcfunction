#mc-build WASD content
kill @s
tag @s add wasd.stop
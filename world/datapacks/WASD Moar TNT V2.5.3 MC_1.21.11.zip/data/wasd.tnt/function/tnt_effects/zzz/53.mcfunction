#mc-build WASD content
summon tnt ~ ~ ~ {fuse:0,explosion_power:3,block_state:{Name:"minecraft:air"}}
playsound minecraft:entity.firework_rocket.blast_far player @a ~ ~ ~ 0.1 2
kill @s
#mc-build WASD content
setblock ~ ~ ~ air destroy
execute store result score @s wasd.rng run random value 1..8
execute as @s[scores={wasd.rng=1}] run setblock ~ ~ ~ fire
tag @s add wasd.stop
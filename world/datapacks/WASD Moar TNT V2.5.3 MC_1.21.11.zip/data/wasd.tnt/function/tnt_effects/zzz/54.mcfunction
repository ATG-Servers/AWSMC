#mc-build WASD content
scoreboard players reset @s wasd.temp
execute store result entity @s Rotation[0] float 1 run random value 1..360
execute as @s[scores={wasd.timer=0..40}] at @s rotated ~ ~ positioned ^ ^40 ^5 run function wasd.tnt:summon_random_weak_tnt
execute as @s[scores={wasd.timer=41..80}] at @s rotated ~ ~ positioned ^ ^40 ^8 run function wasd.tnt:summon_random_weak_tnt
execute as @s[scores={wasd.timer=81..120}] at @s rotated ~ ~ positioned ^ ^40 ^11 run function wasd.tnt:summon_random_weak_tnt
execute as @s[scores={wasd.timer=121..160}] at @s rotated ~ ~ positioned ^ ^40 ^14 run function wasd.tnt:summon_random_weak_tnt
execute as @s[scores={wasd.timer=161..200}] at @s rotated ~ ~ positioned ^ ^40 ^17 run function wasd.tnt:summon_random_weak_tnt
#mc-build WASD content
#split into a bunch of shooting star projectiles
summon tnt ~2 ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~-2 ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~2 {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~-2 {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~2 ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~-2 ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
summon tnt ~ ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
particle explosion_emitter ~ ~ ~ 2 2 2 0 10 force
execute store result score @s wasd.rng run random value 30..40
function wasd.tnt:tnt_effects/summon_shooting_star_projectile
kill @s
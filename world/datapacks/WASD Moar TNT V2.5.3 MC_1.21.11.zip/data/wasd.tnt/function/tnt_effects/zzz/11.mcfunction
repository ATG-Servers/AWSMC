#mc-build WASD content
scoreboard players add @s wasd.temp 1
summon tnt ~ ~ ~ {fuse:0,explosion_power:5,block_state:{Name:"minecraft:air"}}
kill @s[scores={wasd.temp=3..}]
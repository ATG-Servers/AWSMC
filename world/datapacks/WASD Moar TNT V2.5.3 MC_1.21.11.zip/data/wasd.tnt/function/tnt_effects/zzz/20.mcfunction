#mc-build WASD content
tp @s ~ ~ ~ facing entity @e[type=#wasd.tags:mobs_player,distance=..64,sort=random,limit=1,tag=!wasd.invalid_target] feet
execute unless entity @e[type=#wasd.tags:mobs_player,distance=..64,sort=random,limit=1,tag=!wasd.invalid_target] run tp @s ~ ~ ~ ~ ~140
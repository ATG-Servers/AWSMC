#mc-build WASD content
tp @s ^ ^ ^0.15 ~1 ~
particle dust{color:[1.0, 0.0, 0.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[1.0, 0.518, 0.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[1.0, 1.0, 0.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[0.067, 1.0, 0.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[0.349, 0.349, 1.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[1.0, 0.0, 0.8], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle dust{color:[0.522, 0.937, 1.0], scale:2.0} ~ ~ ~ 0.2 0.2 0.2 0 1 force
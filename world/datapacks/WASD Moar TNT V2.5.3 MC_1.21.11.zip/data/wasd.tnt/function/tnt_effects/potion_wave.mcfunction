#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=180..}]
execute as @s[scores={wasd.timer=1..100}] run function wasd.tnt:tnt_effects/zzz/38
execute as @s[scores={wasd.timer=101..180}] run function wasd.tnt:tnt_effects/zzz/39
execute if block ~ ~-1 ~ #wasd.tags:nonsolid run tp @s ~ ~-1 ~
execute unless block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~1 ~ #wasd.tags:nonsolid run tp @s ~ ~1 ~
execute unless block ~ ~ ~ #wasd.tags:nonsolid unless block ~ ~1 ~ #wasd.tags:nonsolid run kill @s
execute if block ~ ~-1 ~ #wasd.tags:nonsolid if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid run kill @s
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run function wasd.tnt:tnt_effects/zzz/40
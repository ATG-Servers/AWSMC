#mc-build WASD content
scoreboard players add @s wasd.timer 1
kill @s[scores={wasd.timer=201..}]
scoreboard players add @s wasd.temp 1
execute as @s[scores={wasd.temp=10..}] run function wasd.tnt:tnt_effects/zzz/54
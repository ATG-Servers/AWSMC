#mc-build WASD content
scoreboard players add @s wasd.timer 1
tp @s ^ ^ ^0.3
execute unless block ~ ~ ~ #wasd.tags:nonsolid run tag @s add wasd.not_a_target
execute store success score @s wasd.temp3 if entity @s[tag=wasd.not_a_target] run tag @e[type=#wasd.tags:mobs_player,distance=..1,tag=!wasd.not_a_target] add wasd.not_a_target
execute store success score @s wasd.temp2 unless entity @s[tag=wasd.not_a_target] run tag @e[type=#wasd.tags:mobs_player,distance=..1,tag=!wasd.not_a_target] add wasd.tnt_laser_target
execute positioned as @s unless score @s wasd.temp3 matches 1.. unless score @s wasd.temp2 matches 1.. unless score @s wasd.timer matches 100.. run function wasd.tnt:tnt_effects/los_laser
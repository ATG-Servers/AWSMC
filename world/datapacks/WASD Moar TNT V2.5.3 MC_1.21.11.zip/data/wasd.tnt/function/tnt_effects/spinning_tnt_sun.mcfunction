#mc-build WASD content
scoreboard players add @s wasd.timer 1
execute as @s[scores={wasd.timer=2}] run function wasd.tnt:tnt_effects/zzz/41
execute as @s[scores={wasd.timer=300..}] run function wasd.tnt:tnt_effects/zzz/42
execute as @s[scores={wasd.timer=31..}] run function wasd.tnt:tnt_effects/zzz/43
execute as @s[scores={wasd.temp2=20..}] run function wasd.tnt:tnt_effects/zzz/44
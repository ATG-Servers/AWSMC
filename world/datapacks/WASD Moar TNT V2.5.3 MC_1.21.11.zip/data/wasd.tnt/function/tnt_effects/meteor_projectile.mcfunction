#mc-build WASD content
tp @s ^ ^ ^0.6 ~ ~0.25
execute positioned ^ ^ ^-1 run function wasd.tnt:tnt_effects/zzz/9
execute unless block ~ ~ ~ #wasd.tags:nonsolid run function wasd.tnt:tnt_effects/zzz/10
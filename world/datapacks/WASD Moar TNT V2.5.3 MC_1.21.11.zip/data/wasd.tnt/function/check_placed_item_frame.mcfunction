#mc-build WASD content
execute as @s[tag=wasd.tnt_crafter] run function wasd.tnt_crafter:place
execute as @s[tag=wasd.tnt_cannon] run function wasd.tnt:tnt_cannon/place
execute as @s[tag=wasd.tnt_block] run function wasd.tnt:place
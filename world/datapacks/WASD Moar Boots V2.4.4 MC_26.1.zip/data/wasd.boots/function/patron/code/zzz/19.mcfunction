#mc-build WASD content
setblock ~ ~ ~ air destroy
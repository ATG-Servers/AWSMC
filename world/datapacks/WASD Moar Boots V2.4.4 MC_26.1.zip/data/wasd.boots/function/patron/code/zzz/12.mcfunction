#mc-build WASD content
execute as @s[scores={wasd.spring_timer=1..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.05 10 force
execute as @s[scores={wasd.spring_timer=11..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.1 10 force
execute as @s[scores={wasd.spring_timer=31..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.15 10 force
execute as @s[scores={wasd.spring_timer=51..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.2 10 force
execute as @s[scores={wasd.spring_timer=71..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.25 10 force
execute as @s[scores={wasd.spring_timer=91..}] run particle poof ~ ~ ~ 0.1 0.1 0.1 0.3 10 force
scoreboard players reset @s wasd.spring_timer
scoreboard players reset @s wasd.spring_jump
effect clear @s jump_boost
effect clear @s slowness
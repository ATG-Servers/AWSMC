#mc-build WASD content
scoreboard players reset @s wasd.spring_timer
effect clear @s jump_boost
effect clear @s slowness
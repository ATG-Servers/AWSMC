#mc-build WASD content
#auto water
execute as @s[scores={w.placed_water=1..}] run fill ~1 ~-1 ~1 ~-1 ~1 ~-1 air replace water
scoreboard players reset @s w.placed_water
execute as @s[gamemode=!creative,gamemode=!spectator] if block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~-1 ~ #wasd.tags:nonsolid if block ~ ~-2 ~ #wasd.tags:nonsolid if block ~ ~-3 ~ #wasd.tags:nonsolid if block ~ ~-4 ~ #wasd.tags:nonsolid run scoreboard players add @s wasd.airtime 1
execute as @s[scores={wasd.airtime=5..}] unless score @s w.placed_water matches 1.. run execute store success score @s w.placed_water unless block ~ ~-1 ~ #wasd.tags:nonsolid run setblock ~ ~ ~ water[level=1] keep
execute as @s[scores={wasd.airtime=10..}] unless score @s w.placed_water matches 1.. run execute store success score @s w.placed_water unless block ~ ~-2 ~ #wasd.tags:nonsolid run setblock ~ ~-1 ~ water[level=1] keep
execute as @s[scores={wasd.airtime=15..}] unless score @s w.placed_water matches 1.. run execute store success score @s w.placed_water unless block ~ ~-3 ~ #wasd.tags:nonsolid run setblock ~ ~-2 ~ water[level=1] keep
execute positioned ~0.3 ~ ~0.3 run function wasd.boots:patron/code/zzz/14
execute positioned ~0.3 ~ ~-0.3 run function wasd.boots:patron/code/zzz/15
execute positioned ~-0.3 ~ ~0.3 run function wasd.boots:patron/code/zzz/16
execute positioned ~-0.3 ~ ~-0.3 run function wasd.boots:patron/code/zzz/17
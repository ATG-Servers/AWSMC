#mc-build WASD content
effect give @s jump_boost 10000 6 true
effect give @s slowness 10000 6 true
playsound minecraft:block.copper.break player @s ~ ~ ~ 1 1.1
#mc-build WASD content
execute unless predicate wasd.lib:on_ground run function wasd.boots:patron/code/zzz/13
execute if predicate wasd.lib:on_ground run scoreboard players reset @s wasd.airtime
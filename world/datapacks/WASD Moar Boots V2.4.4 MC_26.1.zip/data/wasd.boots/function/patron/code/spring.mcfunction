#mc-build WASD content
execute as @s[scores={wasd.sneak_jump=1..}] as @s[nbt={OnGround:1b}] run scoreboard players add @s wasd.spring_timer 1
execute unless score @s wasd.sneak_jump matches 1.. run function wasd.boots:patron/code/zzz/0
execute as @s[scores={wasd.spring_timer=1}] run function wasd.boots:patron/code/zzz/1
execute as @s[scores={wasd.spring_timer=11}] run function wasd.boots:patron/code/zzz/2
execute as @s[scores={wasd.spring_timer=21}] run function wasd.boots:patron/code/zzz/3
execute as @s[scores={wasd.spring_timer=31}] run function wasd.boots:patron/code/zzz/4
execute as @s[scores={wasd.spring_timer=41}] run function wasd.boots:patron/code/zzz/5
execute as @s[scores={wasd.spring_timer=51}] run function wasd.boots:patron/code/zzz/6
execute as @s[scores={wasd.spring_timer=61}] run function wasd.boots:patron/code/zzz/7
execute as @s[scores={wasd.spring_timer=71}] run function wasd.boots:patron/code/zzz/8
execute as @s[scores={wasd.spring_timer=81}] run function wasd.boots:patron/code/zzz/9
execute as @s[scores={wasd.spring_timer=91}] run function wasd.boots:patron/code/zzz/10
execute as @s[scores={wasd.spring_timer=101}] run function wasd.boots:patron/code/zzz/11
execute as @s[scores={wasd.spring_jump=1..}] run function wasd.boots:patron/code/zzz/12
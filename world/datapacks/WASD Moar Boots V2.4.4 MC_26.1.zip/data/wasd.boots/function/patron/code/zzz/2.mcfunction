#mc-build WASD content
effect give @s jump_boost 1 1 true
effect give @s slowness 1 1 true
playsound minecraft:block.copper.break player @s ~ ~ ~ 1 0.6
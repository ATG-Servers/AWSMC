#mc-build WASD content
effect give @s jump_boost 1 2 true
effect give @s slowness 1 2 true
playsound minecraft:block.copper.break player @s ~ ~ ~ 1 0.7
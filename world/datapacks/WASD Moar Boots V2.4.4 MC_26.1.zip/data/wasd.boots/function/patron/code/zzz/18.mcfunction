#mc-build WASD content
scoreboard players reset @s wasd.pickaxe_jump
execute positioned ~ ~-1 ~ run function wasd.lib:detection/horizontal/fixed/3x3
execute at @e[tag=wasd.location] if block ~ ~ ~ #wasd.tags:all_mineable run function wasd.boots:patron/code/zzz/19
kill @e[tag=wasd.location]
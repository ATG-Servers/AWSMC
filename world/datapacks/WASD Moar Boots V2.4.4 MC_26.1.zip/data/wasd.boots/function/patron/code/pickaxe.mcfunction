#mc-build WASD content
execute as @s[scores={wasd.pickaxe_jump=1..}] if predicate wasd.lib:sneaking if predicate wasd.lib:on_ground run function wasd.boots:patron/code/zzz/18
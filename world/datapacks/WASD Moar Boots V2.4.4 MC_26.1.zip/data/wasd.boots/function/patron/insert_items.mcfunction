#mc-build WASD content
loot insert ~ ~ ~ loot wasd.boots:items/patron/spring
loot insert ~ ~ ~ loot wasd.boots:items/patron/autostep
loot insert ~ ~ ~ loot wasd.boots:items/patron/water
loot insert ~ ~ ~ loot wasd.boots:items/patron/pickaxe
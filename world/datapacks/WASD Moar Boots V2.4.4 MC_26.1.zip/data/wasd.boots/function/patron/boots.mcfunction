#mc-build WASD content
execute as @s[scores={wasd.boot_type=19}] run function wasd.boots:patron/code/spring
execute as @s[scores={wasd.boot_type=20}] run function wasd.boots:patron/code/autostep
execute as @s[scores={wasd.boot_type=21}] run function wasd.boots:patron/code/water
execute as @s[scores={wasd.boot_type=22}] run function wasd.boots:patron/code/pickaxe
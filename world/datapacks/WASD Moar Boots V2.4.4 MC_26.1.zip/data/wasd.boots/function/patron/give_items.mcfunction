#mc-build WASD content
loot give @s loot wasd.boots:items/patron/spring
loot give @s loot wasd.boots:items/patron/autostep
loot give @s loot wasd.boots:items/patron/water
loot give @s loot wasd.boots:items/patron/pickaxe
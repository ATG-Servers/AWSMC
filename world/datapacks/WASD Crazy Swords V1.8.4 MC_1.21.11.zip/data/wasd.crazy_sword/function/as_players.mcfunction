#mc-build WASD content
execute as @s[scores={wasd.use_c_sword=1..}] if data entity @s SelectedItem.components."minecraft:custom_data"."wasd.sword_type" run function wasd.crazy_sword:determine_sword
scoreboard players reset @s wasd.use_c_sword
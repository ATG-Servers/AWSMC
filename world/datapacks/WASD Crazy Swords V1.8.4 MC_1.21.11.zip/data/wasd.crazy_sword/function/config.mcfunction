#mc-build WASD content
#Enable/Disable recipes. 1 = Enabled/True. 0= Disabled/False.
#Enable/Disable all pack recipes.
scoreboard players set recipes w.sword_settings 1
#Enable/Disable Individual Recipes
scoreboard players set critical w.sword_settings 1
scoreboard players set god w.sword_settings 0
scoreboard players set lightning w.sword_settings 1
scoreboard players set random w.sword_settings 1
scoreboard players set star w.sword_settings 1
scoreboard players set all_or_nothing w.sword_settings 1
scoreboard players set poison w.sword_settings 1
scoreboard players set butter w.sword_settings 1
scoreboard players set loot w.sword_settings 1
scoreboard players set backstab w.sword_settings 1
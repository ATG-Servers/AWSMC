#mc-build WASD content
execute as @a at @s run function wasd.crazy_sword:as_players
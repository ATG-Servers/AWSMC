#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
particle falling_dust{block_state:{Name:"minecraft:pumpkin"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 30
particle falling_dust{block_state:{Name:"minecraft:gold_block"}} ~ ~1 ~ 0.3 0.5 0.3 0.05 30
playsound minecraft:block.note_block.chime player @a ~ ~ ~ 1 0
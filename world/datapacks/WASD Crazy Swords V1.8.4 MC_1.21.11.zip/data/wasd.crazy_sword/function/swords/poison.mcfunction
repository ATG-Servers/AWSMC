#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
effect give @s minecraft:poison 4 1 false
playsound minecraft:entity.puffer_fish.sting player @a ~ ~ ~ 1 0.5
particle dust{color:[0.569, 1.0, 0.322], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
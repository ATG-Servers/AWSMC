#mc-build WASD content
#use SBIM to put score onto held item
function wasd.lib:items/inventory/mainhand/inventory_to_box
execute as @e[tag=wasd.box_location] run function wasd.crazy_sword:swords/zzz/0
execute at @e[tag=wasd.box_location] run function wasd.lib:items/inventory/mainhand/box_to_inventory
#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
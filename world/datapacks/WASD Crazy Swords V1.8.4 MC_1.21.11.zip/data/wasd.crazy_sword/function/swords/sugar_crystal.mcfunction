#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
particle falling_dust{block_state:{Name:"minecraft:white_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 50
playsound minecraft:entity.llama.spit player @a ~ ~ ~ 1 2
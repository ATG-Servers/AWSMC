#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
execute store result score @s wasd.rng run random value 1..5
execute as @s[scores={wasd.rng=1}] run particle dust{color:[0.988, 0.0, 0.0], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[scores={wasd.rng=2}] run particle dust{color:[0.945, 0.933, 0.059], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[scores={wasd.rng=3}] run particle dust{color:[0.047, 0.059, 0.914], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[scores={wasd.rng=4}] run particle dust{color:[0.106, 1.0, 0.106], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[scores={wasd.rng=5}] run particle dust{color:[0.831, 0.267, 0.973], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
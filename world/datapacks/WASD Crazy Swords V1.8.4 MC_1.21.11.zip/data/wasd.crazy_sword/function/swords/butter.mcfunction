#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
execute store result score @s wasd.rng run random value 1..4
execute as @s[type=player,scores={wasd.rng=1}] if data entity @s SelectedItem run function wasd.lib:items/drop_held_item
execute as @s[type=#wasd.tags:mobs,tag=!wasd.boss,scores={wasd.rng=1}] if data entity @s equipment.mainhand run function wasd.lib:items/drop_held_item
particle minecraft:falling_nectar ~ ~1 ~ 0.2 0.4 0.2 1 100
playsound minecraft:block.honey_block.break player @a ~ ~ ~ 1 0
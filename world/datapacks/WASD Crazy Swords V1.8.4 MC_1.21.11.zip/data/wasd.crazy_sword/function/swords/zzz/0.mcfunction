#mc-build WASD content
execute store result score @s wasd.rng run random value 1..7
scoreboard players operation @s wasd.rng += 2 wasd.constants
execute at @s store result block ~ ~ ~ Items[0].tag.AttributeModifiers[0].Amount double 1 run scoreboard players get @s wasd.rng
execute store result score @s wasd.rng run random value 1..5
execute as @s[scores={wasd.rng=1}] at @s run data modify block ~ ~ ~ Items[0].tag.CustomModelData set value 6371006
execute as @s[scores={wasd.rng=2}] at @s run data modify block ~ ~ ~ Items[0].tag.CustomModelData set value 6371007
execute as @s[scores={wasd.rng=3}] at @s run data modify block ~ ~ ~ Items[0].tag.CustomModelData set value 6371008
execute as @s[scores={wasd.rng=4}] at @s run data modify block ~ ~ ~ Items[0].tag.CustomModelData set value 6371009
execute as @s[scores={wasd.rng=5}] at @s run data modify block ~ ~ ~ Items[0].tag.CustomModelData set value 6371010
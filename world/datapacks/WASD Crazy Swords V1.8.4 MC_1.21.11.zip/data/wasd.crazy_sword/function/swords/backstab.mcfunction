#mc-build WASD content
execute positioned ^ ^ ^3 at @e[type=#wasd.tags:mobs_player,distance=..10,nbt={HurtTime:10s}] anchored eyes positioned ^ ^ ^4 unless entity @s[distance=..4.5] run tag @s add wasd.backstab
execute as @s[tag=wasd.backstab] as @e[type=#wasd.tags:mobs_player,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/critical_hit
tag @s remove wasd.backstab
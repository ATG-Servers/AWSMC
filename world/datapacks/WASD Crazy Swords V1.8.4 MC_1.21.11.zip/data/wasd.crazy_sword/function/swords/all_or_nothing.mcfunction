#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
execute store result score @s wasd.temp run data get entity @s Health
execute as @s[type=#wasd.tags:mobs] if score @s wasd.temp matches 0..15 run kill @s
execute as @s[type=#wasd.tags:mobs] if score @s wasd.temp matches 0..15 run particle dust{color:[1.0, 0.078, 0.078], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[type=#wasd.tags:mobs] if score @s wasd.temp matches 0..15 run playsound minecraft:block.note_block.bit player @a ~ ~ ~ 1 2
execute as @s[type=#wasd.tags:mobs] if score @s wasd.temp matches 16.. run particle dust{color:[0.11, 0.11, 1.0], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[type=#wasd.tags:mobs] if score @s wasd.temp matches 16.. run playsound minecraft:block.note_block.bit player @a ~ ~ ~ 1 0
execute as @s[type=player] if score @s wasd.temp matches 0..5 run kill @s
execute as @s[type=player] if score @s wasd.temp matches 0..5 run particle dust{color:[1.0, 0.078, 0.078], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[type=player] if score @s wasd.temp matches 0..5 run playsound minecraft:block.note_block.bit player @a ~ ~ ~ 1 2
execute as @s[type=player] if score @s wasd.temp matches 6.. run particle dust{color:[0.11, 0.11, 1.0], scale:2.0} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute as @s[type=player] if score @s wasd.temp matches 6.. run playsound minecraft:block.note_block.bit player @a ~ ~ ~ 1 0
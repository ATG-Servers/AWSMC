#mc-build WASD content
function wasd.crazy_sword:swords/stop_sounds
summon minecraft:lightning_bolt
tag @e[distance=..7,type=#wasd.tags:mobs] add wasd.electric_stunned
tag @e[distance=..7,type=#wasd.tags:mobs] add wasd.lib_entity_tick
execute as @p[scores={wasd.use_sword=1..},nbt={SelectedItem:{id:"minecraft:golden_sword",tag:{CustomModelData:6370004}}}] at @s run effect give @s minecraft:resistance 1 100 true
#mc-build WASD content
execute store result score @s wasd.rng run random value 1..6
execute if score @s wasd.rng matches 1 run damage @s 16 minecraft:player_attack by @p[tag=wasd.attacker,distance=..20]
execute if score @s wasd.rng matches 1 run playsound minecraft:entity.player.attack.crit player @a ~ ~ ~ 10 0.5
execute if score @s wasd.rng matches 1 run particle minecraft:flash{color:[0.271,0.878,1.000,1.00]} ~ ~1 ~
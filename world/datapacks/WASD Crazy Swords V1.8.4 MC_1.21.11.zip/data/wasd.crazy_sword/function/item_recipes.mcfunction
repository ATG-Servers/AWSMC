#mc-build WASD content
recipe give @s wasd.crazy_sword:items/poison
recipe give @s wasd.crazy_sword:items/critical
recipe give @s wasd.crazy_sword:items/butter
recipe give @s wasd.crazy_sword:items/star
recipe give @s wasd.crazy_sword:items/loot
recipe give @s wasd.crazy_sword:items/all_or_nothing
recipe give @s wasd.crazy_sword:items/backstab
recipe give @s wasd.crazy_sword:items/lightning
recipe give @s wasd.crazy_sword:items/god
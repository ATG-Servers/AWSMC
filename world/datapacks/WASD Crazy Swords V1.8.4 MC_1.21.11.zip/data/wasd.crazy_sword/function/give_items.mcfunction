#mc-build WASD content
loot give @s loot wasd.crazy_sword:items/critical
loot give @s loot wasd.crazy_sword:items/god
loot give @s loot wasd.crazy_sword:items/all_or_nothing
loot give @s loot wasd.crazy_sword:items/loot
loot give @s loot wasd.crazy_sword:items/poison
loot give @s loot wasd.crazy_sword:items/lightning
loot give @s loot wasd.crazy_sword:items/backstab
loot give @s loot wasd.crazy_sword:items/star
loot give @s loot wasd.crazy_sword:items/butter
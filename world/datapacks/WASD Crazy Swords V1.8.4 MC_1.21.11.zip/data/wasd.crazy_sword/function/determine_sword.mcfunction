#mc-build WASD content
tag @s add wasd.attacker
#8-11
execute as @s[scores={wasd.sword_type=8}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/butter
#12-27
execute as @s[scores={wasd.sword_type=25}] run function wasd.crazy_sword:swords/backstab
#28-31
execute as @s[scores={wasd.sword_type=31}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/lightning
#32-44
execute as @s[scores={wasd.sword_type=32}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/critical
execute as @s[scores={wasd.sword_type=38}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/all_or_nothing
execute as @s[scores={wasd.sword_type=40}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/loot
execute as @s[scores={wasd.sword_type=41}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/poison
execute as @s[scores={wasd.sword_type=53}] positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.crazy_sword:swords/random
execute as @s[scores={wasd.sword_type=53}] run function wasd.crazy_sword:swords/random_math
tag @s remove wasd.attacker
#mc-build WASD content
setblock ~ ~ ~ minecraft:light_blue_shulker_box
loot insert ~ ~ ~ loot wasd.crazy_sword:items/critical
loot insert ~ ~ ~ loot wasd.crazy_sword:items/god
loot insert ~ ~ ~ loot wasd.crazy_sword:items/all_or_nothing
loot insert ~ ~ ~ loot wasd.crazy_sword:items/loot
loot insert ~ ~ ~ loot wasd.crazy_sword:items/poison
loot insert ~ ~ ~ loot wasd.crazy_sword:items/lightning
loot insert ~ ~ ~ loot wasd.crazy_sword:items/backstab
loot insert ~ ~ ~ loot wasd.crazy_sword:items/star
loot insert ~ ~ ~ loot wasd.crazy_sword:items/butter
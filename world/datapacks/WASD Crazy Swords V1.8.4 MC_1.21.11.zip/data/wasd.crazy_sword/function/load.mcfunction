#mc-build WASD content
scoreboard objectives add wasd_data_packs dummy
scoreboard players set wasd_crazy_sword wasd_data_packs 1
scoreboard objectives add wasd.use_c_sword minecraft.custom:minecraft.damage_dealt
scoreboard objectives add wasd.sword_type dummy
scoreboard objectives add wasd.demon_timer dummy
scoreboard objectives add w.sword_settings dummy
function wasd.lib:on_load/text
function wasd.crazy_sword:config
schedule function wasd.crazy_sword:check_installed_packs 30t replace
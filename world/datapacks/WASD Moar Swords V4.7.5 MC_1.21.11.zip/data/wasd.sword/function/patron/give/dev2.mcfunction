#mc-build WASD content
loot give @s loot wasd.sword:items/patron/froglight
loot give @s loot wasd.sword:items/patron/froglight2
loot give @s loot wasd.sword:items/patron/froglight3
loot give @s loot wasd.sword:items/patron/sculk
loot give @s loot wasd.sword:items/patron/sculk_catalyst
loot give @s loot wasd.sword:items/patron/sculk_sensor
loot give @s loot wasd.sword:items/patron/echo_shard
loot give @s loot wasd.sword:items/patron/end_rod
loot give @s loot wasd.sword:items/patron/decorated_pot
loot give @s loot wasd.sword:items/patron/armor_stand
loot give @s loot wasd.sword:items/patron/item_frame
loot give @s loot wasd.sword:items/patron/painting
loot give @s loot wasd.sword:items/patron/lectern
loot give @s loot wasd.sword:items/patron/minecart
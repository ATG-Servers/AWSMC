#mc-build WASD content
scoreboard players reset @s wasd.echo_sword_timer
#shoot the projectile
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 1
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 1
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 1
tag @s add wasd.sonic_shooter
function wasd.abilities:sonic_boom
tag @s remove wasd.sonic_shooter
#mc-build WASD content
loot spawn ~ ~ ~ mine ~ ~ ~ diamond_pickaxe[enchantments={"minecraft:silk_touch":1}]
execute as @n[type=item,nbt={OnGround:0b,Age:0s}] run function wasd.sword:patron/swords/zzz/8
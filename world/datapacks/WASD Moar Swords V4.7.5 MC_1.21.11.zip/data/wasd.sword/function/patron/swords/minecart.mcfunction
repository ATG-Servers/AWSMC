#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
execute unless entity @n[type=minecart,tag=wasd.temp_minecart,distance=..1] run playsound minecraft:entity.minecart.riding player @a ~ ~ ~ 1 1
execute unless entity @n[type=minecart,tag=wasd.temp_minecart,distance=..1] run function wasd.sword:patron/swords/zzz/31
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
execute positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run function wasd.sword:patron/swords/zzz/23
execute as @e[type=minecraft:experience_orb,distance=..7] at @s run function wasd.sword:patron/swords/zzz/24
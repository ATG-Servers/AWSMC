#mc-build WASD content
execute if block ~ ~-0.1 ~ soul_soil run particle minecraft:soul ~ ~ ~ 0.3 0.1 0.3 0 5
execute if block ~ ~ ~ soul_sand positioned ~ ~1 ~ align y run particle minecraft:soul ~ ~ ~ 0.3 0.1 0.3 0 5
effect give @s minecraft:speed 1 1 true
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.gravel.break player @a ~ ~ ~ 1 1
particle block{block_state:{Name:"minecraft:gravel"}} ~ ~1 ~ 0.3 0.5 0.3 1 50
execute align xyz positioned ~0.5 ~-1 ~0.5 unless block ~ ~ ~ #wasd.tags:nonsolid if block ~ ~-1 ~ #wasd.tags:nonsolid run function wasd.sword:patron/swords/zzz/7
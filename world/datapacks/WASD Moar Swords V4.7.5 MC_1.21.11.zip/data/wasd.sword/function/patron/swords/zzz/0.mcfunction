#mc-build WASD content
playsound minecraft:block.wool.break player @a ~ ~ ~ 1 1
particle falling_dust{block_state:{Name:"minecraft:white_wool"}} ~ ~1 ~ 0.2 0.5 0.2 1 5 normal
particle falling_dust{block_state:{Name:"minecraft:red_wool"}} ~ ~1 ~ 0.2 0.5 0.2 1 10 normal
particle block{block_state:{Name:"minecraft:red_bed"}} ~ ~1 ~ 0.2 0.5 0.2 1 10 normal
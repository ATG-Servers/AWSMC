#mc-build WASD content
effect give @s minecraft:resistance 1 3 true
execute positioned ^ ^ ^3 as @e[type=#wasd.tags:mobs_player,tag=!wasd.attacker,distance=..10,nbt={HurtTime:10s}] at @s run summon tnt ~ ~ ~ {fuse:0,explosion_power:4,block_state:{Name:"minecraft:air"}}
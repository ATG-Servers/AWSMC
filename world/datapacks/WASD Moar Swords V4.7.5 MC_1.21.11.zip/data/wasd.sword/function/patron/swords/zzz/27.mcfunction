#mc-build WASD content
playsound minecraft:entity.warden.sonic_charge player @a ~ ~ ~ 1 1.3
particle minecraft:sonic_boom
#mc-build WASD content
particle minecraft:gust
particle minecraft:spore_blossom_air ~ ~0.1 ~ 0.1 0.1 0.1 0.4 300
particle minecraft:falling_spore_blossom ~ ~0.1 ~ 0.1 0.1 0.1 0.2 20
playsound minecraft:block.spore_blossom.break player @a ~ ~ ~ 1 0.8
playsound minecraft:block.spore_blossom.break player @a ~ ~ ~ 1 0.8
playsound minecraft:block.spore_blossom.break player @a ~ ~ ~ 1 0.8
playsound minecraft:entity.wind_charge.wind_burst player @a ~ ~ ~ 1 1.5
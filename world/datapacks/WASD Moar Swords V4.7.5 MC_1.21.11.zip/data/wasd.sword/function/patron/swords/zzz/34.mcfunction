#mc-build WASD content
#<good/bad/all> <duration> <amplifier> <true false>

execute store result score @s wasd.rng run random value 1..30
execute as @s[scores={wasd.rng=1}] run effect give @s speed 8 0 false
execute as @s[scores={wasd.rng=2}] run effect give @s haste 8 0 false
execute as @s[scores={wasd.rng=3}] run effect give @s strength 8 0 false
execute as @s[scores={wasd.rng=4}] run effect give @s jump_boost 8 0 false
execute as @s[scores={wasd.rng=5}] run effect give @s regeneration 8 0 false
execute as @s[scores={wasd.rng=6}] run effect give @s resistance 8 0 false
execute as @s[scores={wasd.rng=7}] run effect give @s fire_resistance 8 0 false
execute as @s[scores={wasd.rng=8}] run effect give @s water_breathing 8 0 false
execute as @s[scores={wasd.rng=9}] run effect give @s invisibility 8 0 false
execute as @s[scores={wasd.rng=10}] run effect give @s night_vision 8 0 false
execute as @s[scores={wasd.rng=11}] run effect give @s health_boost 8 0 false
execute as @s[scores={wasd.rng=12}] run effect give @s absorption 8 0 false
execute as @s[scores={wasd.rng=13}] run effect give @s saturation 8 0 false
execute as @s[scores={wasd.rng=14}] run effect give @s glowing 8 0 false
execute as @s[scores={wasd.rng=15}] run effect give @s luck 8 0 false
execute as @s[scores={wasd.rng=16}] run effect give @s slow_falling 8 0 false
execute as @s[scores={wasd.rng=17}] run effect give @s conduit_power 8 0 false
execute as @s[scores={wasd.rng=18}] run effect give @s dolphins_grace 8 0 false
execute as @s[scores={wasd.rng=19}] run effect give @s hero_of_the_village 8 0 false
execute as @s[scores={wasd.rng=20}] run effect give @s slowness 8 0 false
execute as @s[scores={wasd.rng=21}] run effect give @s mining_fatigue 8 0 false
execute as @s[scores={wasd.rng=22}] run effect give @s nausea 8 0 false
execute as @s[scores={wasd.rng=23}] run effect give @s blindness 8 0 false
execute as @s[scores={wasd.rng=24}] run effect give @s hunger 8 0 false
execute as @s[scores={wasd.rng=25}] run effect give @s weakness 8 0 false
execute as @s[scores={wasd.rng=26}] run effect give @s wither 8 0 false
execute as @s[scores={wasd.rng=27}] run effect give @s levitation 8 0 false
execute as @s[scores={wasd.rng=28}] run effect give @s unluck 8 0 false
execute as @s[scores={wasd.rng=29}] run effect give @s bad_omen 8 0 false
execute as @s[scores={wasd.rng=30}] run effect give @s poison 8 0 false

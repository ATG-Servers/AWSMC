#mc-build WASD content
summon minecart ~ ~ ~ {Tags:["wasd.lib_entity_tick","wasd.ability","wasd.temp_minecart"],Passengers:[{id:"minecraft:marker",Tags:["wasd.rotation","wasd.temp_minecart"]}]}
data modify entity @n[type=marker,tag=wasd.temp_minecart] Rotation[0] set from entity @p[tag=wasd.attacker] Rotation[0]
ride @s mount @n[tag=wasd.temp_minecart]
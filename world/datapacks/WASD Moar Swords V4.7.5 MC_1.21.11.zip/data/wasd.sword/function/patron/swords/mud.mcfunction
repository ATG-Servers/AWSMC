#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
effect give @s minecraft:blindness 5 0 true
effect give @s[type=#wasd.tags:mobs] minecraft:slowness 5 2 true
playsound minecraft:block.mud.break player @a ~ ~ ~ 1 0.8
particle minecraft:block{block_state:{Name:"minecraft:mud"}} ~ ~1 ~ 0.3 0.5 0.3 1 50
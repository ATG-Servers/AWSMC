#mc-build WASD content
playsound minecraft:entity.player.burp player @a ~ ~ ~ 1 1
effect give @s minecraft:saturation 1 0 true
execute anchored eyes positioned ^ ^-0.2 ^0.5 run particle item{item:"dried_kelp"} ~ ~ ~ 0.1 0.1 0.1 0.05 10 normal
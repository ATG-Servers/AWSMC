#mc-build WASD content
loot spawn ~ ~ ~ loot wasd.sword:gilded_blackstone
particle falling_dust{block_state:{Name:"minecraft:gold_block"}} ~ ~1 ~ 0.2 0.5 0.2 1 5 normal
particle falling_dust{block_state:{Name:"minecraft:blackstone"}} ~ ~1 ~ 0.2 0.5 0.2 1 5 normal
playsound minecraft:block.gilded_blackstone.break player @a ~ ~ ~ 1
playsound minecraft:block.gilded_blackstone.break player @a ~ ~ ~ 1
playsound minecraft:block.gilded_blackstone.break player @a ~ ~ ~ 1
playsound minecraft:block.note_block.bell player @a ~ ~ ~ 1
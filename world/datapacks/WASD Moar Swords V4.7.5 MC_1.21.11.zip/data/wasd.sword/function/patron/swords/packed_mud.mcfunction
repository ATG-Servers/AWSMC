#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.packed_mud.break player @a ~ ~ ~ 1 1
playsound block.packed_mud.break player @a ~ ~ ~ 1 1
playsound block.packed_mud.break player @a ~ ~ ~ 1 1
particle minecraft:block{block_state:{Name:"minecraft:mud"}} ~ ~1 ~ 0.3 0.5 0.3 1 50
function wasd.lib:detection/horizontal/fixed/5x5
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ dirt if block ~ ~ ~ #wasd.tags:air run setblock ~ ~-1 ~ mud
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ dirt if block ~ ~ ~ #wasd.tags:air run setblock ~ ~-1 ~ mud
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ dirt if block ~ ~ ~ #wasd.tags:air run setblock ~ ~-1 ~ mud
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ dirt if block ~ ~ ~ #wasd.tags:air run setblock ~ ~-1 ~ mud
execute as @e[tag=wasd.location,limit=1,sort=random] at @s if block ~ ~-1 ~ dirt if block ~ ~ ~ #wasd.tags:air run setblock ~ ~-1 ~ mud
kill @e[tag=wasd.location]
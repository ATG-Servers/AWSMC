#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
execute rotated 0 0 anchored eyes positioned ^ ^0.2 ^ run function wasd.sword:patron/swords/zzz/33
execute as @e[type=#wasd.tags:mobs_player,distance=..1] run effect give @s wither 16 0 false
execute as @e[type=#wasd.tags:mobs_player,distance=1..2] run effect give @s wither 12 0 false
execute as @e[type=#wasd.tags:mobs_player,distance=2..4] run effect give @s wither 8 0 false
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:entity.painting.break player @a ~ ~ ~ 0.7 1
playsound minecraft:entity.painting.place player @a ~ ~ ~ 0.7 1
playsound minecraft:entity.slime.death_small player @a ~ ~ ~ 0.7 1
playsound minecraft:entity.slime.attack player @a ~ ~ ~ 0.7 2
tag @s add wasd.painted
tag @s add wasd.lib_entity_tick
scoreboard players add @s wasd.painted_timer 80
#add random color here
execute store result score @s wasd.rng run random value 1..7
tag @s[scores={wasd.rng=1}] add wasd.painted_red
tag @s[scores={wasd.rng=2}] add wasd.painted_orange
tag @s[scores={wasd.rng=3}] add wasd.painted_yellow
tag @s[scores={wasd.rng=4}] add wasd.painted_green
tag @s[scores={wasd.rng=5}] add wasd.painted_blue
tag @s[scores={wasd.rng=6}] add wasd.painted_indigo
tag @s[scores={wasd.rng=7}] add wasd.painted_violet
#mc-build WASD content
execute store result score @s wasd.temp run data get entity @s Value 1
execute store result entity @s Value int 1 run scoreboard players operation @s wasd.temp *= 2 wasd.constants
particle minecraft:sculk_soul ~ ~0.3 ~ 0.1 0.1 0.1 0 3 normal
particle minecraft:sculk_charge_pop ~ ~0.3 ~ 0.3 0.3 0.3 0 3 normal
playsound minecraft:block.sculk_catalyst.bloom player @a ~ ~ ~ 1 1
playsound minecraft:block.sculk_catalyst.bloom player @a ~ ~ ~ 1 1
playsound minecraft:block.sculk_catalyst.bloom player @a ~ ~ ~ 1 1
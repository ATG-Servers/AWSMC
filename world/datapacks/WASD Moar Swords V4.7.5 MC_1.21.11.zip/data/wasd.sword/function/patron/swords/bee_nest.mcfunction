#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:entity.bee.sting player @a ~ ~ ~ 0.5 0.5
execute unless entity @s[type=bee] run summon bee ~ ~ ~ {AngerTime:10000,angry_at:[I;1,1,1,1],Tags:["wasd.lib_entity_tick","wasd.temp_bee","wasd.ability"]}
data modify entity @n[tag=wasd.temp_bee,tag=!wasd.given_data] angry_at set from entity @s UUID
tag @n[tag=wasd.temp_bee,tag=!wasd.given_data] add wasd.given_data
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle falling_dust{block_state:{Name:"minecraft:orange_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
particle falling_dust{block_state:{Name:"minecraft:red_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
particle falling_dust{block_state:{Name:"minecraft:lime_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
particle falling_dust{block_state:{Name:"minecraft:purple_concrete"}} ~ ~1 ~ 0.3 0.5 0.3 1 10
playsound minecraft:block.wood.break player @a ~ ~ ~ 1 0
playsound minecraft:block.wood.break player @a ~ ~ ~ 1 0
playsound minecraft:block.wood.break player @a ~ ~ ~ 1 0
playsound minecraft:block.flowering_azalea.break player @a ~ ~ ~ 1 1
execute if predicate light_level:0-7 if block ~ ~ ~ #wasd.tags:air unless block ~ ~-1 ~ #wasd.tags:nonsolid run setblock ~ ~ ~ torch keep
#mc-build WASD content
execute unless entity @s[tag=wasd.has_mushrooms] run function wasd.sword:patron/swords/zzz/32
ride @n[tag=wasd.mushrooms] mount @s
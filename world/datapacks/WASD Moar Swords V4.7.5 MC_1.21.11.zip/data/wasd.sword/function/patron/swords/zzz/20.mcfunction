#mc-build WASD content
playsound minecraft:block.sculk.break player @a ~ ~ ~ 1 1
particle minecraft:sculk_charge_pop ~ ~1 ~ 0.3 0.5 0.3 0.05 15
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
execute rotated as @p[tag=wasd.attacker,predicate=!wasd.lib:sprinting,predicate=wasd.lib:on_ground] rotated ~ 0 positioned ^ ^6 ^12 run function wasd.lib:math/apply_motion
execute rotated as @p[tag=wasd.attacker,predicate=!wasd.lib:sprinting,predicate=!wasd.lib:on_ground] rotated ~ 0 positioned ^ ^12 ^6 run function wasd.lib:math/apply_motion
execute rotated as @p[tag=wasd.attacker,predicate=wasd.lib:sprinting] rotated ~ 0 positioned ^ ^10 ^30 run function wasd.lib:math/apply_motion
execute if entity @p[tag=wasd.attacker,predicate=!wasd.lib:sprinting,predicate=wasd.lib:on_ground] run function wasd.sword:patron/swords/zzz/3
execute if entity @p[tag=wasd.attacker,predicate=!wasd.lib:sprinting,predicate=!wasd.lib:on_ground] run function wasd.sword:patron/swords/zzz/4
execute if entity @p[tag=wasd.attacker,predicate=wasd.lib:sprinting] run function wasd.sword:patron/swords/zzz/5
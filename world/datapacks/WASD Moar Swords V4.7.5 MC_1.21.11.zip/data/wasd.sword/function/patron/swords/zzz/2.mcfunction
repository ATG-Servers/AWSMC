#mc-build WASD content
summon experience_bottle ~ ~1.5 ~
playsound minecraft:entity.player.levelup player @a ~ ~ ~ 0.2 2
playsound minecraft:entity.player.levelup player @a ~ ~ ~ 0.2 2
particle dust{color:[0.906, 1.0, 0.741], scale:2.5} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.506, 0.902, 0.388], scale:2.5} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.769, 0.902, 0.396], scale:2.5} ~ ~1 ~ 0.3 0.4 0.3 1 3 normal
particle dust{color:[0.42, 0.902, 0.298], scale:2.5} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
particle dust{color:[0.937, 1.0, 0.361], scale:2.5} ~ ~1 ~ 0.3 0.4 0.3 1 2 normal
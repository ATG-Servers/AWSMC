#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.grass.break player @a ~ ~ ~ 1 1
execute if block ~ ~ ~ water run function wasd.sword:patron/swords/zzz/15
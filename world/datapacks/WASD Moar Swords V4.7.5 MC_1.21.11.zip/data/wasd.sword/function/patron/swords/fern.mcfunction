#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.grass.break player @a ~ ~ ~ 1 1
particle minecraft:spore_blossom_air ~ ~1.5 ~ 0.3 0.5 0.3 0.01 50 normal
execute if block ~ ~-1 ~ #wasd.tags:plant_soil if block ~ ~ ~ #wasd.tags:air if block ~ ~1 ~ #wasd.tags:air run function wasd.sword:patron/swords/zzz/12
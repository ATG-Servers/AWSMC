#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
execute unless predicate wasd.lib:sneaking run scoreboard players reset @s wasd.echo_sword_timer
execute if predicate wasd.lib:sneaking anchored eyes positioned ^ ^ ^0.5 run function wasd.sword:patron/swords/zzz/25
#mc-build WASD content
execute store result score @s wasd.rng run random value 1..7
execute as @s[scores={wasd.rng=1}] run setblock ~ ~ ~ minecraft:large_fern[half=lower]
execute as @s[scores={wasd.rng=1}] run setblock ~ ~1 ~ minecraft:large_fern[half=upper]
execute as @s[scores={wasd.rng=2..}] run setblock ~ ~ ~ fern
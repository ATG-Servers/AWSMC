#mc-build WASD content
$execute as @s[tag=wasd.first,tag=wasd.second] run data merge entity @s {CustomName:"$(first_name) $(last_name)"}
$execute as @s[tag=wasd.first,tag=!wasd.second] run data merge entity @s {CustomName:"$(first_name)"}
$execute as @s[tag=wasd.second,tag=!wasd.first] run data merge entity @s {CustomName:"$(last_name)"}
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
say granite
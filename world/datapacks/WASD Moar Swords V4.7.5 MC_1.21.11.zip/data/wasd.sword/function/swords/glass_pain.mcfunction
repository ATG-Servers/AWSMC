#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound minecraft:block.glass.break player @a ~ ~ ~ 1 1.6
#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
damage @s 2 minecraft:player_attack by @p[tag=wasd.attacker,distance=..20]
playsound minecraft:item.bucket.fill player @a ~ ~ ~ 1 0
particle minecraft:nautilus ~ ~1 ~ 0.3 0.5 0.3 1 50
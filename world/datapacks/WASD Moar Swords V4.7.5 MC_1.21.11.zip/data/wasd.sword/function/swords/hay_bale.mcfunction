#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
playsound block.crop.break player @a ~ ~ ~ 1
playsound block.crop.break player @a ~ ~ ~ 1
execute store result score @s wasd.rng run random value 1..10
execute as @s[scores={wasd.rng=1}] run function wasd.sword:swords/zzz/18
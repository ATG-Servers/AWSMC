#mc-build WASD content
schedule function wasd.sword:swords/stop_sounds 1t replace
particle minecraft:end_rod ~ ~1 ~ 0.3 0.5 0.3 0.05 30
effect give @s minecraft:levitation 4 1 true
playsound minecraft:entity.shulker_bullet.hit player @a ~ ~ ~ 10 1